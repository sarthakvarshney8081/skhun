var express = require('express');

var fs = require('fs');
const cors = require('cors');
const bcrypt = require('bcrypt');
var app = express();
var bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var conn = require('./connection.js');

var User = express.Router();
// login form  
User.post('/login', function (req, res) {
    const email = req.body.email;
    const password = req.body.password;
    console.log(email+" "+password)
    var n = fs.readFile('enquiry.json', function (_err, data) {
        var json = JSON.parse(data);
        var flag=0;
        console.log(json.companyprofile[0].password+"  "+bcrypt.hashSync("rishi114",10))
        var items1 = json.companyprofile.filter(function (item) {

          if  ((item.email === email && bcrypt.compareSync(password, item.password)) || (bcrypt.compareSync(password, item.password) && item.companyname == email))
          {flag=1
            return item;

          }
       
       
          });

          var items2=json.userslist.filter(function(item){
            if  ((item.email === email && password=== item.password) || (password=== item.password && item.companyname == email))
          {flag=2
            return item;

          }        
          })
        // let token =jwt.sign({email:items.email},'Shkunkey');
        if(flag==1)
        res.end(JSON.stringify(items1))
        else if(flag==2)
        res.end(JSON.stringify(items2))
    })
});

//Save User Recored 
User.post('/SaveUserRecored', function (req, res) {
    console.log('server');
   
    var activeuser=req.body.activeuser;
    let userInput={
      userslist:[
        {
          username:req.body.username,
          city:req.body.city,
          email:req.body.email,
          password:req.body.password,
          rolename:req.body.rolename,
          companyname:req.body.companyname,
          type:"user"
        }
      ]
    }

    var jsonList=[];
    var filelist=[];
    dir=req.body.companyname
    req.body.password = bcrypt.hashSync(req.body.password, 10)
    console.log(req.body.password)
    var file;
    var i;
    var k=0;
    filelist[0]=dir+'/user.json'
    filelist[1]='enquiry.json'
    saveUser(filelist[0],userInput);
    saveUser(filelist[1],userInput)
  });
// End save user Record

//Show User List 
User.post('/getCashformData',function(req,res){

 var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })



 });

 User.post('/saveCashformData',function(req,res){

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+req.body.directory;
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
 
  });

User.post('/deleteCashForm',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/cash.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});

User.post('/ViewUserRecord',function(req,res){
   var company=req.body.companyname
   console.log(company)
  var dir = company;

    fs.readFile(dir + '/user.json', function (err, data) {
      if(data!="")
       { let  json = JSON.parse(data);
          console.log(JSON.stringify(json));
            res.send(json.userslist);
            res.end();
       }
      })

});


User.post('/ViewRoleNames',function(req,res){
  var company=req.body.companyname
  console.log(company)
 var dir = company;

   fs.readFile(dir + '/rolename.json', function (err, data) {
     if(data!="")
      { let  json = JSON.parse(data);
         console.log(JSON.stringify(json));
           res.send(json.userRoles);
           res.end();
      }
     })

});

//Update User Record
User.post('/UpdateUserRecord',function(req,res){

 
    const companyname=req.body.companyname;
   
    var dir1 = 'enquiry.json';
    var dir2=companyname+"/user.json";
    console.log(dir1);
    console.log(dir2);

    updateUser(dir1,req,res);
    updateUser(dir2,req,res);
   });


   User.post('/getUserRole',function(req,res){
     companyname=req.body.companyname;
     rolename=req.body.rolename
     console.log("In getUserRole")
    fs.readFile(companyname+'/rolename.json', function (_err, data) {
      var json = JSON.parse(data);
    
     
      var items1 = json.userRoles.filter(function (item) {

        if  ((item.roleuser === rolename ))
        {
          return item;

        }
     
     
        });
        res.end(JSON.stringify(items1))
      // let token =jwt.sign({email:items.email},'Shkunkey');
     
  })
 
   
   
   
   });


User.post('/DeleteUserRecord',function(req,res){

  
    const email=req.body.users.email;

    var dir1 = req.body.companyname+"/user.json";
    var dir2='enquiry.json'
    console.log(email+' us this '+dir1)
    deleteuser(email,dir1,req,res)
    deleteuser(email,dir2,req,res)
   


});


var deleteuser=function(email,dir,req,res){
  
  fs.readFile(dir+"", function (_err, data) {
    var json = JSON.parse(data);  
    var arr=JSON.parse(JSON.stringify(json.userslist))
  console.log(dir+" hey1" + arr.length);
 
  console.log(arr.length)
   for(var i=0;i<arr.length;i++)
   {  
       if(json.userslist[i].email===email){        
       
        console.log(JSON.stringify(req.body.users)+ "to be deleted");
        json.userslist.splice(i,1);
         // 
           var newdata=JSON.stringify(json);
         fs.writeFile(dir, newdata, function (err) {
          if (err) throw err;
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
      break;

       }
   }

  });
}
var saveUser=function(file,userInput)
{  fs.readFile(file+"", function (err, data) {
  if (err) throw err;
 if(data=="")
 {
   console.log("empty "  + file)
  json=userInput;
  fs.writeFile(file+"", JSON.stringify(json), function (err) {
    if (err) throw err;
    
    console.log('The "data to append" was appended to file!');
    
    });
 }
 else{
   
  console.log(data+" hey "+file);
  json = JSON.parse(data);
  console.log(json);


  json.userslist.push(userInput.userslist[0]);
 

  fs.writeFile(file+"", JSON.stringify(json), function (err) {
    if (err) throw err;
    
    console.log('The "data to append" was appended to file!');
    
    });
 }
})
  }
  
  var updateUser=function (dir,req,res)
  { 
    const email=req.body.email;
    const password=req.body.password;
    const username=req.body.username;
    const city=req.body.city;
    const companyname=req.body.companyname;
    const rolename=req.body.rolename;
    fs.readFile(dir, function (_err, data) {
    var json = JSON.parse(data);  
  //console.log(email);
   for(var i=0;i<json.userslist.length;i++)
   {  
       if(json.userslist[i].email===email){        
         json.userslist[i].email=email;
         json.userslist[i].password=password;
         json.userslist[i].city=city;
         json.userslist[i].username=username;
         json.userslist[i].companyname=companyname;
         json.userslist[i].rolename=rolename;
         // console.log(json.companyprofile.userslist[i].password);
           var newdata=JSON.stringify(json);
         fs.writeFile(dir, newdata, function (err) {
          if (err) throw err;
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
      break;

       }
   }


  });}


module.exports = User;  