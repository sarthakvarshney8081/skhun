var mysql=require('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "shkundb"
  
  });
  con.connect(function (err) {
    if (err) {
     console.log("Database Connection Not stablish");
    }else{
      console.log('database connected successfully');
    }

  });

module.exports.connection=con;