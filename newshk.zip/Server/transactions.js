var express = require('express');

var fs = require('fs');
const cors = require('cors');
const bcrypt = require('bcrypt');
var app = express();
var bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var conn = require('./connection.js');
const { RSA_PKCS1_OAEP_PADDING } = require('constants');

var Transaction = express.Router();

//Purchase Series Api


Transaction.post("/modifyLedgerName",function(req,res){
  var json;
 var index=req.body.index
 var newVal=req.body.newval
  var companyName = req.body.companyname
  console.log("companyName is:" + companyName)
  fs.readFile(companyName + '/ledger_master.json', function (err, data) {

    json=JSON.parse(data)
    json.ledgerdata[index].AcName=newVal

    fs.writeFile(companyName + '/ledger_master.json',JSON.stringify(json), function (err) {
      if (err) throw err;
      // console.log('The "data to append" was appended to file!');
      console.log("Updated the data")
      res.send({ 'dooda': "updated" });
      return;})
  })
})

Transaction.post('/savePurchaseSeries', function (req, res) {
  var json;
  var companyName = req.body.companyname
  console.log("companyName is:" + companyName)

  var model = {

    "purchaseseriesdata": [

    ]


  }

  

  fs.readFile(companyName + '/purchaseseries.json', function (err, data) {
    flag2 = 0;
    if (data == "") {
      model.purchaseseriesdata.push(req.body.dataAll);
      model.purchaseseriesdata[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
     
      json.purchaseseriesdata.filter(function (item,index) {
        console.log("\n \n index is "+item.index+" "+req.body.dataAll.index)
        if (item.index === req.body.dataAll.index) {

          flag = 1
          json.purchaseseriesdata[index]=req.body.dataAll
          
        
          for (let i = 0; i < json.purchaseseriesdata.length; i++) {
            json.purchaseseriesdata[i].index = parseInt(i)

          }
          fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
            if (err) throw err;
            // console.log('The "data to append" was appended to file!');
            console.log("Updated the data")
            res.send({ 'dooda': "updated" });
            return;
          });

          flag2 = 1;

        }
        else
          ++index;

      })
      if (flag != 1) { json.purchaseseriesdata.push(req.body.dataAll); }

    }

    if (flag2 == 0) {
      for (let i = 0; i < json.purchaseseriesdata.length; i++) {
        json.purchaseseriesdata[i].index = parseInt(i)
      }
      fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
    if (flag2 == 2) {

      fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
  })
});


Transaction.post('/getPurchaseSeries', function (req, res) {
  var json;

  var companyName = req.body.companyname

  fs.readFile(companyName + '/purchaseseries.json', function (err, data) {
    if (data == "") {
      json = {
        Ahead: "no data"
      };
      console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.requiredIndex)
      if (s != -999) {
        if (s >= 0 && s < json.purchaseseriesdata.length) {

          res.send(
            json.purchaseseriesdata[parseInt(req.body.requiredIndex)]
          )
        }

        else {
          console.log("sending out of bounds cuz req is: " + s)
          res.send(
            {

              Ahead: "out of bounds"
            }
          )
        }
      }

      else {
        res.send(
          json.purchaseseriesdata[json.purchaseseriesdata.length - 1]
        )
      }

    }

  })
});

Transaction.post('/deleteLedger', function (req, res) {
  var json;
  var companyName = req.body.companyname

  fs.readFile(companyName + '/saleseries.json', function (err, data) {
    if (data == "") {

      console.log("sending no data")
      res.send(
        "no data found"
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.indexToDelete)
      console.log("index to delete is: " + s)
      json.ledgerdata.splice(s, 1);
      for (let i = 0; i < json.saleseriesdata.length; i++) {
        json.saleseriesdata[i].index = parseInt(i)

      }

      fs.writeFile(companyName + '/saleseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("Deleted the data")

        res.send("Deleted the data");

      });


    }

  })
});
//PurchaseSeries apis end






//Sale Series Api


Transaction.post("/modifyLedgerName",function(req,res){
  var json;
 var index=req.body.index
 var newVal=req.body.newval
  var companyName = req.body.companyname
  console.log("companyName is:" + companyName)
  fs.readFile(companyName + '/ledger_master.json', function (err, data) {

    json=JSON.parse(data)
    json.ledgerdata[index].AcName=newVal

    fs.writeFile(companyName + '/ledger_master.json',JSON.stringify(json), function (err) {
      if (err) throw err;
      // console.log('The "data to append" was appended to file!');
      console.log("Updated the data")
      res.send({ 'dooda': "updated" });
      return;})
  })
})

Transaction.post('/saveSaleSeries', function (req, res) {
  var json;
  var companyName = req.body.companyname
  var note=req.body.note
  console.log("companyName is:" + companyName)
if(note=="sale")
  {var model = {

    "saleseriesdata": [

    ]


  }


  

  fs.readFile(companyName + '/saleseries.json', function (err, data) {
    flag2 = 0;
    if (data == "") {
      model.saleseriesdata.push(req.body.dataAll);
      model.saleseriesdata[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
     
      json.saleseriesdata.filter(function (item,index) {
        console.log("\n \n index is "+item.index+" "+req.body.dataAll.index)
        if (item.index === req.body.dataAll.index) {

          flag = 1
          json.saleseriesdata[index]=req.body.dataAll
          
        
          for (let i = 0; i < json.saleseriesdata.length; i++) {
            json.saleseriesdata[i].index = parseInt(i)

          }
          fs.writeFile(companyName + '/saleseries.json', JSON.stringify(json), function (err) {
            if (err) throw err;
            // console.log('The "data to append" was appended to file!');
            console.log("Updated the data")
            res.send({ 'dooda': "updated" });
            return;
          });

          flag2 = 1;

        }
        else
          ++index;

      })
      if (flag != 1) { json.saleseriesdata.push(req.body.dataAll); }

    }

    if (flag2 == 0) {
      for (let i = 0; i < json.saleseriesdata.length; i++) {
        json.saleseriesdata[i].index = parseInt(i)
      }
      fs.writeFile(companyName + '/saleseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
    if (flag2 == 2) {

      fs.writeFile(companyName + '/saleseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
  })
}
else if(note=="purchase")
{
  var model = {

    "purchaseseriesdata": [

    ]


  }


  

  fs.readFile(companyName + '/purchaseseries.json', function (err, data) {
    flag2 = 0;
    if (data == "") {
      model.purchaseseriesdata.push(req.body.dataAll);
      model.purchaseseriesdata[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
     
      json.purchaseseriesdata.filter(function (item,index) {
        console.log("\n \n index is "+item.index+" "+req.body.dataAll.index)
        if (item.index === req.body.dataAll.index) {

          flag = 1
          json.purchaseseriesdata[index]=req.body.dataAll
          
        
          for (let i = 0; i < json.purchaseseriesdata.length; i++) {
            json.purchaseseriesdata[i].index = parseInt(i)

          }
          fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
            if (err) throw err;
            // console.log('The "data to append" was appended to file!');
            console.log("Updated the data")
            res.send({ 'dooda': "updated" });
            return;
          });

          flag2 = 1;

        }
        else
          ++index;

      })
      if (flag != 1) { json.purchaseseriesdata.push(req.body.dataAll); }

    }

    if (flag2 == 0) {
      for (let i = 0; i < json.purchaseseriesdata.length; i++) {
        json.purchaseseriesdata[i].index = parseInt(i)
      }
      fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
    if (flag2 == 2) {

      fs.writeFile(companyName + '/purchaseseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
  })

}
});


Transaction.post('/getSaleSeries', function (req, res) {
  var json;

  var companyName = req.body.companyname
  var note=req.body.note
  console.log("my note is "+note)
if(note=="sale")
{
  fs.readFile(companyName + '/saleseries.json', function (err, data) {
    if (data == "") {
      json = {
        Ahead: "no data"
      };
      console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.requiredIndex)
      if (s != -999) {
        if (s >= 0 && s < json.saleseriesdata.length) {

          res.send(
            json.saleseriesdata[parseInt(req.body.requiredIndex)]
          )
        }

        else {
          console.log("sending out of bounds cuz req is: " + s)
          res.send(
            {

              Ahead: "out of bounds"
            }
          )
        }
      }

      else {
        res.send(
          json.saleseriesdata[json.saleseriesdata.length - 1]
        )
      }

    }

  })
}
else if(note=="purchase")
{

  fs.readFile(companyName + '/purchaseseries.json', function (err, data) {
    if (data == "") {
      json = {
        Ahead: "no data"
      };
      console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.requiredIndex)
      if (s != -999) {
        if (s >= 0 && s < json.purchaseseriesdata.length) {

          res.send(
            json.purchaseseriesdata[parseInt(req.body.requiredIndex)]
          )
        }

        else {
          console.log("sending out of bounds cuz req is: " + s)
          res.send(
            {

              Ahead: "out of bounds"
            }
          )
        }
      }

      else {
        res.send(
          json.purchaseseriesdata[json.purchaseseriesdata.length - 1]
        )
      }

    }

  })

}
});

Transaction.post('/deleteLedger', function (req, res) {
  var json;
  var companyName = req.body.companyname

  fs.readFile(companyName + '/saleseries.json', function (err, data) {
    if (data == "") {

      console.log("sending no data")
      res.send(
        "no data found"
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.indexToDelete)
      console.log("index to delete is: " + s)
      json.ledgerdata.splice(s, 1);
      for (let i = 0; i < json.saleseriesdata.length; i++) {
        json.saleseriesdata[i].index = parseInt(i)

      }

      fs.writeFile(companyName + '/saleseries.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        console.log("Deleted the data")

        res.send("Deleted the data");

      });


    }

  })
});
//SaleSeries apis end



//JournalForm Apis

Transaction.post('/saveJOURNAL',function(req,res){

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+req.body.directory;
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
 
  });



  Transaction.post('/deleteJOURNAL',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/jour.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  

  
    
    //Journal Apis end
    
//Material Rec APIs start


Transaction.post('/SaveMaterialRec', function (req, res) {

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"materialrec.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  
        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to Transactionend" was Transactionended to file!');
        res.end("heo");
    });
     })
 
 
});

// Get Material Rec data

Transaction.post('/getMaterialRecData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


Transaction.post('/deleteMaterialRec',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/materialrec.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});



//<Material Rec APis end

//InveMaterialTest APIs start


Transaction.post('/SaveInveMaterialTest', function (req, res) {

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"invematerialtest.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to Transactionend" was Transactionended to file!');
        res.end("heo");
    });
     })
 
 
});

// Get Material issue data

Transaction.post('/getInveMaterialTest', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


Transaction.post('/deleteInveMaterialTest',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/invematerialtest.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});




//InveMaterialTest APis end


//Material Issue APIs start


Transaction.post('/SaveMaterialIssue', function (req, res) {

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"materialissue.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to Transactionend" was Transactionended to file!');
        res.end("heo");
    });
     })
 
 
});

// Get Material issue data

Transaction.post('/getMaterialIssueData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


Transaction.post('/deleteMaterialIssue',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/materialissue.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});




//<Material Issue APis end

//SALEGSTChallan APIs

Transaction.post('/SaveSaleGstChallan', function (req, res) {
  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"salechallan.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  
json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});

// GetSalegst

Transaction.post('/getSaleGstChallanData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


Transaction.post('/deleteSaleGstChallanData',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/salechallan.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});


//SaleGStChallan apis end




// Purchase return apis start



Transaction.post('/SavePurchaseReturn', function (req, res) {
    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+"purchasereturn.json";
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
  json1 = JSON.parse(data);
          
          var length=json1.data.length;
           json1.data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata.data[0][todaydate][0])
                json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata.data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1.data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1.data.splice(finalindex+1,0,newdata.data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1.data.splice(finalindex,0,newdata.data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           }) }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to Transactionend" was Transactionended to file!');
          res.end("heo");
      });
       })
   
   
  });
  
  
  // get purchase return
  
  Transaction.post('/getPurchaseReturnData', function (req, res) {
    var json1,json2;
    const companyname=req.body.companyname;
    const directory=companyname+"/"+req.body.directory;
   
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          console.log(JSON.stringify(json));
          res.send(json1);
          res.end();
       }
      })
  
  
  });
  
  
  
  Transaction.post('/deletePurchaseReturn',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/purchasereturn.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  
  
  
  //Purchase return apis end

//APIs for production chart start



Transaction.post('/SaveProductionChart', function (req, res) {
    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+"productionchart.json";
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
  json1 = JSON.parse(data);
          
          var length=json1.data.length;
           json1.data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata.data[0][todaydate][0])
                json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata.data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1.data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1.data.splice(finalindex+1,0,newdata.data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1.data.splice(finalindex,0,newdata.data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           })
          
        }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
       })
   
   
  });
  
  
  // Get Production chart item(s)
  
  Transaction.post('/getProductionChartData', function (req, res) {
    var json1,json2;
    const companyname=req.body.companyname;
    const directory=companyname+"/"+req.body.directory;
   
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          console.log(JSON.stringify(json));
          res.send(json1);
          res.end();
       }
      })
  
  
  });
  
  // API to delete a production chart db item
  
  Transaction.post('/deleteProductionChart',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/productionchart.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  
  //APIs for production chart end.


//StockTransferApis

Transaction.post('/saveStockTransferData',function(req,res){

    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+req.body.directory;
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
  
  
          json1 = JSON.parse(data);
          
          var length=json1.data.length;
           json1.data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata.data[0][todaydate][0])
                json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata.data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1.data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1.data.splice(finalindex+1,0,newdata.data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1.data.splice(finalindex,0,newdata.data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           })
          
         
        
  
        
        
           
        }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
       })
   
   
   
    });

    
  Transaction.post('/deleteStockTransferData',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/stocktransfer.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  
    
    //Stock transfer Apis end




//SALEGST APIs

Transaction.post('/SaveSaleGst', function (req, res) {
    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+"sale_win.json";
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var heading=req.body.heading
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
         
          
  json1 = JSON.parse(data);
        if(json1[heading]+""!="undefined")
        {  
          var length=json1[heading].data.length;
           json1[heading].data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata[heading].data[0][todaydate][0])
                json1[heading].data[index][todaydate][index2]=newdata[heading].data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata[heading].data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1[heading].data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1[heading].data.splice(finalindex+1,0,newdata[heading].data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1[heading].data.splice(finalindex,0,newdata[heading].data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           })
        }

        else
        {console.log("sad")
          json1[heading]=newdata[heading]} 
          json2=JSON.stringify(json1)
        }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
       })
   
   
  });
  
  // GetSalegst
  
  Transaction.post('/getSaleGstData', function (req, res) {
    var json1,json2;
    const companyname=req.body.companyname;
    const directory=companyname+"/"+req.body.directory;
   
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          console.log(JSON.stringify(json));
          res.send(json1);
          res.end();
       }
      })
  
  
  });
  
  
  Transaction.post('/deleteSaleGstData',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/sale_win.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  

  //SaleGSt apis end

  //API for taxtype Dropdown values retrieval start


Transaction.post('/getTaxDropdown', function (req, res) {
    var json1
    const companyname=req.body.companyname;
    const directory=companyname+"/"+"taxtype.json";
   console.log("\n here\n")
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          //console.log(JSON.stringify(json));
          if(req.body.note == 'sale')
          {
            let model1 = {
              taxtypelist: "",
              supplylist: ""
            }
            model1.taxtypelist = json1.taxtypeS;
            model1.supplylist = json1.supplyS;
            res.send(model1);
          res.end();
  
          }
  
          else if(req.body.note == 'purchase')
          {
           
            let model1 = {
              taxtypelist: "",
              vattypelist: ""
            }
            model1.taxtypelist = json1.taxtypeP;
            model1.vattypelist = json1.vattypeP;
            res.send(model1);
          res.end();
  
          
          }
          
       }
      })
  
  
  });
  
  //API for taxtype Dropdown values retrieval end


  
//API for taxtype Dropdown Save the values 

Transaction.post('/saveTaxStructure', function (req, res) {
  var json1
  const companyname=req.body.companyname;
  const taxTable=req.body.taxTable
  const directory=companyname+"/"+"saletaxstructure.json";
 console.log("\n here\n")
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""=="")
     {  let model1
        //console.log(JSON.stringify(json));
        if(req.body.note == 'sale')
        {
           model1= {
            sale: {data:{}},
            purchase: {data: {}}
          }
          model1.sale.data=taxTable
          
        

        }

        else if(req.body.note == 'purchase')
        {
         
           model1 = {
             sale:{data: {}},
            purchase: {data:{}}
            
          }
          model1.purchase.data=taxTable

        
        }

        fs.writeFile(directory,JSON.stringify(model1),function (err, data){
          if (err) throw err;
          res.send("saved")
        })
        
     }
else
{
  json1 = JSON.parse(data);
  //console.log(JSON.stringify(json));
  if(req.body.note == 'sale')
  {
   
    json1.sale.data=taxTable
    
  
 

  }

  else if(req.body.note == 'purchase')
  {
   
    json1.purchase.data=taxTable
    
 
  

  
  }

  fs.writeFile(directory,JSON.stringify(json1),function (err, data){
    if (err) throw err;
    res.send("saved")
  })

}

    })


});


Transaction.post('/getTaxStructure', function (req, res) {
  var json1
  const companyname=req.body.companyname;
  
  const directory=companyname+"/"+"saletaxstructure.json";
 console.log("\n here\n")
console.log("My comp name"+companyname)
var names
  fs.readFile(directory, function (err, data) {
    console.log("data:  "+directory)
    if(data+""!="")
     { var json1=JSON.parse(data)
    if(req.body.note=="sale")
      { 
        names={taxtypeS:[]}
        json1.sale.data.filter((item)=>{
          var s={text:item.Name,
          value:item.Name.toLowerCase()}
            names.taxtypeS.push(s)
        })
        res.send({completejson:json1,
        names:names})
      }
      else if(req.body.note="purchase")
      { 
        names={taxtypeP:[]}
        json1.purchase.data.filter((item)=>{
        var s={text:item.Name,
        value:item.Name.toLowerCase()}
          names.taxtypeP.push(s)
      })
      res.send({completejson:json1,
      names:names})}
        
     }


    })


});

//API for save taxtype Dropdown values retrieval end




//SALEGST APIs

Transaction.post('/SaveSaleReturnGst', function (req, res) {
    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+"salereturn.json";
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
  json1 = JSON.parse(data);
          
          var length=json1.data.length;
           json1.data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata.data[0][todaydate][0])
                json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata.data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1.data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1.data.splice(finalindex+1,0,newdata.data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1.data.splice(finalindex,0,newdata.data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           })
          
         
        
  
        
        
           
        }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to append" was appended to file!');
          res.end("heo");
      });
       })
   
   
  });
  
  // GetSalegst
  
  Transaction.post('/getSaleReturnGstData', function (req, res) {
    var json1,json2;
    const companyname=req.body.companyname;
    const directory=companyname+"/"+req.body.directory;
   
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          console.log(JSON.stringify(json));
          res.send(json1);
          res.end();
       }
      })
  
  
  });
  
  
  Transaction.post('/deleteSaleReturnGstData',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/salereturn.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  

  //SaleGSt apis end

  //APIs for cashreceipt start



Transaction.post('/SaveCashReceipt', function (req, res) {
    var json1,json2;
     const companyname=req.body.companyname;
     const directory=companyname+"/"+"cashreceipt.json";
     var data2=req.body.exportdata
     var newdata=JSON.parse(data2)
     var todaydate=req.body.date
     var voucherno=req.body.voucherno
  var found="false";
     
     var dates=[]   
   console.log("My comp name"+companyname)
     var flag=0;var flag2=0;
     fs.readFile(directory, function (err, data) {
       console.log("data:"+directory)
  
  
       if(data+""!="")
        {  
  json1 = JSON.parse(data);
          
          var length=json1.data.length;
           json1.data.filter(function(item,index){
  
  
            console.log("\n\n"+JSON.stringify(item[todaydate]));
            if(item[todaydate]+""!="undefined")
            {
              item[todaydate].filter(function(item2,index2){
                console.log(item2.voucherno+" is voucherno")
                if(item2.voucherno==voucherno)
                {
                flag2=1
                console.log("\n"+newdata.data[0][todaydate][0])
                json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
                json2=JSON.stringify(json1)
                }
                else{
                  if(index2==item[todaydate].length-1&&flag2==0)
                  {item[todaydate].push(newdata.data[0][todaydate][0])
                  json2=JSON.stringify(json1)
                  }
                }
              })
             
            flag=1
          }
            else { 
         
           dates[index]=Object.keys(json1.data[index])[0]
           var finalindex
           var q;
           var n;
           if(todaydate<(dates[index]))
              n=-1
              else n=1
           if(n==-1)
              {if(found=="false")
                {finalindex=index
                found="true"}
  
              }
              else if(n==1)
              finalindex=length
            if((index==(length-1))&& flag==0)
              {
               if(finalindex==length)
               { json1.data.splice(finalindex+1,0,newdata.data[0]) 
                json2=JSON.stringify(json1)}
                else
             { json1.data.splice(finalindex,0,newdata.data[0]) 
              json2=JSON.stringify(json1)
             }
              }
            }
           })
          
        }
        else
        {json2=data2
        console.log(json2+" in khali")
      }
        fs.writeFile(directory, json2, function (err) {
          if (err) throw err;
          res.send(json2)
        //  console.log('The "data to Transactionend" was Transactionended to file!');
          res.end("heo");
      });
       })
   
   
  });
  
  
  // Get Cash REceipt item(s)
  
  Transaction.post('/getCashReceiptData', function (req, res) {
    var json1,json2;
    const companyname=req.body.companyname;
    const directory=companyname+"/"+req.body.directory;
   
  console.log("My comp name"+companyname)
    
    fs.readFile(directory, function (err, data) {
      console.log("data:"+directory)
      if(data+""!="")
       {   json1 = JSON.parse(data);
          console.log(JSON.stringify(json));
          res.send(json1);
          res.end();
       }
      })
  
  
  });
  
  // API to delete a cash receipt item
  
  Transaction.post('/deleteCashReceipt',function(req,res){
    console.log("\n\n"+"here")
  var companyname=req.body.companyname;
  var date=req.body.date;
  var voucherno=req.body.voucherno;
  var directory=companyname+"/cashreceipt.json"
  var json
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
  if(data+""!="")
  { json = JSON.parse(data);
  json.data.filter(function(item,index){
    if(item[date]+""!="undefined")
    {
      if(item[date].length==1)
      {json.data.splice(index,1)}
      else
      {
      json.data[index][date].splice(parseInt(voucherno+"")-1,1)
     
      for(let i=0;i<json.data[index][date].length;i++)
      {
        json.data[index][date][i].voucherno=(parseInt(i)+1)+""
      }
    }
      fs.writeFile(directory, JSON.stringify(json), function (err) {
        if (err) throw err;
        res.send(json)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
    }
  })
  }
  
  })
  
  });
  
  //APIs for cash receipt end

  //APIs for bank form start



Transaction.post('/SaveBankForm', function (req, res) {
  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"bank.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var heading=req.body.heading
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     console.log("data:"+directory)


     if(data+""!="")
      {  
json1 = JSON.parse(data);
        
        var length=json1[heading].data.length;
         json1[heading].data.filter(function(item,index){


          console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              console.log("\n"+newdata[heading].data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata[heading].data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata[heading].data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1[heading].data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1[heading+""].data.splice(finalindex+1,0,newdata[heading].data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1[heading+""].data.splice(finalindex,0,newdata[heading].data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
      }
      else
      {json2=data2
      console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});


// Get bank form item(s)

Transaction.post('/getBankFormData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});

// API to delete a bank form item

Transaction.post('/deleteBankForm',function(req,res){
  console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/bank.json"
var json
fs.readFile(directory, function (err, data) {
  console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});

//APIs for bank form end

module.exports = Transaction;  