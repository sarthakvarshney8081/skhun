const express = require('express');
const jsonQ = require("jsonq");
const fs = require('fs');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const app = express();
const bodyParser = require('body-parser');
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var conn = require('./connection.js');
var enquiry = require('./enquiry.json');
var user = require('./user.js');
var tansactions = require('./transactions.js');
var userRoles;
var normalizedPath = require("path");
var finalJson;
var num;


app.use('/user', user);
app.use('/transactions',tansactions)
fs.readFile('enquiry.json', function (err, data) {
  if (data == "") {
  }
  else {
    json = JSON.parse(data);
    num = JSON.stringify(json)
  }
})



//Excise setup api start

app.post('/saveExciseSetup', function (req, res) {
  ////console.log("\n\n" + "here to save the setup details")
  var jsontowrite ; 
  const companyName = req.body.companyname;

    
  fs.readFile(companyName + '/excisesetup.json', function (err, data) {
    console.log(req.body.excisedata)    

    if (data + "" === "") {
      jsontowrite = {
        data: {
          excisedata: ""  
        }
      }
      jsontowrite.data.excisedata = req.body.excisedata;
          
        fs.writeFile(companyName + '/excisesetup.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("Saved excise setup successfully to an empty file")

        });  
    
    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.data.excisedata = req.body.excisedata;
      fs.writeFile(companyName + '/excisesetup.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("Saved excise setup successfully")
      });  
    
    }

  })
  
});

//Excise setup api end

//Company Info API start

app.post('/saveCompanyInfo', function (req, res) {
  ////console.log("\n\n" + "here to save the setup details")
  var jsontowrite ; 
  const companyName = req.body.companyname;

    
  fs.readFile(companyName + '/companyinfo.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        data: {
          companyinfo: ""  
        }
      }
      jsontowrite.data.companyinfo = req.body.companyinfodata;
          
        fs.writeFile(companyName + '/companyinfo.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("Saved company info successfully to an empty file")

        });  
      

    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.data.companyinfo = req.body.companyinfodata;
      fs.writeFile(companyName + '/companyinfo.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("Saved company info successfully")
      });  
    
    }

  })
  


});


//Company Info API end


//Sale Series Continuous...God help Sri

app.post('/SaveSaleContinuous', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in saving stock account block")
  var companyName = req.body.companyname
  var heading = req.body.heading
  // //console.log("companyName is:" + companyName)

  var model = {

}

  model[heading]=[]

  fs.readFile(companyName + '/sale_win_cont.json', function (err, data) {
    flag2 = 0;
    //console.log(data+"")
    if (data + "" === "") {
      model[heading].push(req.body.dataAll);
      
      model[heading][0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      console.log(heading)
      //console.log(JSON.stringify(json));
      if(json[heading]+""!="undefined")
      {
      json[heading].filter(function (item) {
        //console.log(req.body.dataAll.name)
        if (item.voucherno === req.body.dataAll.voucherno) {
          
          if(req.body.isEditingOld == true)
          {
            json[heading][index] = req.body.dataAll
            flag = 1;
            // //console.log(json.stock_accounts)
            for (let i = 0; i < json[heading].length; i++) {
              json[heading][i].index = parseInt(i)
      
            }
           
          }

          if( req.body.isEditingOld == false)
          {
            // //console.log("duplicate Alert!!!!!")
            flag = 1
            res.send(
              { 'dooda': "duplicate" }
            );

            flag2 = 1;
          }

        }
        else
          ++index;

        
      })
      if (flag != 1) {
        json[heading].push(req.body.dataAll);
      }
    }
     

      else{
        json[heading]=[]
        json[heading].push(req.body.dataAll);
      
       }

    }

    if (flag2 == 0) {
      // No duplicate, clear to write the new data
      for (let i = 0; i < json[heading].length; i++) {
        json[heading][i].index = parseInt(i)

      }
      fs.writeFile(companyName + '/sale_win_cont.json', JSON.stringify(json), function (err) {
        if (err) throw err;

        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });


    }
    if (flag2 == 2) {
      // Empty db, write it all.

      fs.writeFile(companyName + '/sale_win_cont.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        //console.log('The "data to append" was appended to file!');
        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });
    }


  })
});


app.post('/GetSaleContinuous', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in returning stock accounts block")
  var companyName = req.body.companyname
  var heading=req.body.heading
  //  //console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/sale_win_cont.json', function (err, data) {
    //console.log(data+"")
    if (data + "" === "") {
      json = {
        
      };

      json[heading]=[]
      // //console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)
      //console.log(JSON.stringify(json));

      if(req.body.note == 'all')
    {
      var model = {
      
      }

      model[heading]=[]
      //console.log(JSON.stringify(json));


      for (let i = 0; i < json[heading].length; i++) {
        model[heading].push(json[heading][i])
      }
      res.send(model)

    }
    
    else if(req.body.note == 'first')
    {
      
     if(json[heading]+""!="undefined")
        res.send(json[heading][0]);
        else
        {json[heading]=[]
          // //console.log("sending no data")
          res.send(
            json
          );}
      
    }
    else if(req.body.note == 'last')
    {if(json[heading]+""!="undefined")
{
      console.log("\n\n"+JSON.stringify(json[heading])+"  "+heading)
      res.send(json[heading][json[heading].length -1]);
}
else
{ json[heading]=[]
  // //console.log("sending no data")
  res.send(
    json
  );}
    }
    else if(req.body.note == 'prev')
    {
      if (parseInt(req.body.reqIndex) == -999) {
         //console.log("initial, so sending last data")
        res.send(json[heading][json[heading].length -1])
      }
      else if(parseInt(req.body.reqIndex) >0 && parseInt(req.body.reqIndex) <= json[heading].length)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json[heading][parseInt(req.body.reqIndex) - 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'next')
    {
      if (parseInt(req.body.reqIndex) == -999) {
        ////console.log("initial, so sending last data")
        res.send(json[heading][json[heading].length -1])
      }
      else if(parseInt(req.body.reqIndex) >=0 && parseInt(req.body.reqIndex) < json[heading].length -1)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json[heading][parseInt(req.body.reqIndex) + 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'selected')
    {var k=0
      for (let i = 0; i < json[heading].length; i++) {
        if(json[heading][i].date == req.body.selectedName)
        {
          ////console.log("sending selected data found to be: "+ json.stock_accounts[i].Name)
          k=1;
          if(i==json[heading].length-1)
          { res.send(json[heading][i]);}
          
        }
        else
        {if(k==1)
          {console.log("\n\n bbb"+JSON.stringify(json[heading][i-1]))
            res.send(json[heading][i-1]);
          }
        }
      }
        
      
    }
    }

  })
});


app.post('/DeleteStockAccount', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in deleting stock accounts block")
  var companyName = req.body.companyname
   ////console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/stock_master.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      
      ////console.log("sending no data")
      res.send(
       "emptydb"
      );

    }
    else {
      json = JSON.parse(data)
      //////console.log(JSON.stringify(json));
        json.stock_accounts.splice(parseInt(req.body.idToDelete) , 1)
        fs.writeFile(companyName + '/stock_master.json', JSON.stringify(json), function (err) {
          if (err) throw err;
          // ////console.log('The "data to append" was appended to file!');
          ////console.log("written the data")
          res.send('deleted');
  
        });
    }

  })
});


// Sale Series continuous APIs end


//Continuous Purchase APi


app.post('/SavePurchaseContinuous', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in saving stock account block")
  var companyName = req.body.companyname
  var heading = req.body.heading
  // //console.log("companyName is:" + companyName)

  var model = {

}

  model[heading]=[]

  fs.readFile(companyName + '/purchasegst_cont.json', function (err, data) {
    flag2 = 0;
    //console.log(data+"")
    if (data + "" === "") {
      model[heading].push(req.body.dataAll);
      
      model[heading][0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      console.log(heading)
      //console.log(JSON.stringify(json));
      if(json[heading]+""!="undefined")
      {
      json[heading].filter(function (item) {
        //console.log(req.body.dataAll.name)
        if (item.voucherno === req.body.dataAll.voucherno) {
          
          if(req.body.isEditingOld == true)
          {
            json[heading][index] = req.body.dataAll
            flag = 1;
            // //console.log(json.stock_accounts)
            for (let i = 0; i < json[heading].length; i++) {
              json[heading][i].index = parseInt(i)
      
            }
           
          }

          if( req.body.isEditingOld == false)
          {
            // //console.log("duplicate Alert!!!!!")
            flag = 1
            res.send(
              { 'dooda': "duplicate" }
            );

            flag2 = 1;
          }

        }
        else
          ++index;

        
      })
      if (flag != 1) {
        json[heading].push(req.body.dataAll);
      }
    }
     

      else{
        json[heading]=[]
        json[heading].push(req.body.dataAll);
      
       }

    }

    if (flag2 == 0) {
      // No duplicate, clear to write the new data
      for (let i = 0; i < json[heading].length; i++) {
        json[heading][i].index = parseInt(i)

      }
      fs.writeFile(companyName + '/purchasegst_cont.json', JSON.stringify(json), function (err) {
        if (err) throw err;

        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });


    }
    if (flag2 == 2) {
      // Empty db, write it all.

      fs.writeFile(companyName + '/purchasegst_cont.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        //console.log('The "data to append" was appended to file!');
        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });
    }


  })
});


app.post('/GetPurchaseContinuous', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in returning stock accounts block")
  var companyName = req.body.companyname
  var heading=req.body.heading
  //  //console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/purchasegst_cont.json', function (err, data) {
    //console.log(data+"")
    if (data + "" === "") {

      console.log("in purchase c")
      json = {
        
      };

      json[heading]=[]
      // //console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)
      //console.log(JSON.stringify(json));

      if(req.body.note == 'all')
    {
      var model = {
      
      }

      model[heading]=[]
      //console.log(JSON.stringify(json));


      for (let i = 0; i < json[heading].length; i++) {
        model[heading].push(json[heading][i])
      }
      res.send(model)

    }
    
    else if(req.body.note == 'first')
    {
      
     if(json[heading]+""!="undefined")
        res.send(json[heading][0]);
        else
        {json[heading]=[]
          // //console.log("sending no data")
          res.send(
            json
          );}
      
    }
    else if(req.body.note == 'last')
    {if(json[heading]+""!="undefined")
{
      console.log("\n\n"+JSON.stringify(json[heading])+"  "+heading)
      res.send(json[heading][json[heading].length -1]);
}
else
{ json[heading]=[]
  // //console.log("sending no data")
  res.send(
    json
  );}
    }
    else if(req.body.note == 'prev')
    {
      if (parseInt(req.body.reqIndex) == -999) {
         //console.log("initial, so sending last data")
        res.send(json[heading][json[heading].length -1])
      }
      else if(parseInt(req.body.reqIndex) >0 && parseInt(req.body.reqIndex) <= json[heading].length)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json[heading][parseInt(req.body.reqIndex) - 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'next')
    {
      if (parseInt(req.body.reqIndex) == -999) {
        ////console.log("initial, so sending last data")
        res.send(json[heading][json[heading].length -1])
      }
      else if(parseInt(req.body.reqIndex) >=0 && parseInt(req.body.reqIndex) < json[heading].length -1)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json[heading][parseInt(req.body.reqIndex) + 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'selected')
    {var k=0
      for (let i = 0; i < json[heading].length; i++) {
        if(json[heading][i].date == req.body.selectedName)
        {
          ////console.log("sending selected data found to be: "+ json.stock_accounts[i].Name)
          k=1;
          if(i==json[heading].length-1)
          { res.send(json[heading][i]);}
          
        }
        else
        {if(k==1)
          {console.log("\n\n bbb"+JSON.stringify(json[heading][i-1]))
            res.send(json[heading][i-1]);
          }
        }
      }
        
      
    }
    }

  })
});


app.post('/DeleteStockAccount', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in deleting stock accounts block")
  var companyName = req.body.companyname
   ////console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/stock_master.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      
      ////console.log("sending no data")
      res.send(
       "emptydb"
      );

    }
    else {
      json = JSON.parse(data)
      //////console.log(JSON.stringify(json));
        json.stock_accounts.splice(parseInt(req.body.idToDelete) , 1)
        fs.writeFile(companyName + '/stock_master.json', JSON.stringify(json), function (err) {
          if (err) throw err;
          // ////console.log('The "data to append" was appended to file!');
          ////console.log("written the data")
          res.send('deleted');
  
        });
    }

  })
});




//Continuous purchase ends

// Purchase SERIES API. 


app.post('/getPurchaseSeriesData',function(req,res){

  var json1;


   const directory=req.body.companyname+"/"+"purchaseseries.json";

   fs.readFile(directory, function (err, data) {
    // //console.log("data:"+directory)
    var keys = [];
    var values = [];
    
    var valueslabel=[];
    var valueswidth=[];
    let seriesindex = parseInt(req.body.seriesindex);
     if(data+""!="")
      {   json1 = JSON.parse(data);
       
         let columndata = json1.purchaseseriesdata[seriesindex].columndata;
      
         let datas=json1.purchaseseriesdata[seriesindex].data.data
        
        
columndata={}
            datas.forEach(function(item,index){

                  keys.push(Object.keys(item)[0])
                  values.push(item[Object.keys(item)[0]])

                  columndata[keys[index]]=values[index]

                });

            var  labeldata={}
            var labeldata2 = [];
            datas.forEach(function(item,index){

                  valueslabel.push(item[Object.keys(item)[2]])

                  labeldata[keys[index]]=valueslabel[index];
                  labeldata2.push(valueslabel[index]);
                //}
                });

                var  widthdata={}
                datas.forEach(function(item,index){
                     
                      valueswidth.push(item[Object.keys(item)[3]])
    
                      widthdata[keys[index]]=valueswidth[index]
                    //}
                    });

      
         res.send({
          keys: keys, 
          values: values,
          columndata: columndata,
          labeldata: labeldata,
          labeldata2: labeldata2,
          widthdata:widthdata,
          orderdata: json1.purchaseseriesdata[seriesindex].orderdata,
          heading: json1.purchaseseriesdata[seriesindex].Ahead,
          cont:json1.purchaseseriesdata[seriesindex].cont,
         });
         res.end();
      }
     })
 
 
 
  });

  app.post('/getPurchaseSeriesNames',function(req,res){

    var json1;
  const directory=req.body.companyname+"/"+"purchaseseries.json";
   fs.readFile(directory, function (err, data) {
  
      var names = [];      
       if(data+"" =="")
        { 
          console.log("EMPTY SERIES JSON FILE")
          res.send({
            names: "empty", 
           });
          res.end();
        }
        else 
        {
          console.log("NON EMP+TY SERIES JSON FILE")
          
          json1 = JSON.parse(data);
  
          json1.purchaseseriesdata.forEach(function(obj)
          {
            let bufferObj = {"name": "", "index": ""}
            bufferObj.name = obj.Ahead;
            bufferObj.index = obj.index;
            names.push(bufferObj)
          })
          
           console.log(names);
           res.send({
             names: names, 
            });
           res.end();
          
        }
       })
   
   
   
    });

    //Purchase series api end

    app.post('/saveBankSeriesNames',function(req,res){

      var json1;
      console.log(req.body.bankseries)
      const directory=req.body.companyname+"/"+"bankseries.json";

     fs.readFile(directory, function (err, data) {
    
            
         if(data+"" =="")
          { 
            var po = {
              bankseries: ""
            }
            
              po.bankseries = req.body.bankseries;
              json1 = po;
            
          }
          else 
          {
            json1 = JSON.parse(data);
    
            json1.bankseries = req.body.bankseries;
          }

          console.log(JSON.stringify(json1) + " bdsidsuui")

         fs.writeFile(req.body.companyname + '/bankseries.json', JSON.stringify(json1), function (err) {
          if (err) throw err;
          res.send({ 'dooda': "Saved the series names" });
  
        });

         });
        });

        app.post('/saveTDSSeriesNames',function(req,res){

          var json1;
          console.log(req.body.tdsseries)
          const directory=req.body.companyname+"/"+"tdsseries.json";
    
         fs.readFile(directory, function (err, data) {
        
                
             if(data+"" =="")
              { 
                var po = {
                  tdsseries: ""
                }
                
                  po.tdsseries = req.body.tdsseries;
                  json1 = po;
                
              }
              else 
              {
                json1 = JSON.parse(data);
        
                json1.tdsseries = req.body.tdsseries;
              }
    
              console.log(JSON.stringify(json1) + " bdsidsuui")
    
             fs.writeFile(req.body.companyname + '/tdsseries.json', JSON.stringify(json1), function (err) {
              if (err) throw err;
              res.send({ 'dooda': "Saved the tds series names" });
      
            });
    
             });
            });
    

    app.post('/getBankSeriesNames',function(req,res){

      var json1;
     const directory=req.body.companyname+"/"+"bankseries.json";
     fs.readFile(directory, function (err, data) {
    
        var names = [];      
         if(data+"" =="")
          { 
           // console.log("EMPTY SERIES JSON FILE")
            res.send({
              names: "empty", 
             });
            res.end();
          }
          else 
          {
           // console.log("NON EMP+TY SERIES JSON FILE")
            
            json1 = JSON.parse(data);
            let i = 0;
            json1.bankseries.forEach(function(obj)
            {
              let bufferObj = {"name": "", "Form_type": "", "index" : ""}
              bufferObj.name = obj.Ahead;
              bufferObj.Form_type = obj.Form_type;
              bufferObj.index = i;
              names.push(bufferObj)
              i++;
            })
            
             //console.log(names);
             res.send({
               names: names, 
               list : json1.bankseries
              });
             res.end();
            
          }
         })
     
      });

      app.post('/getTDSSeriesNames',function(req,res){

        var json1;
       const directory=req.body.companyname+"/"+"tdsseries.json";
       fs.readFile(directory, function (err, data) {
      
          var names = [];      
           if(data+"" =="")
            { 
             // console.log("EMPTY SERIES JSON FILE")
              res.send({
                names: "empty", 
               });
              res.end();
            }
            else 
            {
             // console.log("NON EMP+TY SERIES JSON FILE")
              
              json1 = JSON.parse(data);
              let i = 0;
              json1.tdsseries.forEach(function(obj)
              {
                let bufferObj = {"name": "", "Form_type": "", "index" : ""}
                bufferObj.name = obj.Ahead;
                bufferObj.Form_type = obj.Form_type;
                bufferObj.index = i;
                names.push(bufferObj)
                i++;
              })
              
               res.send({
                 names: names, 
                 list : json1.tdsseries
                });
               res.end();
              
            }
           })
       
        });

// SALE SERIES API.  God help me!


app.post('/getSaleSeriesData',function(req,res){

  var json1;


   const directory=req.body.companyname+"/"+"saleseries.json";

   fs.readFile(directory, function (err, data) {
    // //console.log("data:"+directory)
    var keys = [];
    var values = [];
    
    var valueslabel=[];
    var valueswidth=[];
    let seriesindex = parseInt(req.body.seriesindex);
     if(data+""!="")
      {   json1 = JSON.parse(data);
       
         let columndata = json1.saleseriesdata[seriesindex].columndata;
      
         let datas=json1.saleseriesdata[seriesindex].data.data
        
        
columndata={}
            datas.forEach(function(item,index){

                  keys.push(Object.keys(item)[0])
                  values.push(item[Object.keys(item)[0]])

                  columndata[keys[index]]=values[index]

                });

            var  labeldata={}
            var labeldata2 = [];
            datas.forEach(function(item,index){

                  valueslabel.push(item[Object.keys(item)[2]])

                  labeldata[keys[index]]=valueslabel[index];
                  labeldata2.push(valueslabel[index]);
                //}
                });

                var  widthdata={}
                datas.forEach(function(item,index){
                     
                      valueswidth.push(item[Object.keys(item)[3]])
    
                      widthdata[keys[index]]=valueswidth[index]
                    //}
                    });

      
         res.send({
          keys: keys, 
          values: values,
          columndata: columndata,
          labeldata: labeldata,
          labeldata2: labeldata2,
          widthdata:widthdata,
          orderdata: json1.saleseriesdata[seriesindex].orderdata,
          heading: json1.saleseriesdata[seriesindex].Ahead,
          cont:json1.saleseriesdata[seriesindex].cont,
          index: json1.saleseriesdata[seriesindex].index,
          Ahead: json1.saleseriesdata[seriesindex].Ahead,
          Form_type: json1.saleseriesdata[seriesindex].Form_type,
          Led_post: json1.saleseriesdata[seriesindex].Led_post,
          Vat_post: json1.saleseriesdata[seriesindex].Vat_post  ,
          Ex_post : json1.saleseriesdata[seriesindex].Ex_post ,
          Serial : json1.saleseriesdata[seriesindex].Serial  ,
          Short_name : json1.saleseriesdata[seriesindex].Short_name ,
          Stk_post : json1.saleseriesdata[seriesindex].Stk_post ,
          Form_rtype : json1.saleseriesdata[seriesindex].Form_rtype ,
          Rep_name :  json1.saleseriesdata[seriesindex].Rep_name,
          Bill_no_h :  json1.saleseriesdata[seriesindex].Bill_no_h,
          Salef3 :  json1.saleseriesdata[seriesindex].Salef3,
          Tick :  json1.saleseriesdata[seriesindex].Tick,
          Vacode :  json1.saleseriesdata[seriesindex].Vacode,
          Rep_gst :  json1.saleseriesdata[seriesindex].Rep_gst,
          cont : json1.saleseriesdata[seriesindex].cont,
         });
         res.end();
      }
     })
 
 
 
  });

  app.post('/getSaleSeriesNames',function(req,res){

    var json1;
  const directory=req.body.companyname+"/"+"saleseries.json";
   fs.readFile(directory, function (err, data) {
  
      var names = [];      
       if(data+"" =="")
        { 
          console.log("EMPTY SERIES JSON FILE")
          res.send({
            names: "empty", 
           });
          res.end();
        }
        else 
        {
          console.log("NON EMP+TY SERIES JSON FILE")
          
          json1 = JSON.parse(data);
  
          json1.saleseriesdata.forEach(function(obj)
          {
            let bufferObj = {"name": "", "index": ""}
            bufferObj.name = obj.Ahead;
            bufferObj.index = obj.index;
            names.push(bufferObj)
          })
          
           console.log(names);
           res.send({
             names: names, 
            });
           res.end();
          
        }
       })
   
   
   
    });



//Zone Details APIs start

app.post('/saveZoneDetails', function (req, res) {

  var jsontowrite ; 
  const companyName = req.body.companyname;
   var fl = 0;

   
  fs.readFile(companyName + '/zone.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        zonedetails: {
        }
      }
      jsontowrite.zonedetails = req.body.exportdata;
          
        fs.writeFile(companyName + '/zone.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("saved zone details to empty zone.json")
         console.log("saved zone details in empty json")
          res.end("saved");
        });  
      

    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.zonedetails = req.body.exportdata;
      fs.writeFile(companyName + '/zone.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("overwrote the data with new one in zone.json")
        console.log("overwrote the data with new one in zone.json")
        res.end("Done! Saved.");
      });  
    
    }

  })
  
});


app.post('/getZoneDetails', function (req, res) {
  var json1;
  
  const directory = req.body.companyname + "/zone.json";

  fs.readFile(directory, function (err, data) {

    if (data + "" != "") {
      json1 = JSON.parse(data);
      json1 = json1.zonedetails
     
      res.send(json1);
      res.end();
    }
  })
});

//Zone Details APIs end

//Stock setup apis

app.post('/savestocksetup', function (req, res) {
  ////console.log("\n\n" + "here to save the setup details")
  var jsontowrite ; 
  const companyName = req.body.companyname;
var fl = 0;

  ////console.log("My comp name" + companyName)


    
  fs.readFile(companyName + '/stocksetup.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        setupdata: {
        }
      }
      jsontowrite.setupdata = req.body.exportdata;
    
      ////console.log("the json i am trying to wrrite is:  "+ JSON.stringify(jsontowrite));
          
        fs.writeFile(companyName + '/stocksetup.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("savved something to empty purchase setup")
  
          res.end("heo");
        });  
      

    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.setupdata = req.body.exportdata;
      fs.writeFile(companyName + '/stocksetup.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("savved something to purchase setup with data")

        res.end("heo");
      });  
    
    }

  })
  
});


app.post('/getstocksetup', function (req, res) {
  var json1;
  const companyname = req.body.companyname;
  const directory = companyname + "/" + req.body.directory;

  ////console.log("My comp name" + companyname)


  fs.readFile(directory, function (err, data) {
    ////console.log("data:" + directory)
    if (data + "" != "") {
      json1 = JSON.parse(data);
      json1 = json1.setupdata
     
      res.send(json1);
      res.end();
    }
  })




});


//stock setup apis end


//Ledger Setup

app.post('/saveledgersetup', function (req, res) {
  ////console.log("\n\n" + "here to save the setup details")
  var jsontowrite ; 
  const companyName = req.body.companyname;
var fl = 0;

  ////console.log("My comp name" + companyName)


    
  fs.readFile(companyName + '/ledgersetup.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        setupdata: {
        }
      }
      jsontowrite.setupdata = req.body.exportdata;
    
      ////console.log("the json i am trying to wrrite is:  "+ JSON.stringify(jsontowrite));
          
        fs.writeFile(companyName + '/ledgersetup.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("savved something to empty purchase setup")
  
          res.end("heo");
        });  
      

    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.setupdata = req.body.exportdata;
      fs.writeFile(companyName + '/ledgersetup.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("savved something to purchase setup with data")

        res.end("heo");
      });  
    
    }

  })
  
});


app.post('/getledgersetup', function (req, res) {
  var json1;
  const companyname = req.body.companyname;
  const directory = companyname + "/" + req.body.directory;

  ////console.log("My comp name" + companyname)


  fs.readFile(directory, function (err, data) {
    ////console.log("data:" + directory)
    if (data + "" != "") {
      json1 = JSON.parse(data);
      json1 = json1.setupdata
     
      res.send(json1);
      res.end();
    }
  })




});



//End of Ledger setup apis
//Purchase setup API

app.post('/SaveSpSetup', function (req, res) {
  ////console.log("\n\n" + "here to save the setup details")
  var jsontowrite ; 
  const companyName = req.body.companyname;
var fl = 0;

  ////console.log("My comp name" + companyName)

  if(req.body.note == "purchase")
  {
    
  fs.readFile(companyName + '/sp_setup.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        setupdata: {
          purchase: "",
          sale: ""
        }
      }
      jsontowrite.setupdata.purchase = req.body.exportdata;
    
      ////console.log("the json i am trying to wrrite is:  "+ JSON.stringify(jsontowrite));
          
        fs.writeFile(companyName + '/sp_setup.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("savved something to empty purchase setup")
  
          res.end("heo");
        });  
      

    }
    else {
      jsontowrite = JSON.parse(data);
      jsontowrite.setupdata.purchase = req.body.exportdata;
      fs.writeFile(companyName + '/sp_setup.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("savved something to purchase setup with data")

        res.end("heo");
      });  
    
    }

  })
  }

  if(req.body.note == "sale")
  {
    
  fs.readFile(companyName + '/sp_setup.json', function (err, data) {
    ////console.log(req.body.exportdata)    

    if (data + "" === "") {
      jsontowrite = {
        setupdata: {
          purchase: "",
          sale: ""
        }
      }
      jsontowrite.setupdata.sale = req.body.exportdata;
    
      ////console.log("the json i am trying to wrrite is:  "+ JSON.stringify(jsontowrite));
          
        fs.writeFile(companyName + '/sp_setup.json', JSON.stringify(jsontowrite), function (err) {
          if (err) throw err;
          res.send("savved something to empty sale setup")
  
          res.end("heo");
        });  
      

    }
    else {
      
      jsontowrite = JSON.parse(data);
      jsontowrite.setupdata.sale = req.body.exportdata;
      fs.writeFile(companyName + '/sp_setup.json', JSON.stringify(jsontowrite), function (err) {
        if (err) throw err;
        res.send("savved something to sale setup with data")

        res.end("heo");
      });  
    
    }

  })
  }

});


app.post('/getSpSetup', function (req, res) {
  var json1;
  const companyname = req.body.companyname;
  const directory = companyname + "/" + req.body.directory;

  ////console.log("My comp name" + companyname)

if(req.body.note === 'purchase')
{
  fs.readFile(directory, function (err, data) {
    ////console.log("data:" + directory)
    if (data + "" != "") {
      json1 = JSON.parse(data);
      json1 = json1.setupdata.purchase
     
      res.send(json1);
      res.end();
    }
  })
}

if(req.body.note === 'sale')
{
  fs.readFile(directory, function (err, data) {
    ////console.log("data:" + directory)
    if (data + "" != "") {
      json1 = JSON.parse(data);
      json1 = json1.setupdata.sale
     
      res.send(json1);
      res.end();
    }
  })
}


});




  
//Purchase setup Api end


// NOTICE the /SaveCreditNote endpoint.

app.post('/SaveCreditNote', function (req, res) {

  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"creditnote.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 ////console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     ////console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          ////console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              ////console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              ////console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      ////console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  ////console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});

// GetCreditNote

app.post('/getCreditNoteData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
////console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    ////console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        ////console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


app.post('/deleteCreditNote',function(req,res){
  ////console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/creditnote.json"
var json
fs.readFile(directory, function (err, data) {
  ////console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  ////console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});

//Creditnote Apis end

// NOTICE the /SaveTDS endpoint.

app.post('/SaveTDS', function (req, res) {
  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"tds.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 ////console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     ////console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          ////console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              ////console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              ////console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       }
      else
      {json2=data2
      ////console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  ////console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});

// GetTDS

app.post('/getTDSData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
////console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    ////console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        ////console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});

//deleteTDS
app.post('/deleteTDS',function(req,res){
  ////console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/tds.json"
var json
fs.readFile(directory, function (err, data) {
  ////console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  ////console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});

//TDS apis end

// Purchase GST apis start



app.post('/SavePurchaseGst', function (req, res) {
  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"purchasegst.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 ////console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     ////console.log("data:"+directory)


     if(data+""!="")
      {  
json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          ////console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              ////console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              ////console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      ////console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  ////console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});


// GetPurchasegst

app.post('/getPurchaseGstData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
////console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    ////console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        ////console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});



app.post('/deletePurchaseGst',function(req,res){
  ////console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/purchasegst.json"
var json
fs.readFile(directory, function (err, data) {
  ////console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  ////console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});



//Purchase gst apis end


//SALEGST Apis end

// NOTICE the /SaveDebitNote endpoint.



app.post('/SaveDebitNote', function (req, res) {
  var json1,json2;
   const companyname=req.body.companyname;
   const directory=companyname+"/"+"debitnote.json";
   var data2=req.body.exportdata
   var newdata=JSON.parse(data2)
   var todaydate=req.body.date
   var voucherno=req.body.voucherno
var found="false";
   
   var dates=[]   
 ////console.log("My comp name"+companyname)
   var flag=0;var flag2=0;
   fs.readFile(directory, function (err, data) {
     ////console.log("data:"+directory)


     if(data+""!="")
      {  


        json1 = JSON.parse(data);
        
        var length=json1.data.length;
         json1.data.filter(function(item,index){


          ////console.log("\n\n"+JSON.stringify(item[todaydate]));
          if(item[todaydate]+""!="undefined")
          {
            item[todaydate].filter(function(item2,index2){
              ////console.log(item2.voucherno+" is voucherno")
              if(item2.voucherno==voucherno)
              {
              flag2=1
              ////console.log("\n"+newdata.data[0][todaydate][0])
              json1.data[index][todaydate][index2]=newdata.data[0][todaydate][0]
              json2=JSON.stringify(json1)
              }
              else{
                if(index2==item[todaydate].length-1&&flag2==0)
                {item[todaydate].push(newdata.data[0][todaydate][0])
                json2=JSON.stringify(json1)
                }
              }
            })
           
          flag=1
        }
          else { 
       
         dates[index]=Object.keys(json1.data[index])[0]
         var finalindex
         var q;
         var n;
         if(todaydate<(dates[index]))
            n=-1
            else n=1
         if(n==-1)
            {if(found=="false")
              {finalindex=index
              found="true"}

            }
            else if(n==1)
            finalindex=length
          if((index==(length-1))&& flag==0)
            {
             if(finalindex==length)
             { json1.data.splice(finalindex+1,0,newdata.data[0]) 
              json2=JSON.stringify(json1)}
              else
           { json1.data.splice(finalindex,0,newdata.data[0]) 
            json2=JSON.stringify(json1)
           }
            }
          }
         })
        
       
      

      
      
         
      }
      else
      {json2=data2
      ////console.log(json2+" in khali")
    }
      fs.writeFile(directory, json2, function (err) {
        if (err) throw err;
        res.send(json2)
      //  ////console.log('The "data to append" was appended to file!');
        res.end("heo");
    });
     })
 
 
});

// GetDebitNote

app.post('/getDebitNoteData', function (req, res) {
  var json1,json2;
  const companyname=req.body.companyname;
  const directory=companyname+"/"+req.body.directory;
 
////console.log("My comp name"+companyname)
  
  fs.readFile(directory, function (err, data) {
    ////console.log("data:"+directory)
    if(data+""!="")
     {   json1 = JSON.parse(data);
        ////console.log(JSON.stringify(json));
        res.send(json1);
        res.end();
     }
    })


});


app.post('/deleteDebitNote',function(req,res){
  ////console.log("\n\n"+"here")
var companyname=req.body.companyname;
var date=req.body.date;
var voucherno=req.body.voucherno;
var directory=companyname+"/debitnote.json"
var json
fs.readFile(directory, function (err, data) {
  ////console.log("data:"+directory)
if(data+""!="")
{ json = JSON.parse(data);
json.data.filter(function(item,index){
  if(item[date]+""!="undefined")
  {
    if(item[date].length==1)
    {json.data.splice(index,1)}
    else
    {
    json.data[index][date].splice(parseInt(voucherno+"")-1,1)
   
    for(let i=0;i<json.data[index][date].length;i++)
    {
      json.data[index][date][i].voucherno=(parseInt(i)+1)+""
    }
  }
    fs.writeFile(directory, JSON.stringify(json), function (err) {
      if (err) throw err;
      res.send(json)
    //  ////console.log('The "data to append" was appended to file!');
      res.end("heo");
  });
  }
})
}

})

});

//Narrations api
app.post('/addNarration',function(req,res){

  var companyname=req.body.companyname;
  var json
  var finalindex;
var input1=req.body.data
var key=req.body.key
  fs.readFile(companyname + '/narration.json', function (err, data) {
    ////console.log("\n\n key:"+companyname)
    if (data+""== "") {
      json=req.body.value
      var mydata={}
      finalindex=0
      mydata[key]=[{ name: input1+"" }]
      ////console.log("\n\n key:"+key)
      json.narrations.push(mydata)
      ////console.log("\n json:"+JSON.stringify(json))
    }
    else
    {var flag=0;
      json=JSON.parse(data);
      json.narrations.filter(function(item,index){
        if(item[key]+""!="undefined")
        {var mydata={name: input1+""}
          json.narrations[index][key].push(mydata)
          flag=1
          finalindex=index
          ////console.log("\n json2:"+JSON.stringify(json))
        }
        else
        {
          if(flag==0&&index==json.narrations.length-1)
          {
            var mydata={}
            mydata[key]=[{ name: input1+"" }]
            json.narrations.push(mydata)
            finalindex=index+1
          }
        }
      })
     
    }

    fs.writeFile(companyname + '/narration.json', JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      ////console.log("Updated the data")
      res.send(json.narrations[finalindex][key]);
      return;
    });
})

})

     
      app.post("/modifyNarration",function(req,res){
        var companyname=req.body.companyname;
        var json;
        
        var finalindex=req.body.index;
      var input1=req.body.inputval
      var key=req.body.key
      
      fs.readFile(companyname+"/narration.json",function (err, data) {
        json=JSON.parse(data);
        json.narrations.filter(function(item,index){
          if(item[key]+""!="undefined")
          {////console.log(json.narrations[index][key]+" "+finalindex)
            json.narrations[index][key][finalindex].name=input1
            
    fs.writeFile(companyname + '/narration.json', JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      ////console.log("Updated the data")
      res.send(json.narrations[index][key]);
      return;
    });
          }
        })

      })
      })

      app.post('/deleteNarration',function(req,res){
        ////console.log("\n\n"+"here")
      var companyname=req.body.companyname;
      var finalindex=req.body.index;
      var input1=req.body.inputval
      var key=req.body.key
    
      var directory=companyname+"/narration.json"
      var json
      fs.readFile(directory, function (err, data) {
        ////console.log("data:"+directory)
      if(data+""!="")
      { json = JSON.parse(data);
      json.narrations.filter(function(item,index){
        if(item[key]+""!="undefined")
        {
          if(item[key].length==1)
          {json.narrations.splice(index,1)}
          else
          {
          json.narrations[index][key].splice(parseInt(finalindex+"")-1,1)
         
         
        }
          fs.writeFile(directory, JSON.stringify(json), function (err) {
            if (err) throw err;
            res.send(json)
          //  ////console.log('The "data to append" was appended to file!');
            res.end("heo");
        });
        }
      })
      }
      
      })
      
      });

//Narrations api end

//Ledger apis

app.post("/modifyLedgerName",function(req,res){
  var json;
 var index=req.body.index
 var newVal=req.body.newval
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)
  fs.readFile(companyName + '/ledger_master.json', function (err, data) {

    json=JSON.parse(data)
    json.ledgerdata[index].AcName=newVal

    fs.writeFile(companyName + '/ledger_master.json',JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      ////console.log("Updated the data")
      res.send({ 'dooda': "updated" });
      return;})
  })
})

app.post('/saveLedger', function (req, res) {
  var json;
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)

  var model = {

    "ledgerdata": [

    ]


  }

  fs.readFile(companyName + '/ledger_master.json', function (err, data) {
    flag2 = 0;
    if (data == "") {
      model.ledgerdata.push(req.body.dataAll);
      model.ledgerdata[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;

      json.ledgerdata.filter(function (item) {

        if (item.index === req.body.dataAll.index) {

          flag = 1


          item.AcCode = req.body.dataAll.AcCode;
          item.AcName = req.body.dataAll.AcName;
          item.Address1 = req.body.dataAll.Address1;
          item.RCNo = req.body.dataAll.RCNo;
          item.Address2 = req.body.dataAll.Address2;
          item.Range = req.body.dataAll.Range;
          item.City = req.body.dataAll.City;
          item.Division = req.body.dataAll.Division;
          item.PinCode = req.body.dataAll.PinCode;
          item.Collectorate = req.body.dataAll.Collectorate;
          item.Distt = req.body.dataAll.Distt;
          item.DGSTNo = req.body.dataAll.DGSTNo;
          item.SACCode = req.body.dataAll.SACCode;
          item.Distance = req.body.dataAll.Distance;
          item.OpeningBalanceDr = req.body.dataAll.OpeningBalanceDr;
          item.ContactPerson = req.body.dataAll.ContactPerson;
          item.OpeningBalanceCr = req.body.dataAll.OpeningBalanceCr;
          item.InttDepcRate = req.body.dataAll.InttDepcRate;
          item.ContactNo = req.body.dataAll.ContactNo;
          item.TDSRate = req.body.dataAll.TDSRate;
          item.MEmailIDArea = req.body.dataAll.MEmailIDArea;
          item.TGSTShare = req.body.dataAll.TGSTShare;
          item.AgentGroup = req.body.dataAll.AgentGroup;
          item.Quantitiy = req.body.dataAll.Quantitiy;
          item.PAN = req.body.dataAll.PAN;
          item.BankAcNo = req.body.dataAll.BankAcNo;
          item.TDSAcNo = req.body.dataAll.TDSAcNo;
          item.CompositionYN = req.body.dataAll.CompositionYN;
          item.Works = req.body.dataAll.Works;
          item.NameAddress1 = req.body.dataAll.NameAddress1;
          item.NameAddress2 = req.body.dataAll.NameAddress2;
          for (let i = 0; i < json.ledgerdata.length; i++) {
            json.ledgerdata[i].index = parseInt(i)

          }
          fs.writeFile(companyName + '/ledger_master.json', JSON.stringify(json), function (err) {
            if (err) throw err;
            // //console.log('The "data to append" was appended to file!');
            ////console.log("Updated the data")
            res.send({ 'dooda': "updated" });
            return;
          });

          flag2 = 1;

        }
        else
          ++index;

      })
      if (flag != 1) { json.ledgerdata.push(req.body.dataAll); }

    }

    if (flag2 == 0) {
      for (let i = 0; i < json.ledgerdata.length; i++) {
        json.ledgerdata[i].index = parseInt(i)
      }
      fs.writeFile(companyName + '/ledger_master.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        ////console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
    if (flag2 == 2) {

      fs.writeFile(companyName + '/ledger_master.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        ////console.log("written the data")
        res.send({ 'dooda': "saved" });
      });
    }
  })
});


app.post('/getLedger', function (req, res) {
  var json;

  var companyName = req.body.companyname

  fs.readFile(companyName + '/ledger_master.json', function (err, data) {
    if (data == "") {
      json = {
        AcName: "no data"
      };
      ////console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.requiredIndex)
      if (s != -999) {
        if (s >= 0 && s < json.ledgerdata.length) {

          res.send(
            json.ledgerdata[parseInt(req.body.requiredIndex)]
          )
        }

        else {
          ////console.log("sending out of bounds cuz req is: " + s)
          res.send(
            {

              AcName: "out of bounds"
            }
          )
        }
      }

      else {
        res.send(
          json.ledgerdata[json.ledgerdata.length - 1]
        )
      }

    }

  })
});

app.post('/deleteLedger', function (req, res) {
  var json;
  var companyName = req.body.companyname

  fs.readFile(companyName + '/ledger_master.json', function (err, data) {
    if (data == "") {

      ////console.log("sending no data")
      res.send(
        "no data found"
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.indexToDelete)
      ////console.log("index to delete is: " + s)
      json.ledgerdata.splice(s, 1);
      for (let i = 0; i < json.ledgerdata.length; i++) {
        json.ledgerdata[i].index = parseInt(i)

      }

      fs.writeFile(companyName + '/ledger_master.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        ////console.log("Deleted the data")

        res.send("Deleted the data");

      });


    }

  })
});
//ledger apis end

///annexure apis
app.post('/SaveAnnexure', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in saving annexure block")
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)

  var model = {

    "annexures": [

    ]


  }

  fs.readFile(companyName + '/annexure.json', function (err, data) {
    flag2 = 0;
    // ////console.log(data+"")
    if (data + "" === "") {
      model.annexures.push(req.body.dataAll);
      model.annexures[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      //////console.log(JSON.stringify(json));
      json.annexures.filter(function (item) {
        //////console.log(req.body.dataAll.name)
        if (item.index === req.body.dataAll.index) {
          //////console.log("duplicate Alert!!!!!")
          flag = 1
          // res.send(
          //   { 'dooda': "duplicate" }
          // );

          item.name = req.body.dataAll.name;
          item.code = req.body.dataAll.code;
          item.details = req.body.dataAll.details;
          item.description = req.body.dataAll.description;
          item.debit = req.body.dataAll.debit;
          item.drcr = req.body.dataAll.drcr;
          item.annx = req.body.dataAll.annx;
          item.group = req.body.dataAll.group;
          for (let i = 0; i < json.annexures.length; i++) {
            json.annexures[i].index = parseInt(i)

          }
          fs.writeFile(companyName + '/annexure.json', JSON.stringify(json), function (err) {
            if (err) throw err;
            // ////console.log('The "data to append" was appended to file!');
            ////console.log("Updated the data")
            res.send({ 'dooda': "updated" });
            return;
          });

          // else {
          // let buff  = {
          //    name : req.body.dataAll.name,
          //     code : req.body.dataAll.code,
          //     details : req.body.dataAll.details,
          //     description : req.body.dataAll.description,
          //     debit : req.body.dataAll.debit,
          //     drcr : req.body.dataAll.drcr,
          //    annx : req.body.dataAll.annx,
          //   group : req.body.dataAll.group,
          //   index : req.body.dataAll.index,
          //   }
          //   json.annexures.push(buff)
          //   fs.writeFile(companyName + '/annexure.json', JSON.stringify(json), function (err) {
          //     if (err) throw err;
          //     // ////console.log('The "data to append" was appended to file!');
          //     ////console.log("written the data")
          //     res.send({ 'dooda': "saved" });
          //     return;
          //   });
          // }
          flag2 = 1;

        }
        else
          ++index;

      })
      if (flag != 1) { json.annexures.push(req.body.dataAll); }

    }

    if (flag2 == 0) {
      let ind = "";

      //let parsed = JSON.parse(info)
      // ind = parsed.annexures[parsed.annexures.length - 1].index;
      // ////console.log("last index is: " + ind)
      for (let i = 0; i < json.annexures.length; i++) {
        json.annexures[i].index = parseInt(i)

      }

      fs.writeFile(companyName + '/annexure.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        // ////console.log('The "data to append" was appended to file!');
        ////console.log("written the data")
        res.send({ 'dooda': "saved" });

      });


    }
    if (flag2 == 2) {
      // Existing details case writing file.

      fs.writeFile(companyName + '/annexure.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        // ////console.log('The "data to append" was appended to file!');
        ////console.log("written the data")
        res.send({ 'dooda': "saved" });

      });
    }


  })
});

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// Return the data requested by annexure form

app.post('/GetAnnexure', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in returning annexure data block")
  var companyName = req.body.companyname
  // ////console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/annexure.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      json = {
        name: "no data"
      };
      ////console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.requiredIndex)
      //////console.log(JSON.stringify(json));
      if (s != -999) {
        if (s >= 0 && s < json.annexures.length) {

          res.send(
            json.annexures[parseInt(req.body.requiredIndex)]
          )
        }

        else {
          ////console.log("sending out of bounds cuz req is: " + s)
          res.send(
            {

              name: "out of bounds"
            }
          )
        }
      }

      else {
        res.send(
          json.annexures[json.annexures.length - 1]
        )
      }

    }

  })
});

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// Return the data requested by annexure form

app.post('/GetAllAnnexureNames', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in returning annexure data block")
  var companyName = req.body.companyname
  // ////console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/annexure.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      json = {
        names: ["no data"]
      };
      ////console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)

      var model = {
        names: []
      }
      //////console.log(JSON.stringify(json));


      for (let i = 0; i < json.annexures.length; i++) {
        model.names.push(json.annexures[i])
      }
      res.send(model)


    }

  })
});

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// Delete data sent by annexure form

app.post('/DeleteAnnexure', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in deleting annexure block")
  var companyName = req.body.companyname
  ////console.log("companyName to del annex from:" + companyName)

  fs.readFile(companyName + '/annexure.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {

      ////console.log("sending no data")
      res.send(
        "no data found"
      );

    }
    else {
      json = JSON.parse(data)

      let s = parseInt(req.body.indexToDelete)
      ////console.log("index to delete is: " + s)
      json.annexures.splice(s, 1);
      ////console.log("spliced the fuck outta it")
      for (let i = 0; i < json.annexures.length; i++) {
        json.annexures[i].index = parseInt(i)

      }

      fs.writeFile(companyName + '/annexure.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        // ////console.log('The "data to append" was appended to file!');
        ////console.log("DEleted the data")

        res.send("DEleted the data");

      });


    }

  })
});
//annexur apis closed


// New Stock accounts APIs start
app.post("/modifyStockName",function(req,res){
  var json;
 var index=req.body.index
 var newVal=req.body.newval
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)
  fs.readFile(companyName + '/stock_master.json', function (err, data) {

    json=JSON.parse(data)
    json.stock_accounts[index].Name=newVal

    fs.writeFile(companyName + '/stock_master.json',JSON.stringify(json), function (err) {
      if (err) throw err;
      // //console.log('The "data to append" was appended to file!');
      // //console.log("Updated the data")
      res.send({ 'dooda': "updated" });
      return;})
  })
})


app.post('/SaveStockAccount', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in saving stock account block")
  var companyName = req.body.companyname
  // //console.log("companyName is:" + companyName)

  var model = {

    "stock_accounts": [

    ]


  }

  fs.readFile(companyName + '/stock_master.json', function (err, data) {
    flag2 = 0;
    //console.log(data+"")
    if (data + "" === "") {
      model.stock_accounts.push(req.body.dataAll);
      
      model.stock_accounts[0].index = 0;
      json = model;
      flag2 = 2;
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      //console.log(JSON.stringify(json));
      json.stock_accounts.filter(function (item) {
        //console.log(req.body.dataAll.name)
        if (item.Accode === req.body.dataAll.Accode) {
          
          if(req.body.isEditingOld == true)
          {
            json.stock_accounts[index ] = req.body.dataAll
            flag = 1;
            // //console.log(json.stock_accounts)
            for (let i = 0; i < json.stock_accounts.length; i++) {
              json.stock_accounts[i].index = parseInt(i)
      
            }
           
          }

          if( req.body.isEditingOld == false)
          {
            // //console.log("duplicate Alert!!!!!")
            flag = 1
            res.send(
              { 'dooda': "duplicate" }
            );

            flag2 = 1;
          }

        }
        else
          ++index;

      })
      if (flag != 1) {
        json.stock_accounts.push(req.body.dataAll);
      }

    }

    if (flag2 == 0) {
      // No duplicate, clear to write the new data
      for (let i = 0; i < json.stock_accounts.length; i++) {
        json.stock_accounts[i].index = parseInt(i)

      }
      fs.writeFile(companyName + '/stock_master.json', JSON.stringify(json), function (err) {
        if (err) throw err;

        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });


    }
    if (flag2 == 2) {
      // Empty db, write it all.

      fs.writeFile(companyName + '/stock_master.json', JSON.stringify(json), function (err) {
        if (err) throw err;
        //console.log('The "data to append" was appended to file!');
        // //console.log("written the data")
        res.send({ 'dooda': "saved" });

      });
    }


  })
});


app.post('/GetStockAccount', function (req, res) {
  var json;

  //console.log(JSON.stringify(req.body));
  // //console.log("in returning stock accounts block")
  var companyName = req.body.companyname
  //  //console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/stock_master.json', function (err, data) {
    //console.log(data+"")
    if (data + "" === "") {
      json = {
        'stock_accounts' : []
      };
      // //console.log("sending no data")
      res.send(
        json
      );

    }
    else {
      json = JSON.parse(data)
      //console.log(JSON.stringify(json));

      if(req.body.note == 'all')
    {
      var model = {
        stock_accounts: []
      }
      //console.log(JSON.stringify(json));


      for (let i = 0; i < json.stock_accounts.length; i++) {
        model.stock_accounts.push(json.stock_accounts[i])
      }
      res.send(model)

    }
    else if(req.body.note == 'first')
    {
      
     
        res.send(json.stock_accounts[0]);
      
    }
    else if(req.body.note == 'last')
    {
      res.send(json.stock_accounts[json.stock_accounts.length -1]);
    }
    else if(req.body.note == 'prev')
    {
      if (parseInt(req.body.reqIndex) == -999) {
        // //console.log("initial, so sending last data")
        res.send(json.stock_accounts[json.stock_accounts.length -1])
      }
      else if(parseInt(req.body.reqIndex) >0 && parseInt(req.body.reqIndex) <= json.stock_accounts.length)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json.stock_accounts[parseInt(req.body.reqIndex) - 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'next')
    {
      if (parseInt(req.body.reqIndex) == -999) {
        ////console.log("initial, so sending last data")
        res.send(json.stock_accounts[json.stock_accounts.length -1])
      }
      else if(parseInt(req.body.reqIndex) >=0 && parseInt(req.body.reqIndex) < json.stock_accounts.length -1)
      {
        ////console.log("sending data at required index: "+ req.body.reqIndex)
        res.send(json.stock_accounts[parseInt(req.body.reqIndex) + 1])
      }
      else {
        res.send('outofbounds');
      }
    }
    else if(req.body.note == 'selected')
    {
      for (let i = 0; i < json.stock_accounts.length; i++) {
        if(json.stock_accounts[i].Name == req.body.selectedName)
        {
          ////console.log("sending selected data found to be: "+ json.stock_accounts[i].Name)
          res.send(json.stock_accounts[i]);
        }
      }
        
      
    }
    }

  })
});


app.post('/DeleteStockAccount', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in deleting stock accounts block")
  var companyName = req.body.companyname
   ////console.log("companyName is:" + companyName)

  fs.readFile(companyName + '/stock_master.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      
      ////console.log("sending no data")
      res.send(
       "emptydb"
      );

    }
    else {
      json = JSON.parse(data)
      //////console.log(JSON.stringify(json));
        json.stock_accounts.splice(parseInt(req.body.idToDelete) , 1)
        fs.writeFile(companyName + '/stock_master.json', JSON.stringify(json), function (err) {
          if (err) throw err;
          // ////console.log('The "data to append" was appended to file!');
          ////console.log("written the data")
          res.send('deleted');
  
        });
    }

  })
});


// New Stock accounts APIs end


// forget passowrd  Company Profile form  
app.post('/forgetpassword', function (req, res) {
  const email = req.body.email;
  const password = req.body.password;

  fs.readFile('enquiry.json', function (_err, data) {
    var json = JSON.parse(data);
    //////console.log(email);
    for (var i = 0; i < json.companyprofile.length; i++) {
      if (json.companyprofile[i].email === email) {
        json.companyprofile[i].password = password;
        // ////console.log(json.companyprofile[i].password);
        var newdata = JSON.stringify(json);
        fs.writeFile("enquiry.json", newdata, function (err) {
          if (err) throw err;
          //  ////console.log('The "data to append" was appended to file!');
          res.end("heloo");
        });
        break;

      }
    }

  });
});


// //Save User Repored
// app.post('/SaveUserRecored',function(req,res){
//   req.body.password=bcrypt.hashSync(req.body.password,10)
//   ////console.log(req.body.password)
//   fs.readFile('enquiry.json', function (err, data) {
//     var json = JSON.parse(data);
//     json.companyprofile.push(req.body);

//     fs.writeFile("enquiry.json", JSON.stringify(json), function (err) {
//         if (err) throw err;
//         ////console.log('The "data to append" was appended to file!');
//         res.end("helool");
//     });
// })
// })


//Store User Roles Permission And Report
app.post('/UserRoleDetails', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in userroledetail")
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)

  var value = { "userRoles": [] }

  fs.readFile(companyName + '/rolename.json', function (err, data) {
    ////console.log(data + "")
    if (data + "" === "") {
      json = req.body.myval
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      //////console.log(JSON.stringify(json));
      json.userRoles.filter(function (item) {

        if (item.roleuser === req.body.myval.userRoles[0].roleuser) {
          json.userRoles[index] = req.body.myval.userRoles[0]

          flag = 1
        }
        else
          ++index;

      })
      if (flag != 1)
        json.userRoles.push(req.body.myval.userRoles[0]);
    }

    fs.writeFile(companyName + '/rolename.json', JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      res.end();
    });
  })
});

// Delete the existing User Roles
app.post('/DeleteUserRole', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in user role delete")
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)

  var value = { "userRoles": [] }

  fs.readFile(companyName + '/rolename.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      res.end();
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      //////console.log(JSON.stringify(json));
      json.userRoles.filter(function (item) {
        ////console.log(req.body.roleuser[0])
        if (item.roleuser === req.body.roleuser[0]) {
          json.userRoles.splice(index, 1);

          flag = 1
        }
        else
          ++index;

      })
     // if (flag != 1)
        //console.log("can't find role to delete")
    }

    fs.writeFile(companyName + '/rolename.json', JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      res.end();
    });
  })
});

//----------------------------------------------------------------------------------------------------------------
// Modify the existing User Roles
app.post('/ModifyUserRole', function (req, res) {
  var json;

  // ////console.log(JSON.stringify(req.body));
  ////console.log("in user role modify")
  var companyName = req.body.companyname
  ////console.log("companyName is:" + companyName)

  var value = { "userRoles": [] }

  fs.readFile(companyName + '/rolename.json', function (err, data) {
    // ////console.log(data+"")
    if (data + "" === "") {
      res.end();
    }
    else {
      json = JSON.parse(data)
      var flag = 0;
      var index = 0;
      //////console.log(JSON.stringify(json));
      json.userRoles.filter(function (item) {
        ////console.log(req.body.roleuserToModify)
        if (item.roleuser === req.body.roleuserToModify) {

          json.userRoles[index].roleuser = req.body.roleuserNewValue;

          flag = 1
        }
        else
          ++index;

      })
      //if (flag != 1)
        ////console.log("can't find role to modify")
    }

    fs.writeFile(companyName + '/rolename.json', JSON.stringify(json), function (err) {
      if (err) throw err;
      // ////console.log('The "data to append" was appended to file!');
      res.end();
    });
  })
});



//send User Role name on user select option  
app.post('/RoleName', function (req, res) {
  var companyname = req.body.companyname
  ////console.log(companyname + " is this")
  var arr = [];
  fs.readFile(companyname + '/rolename.json', function (_err, data) {
    if (data + "" === "") {
      ////console.log("rolename")
    }
    else {
      var json = JSON.parse(data);
      //  ////console.log(json);
      var items = json.userRoles.filter(function (item) {

        return (item['roleuser'] != "");
      })

      for (i = 0; i < items.length; i++) {
        arr[i] = items[i].roleuser;
      }

      res.send({ arr });
    }

  });

})



app.get('/companyprofiledetails', function (req, res) {
  res.send(enquiry);
});

app.get('/onlinecomapnydata', function (req, res) {

  var selectcompany = "select companydetails from `ezmata`";
  conn.connection.query(selectcompany, function (err, response) {
    if (err) throw err;
    fs.writeFile("enquiry.json", response, function (err) {
      if (err) throw err;
      //  ////console.log('The "data to append" was appended to file!');
    });
    // ////console.log(response);
    res.send(response)
    res.end();

  });

});


app.post('/UserRoleDetails', function (req, res) {
  ////console.log("inuserrolesdetails2")
  fs.writeFile("userRoles.json", JSON.stringify(req.body), function (err) {
    if (err) throw err;
    //  ////console.log('The "data to append" was appended to file!');
    res.redirect();
  });


});


app.post('/', function (req, res) {
  res.send(req.body);
  var str = JSON.stringify(req.body);


  let userInput = {
    companyprofile: [
      {
        format: req.body.format,
        companyname: req.body.companyname,
        date: req.body.date,
        date2: req.body.date2,
        password: bcrypt.hashSync(req.body.password, 10),
        landline: req.body.landline,
        companytype: req.body.companytype,
        mobileno: req.body.mobileno,
        email: req.body.email,
        address: req.body.address,
        ownername: req.body.ownername,
        city: req.body.city,
        distt: req.body.distt,
        state: req.body.state,
        pincode: req.body.pincode,
        pancard: req.body.pancard,
        tdscircle: req.body.tdscircle,
        tdsno: req.body.tdsno,
        style: req.body.style,
        commodity: req.body.commodity,
        registrationno: req.body.registrationno,
        division: req.body.division,
        collectorate: req.body.collectorate,
        range: req.body.range,
        aadharudyog: req.body.aadharudyog,
        cinno: req.body.cinno,
        jobwork: req.body.jobwork,
        gstno: req.body.gstno,
        gsttype: req.body.gsttype,
        filedata: req.body.filedata,
        type: "admin"

      }
    ],
    userslist: []
  }
  var companyname = req.body.companyname;


  fs.readFile('enquiry.json', function (err, data) {

    if (data == "") {

      fs.writeFile("enquiry.json", str, function (err) {
        if (err) throw err;
        //  ////console.log('The "data to append" was appended to file!');

      });
    }
    else {

      var json = JSON.parse(data);
      json.companyprofile.push(userInput.companyprofile[0]);
      num = JSON.stringify(json)


      //  ////console.log(num);
      fs.writeFile("enquiry.json", JSON.stringify(json), function (err) {
        if (err) throw err;
        //   ////console.log('The "data to append" was appended to file!');              
      });
    }
  })

  var str = JSON.stringify(userInput);

  var insertQuery = "CREATE TABLE  `" + companyname + "` (`companyid` int NOT NULL AUTO_INCREMENT,`companydetails` text,`annexure` text,`bank` text,`cash` text,`ledger_master` text,`jour` text,`narration` text,`prodcard` text,`sal_setup` text,`sale_win` text,`sale_sale1_pur_pur1` text,`schedule` text,`security` text, `tax` text,`stock_master` text,`fa` text,PRIMARY KEY (companyid))";

  conn.connection.query(insertQuery, function (err, response) {
    if (err) throw err;

    res.end();

  });

  createnewcompant(companyname);
  fs.readFile(companyname + '/companydetails.json', function (err, data) {
    if (data == "") {

      fs.writeFile(companyname + "/companydetails.json", str, function (err) {
        if (err) throw err;
        //////console.log('The "data to append" was appended to file!');

      });
    }
    else {

      var json = JSON.parse(data);
      json.companyprofile.push(userInput.companyprofile[0]);
      num = JSON.stringify(json)

      var insertQuery = "insert into `" + companyname + "` (`companydetails`) VALUES (?)";

      var query = conn.connection.format(insertQuery, [num]);
      conn.connection.query(query, function (err, response) {
        if (err) throw err;
        res.end();
      });
      //     ////console.log(num);
      fs.writeFile(companyname + "/companydetails.json", JSON.stringify(json), function (err) {
        if (err) throw err;
        //  //console.log('The "data to append" was appended to file!');              
      });
    }
  })

});

var createnewcompant = function (companyname) {
  var fs = require('fs');
  var dir = './' + companyname;
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
    //   //console.log('hogya');
  }
  var files = ['companydetails.json', 'annexure.json', 'user.json', 'rolename.json', 'roletype.json', 'bank.json', 'cash.json', 'ledger_master.json', 'jour.json', 'narration.json', 'procard.json', 'sal_setup.json', 'sale_win.json', 'sale_sale1_pur_pur1.json', 'schedule.json', 'security.json', 'tax.json', 'stock_master.json', 'fa.json'];
  //  //console.log( dir+"/compan.json");
  for (file in files) {
    fs.writeFile(dir + "/" + files[file], "", function (err) {
      if (err) throw err;
      //  //console.log(files[file]);             
    });
  }
}


app.listen(2000, function () {
  //console.log('Example app listening on port 2000!');
});



app.get('/getCompanyList', function (req, res) {
  res.send(num);
});

app.get('/register', (req, res, next) => {

  var name = req.param('c_name');
  var city = req.param('c_city');
  var ownername = req.param('c_ownername');
  var distt = req.param('c_distt');
  var state = req.param('c_state');
  var startdate = req.param('c_startdate');
  var enddate = req.param('c_enddate');
  var email = req.param('c_email');
  var password = req.param('c_password');

  let userInput = {
    companyprofile: [
      {
        c_name: name,
        c_city: city,
        c_ownername: ownername,
        c_distt: distt,
        c_state: state,
        c_startdate: startdate,
        c_enddate: enddate,
        c_email: email,
        c_password: password,
      },
    ]
  };



  var str = JSON.stringify(userInput);

  //  //console.log(str);


  fs.readFile('enquiry.json', function (err, data) {
    var json = JSON.parse(data);
    json.companyprofile.push(userInput.companyprofile);
    res.send(str + "  " + JSON.stringify(json));
    fs.writeFile("enquiry.json", JSON.stringify(json), function (err) {
      if (err) throw err;
      //   //console.log('The "data to append" was appended to file!');
      res.redirect();
    });
  })
});


app.get('/companydetails', (req, res, next) => {

  var name = req.params;
  res.send(name);


});


app.post('/syncOnline', function (req, res) {
  var companyprofiles = "companyprofiles";

  fs.readFile('enquiry.json', function (err, data) {

    if (data == "") {



    }
    else {

      json = JSON.parse(data);

      num = JSON.stringify(json)


    }
  })

  var d = 0;
  var insertQuery = "CREATE TABLE  `" + companyprofiles + "` (`companyid` int NOT NULL AUTO_INCREMENT,`companydetails` text,`annexure` text,`bank` text,`cash` text,`ledger_master` text,`jour` text,`narration` text,`prodcard` text,`sal_setup` text,`sale_win` text,`sale_sale1_pur_pur1` text,`schedule` text,`security` text, `tax` text,`stock_master` text,`fa` text,PRIMARY KEY (companyid))";

  conn.connection.query(insertQuery, function (err, response) {
    if (err) { res.end(); };

    var insertQuery = "insert into `" + companyprofiles + "` (`companydetails`) VALUES (?)";

    for (row in json.companyprofile) {
      var val = JSON.stringify(json.companyprofile[row])
      var query = conn.connection.format(insertQuery, [val]);
      //  //console.log(++d);
      conn.connection.query(query, function (err, response) {
        if (err) throw err;

        res.end();

      });
    }


  });



  var c = 0;
  var k = 0;

  var fj = [];

  json.companyprofile.forEach(function (company) {

    var companyname = company.companyname;
    //console.log(" comp name : " + companyname);
    if (companyname != "Shkun") {
      fs.readFile(companyname + "/" + "companydetails" + ".json", function (err, data) {

        if (data == "") {
          var finalJson = "";


        }
        else {

          var finalJson = JSON.parse(data);


          fj[c] = finalJson
          //        //console.log(JSON.stringify(finalJson)+" is this yay")
          ++c;
          var test = 0;
          //      //console.log("\n"+companyname+" "+c)
          var insertQuery = "CREATE TABLE  `" + companyname + "` (`companyid` int NOT NULL AUTO_INCREMENT,`companydetails` text,`annexure` text,`bank` text,`cash` text,`ledger_master` text,`jour` text,`narration` text,`prodcard` text,`sal_setup` text,`sale_win` text,`sale_sale1_pur_pur1` text,`schedule` text,`security` text, `tax` text,`stock_master` text,`fa` text,PRIMARY KEY (companyid))";

          conn.connection.query(insertQuery, function (err, response) {
            if (err) { res.end(); };

            var testquery = "SELECT * FROM `" + companyname + "` WHERE companyid=1"
            testq = conn.connection.format(testquery);
            conn.connection.query(testq, function (err, response) {
              if (err) throw err;
              //        //console.log(JSON.stringify(response)+" yay")
              if ((response + "").length > 0) { test = 1; }

              //      //console.log("test val="+ test)

              if (test == 1)
                insertQuery = "UPDATE `" + companyname + "` SET companydetails=(?) WHERE companyid=1";
              else
                insertQuery = "INSERT INTO `" + companyname + "` (`companydetails`) VALUES (?)"

              //    //console.log("Working"+ insertQuery);
              var query = conn.connection.format(insertQuery, [JSON.stringify(fj[k++])]);
              conn.connection.query(query, function (err,

              ) {
                if (err) throw err;

              });

            })



          });

        }


      })
    }



  });

  k = 0;

});




