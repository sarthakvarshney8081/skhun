
<style>
.select-large input.vs-select--input {
  padding: 5px;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}
#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

.vs-button {
  display: inline-block;
}
.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
}

.column1 {
  float: left;
  width: 75%;
  padding: 10px;
}

.column2 {
  float: right;
  width: 25%;
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>

<template>
  <div class="vx-card p-6" style>
    <vs-popup classContent="popup-example" title="Purchase Setup" :active.sync="popupActivepurchaseSetup"  fullscreen>
       <modalpurchasesetup v-model="modalpurchasesetupOpen" />
   </vs-popup> 
   <vs-popup      
 classContent="popup-example"
      title="Narrations"
      name="popupActive3"
      :active.sync="popupActiveNarration"
      >
       <modalnarration 
      ref="childComponent"
      :parentData="narrationtypename"
       v-model="modalOpenNarration" v-on:childToParentNarration="onChildClickNarration" :SearchText="searchlabel"/>
   </vs-popup>

 <vs-popup classContent="popup-example" title="Account Form" :active.sync="popupActive2" >
       <modal v-model="modalOpen" v-on:childToParent="onChildClick" :SearchText="searchlabel" ref="childComponentLedger"/>
   </vs-popup>

    <div id="manufacturerpop">
      <vs-popup
        classContent="popup"
        title="Manufacturer Information"
        :active.sync="manufacturerpop"
        id="manufacturerpop"
        name="manufacturerpop"
      >
       <tr>
              <vs-td style="padding-right:10px">Supplier</vs-td>
              <vs-td>
                <vs-input class="w-full" size="small" type="text" placeholder="supplier" v-model="man_supplier" />
              </vs-td>
            </tr>
            <br/>
        <div class="row">
          <div class="column">
            <tr>
              <vs-td>Bill No.</vs-td>
              <vs-td>
                <vs-input class="w-full" size="medium" type="text" placeholder="bill no." v-model="man_billno"/>
              </vs-td>
            </tr>

            <tr>
              <vs-td>Weight</vs-td>
              <vs-td>
                <vs-input class="w-full" size="medium" type="text" placeholder="weight" v-model="man_weight" />
              </vs-td>
            </tr>

            <tr>
              <vs-td>Rate</vs-td>
              <vs-td>
                <vs-input class="w-full" size="medium" type="text" placeholder="rate" v-model="man_rate"/>
              </vs-td>
            </tr>

            <tr>
              <vs-td>Ass. Value</vs-td>
              <vs-td>
                <vs-input class="w-full" size="medium" type="text" placeholder="ass value" v-model="man_assvalue" />
              </vs-td>
            </tr>
          </div>
          <div class="column">
            <tr>
              <vs-td>Bill Date</vs-td>
              <vs-td>
                <vs-input class="w-full" size="small" type="text" placeholder="bill date." v-model="man_billdate"/>
              </vs-td>
            </tr>

            <br />

            <tr>
              <vs-td>Page No.</vs-td>
              <vs-td>
                <vs-input class="w-full" size="small" type="text" placeholder="page no" v-model="man_pageno"/>
              </vs-td>
            </tr>

            <tr>
              <vs-td>Entry No.</vs-td>
              <vs-td>
                <vs-input class="w-full" size="small" type="text" placeholder="entry no" v-model="man_entryno" />
              </vs-td>
            </tr>
            <br />
            <tr size="large">
              <vs-td>
                <vs-checkbox  vs-value="importedgoods" v-model="man_impgoods"/>
              </vs-td>
              <vs-td>Imp. goods</vs-td>
            </tr>
          </div>
        </div>
        <div class="row">
          <div class="column1">
            <tr>
              <td style="padding-left:10px;">B.E.D @</td>

              <td style="padding-left:10px;" class="tdInputsmall">
                <vs-input class="w-full" size="small" type="text"  v-model="man_bed1"/>
              </td>
              <td style="padding-left:10px;">
                <vs-input class="w-full" size="small" type="text" v-model="man_bed2"/>
              </td>
            </tr>

            <tr>
              <td style="padding-left:10px;">Cess @</td>

              <td style="padding-left:10px;" class="tdInputsmall">
                <vs-input class="w-full" size="small" type="text" v-model="man_cess1" />
              </td>
              <td style="padding-left:10px;">
                <vs-input class="w-full" size="small" type="text"  v-model="man_cess2"/>
              </td>
            </tr>

            <tr>
              <td style="padding-left:10px;">Hcess @</td>

              <td style="padding-left:10px;" class="tdInputsmall">
                <vs-input class="w-full" size="small" type="text" v-model="man_hcess1" />
              </td>
              <td style="padding-left:10px;">
                <vs-input class="w-full" size="small" type="text" v-model="man_hcess2"/>
              </td>
            </tr>

            <tr>
              <td style="padding-left:10px;">A.Duty @</td>

              <td style="padding-left:10px;" class="tdInputsmall">
                <vs-input class="w-full" size="small" type="text" v-model="man_aduty1"/>
              </td>
              <td style="padding-left:10px;">
                <vs-input class="w-full" size="small" type="text" v-model="man_aduty2"/>
              </td>
            </tr>

            <tr>
              <td style="padding-left:10px;">Vat CST @</td>

              <td style="padding-left:10px;" class="tdInputsmall">
                <vs-input class="w-full" size="small" type="text" v-model="man_vatcst1"/>
              </td>
              <td style="padding-left:10px;">
                <vs-input class="w-full" size="small" type="text" v-model="man_vatcst2" />
              </td>
            </tr>
          </div>
          <div class="column2">
            <br />
            <br />
            <br />
            <vs-button size="small" title="Continue" color="primary" class="w-full">Continue</vs-button>
          </div>
        </div>
      </vs-popup>
    </div>

    <vs-popup
      classContent="popup"
      title="Add / Less Before GST"
      :active.sync="expensepopup1"
      id="expensepopup1"
      name="expensepopup1"
    >
      <div>
        <tr>
          <td style="padding-left:100px;"></td>

          <td style="padding-left:10px;">
            <font color="red">Rate</font>
          </td>
          <td style="padding-left:10px;">
            <font color="red">Value</font>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">CST @</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="cst @ rate" v-model="expense1_1" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="cst @ value"  v-model="expense1_2" />
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Freight</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="postage value"  v-model="expense1_3"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="postage value"  v-model="expense1_4"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Comm.</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="comm. rate"  v-model="expense1_5" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="comm. value"  v-model="expense1_6"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Others</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="others rate"  v-model="expense1_7" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="others value"  v-model="expense1_8"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Expense 5</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense5 rate"  v-model="expense1_9" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense5 value"  v-model="expense1_10" />
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">TCS</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs rate"  v-model="expense1_11" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs value"   v-model="expense1_12"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:100px;"></td>

          <td style="padding-left:10px;">
            <vs-button size="small" title="Exit" color="primary" class="w-full">Exit</vs-button>
          </td>
        </tr>
      </div>
    </vs-popup>

    <vs-popup
      classContent="popup"
      title="Expenses After GST"
      :active.sync="expensepopup2"
      id="expensepopup2"
      name="expensepopup2"
    >
      <div>
        <tr>
          <td style="padding-left:10px;"></td>

          <td style="padding-left:10px;">
            <font color="red">Rate</font>
          </td>
          <td style="padding-left:10px;">
            <font color="red">Value</font>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Expense 6</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 6 rate"  v-model="expense2_1" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 6 value"   v-model="expense2_2"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Expense 7</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 7 rate"   v-model="expense2_3"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 7 value"  v-model="expense2_4"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Expense 8</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 8 rate"  v-model="expense2_5"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="expense 8 rate"  v-model="expense2_6"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:100px;"></td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder  v-model="expense2_7"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder  v-model="expense2_8" />
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">Round Off</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="round off rate"  v-model="expense2_9"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="round off value"  v-model="expense2_10"/>
          </td>
        </tr>

        <tr>
          <td style="padding-left:10px;">TCS</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs rate"  v-model="expense2_11"/>
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs value"  v-model="expense2_12"/>
          </td>
        </tr>
        <tr>
          <td style="padding-left:10px;">TCS Cess</td>

          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs cess rate"  v-model="expense2_13" />
          </td>
          <td style="padding-left:10px;">
            <vs-input class="w-full" size="small" type="text" placeholder="tcs cess value"  v-model="expense2_14"/>
          </td>
        </tr>
        <br />
        <tr>
          <td style="padding-left:100px;"></td>

          <td style="padding-left:100px;"></td>
          <td style="padding-left:100px;">
            <vs-button size="small" title="Back" color="primary" class="w-full">Back</vs-button>
          </td>
        </tr>
      </div>
    </vs-popup>

    <!--header START-->
    <table width="100%" border="0" class="tables">
      <tr>
        <td width="25%"></td>
        <td width="50%">
          <center>
            <h1 class="text-primary">
              Purchase GST
              <br />
              <h4>
                <font color="grey">{{titleAction}}</font>
              </h4>
            </h1>
          </center>
        </td>
        <td width="25%" align="right">
          Today {{now}}
          <br />
          {{currentday}}
        </td>
      </tr>
      <br />
    </table>
    <!--header END-->

    <div class="flex mb-4">
      <div class="w-1/2 bg-grid-color-secondary h-12 flex">
        <table border="0" cellspacing="8" style="width:100%;" align="left">
          <tr>
            <td class="overlap">Date</td>
            <td>
              <div class="vx-col sm:w-1/6 w-full">
                <vs-input
                  type="date"
                  size="small"
                  :disabled="disDate"
                  v-model="date"
                  @change="dateChange"
                  @blur="loseDateFocus"
                  id="date"
                  style="width:180px;  margin-top:10px;"
                />
              </div>
            </td>

             <td>
              <div class="vx-col sm:w-1/6 w-full">
                <vs-button
                size="small"
                 :disabled="buttondis"
                  v-model="setup"
                  id="setup"
                  @click="openSetupModal"
                  style="width:180px;  margin-top:10px;"
                >Setup</vs-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div class="vx-col sm:w-1/3 w-full overlap">
                <span>
                  <p>V.No</p>
                </span>
              </div>
            </td>
            <td>
              <div class="vx-col sm:w-1/5">
                <vs-input
                  v-model="voucherno"
                  id="voucherno"
                  size="small"
                  @change="voucherChange"
                  :disabled="disVoucher"
                  style="width:180px; height:24px;"
                  placeholder
                />
              </div>
            </td>
          </tr>
        </table>
      </div>

      <div class="w-1/2 bg-grid-color h-12 flex">
        <table border="0" style="table-layout:fixed; width:100%;">
          <tr>
            <td></td>
            <td align="right">
              <table border="0">
                <tr>
                  <td>
                    <vs-button color="primary" icon-pack="feather" icon="icon-settings" />
                  </td>
                  <td>
                    <vs-button
                      color="primary"
                      type="filled"
                      icon-pack="feather"
                      icon="icon-align-justify"
                      style="margin-left:10px;"
                    ></vs-button>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </div>
    </div>

    <br />

    <div class="flex mb-4" style="padding-top:20px;">
      <div
        class="w-1/3 bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important; padding-bottom:20px;margin-left: 1%;"
      >
        <table border="0" cellspacing="5" style="width:100%;">
          <tr>
            <td>Supplier</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_supplier"
                @input=" showLedgerPopup('purchase1b_supplier')"               
                style="   "
                @change="enableSave"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td>City</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_city"
                style="margin-top:6px;    "
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td>GST No.</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_gstno"
                 @focus="focusedElement('gstno')"
                  v-on:keyup.18.prevent="showdescNar('gstno')"
                style="margin-top:6px;  "
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>

      <div
        class="w-1/3 bg-grid-color h-12 flex"
        style="height:100% !important; width:100% !important;  padding-bottom:20px; margin-left: 5%; margin-right: 5%;"
      >
        <table border="0" cellspacing="5" style="width:100%;">
          <tr>
            <td>Bill No.</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_billno"
                style="margin-top:6px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Bill Date</td>
            <td>
              <vs-input
                type="date"
                class="w-full"
                size="small"
                :disabled="buttondis"
                v-model="purchase1b_billdate"
                id="datepicker"
                style="width:180px;  margin-top:10px;"
              />
            </td>
          </tr>
          <tr>
            <td>Terms</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_terms"
                style="margin-top:6px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>

      <div
        class="w-1/3 bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important;  padding-bottom:20px; "
      >
        <table border="0" cellspacing="5" style="width:100%;">
          <tr>
            <td>Tax Type</td>
            <td>
              <vs-select
                v-model="purchase1b_taxtype"
                class="w-full select-large"
                style="margin-top:6px;"
                :disabled="buttondis"
              >
                <vs-select-item
                  :key="index"
                  :value="item.value"
                  :text="item.text"
                  v-for="(item,index) in taxtypelist"
                  class="w-full"
                  style="width:180px; height:25px;"
                />
              </vs-select>
            </td>
          </tr>
          <tr>
            <td>
              <font color="red">Vat Type</font>
            </td>
            <td>
              <vs-select
                v-model="purchase1b_selfinv"
                class="w-full select-large"
                style="margin-top:6px;"
                :disabled="buttondis"
              >
                <vs-select-item
                  :key="index"
                  :value="item.value"
                  :text="item.text"
                  v-for="(item,index) in vattypelist"
                  class="w-full"
                  style="width:180px; height:25px;"
                />
              </vs-select>
            </td>
          </tr>
          <tr>
            <td>Bill Cash</td>
            <td>
              <vs-select
                v-model="purchase1b_billcash"
                class="w-full select-large"
                style="margin-top:6px;"
                 autocomplete="true"
                :disabled="buttondis"
                @change="billcashcheck()"
              >
                <vs-select-item value="bill" text="Bill" class="w-full" />
                <vs-select-item value="cashmemo" text="CashMemo" class="w-full" />
              </vs-select>
            </td>
          </tr>
        </table>
      </div>
    </div>

    <!-- Table Start -->
    <div style="overflow-x:scroll" >
  <td
          >
         <table id="customers" :style="'width:'+'100'+'px;'">
        <tr>
          <th
           class="bg-primary"
          >Sr No.</th>
        </tr>

        <tr v-for="(srno, k) in srnos" :key="k">


  <td class="tdInputsmall">
            <vs-input
             class="w-full"
              size="small"
                style="margin-top:3px"
            v-model="srno.counter"
            :id="'srno' + m"
            :disabled="true"
            />
          </td>
        </tr>
        
         </table>
          </td>

<td>
      <table id="customers" :style="'width:'+totalwidth+'px;'" > 
        <tr>
          <th
            v-for="(cashheader,key) in conditionalLabels"
            class="bg-primary"
            :key="`input${key}`"
            v-show="conditionalValues[key]"
          >{{conditionalLabels[key]}}</th>
        </tr>
        <tr v-for="(cashVaucher, k) in cashVauchers" :key="k">
           <!--
          <td scope="row" style="width:30%;">     
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_itemcode"
              
              :id="'0' + k"
              @input="showStockPopup(k)"
              v-on:keyup.enter="enterKeyTrig('salegst_itemcode'+k)"
              :disabled="buttondis"
            />
          </td>
          
          <td scope="row">
            <vs-input
            
              class="w-full"
              size="small"
              v-model="cashVaucher.accountno"
              :id="'salegst_itemcode' + k"
              @keyup.down="moveDown('salegst_itemcode'+k)"
              @keyup.up="moveUp('salegst_itemcode'+k)"
              @click="showPopup(k)"
              v-on:keyup.enter="enterKeyTrig('salegst_itemcode'+k)"
              :disabled="buttondis"
            />
          </td>
          
          <td scope="row">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_description"
              @focus="focusedElement(k)"
              v-on:keyup.18.prevent="showdescNar"
              :id="'salegst_description' + k"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_pcs"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_pcs'+k)"
              :id="'salegst_pcs' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_qty"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_qty'+k)"
              :id="'salegst_qty' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_rate"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_rate'+k)"
              :id="'salegst_rate' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_amount"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_amount'+k)"
              :id="'salegst_amount' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_others"
              dir="rtl"
              v-on:keyup.shift.13.native="downArrowPopupShow(k)"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_others'+k)"
              :id="'salegst_others' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_cgst"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_cgst'+k)"
              :id="'salegst_cgst' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_sgst"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_sgst'+k)"
              :id="'salegst_sgst' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.salegst_igst"
              dir="rtl"
              @keypress="onlyNumber"
              v-on:keyup.enter="enterKeyTrig('salegst_igst'+k)"
              :id="'salegst_igst' + k"
              @input="receiptInputTrig(k)"
              :disabled="buttondis"
            />
          </td>
          -->
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[0]]" :style="{width: wid0+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head0']"
              :id="'head0' + k"
              @input="tableValidations(Object.keys(conditionalColumn)[0],'head0',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[1]]" :style="{width: wid1+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head1']"
              :id="'head1' + k"
               @input="tableValidations(Object.keys(conditionalColumn)[1],'head1',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[2]]" :style="{width: wid2+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head2']"
              :id="'head2' + k"
              @input="tableValidations(Object.keys(conditionalColumn)[2],'head2',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[3]]" :style="{width: wid3+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head3']"
              :id="'head3' + k"
              @input="tableValidations(Object.keys(conditionalColumn)[3],'head3',k)" 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[4]]" :style="{width: wid4+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head4']"
              :id="'head4' + k"
              @input="tableValidations(Object.keys(conditionalColumn)[4],'head4',k)" 
              :disabled="buttondis"
            />
          </td>
           
          <td class="tdInputsmall"  v-show="conditionalColumn[Object.keys(conditionalColumn)[5]]" :style="{width: wid5+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head5']"
              :id="'head5' + k"
              @input="tableValidations(Object.keys(conditionalColumn)[5],'head5',k)" 
              :disabled="buttondis"
            />
           
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[6]]" :style="{width: wid6+'px'}">
            <vs-input
              class="w-full"
              size="small"
             v-model="cashVaucher['head6']"
             :id="'head6' + k"
             @input="tableValidations(Object.keys(conditionalColumn)[6],'head6',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall"  v-show="conditionalColumn[Object.keys(conditionalColumn)[7]]" :style="{width: wid7+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head7']"
              @input="tableValidations(Object.keys(conditionalColumn)[7],'head7',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[8]]" :style="{width: wid8+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head8']"
              @input="tableValidations(Object.keys(conditionalColumn)[8],'head8',k)"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[9]]" :style="{width: wid9+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head9']"
              @input="tableValidations(Object.keys(conditionalColumn)[9],'head9',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[10]]" :style="{width: wid10+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head10']"
              @input="tableValidations(Object.keys(conditionalColumn)[10],'head10',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[11]]" :style="{width: wid11+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head11']"
              @input="tableValidations(Object.keys(conditionalColumn)[11],'head11',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[12]]" :style="{width: wid12+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head12']"
               @input="tableValidations(Object.keys(conditionalColumn)[12],'head12',k)" 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[13]]" :style="{width: wid13+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head13']"
              @input="tableValidations(Object.keys(conditionalColumn)[13],'head13',k)" 
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[14]]" :style="{width: wid14+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head14']"
               @input="tableValidations(Object.keys(conditionalColumn)[14],'head14',k)"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[15]]" :style="{width: wid15+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head15']"
              @input="tableValidations(Object.keys(conditionalColumn)[15],'head15',k)"
              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[16]]" :style="{width: wid16+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head16']"
               @input="tableValidations(Object.keys(conditionalColumn)[16],'head16',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[17]]" :style="{width: wid17+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head17']"
               @input="tableValidations(Object.keys(conditionalColumn)[17],'head17',k)"
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[18]]" :style="{width: wid18+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head18']"
              @input="tableValidations(Object.keys(conditionalColumn)[18],'head18',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[19]]" :style="{width: wid19+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head19']"
               @input="tableValidations(Object.keys(conditionalColumn)[19],'head19',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[20]]" :style="{width: wid20+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head20']"
               @input="tableValidations(Object.keys(conditionalColumn)[20],'head20',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[21]]" :style="{width: wid21+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head20']"
               @input="tableValidations(Object.keys(conditionalColumn)[21],'head21',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[22]]" :style="{width: wid22+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head22']"
               @input="tableValidations(Object.keys(conditionalColumn)[22],'head22',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[23]]" :style="{width: wid23+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head23']"
               @input="tableValidations(Object.keys(conditionalColumn)[23],'head23',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[24]]" :style="{width: wid24+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head24']"
               @input="tableValidations(Object.keys(conditionalColumn)[24],'head24',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[25]]" :style="{width: wid25+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head25']"
               @input="tableValidations(Object.keys(conditionalColumn)[25],'head25',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[26]]" :style="{width: wid26+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head26']"
               @input="tableValidations(Object.keys(conditionalColumn)[26],'head26',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[27]]" :style="{width: wid27+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head27']"
               @input="tableValidations(Object.keys(conditionalColumn)[27],'head27',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[28]]" :style="{width: wid28+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head28']"
               @input="tableValidations(Object.keys(conditionalColumn)[28],'head28',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[29]]" :style="{width: wid29+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head29']"
               @input="tableValidations(Object.keys(conditionalColumn)[29],'head29',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[30]]" :style="{width: wid30+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head30']"
               @input="tableValidations(Object.keys(conditionalColumn)[30],'head30',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[31]]" :style="{width: wid31+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head31']"
               @input="tableValidations(Object.keys(conditionalColumn)[31],'head31',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[32]]" :style="{width: wid32+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head32']"
               @input="tableValidations(Object.keys(conditionalColumn)[32],'head32',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[33]]" :style="{width: wid33+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head33']"
               @input="tableValidations(Object.keys(conditionalColumn)[33],'head33',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[34]]" :style="{width: wid34+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head34']"
               @input="tableValidations(Object.keys(conditionalColumn)[34],'head34',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[35]]" :style="{width: wid35+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head35']"
            @input="tableValidations(Object.keys(conditionalColumn)[35],'head35',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[36]]" :style="{width: wid36+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head36']"
               @input="tableValidations(Object.keys(conditionalColumn)[36],'head36',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[37]]" :style="{width: wid37+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head37']"
               @input="tableValidations(Object.keys(conditionalColumn)[37],'head37',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[38]]" :style="{width: wid38+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head38']"
               @input="tableValidations(Object.keys(conditionalColumn)[38],'head38',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[39]]" :style="{width: wid39+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head39']"
               @input="tableValidations(Object.keys(conditionalColumn)[39],'head39',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[40]]" :style="{width: wid40+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head40']"
               @input="tableValidations(Object.keys(conditionalColumn)[40],'head40',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[41]]" :style="{width: wid41+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head41']"
               @input="tableValidations(Object.keys(conditionalColumn)[40],'head40',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[42]]" :style="{width: wid42+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head42']"
               @input="tableValidations(Object.keys(conditionalColumn)[42],'head42',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[43]]" :style="{width: wid43+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head43']"
               @input="tableValidations(Object.keys(conditionalColumn)[43],'head43',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[44]]" :style="{width: wid44+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head44']"
               @input="tableValidations(Object.keys(conditionalColumn)[44],'head44',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[45]]" :style="{width: wid45+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head45']"
               @input="tableValidations(Object.keys(conditionalColumn)[45],'head45',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[46]]" :style="{width: wid46+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head46']"
               @input="tableValidations(Object.keys(conditionalColumn)[46],'head46',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[47]]" :style="{width: wid47+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head47']"
               @input="tableValidations(Object.keys(conditionalColumn)[47],'head47',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[48]]" :style="{width: wid48+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head48']"
               @input="tableValidations(Object.keys(conditionalColumn)[48],'head48',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[49]]" :style="{width: wid49+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head49']"
               @input="tableValidations(Object.keys(conditionalColumn)[49],'head49',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[50]]" :style="{width: wid50+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head50']"
               @input="tableValidations(Object.keys(conditionalColumn)[50],'head50',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[51]]" :style="{width: wid51+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head51']"
               @input="tableValidations(Object.keys(conditionalColumn)[51],'head51',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[52]]" :style="{width: wid52+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head52']"
               @input="tableValidations(Object.keys(conditionalColumn)[52],'head52',k)" 

              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[53]]" :style="{width: wid53+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head53']"
               @input="tableValidations(Object.keys(conditionalColumn)[53],'head53',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[54]]" :style="{width: wid54+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head54']"
               @input="tableValidations(Object.keys(conditionalColumn)[53],'head53',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[55]]" :style="{width: wid55+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head55']"
              x @input="tableValidations(Object.keys(conditionalColumn)[55],'head55',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[56]]" :style="{width: wid56+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head56']"
               @input="tableValidations(Object.keys(conditionalColumn)[56],'head56',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[57]]" :style="{width: wid57+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head57']"
               @input="tableValidations(Object.keys(conditionalColumn)[57],'head57',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[58]]" :style="{width: wid58+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head58']"
               @input="tableValidations(Object.keys(conditionalColumn)[58],'head58',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[59]]" :style="{width: wid59+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head59']"
               @input="tableValidations(Object.keys(conditionalColumn)[59],'head59',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[60]]" :style="{width: wid60+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head60']"
               @input="tableValidations(Object.keys(conditionalColumn)[60],'head60',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[61]]" :style="{width: wid61+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head61']"
               @input="tableValidations(Object.keys(conditionalColumn)[61],'head61',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[62]]" :style="{width: wid62+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head62']"
               @input="tableValidations(Object.keys(conditionalColumn)[62],'head62',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[63]]" :style="{width: wid63+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head63']"
               @input="tableValidations(Object.keys(conditionalColumn)[63],'head63',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[64]]" :style="{width: wid64+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head64']"
               @input="tableValidations(Object.keys(conditionalColumn)[64],'head64',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[65]]" :style="{width: wid65+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head65']"
               @input="tableValidations(Object.keys(conditionalColumn)[65],'head65',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[66]]" :style="{width: wid66+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head66']"
               @input="tableValidations(Object.keys(conditionalColumn)[66],'head66',k)" 

              :disabled="buttondis"
            />
          </td>
    
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[67]]" :style="{width: wid67+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head67']"
               @input="tableValidations(Object.keys(conditionalColumn)[67],'head67',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[68]]" :style="{width: wid68+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head68']"
               @input="tableValidations(Object.keys(conditionalColumn)[68],'head68',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[69]]" :style="{width: wid69+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head69']"
               @input="tableValidations(Object.keys(conditionalColumn)[69],'head69',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[70]]"  :style="{width: wid70+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head70']"
               @input="tableValidations(Object.keys(conditionalColumn)[70],'head70',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[71]]" :style="{width: wid71+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head71']"
               @input="tableValidations(Object.keys(conditionalColumn)[71],'head71',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[72]]" :style="{width: wid72+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head72']"
               @input="tableValidations(Object.keys(conditionalColumn)[72],'head72',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[73]]" :style="{width: wid73+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head73']"
               @input="tableValidations(Object.keys(conditionalColumn)[73],'head73',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[74]]" :style="{width: wid74+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head74']"
               @input="tableValidations(Object.keys(conditionalColumn)[74],'head74',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[75]]" :style="{width: wid75+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head75']"
               @input="tableValidations(Object.keys(conditionalColumn)[75],'head75',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[76]]" :style="{width: wid76+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head76']"
               @input="tableValidations(Object.keys(conditionalColumn)[76],'head76',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[77]]" :style="{width: wid77+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head77']"
               @input="tableValidations(Object.keys(conditionalColumn)[77],'head77',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[78]]" :style="{width: wid78+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head78']"
               @input="tableValidations(Object.keys(conditionalColumn)[78],'head78',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[79]]" :style="{width: wid79+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head79']"
               @input="tableValidations(Object.keys(conditionalColumn)[79],'head79',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[80]]" :style="{width: wid80+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head80']"
               @input="tableValidations(Object.keys(conditionalColumn)[80],'head80',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[81]]" :style="{width: wid81+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head81']"
               @input="tableValidations(Object.keys(conditionalColumn)[81],'head81',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[82]]" :style="{width: wid82+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head82']"
               @input="tableValidations(Object.keys(conditionalColumn)[82],'head82',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[83]]" :style="{width: wid83+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head83']"
               @input="tableValidations(Object.keys(conditionalColumn)[83],'head83',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[84]]" :style="{width: wid84+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head84']"
               @input="tableValidations(Object.keys(conditionalColumn)[84],'head84',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[85]]" :style="{width: wid85+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head85']"
               @input="tableValidations(Object.keys(conditionalColumn)[85],'head85',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[86]]" :style="{width: wid86+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head86']"
               @input="tableValidations(Object.keys(conditionalColumn)[86],'head86',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[87]]" :style="{width: wid87+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head87']"
               @input="tableValidations(Object.keys(conditionalColumn)[87],'head87',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[88]]" :style="{width: wid88+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head88']"
               @input="tableValidations(Object.keys(conditionalColumn)[88],'head88',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[89]]" :style="{width: wid89+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head89']"
               @input="tableValidations(Object.keys(conditionalColumn)[89],'head89',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[90]]" :style="{width: wid90+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head90']"
               @input="tableValidations(Object.keys(conditionalColumn)[90],'head90',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[91]]" :style="{width: wid91+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head91']"
               @input="tableValidations(Object.keys(conditionalColumn)[91],'head91',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[92]]" :style="{width: wid92+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head92']"
               @input="tableValidations(Object.keys(conditionalColumn)[92],'head92',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[93]]" :style="{width: wid93+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head93']"
               @input="tableValidations(Object.keys(conditionalColumn)[93],'head93',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[94]]" :style="{width: wid94+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head94']"
               @input="tableValidations(Object.keys(conditionalColumn)[94],'head94',k)" 
   
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[95]]" :style="{width: wid95+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head95']"
             @input="tableValidations(Object.keys(conditionalColumn)[95],'head95',k)" 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[96]]" :style="{width: wid96+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head96']"
               @input="tableValidations(Object.keys(conditionalColumn)[96],'head96',k)" 


              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[97]]" :style="{width: wid97+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head97']"
               @input="tableValidations(Object.keys(conditionalColumn)[97],'head97',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[98]]" :style="{width: wid98+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head98']"
               @input="tableValidations(Object.keys(conditionalColumn)[98],'head98',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[99]]" :style="{width: wid99+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head99']"
               @input="tableValidations(Object.keys(conditionalColumn)[99],'head99',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[100]]" :style="{width: wid100+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head100']"
               @input="tableValidations(Object.keys(conditionalColumn)[100],'head100',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[101]]" :style="{width: wid101+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head101']"
               @input="tableValidations(Object.keys(conditionalColumn)[101],'head101',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[102]]" :style="{width: wid102+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head102']"
               @input="tableValidations(Object.keys(conditionalColumn)[102],'head102',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[103]]" :style="{width: wid103+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head103']"
               @input="tableValidations(Object.keys(conditionalColumn)[103],'head103',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[104]]" :style="{width: wid104+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head104']"
               @input="tableValidations(Object.keys(conditionalColumn)[104],'head104',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[105]]" :style="{width: wid105+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head105']"
               @input="tableValidations(Object.keys(conditionalColumn)[105],'head105',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[106]]" :style="{width: wid106+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head106']"
               @input="tableValidations(Object.keys(conditionalColumn)[106],'head106',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[107]]" :style="{width: wid107+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head107']"
               @input="tableValidations(Object.keys(conditionalColumn)[107],'head107',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[108]]" :style="{width: wid108+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head108']"
               @input="tableValidations(Object.keys(conditionalColumn)[108],'head108',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[109]]" :style="{width: wid109+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head109']"
               @input="tableValidations(Object.keys(conditionalColumn)[109],'head109',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[110]]" :style="{width: wid110+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head110']"
               @input="tableValidations(Object.keys(conditionalColumn)[110],'head110',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[111]]" :style="{width: wid111+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head111']"
               @input="tableValidations(Object.keys(conditionalColumn)[111],'head111',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[112]]" :style="{width: wid112+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head112']"
             @input="tableValidations(Object.keys(conditionalColumn)[112],'head112',k)" 
  
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[113]]" :style="{width: wid113+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head113']"
              @input="tableValidations(Object.keys(conditionalColumn)[113],'head113',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[114]]" :style="{width: wid114+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head114']"
               @input="tableValidations(Object.keys(conditionalColumn)[114],'head114',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[115]]" :style="{width: wid115+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head115']"
               @input="tableValidations(Object.keys(conditionalColumn)[115],'head115',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[116]]" :style="{width: wid116+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head116']"
               @input="tableValidations(Object.keys(conditionalColumn)[116],'head116',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[117]]" :style="{width: wid117+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head117']"
               @input="tableValidations(Object.keys(conditionalColumn)[117],'head117',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[118]]" :style="{width: wid118+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head118']"
               @input="tableValidations(Object.keys(conditionalColumn)[118],'head118',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[119]]" :style="{width: wid119+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head119']"
               @input="tableValidations(Object.keys(conditionalColumn)[119],'head119',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[120]]" :style="{width: wid120+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head120']"
               @input="tableValidations(Object.keys(conditionalColumn)[120],'head120',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[121]]" :style="{width: wid121+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head121']"
               @input="tableValidations(Object.keys(conditionalColumn)[121],'head121',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[122]]" :style="{width: wid122+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head122']"
              @input="tableValidations(Object.keys(conditionalColumn)[122],'head122',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[123]]" :style="{width: wid123+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head123']"
               @input="tableValidations(Object.keys(conditionalColumn)[123],'head123',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[124]]" :style="{width: wid124+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head124']"
               @input="tableValidations(Object.keys(conditionalColumn)[124],'head124',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[125]]" :style="{width: wid125+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head125']"
               @input="tableValidations(Object.keys(conditionalColumn)[125],'head125',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[126]]" :style="{width: wid126+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head126']"
               @input="tableValidations(Object.keys(conditionalColumn)[126],'head126',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[127]]" :style="{width: wid127+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head127']"
               @input="tableValidations(Object.keys(conditionalColumn)[127],'head127',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[128]]" :style="{width: wid128+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head128']"
               @input="tableValidations(Object.keys(conditionalColumn)[128],'head128',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[129]]" :style="{width: wid129+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head129']"
               @input="tableValidations(Object.keys(conditionalColumn)[129],'head129',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[130]]" :style="{width: wid129+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head130']"
                @input="tableValidations(Object.keys(conditionalColumn)[130],'head130',k)" 
              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[131]]" :style="{width: wid130+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head131']"
               @input="tableValidations(Object.keys(conditionalColumn)[131],'head131',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[132]]" :style="{width: wid131+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head132']"
               @input="tableValidations(Object.keys(conditionalColumn)[132],'head132',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[133]]" :style="{width: wid132+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head133']"
               @input="tableValidations(Object.keys(conditionalColumn)[133],'head133',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[134]]" :style="{width: wid133+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head134']"
               @input="tableValidations(Object.keys(conditionalColumn)[134],'head134',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[135]]" :style="{width: wid134+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head135']"
               @input="tableValidations(Object.keys(conditionalColumn)[135],'head135',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[136]]" :style="{width: wid135+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head136']"
               @input="tableValidations(Object.keys(conditionalColumn)[136],'head136',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[137]]" :style="{width: wid136+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head137']"
               @input="tableValidations(Object.keys(conditionalColumn)[137],'head137',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[138]]" :style="{width: wid137+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head138']"
               @input="tableValidations(Object.keys(conditionalColumn)[138],'head138',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[139]]" :style="{width: wid138+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head139']"
              @input="tableValidations(Object.keys(conditionalColumn)[139],'head139',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[140]]" :style="{width: wid139+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head140']"
               @input="tableValidations(Object.keys(conditionalColumn)[140],'head140',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[141]]" :style="{width: wid140+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head141']"
               @input="tableValidations(Object.keys(conditionalColumn)[141],'head141',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[142]]" :style="{width: wid141+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head142']"
              @input="tableValidations(Object.keys(conditionalColumn)[142],'head142',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[143]]" :style="{width: wid142+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head143']"
              @input="tableValidations(Object.keys(conditionalColumn)[143],'head143',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[144]]" :style="{width: wid143+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head144']"
               @input="tableValidations(Object.keys(conditionalColumn)[144],'head144',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[145]]" :style="{width: wid144+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head145']"
               @input="tableValidations(Object.keys(conditionalColumn)[145],'head145',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[146]]" :style="{width: wid145+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head146']"
               @input="tableValidations(Object.keys(conditionalColumn)[146],'head146',k)" 

              :disabled="buttondis"
            />
          </td>

          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[147]]" :style="{width: wid147+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head147']"
               @input="tableValidations(Object.keys(conditionalColumn)[147],'head147',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[148]]" :style="{width: wid148+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head148']"
               @input="tableValidations(Object.keys(conditionalColumn)[148],'head148',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[149]]" :style="{width: wid149+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head149']"
               @input="tableValidations(Object.keys(conditionalColumn)[149],'head149',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[150]]" :style="{width: wid150+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head150']"
               @input="tableValidations(Object.keys(conditionalColumn)[150],'head150',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[151]]" :style="{width: wid151+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head151']"
               @input="tableValidations(Object.keys(conditionalColumn)[151],'head151',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[152]]" :style="{width: wid152+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head152']"
               @input="tableValidations(Object.keys(conditionalColumn)[152],'head152',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[153]]" :style="{width: wid153+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head153']"
               @input="tableValidations(Object.keys(conditionalColumn)[153],'head153',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[154]]" :style="{width: wid154+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head154']"
               @input="tableValidations(Object.keys(conditionalColumn)[154],'head154',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[155]]" :style="{width: wid155+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head155']"
               @input="tableValidations(Object.keys(conditionalColumn)[155],'head155',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[156]]" :style="{width: wid156+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head156']"
               @input="tableValidations(Object.keys(conditionalColumn)[156],'head156',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[157]]" :style="{width: wid157+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head157']"
               @input="tableValidations(Object.keys(conditionalColumn)[157],'head157',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[158]]" :style="{width: wid158+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head158']"
               @input="tableValidations(Object.keys(conditionalColumn)[158],'head158',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[159]]" :style="{width: wid159+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head159']"
               @input="tableValidations(Object.keys(conditionalColumn)[159],'head159',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[160]]" :style="{width: wid160+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head160']"
               @input="tableValidations(Object.keys(conditionalColumn)[160],'head160',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[161]]" :style="{width: wid161+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head161']"
               @input="tableValidations(Object.keys(conditionalColumn)[161],'head161',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[162]]" :style="{width: wid162+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head162']"
              @input="tableValidations(Object.keys(conditionalColumn)[162],'head162',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[163]]" :style="{width: wid163+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head163']"
               @input="tableValidations(Object.keys(conditionalColumn)[163],'head163',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[164]]" :style="{width: wid164+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head164']"
               @input="tableValidations(Object.keys(conditionalColumn)[164],'head164',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[165]]" :style="{width: wid165+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head165']"
               @input="tableValidations(Object.keys(conditionalColumn)[165],'head165',k)" 

              :disabled="buttondis"
            />
          </td>
         <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[166]]" :style="{width: wid166+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head166']"
               @input="tableValidations(Object.keys(conditionalColumn)[166],'head166',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[167]]" :style="{width: wid167+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head167']"
               @input="tableValidations(Object.keys(conditionalColumn)[167],'head167',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[168]]" :style="{width: wid168+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head168']"
               @input="tableValidations(Object.keys(conditionalColumn)[168],'head168',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[169]]" :style="{width: wid169+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head169']"
               @input="tableValidations(Object.keys(conditionalColumn)[169],'head169',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[170]]" :style="{width: wid170+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head170']"
               @input="tableValidations(Object.keys(conditionalColumn)[170],'head170',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[171]]" :style="{width: wid171+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head171']"
               @input="tableValidations(Object.keys(conditionalColumn)[171],'head171',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[172]]" :style="{width: wid172+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head172']"
              @input="tableValidations(Object.keys(conditionalColumn)[172],'head172',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[173]]" :style="{width: wid173+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head173']"
              @input="tableValidations(Object.keys(conditionalColumn)[173],'head173',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[174]]" :style="{width: wid174+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head174']"
               @input="tableValidations(Object.keys(conditionalColumn)[174],'head174',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[175]]" :style="{width: wid175+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head175']"
               @input="tableValidations(Object.keys(conditionalColumn)[175],'head175',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[176]]" :style="{width: wid176+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head176']"
               @input="tableValidations(Object.keys(conditionalColumn)[176],'head176',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[177]]" :style="{width: wid177+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head177']"
               @input="tableValidations(Object.keys(conditionalColumn)[177],'head177',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[178]]" :style="{width: wid178+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head178']"
               @input="tableValidations(Object.keys(conditionalColumn)[178],'head178',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[179]]" :style="{width: wid179+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head179']"
               @input="tableValidations(Object.keys(conditionalColumn)[179],'head179',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[180]]" :style="{width: wid180+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head180']"
               @input="tableValidations(Object.keys(conditionalColumn)[180],'head180',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[181]]" :style="{width: wid181+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head181']"
               @input="tableValidations(Object.keys(conditionalColumn)[181],'head181',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[182]]" :style="{width: wid182+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head182']"
               @input="tableValidations(Object.keys(conditionalColumn)[182],'head182',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[183]]" :style="{width: wid183+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head183']"
               @input="tableValidations(Object.keys(conditionalColumn)[183],'head183',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[184]]" :style="{width: wid184+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head184']"
             @input="tableValidations(Object.keys(conditionalColumn)[184],'head184',k)" 
  
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[185]]" :style="{width: wid185+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head185']"
               @input="tableValidations(Object.keys(conditionalColumn)[185],'head185',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[186]]" :style="{width: wid186+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head186']"
              @input="tableValidations(Object.keys(conditionalColumn)[186],'head186',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[187]]" :style="{width: wid187+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head187']"
               @input="tableValidations(Object.keys(conditionalColumn)[187],'head187',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[188]]" :style="{width: wid188+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head188']"
               @input="tableValidations(Object.keys(conditionalColumn)[188],'head188',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[189]]" :style="{width: wid189+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head189']"
              @input="tableValidations(Object.keys(conditionalColumn)[189],'head189',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[190]]" :style="{width: wid190+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head190']"
               @input="tableValidations(Object.keys(conditionalColumn)[190],'head190',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[191]]" :style="{width: wid191+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head191']"
               @input="tableValidations(Object.keys(conditionalColumn)[191],'head191',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[192]]" :style="{width: wid192+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head192']"
              @input="tableValidations(Object.keys(conditionalColumn)[192],'head192',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[193]]" :style="{width: wid193+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head193']"
               @input="tableValidations(Object.keys(conditionalColumn)[193],'head193',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[194]]" :style="{width: wid194+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head194']"
              @input="tableValidations(Object.keys(conditionalColumn)[194],'head194',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[195]]" :style="{width: wid195+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head195']"
               @input="tableValidations(Object.keys(conditionalColumn)[195],'head195',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[196]]" :style="{width: wid196+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head196']"
               @input="tableValidations(Object.keys(conditionalColumn)[196],'head196',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[197]]" :style="{width: wid197+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head197']"
               @input="tableValidations(Object.keys(conditionalColumn)[197],'head197',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[198]]" :style="{width: wid198+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head198']"
               @input="tableValidations(Object.keys(conditionalColumn)[198],'head198',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[199]]" :style="{width: wid199+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head199']"
              @input="tableValidations(Object.keys(conditionalColumn)[199],'head199',k)" 
 
              :disabled="buttondis"
            />
          </td>
        <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[200]]" :style="{width: wid200+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head200']"
               @input="tableValidations(Object.keys(conditionalColumn)[200],'head200',k)" 

              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[201]]" :style="{width: wid201+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head201']"
              @input="tableValidations(Object.keys(conditionalColumn)[201],'head201',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[202]]" :style="{width: wid202+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head202']"
              @input="tableValidations(Object.keys(conditionalColumn)[202],'head202',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[203]]" :style="{width: wid203+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head203']"
              @input="tableValidations(Object.keys(conditionalColumn)[203],'head203',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[204]]" :style="{width: wid204+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head204']"
              @input="tableValidations(Object.keys(conditionalColumn)[204],'head204',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[205]]" :style="{width: wid205+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head205']"
              @input="tableValidations(Object.keys(conditionalColumn)[205],'head205',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[206]]" :style="{width: wid206+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head206']"
              @input="tableValidations(Object.keys(conditionalColumn)[206],'head206',k)" 
 
              :disabled="buttondis"
            />
          </td>
          <td class="tdInputsmall" v-show="conditionalColumn[Object.keys(conditionalColumn)[207]]" :style="{width: wid207+'px'}">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher['head207']"
              @input="tableValidations(Object.keys(conditionalColumn)[207],'head207',k)" 
 
              :disabled="buttondis"
            />
          </td>
        



          

          <td align="center" class="tdDeletebutton">
            <vs-button
              size="small"
              icon-pack="feather"
              icon="icon-trash"
              color="danger"
              style="margin:3px;"
              @click="deleteRow(k, cashVaucher)"
            ></vs-button>
          </td>
        </tr>
      </table>
</td>
    </div>
    <!-- Table End -->
    <br />
    <div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()">
        <i class="fa fa-plus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="pop">
        <i class="fa fa-minus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div>
    <i class="far fa-trash-alt" @click="deleteRow(k, cashVaucher)"></i>
    <br />

    <div class="flex mb-4" style="padding-top:20px;">
      <div
        class="w-1/4 bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important; padding-bottom:20px; margin-right:5%;"
      >
        <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
          <tr>
            <td class="overlap">
              <font color="red">GSTR 2A Status</font>
            </td>
            <td>
              <vs-checkbox v-model="purchase1b_gstr2astatus" :disabled="buttondis"></vs-checkbox>
            </td>
          </tr>

          <tr>
            <td class="overlap">Transport</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_transport"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Broker</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_broker"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>
      <div
        class="w-1/4 bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important; padding-bottom:20px;margin-right:5%; "
      >
        <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
          <tr>
            <td class="overlap">Input Dt.</td>
            <td>
              <vs-input
                type="date"
                class="w-full"
                size="small"
                :disabled="buttondis"
                v-model="purchase1b_inputdt"
                id="datepicker"
                style="width:180px;  margin-top:10px;"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Due Date</td>
            <td>
              <vs-input
                type="date"
                class="w-full"
                size="small"
                :disabled="buttondis"
                v-model="purchase1b_duedate"
                id="datepicker"
                style="width:180px;  margin-top:10px;"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">GR No.</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_grno"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Vehicle</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_vehicle"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">
              <font color="red">Total GST</font>
            </td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_totalgst"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>
      <div
        class="w-1/4 bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important; padding-bottom:20px; margin-right:5%; "
      >
        <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
          <tr>
            <td class="overlap">
              <font color="red">Adjust Advance Rs</font>
            </td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_adjustadvancers"
                style="width:180px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Cess 1</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_cess1"
                style="width:180px; margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Cess 2</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_cess2"
                style="width:180px; margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>
      <div
        class="w-1/ bg-grid-color-secondary h-12 flex"
        style="height:100% !important; width:100% !important; padding-bottom:20px;"
      >
        <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
          <tr>
            <td class="overlap">Sub Total</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_subtotal"
                style="width:180px; "
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Add/Less</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_addless"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
                v-on:keyup.down="expensepopup1 = true"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">C.Gst</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_cgst"
                style="width:180px; margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">S.Gst</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_sgst"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">I.Gst</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_igst"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Expenses</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_expenses"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
                v-on:keyup.down="expensepopup2 = true"
              />
            </td>
          </tr>
          <tr>
            <td class="overlap">Grand Total</td>
            <td>
              <vs-input
                class="w-full"
                size="small"
                v-model="purchase1b_grandtotal"
                style="width:180px;  margin-top:10px;"
                :disabled="buttondis"
              />
            </td>
          </tr>
        </table>
      </div>
    </div>

    <div align="right">
      <br />

      <br />
      <!-- Button set start-->
      <div align="left">
        <vs-button
          :color="getColor('addButton')"
          :disabled="disAdd"
          type="filled"
          id="addButton"
          icon-pack="feather"
          icon="icon-file-plus"
          @keyup.right="buttonNext('addButton')"
          @keyup.left="buttonPrev('addButton ')"
          @click="newdisable"
        />
        <vs-button
          :color="getColor('editButton')"
          type="filled"
          icon-pack="feather"
          icon="icon-edit-1"
          :disabled="disEdit"
          id="editButton"
          class="button margin"
          @keyup.right="buttonNext('editButton')"
          @keyup.left="buttonPrev('editButton')"
          @click="Edit"
        />
        <vs-button
          :color="getColor('previousButton')"
          type="filled"
          icon-pack="feather"
          icon="icon-chevrons-left"
          :disabled="disPrevious"
          id="previousButton"
          class="button margin"
          @keyup.right="buttonNext('previousButton')"
          @keyup.left="buttonPrev('previousButton')"
          @click="previousPage"
        />
        <vs-button
          :color="getColor('nextButton')"
          icon-pack="feather"
          icon="icon-chevrons-right"
          :disabled="disNext"
          id="nextButton"
          class="button margin"
          @keyup.right="buttonNext('nextButton')"
          @keyup.left="buttonPrev('nextButton')"
          @click="nextPage"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-arrow-left"
          :color="getColor('firstButton')"
          :disabled="disFirst"
          id="firstButton"
          class="button margin"
          @keyup.right="buttonNext('firstButton')"
          @keyup.left="buttonPrev('firstButton')"
          @click="firstPage"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-arrow-right"
          :color="getColor('lastButton')"
          :disabled="disLast"
          id="lastButton"
          class="button margin"
          @keyup.right="buttonNext('lastButton')"
          @keyup.left="buttonPrev('lastButton')"
          @click="lastPage"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-search"
          :color="getColor('searchButton')"
          :disabled="disSearch"
          id="searchButton"
          class="button margin"
          @click="Search"
          @keyup.right="buttonNext('searchButton')"
          @keyup.left="buttonPrev('searchButton')"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-copy"
          :color="getColor('copyButton')"
          :disabled="disCopy"
          id="moveButton"
          class="button margin"
          @keyup.right="buttonNext('moveButton')"
          @keyup.left="buttonPrev('moveButton')"
          @click="submit"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-printer"
          :color="getColor('printButton')"
          :disabled="disPrinter"
          id="printButton"
          class="button margin"
          @keyup.right="buttonNext('printButton')"
          @keyup.left="buttonPrev('printButton')"
          @click="print"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-trash"
          :color="getColor('deleteButton')"
          :disabled="disDelete"
          id="deleteButton"
          class="button margin"
          @keyup.right="buttonNext('deleteButton')"
          @keyup.left="buttonPrev('deleteButton')"
          @click="Delete"
        />
        <vs-button
          icon-pack="feather"
          icon="icon-x"
          :color="getColor('exitButton')"
          :disabled="disExit"
          id="exitButton"
          class="button margin"
          @keyup.right="buttonNext('exitButton')"
          @keyup.left="buttonPrev('exitButton')"
          @click="exit"
        />
        <vs-button
          style="float:right; display:inline-block;"
          :color="getColor('saveButton')"
          :disabled="disSave"
          id="saveButton"
          class="button margin"
          @keyup.right="buttonNext('saveButton')"
          @keyup.left="buttonPrev('saveButton')"
          @click="save()"
        >Save</vs-button>
      </div>
      <!-- Button set end -->
    </div>
  </div>
</template>

<script>
import datepicker from "vuejs-datepicker";
// import VCalendar from 'v-calendar';
// import Datepicker from 'vue2-datepicker';
import "flatpickr/dist/flatpickr.css";
import Vue from "vue";
import axios from "@/axios";
import { ComboBoxPlugin } from "@syncfusion/ej2-vue-dropdowns";
import { CheckBoxPlugin } from "@syncfusion/ej2-vue-buttons";
import { Query, DataManager, WebApiAdaptor } from "@syncfusion/ej2-data";
Vue.use(ComboBoxPlugin);
import modalpurchasesetup from "@/components/purchasesetup.vue";
import modalnarration from "@/components/NarrationsModal.vue";
import modal from "@/components/Ledgerpopup.vue";
Vue.use(CheckBoxPlugin);
var remoteData = new DataManager({
  url:
    "https://ej2services.syncfusion.com/production/web-services/api/Employees",
  adaptor: new WebApiAdaptor(),
  crossDomain: true
});

export default {
  data() {
    return {
      totalrows:0,
      rowlength: 1,

srnos: [{counter:""}],

 lastDateis:0,
      firstDateis:0,
      lastIndex:-1,
      isContinuous:false,
        isEditingOld: false,
wid0:0,
wid1:0,
wid2:0,
wid3:0,
wid4:0,
wid5:0,
wid6:0,
wid7:0,
wid8:0,
wid9:0,
wid10:0,
wid11:0,
wid12:0,
wid13:0,
wid14:0,
wid15:0,
wid16:0,
wid17:0,
wid18:0,
wid19:0,
wid20:0,
wid21:0,
wid22:0,
wid23:0,
wid24:0,
wid25:0,
wid26:0,
wid27:0,
wid28:0,
wid29:0,
wid30:0,
wid31:0,
wid32:0,
wid33:0,
wid34:0,
wid35:0,
wid36:0,
wid37:0,
wid38:0,
wid39:0,
wid40:0,
wid41:0,
wid42:0,
wid43:0,
wid44:0,
wid45:0,
wid46:0,
wid47:0,
wid48:0,
wid49:0,
wid50:0,
wid51:0,
wid52:0,
wid53:0,
wid54:0,
wid55:0,
wid56:0,
wid57:0,
wid58:0,
wid59:0,
wid60:0,
wid61:0,
wid62:0,
wid63:0,
wid64:0,
wid65:0,
wid66:0,
wid67:0,
wid68:0,
wid69:0,
wid70:0,
wid71:0,
wid72:0,
wid73:0,
wid74:0,
wid75:0,
wid76:0,
wid77:0,
wid78:0,
wid79:0,
wid80:0,
wid81:0,
wid82:0,
wid83:0,
wid84:0,
wid85:0,
wid86:0,
wid87:0,
wid88:0,
wid89:0,
wid90:0,
wid91:0,
wid92:0,
wid93:0,
wid94:0,
wid95:0,
wid96:0,
wid97:0,
wid98:0,
wid99:0,
wid100:0,
wid101:0,
wid102:0,
wid103:0,
wid104:0,
wid105:0,
wid106:0,
wid107:0,
wid108:0,
wid109:0,
wid110:0,
wid111:0,
wid112:0,
wid113:0,
wid114:0,
wid115:0,
wid116:0,
wid117:0,
wid118:0,
wid119:0,
wid120:0,
wid121:0,
wid122:0,
wid123:0,
wid124:0,
wid125:0,
wid126:0,
wid127:0,
wid128:0,
wid129:0,
wid130:0,
wid131:0,
wid132:0,
wid133:0,
wid134:0,
wid135:0,
wid136:0,
wid137:0,
wid138:0,
wid139:0,
wid140:0,
wid141:0,
wid142:0,
wid143:0,
wid144:0,
wid145:0,
wid146:0,
wid147:0,
wid148:0,
wid149:0,
wid150:0,
wid151:0,
wid152:0,
wid153:0,
wid154:0,
wid155:0,
wid156:0,
wid157:0,
wid158:0,
wid159:0,
wid160:0,
wid161:0,
wid162:0,
wid163:0,
wid164:0,
wid165:0,
wid166:0,
wid167:0,
wid168:0,
wid169:0,
wid170:0,
wid171:0,
wid172:0,
wid173:0,
wid174:0,
wid175:0,
wid176:0,
wid177:0,
wid178:0,
wid179:0,
wid180:0,
wid181:0,
wid182:0,
wid183:0,
wid184:0,
wid185:0,
wid186:0,
wid187:0,
wid188:0,
wid189:0,
wid190:0,
wid191:0,
wid192:0,
wid193:0,
wid194:0,
wid195:0,
wid196:0,
wid197:0,
wid198:0,
wid199:0,
wid200:0,
wid201:0,
wid202:0,
wid203:0,
wid204:0,
wid205:0,
wid206:0,
wid207:0,
wid208:0,


      
      totalwidth: 1500,
      heading: "PURCHASE",
      conditionalWidth:"",
       conditionalColumn: "",
      conditionalValues: "",
      conditionalLabels: "",
      conditionalOrder: "",

      modalOpen:false,
      popupActive2:false,
      modalOpenNarration:false,
      popupActiveNarration:false,
      currentrow:"",
       popupActivepurchaseSetup:false,
      modalpurchasesetupOpen:false,
      expensepopup1: false,
      expensepopup2: false,
      manufacturerpop: false,
      localFields: { text: "Game", value: "Id" },
      localWaterMark: "Select a game",
      autofill: true,
      spdata: [],
      purchasegstdata: [],
      addButtonClicked: "false",
      searchclicked: "false",
      sportsData: [
        "Badminton",
        "Basketball",
        "Cricket",
        "Football",
        "Golf",
        "Gymnastics",
        "Hockey",
        "Rugby",
        "Snooker",
        "Tennis"
      ],

      expense1_1 : "",
      expense1_2 : "",
      expense1_3 : "",
      expense1_4 : "",
      expense1_5 : "",
      expense1_6 : "",
      expense1_7 : "",
      expense1_8 : "",
      expense1_9 : "",
      expense1_10 : "",
      expense1_11 : "",
      expense1_12 : "",

      expense2_1 : "",
      expense2_2 : "",
      expense2_3 : "",
      expense2_4 : "",
      expense2_5 : "",
      expense2_6 : "",
      expense2_7 : "",
      expense2_8 : "",
      expense2_9 : "",
      expense2_10 : "",
      expense2_11 : "",
      expense2_12 : "",
      expense2_13: "",
      expense2_14: "",

      man_supplier: "",
      man_billno: "",
      man_billdate:  "",
      man_weight:  "",
      man_pageno: "",
      man_rate:  "",
      man_entryno: "",
      man_assvalue:  "",
      man_impgoods: "",
      man_bed1:  "",
      man_bed2: "",
      man_cess1: "",
      man_cess2:  "",
      man_hcess1:  "",
      man_hcess2: "",
      man_aduty1:  "",
      man_aduty2:  "",
      man_vatcst1:  "",
      man_vatcst2:  "",


      data: remoteData,
      originalvoucherno: 0,
      height11: "250px",
      remoteFields: { text: "FirstName", value: "EmployeeID" },
      query: new Query()
        .select(["FirstName", "EmployeeID"])
        .take(10)
        .requiresCount(),
      remoteWaterMark: "Select a name",
      selectedDropdown: "accountname",
      paymentTotal: 0.0,
      receiptTotal: 0.0,
      discountTotal: 0.0,
      disAdd: false,
      disCopy: true,
      disDelete: true,
      disEdit: true,
      disFirst: true,
      disLast: true,
      disNext: true,
      disSave: true,
      disSearch: true,
      disPrinter: true,
      disPrevious: true,
      disExit: false,
      buttonen: false,
      date: null,
      due: null,

      handleSearch: "hello",
      configdateTimePicker: {
        allowInput: true,

        dateFormat: "d-m-Y"
      },
      titleAction: "",

      buttondis: true,
      totalcount: 0,
      //UPDATE6
      purchase1b_supplier: "",
      purchase1b_city: "",
      purchase1b_gstno: "",
      purchase1b_billno: "",
      purchase1b_billdate: "",
      purchase1b_terms: "",
      purchase1b_taxtype: "",
      purchase1b_selfinv: "",
      purchase1b_billcash: "",
      purchase1b_gstr2astatus: "",
      purchase1b_transport: "",
      purchase1b_broker: "",
      purchase1b_inputdt: "",
      purchase1b_duedate: "",
      purchase1b_grno: "",
      purchase1b_vehicle: "",
      purchase1b_totalgst: "",
      purchase1b_adjustadvancers: "",
      purchase1b_cess1: "",
      purchase1b_cess2: "",
      purchase1b_subtotal: "",
      purchase1b_addless: "",
      purchase1b_cgst: "",
      purchase1b_sgst: "",
      purchase1b_igst: "",
      purchase1b_expenses: "",
      purchase1b_grandtotal: "",

     cashVauchers: [{

                //UPDATE1   // DECLARATION OF CASHVAUCHERS, i'm marking this to find this bugger faster

                head0: "",

                head1: "",

                head2: "",

                head3: "",

                head4: "",

                head5: "",

                head6: "",

                head7: "",

                head8: "",

                head9: "",

                head10: "",

                head11: "",

                head12: "",

                head13: "",

                head14: "",

                head15: "",

                head16: "",

                head17: "",

                head18: "",

                head19: "",

                head20: "",

                head21: "",

                head22: "",

                head23: "",

                head24: "",

                head25: "",

                head26: "",

                head27: "",

                head28: "",

                head29: "",

                head30: "",

                head31: "",

                head32: "",

                head33: "",

                head34: "",

                head35: "",

                head36: "",

                head37: "",

                head38: "",

                head39: "",

                head40: "",

                head41: "",

                head42: "",

                head43: "",

                head44: "",

                head45: "",

                head46: "",

                head47: "",

                head48: "",

                head49: "",

                head50: "",

                head51: "",

                head52: "",

                head53: "",

                head54: "",

                head55: "",

                head56: "",

                head57: "",

                head58: "",

                head59: "",

                head60: "",

                head61: "",

                head62: "",

                head63: "",

                head64: "",

                head65: "",

                head66: "",

                head67: "",

                head68: "",

                head69: "",

                head70: "",

                head71: "",

                head72: "",

                head73: "",

                head74: "",

                head75: "",

                head76: "",

                head77: "",

                head78: "",

                head79: "",

                head80: "",

                head81: "",

                head82: "",

                head83: "",

                head84: "",

                head85: "",

                head86: "",

                head87: "",

                head88: "",

                head89: "",

                head90: "",

                head91: "",

                head92: "",

                head93: "",

                head94: "",

                head95: "",

                head96: "",

                head97: "",

                head98: "",

                head99: "",

                head100: "",

                head101: "",

                head102: "",

                head103: "",

                head104: "",

                head105: "",

                head106: "",

                head107: "",

                head108: "",

                head109: "",

                head110: "",

                head111: "",

                head112: "",

                head113: "",

                head114: "",

                head115: "",

                head116: "",

                head117: "",

                head118: "",

                head119: "",

                head120: "",

                head121: "",

                head122: "",

                head123: "",

                head124: "",

                head125: "",

                head126: "",

                head127: "",

                head128: "",

                head129: "",

                head130: "",

                head131: "",

                head132: "",

                head133: "",

                head134: "",

                head135: "",

                head136: "",

                head137: "",

                head138: "",

                head139: "",

                head140: "",

                head141: "",

                head142: "",

                head143: "",

                head144: "",

                head145: "",

                head146: "",

                head147: "",

                head148: "",

                head149: "",

                head150: "",

                head151: "",

                head152: "",

                head153: "",

                head154: "",

                head155: "",

                head156: "",

                head157: "",

                head158: "",

                head159: "",

                head160: "",

                head161: "",

                head162: "",

                head163: "",

                head164: "",

                head165: "",

                head166: "",

                head167: "",

                head168: "",

                head169: "",

                head170: "",

                head171: "",

                head172: "",

                head173: "",

                head174: "",

                head175: "",

                head176: "",

                head177: "",

                head178: "",

                head179: "",

                head180: "",

                head181: "",

                head182: "",

                head183: "",

                head184: "",

                head185: "",

                head186: "",

                head187: "",

                head188: "",

                head189: "",

                head190: "",

                head191: "",

                head192: "",

                head193: "",

                head194: "",

                head195: "",

                head196: "",

                head197: "",

                head198: "",

                head199: "",

                head200: "",

                head201: "",

                head202: "",

                head203: "",

                head204: "",

                head205: "",

                head206: "",

                head207: "",

                head208: "",



                currentmrp: "",

                updatemrp: "",

                disc: "",

                discrs: "",

                splcd: "",

                splcdrs: "",

                cdrate: "",

                cdrate1: "",

                cdrate2: "",

                cdaftergstactive: "",

                expenseLabour_rate: "",

                expenseLabour_value: "",

                expensePostage_rate: "",

                expensePostage_value: "",

                expenseDiscount_rate: "",

                expenseDiscount_value: "",

                expenseFreight_rate: "",

                expenseFreight_value: "",

                expense5_rate: "",

                expense5_value: "",

                expenseTCS1_rate: "",

                expenseTCS1_value: "",



                mas_accode: "",

                mas_name: "",

                mas_groupname: "",

                mas_mrp: "",

                mas_salerate: "",

                mas_totalgst: "",

                mas_cgst: "",

                mas_sgst: "",

                mas_cessqty: "",

                mas_cessrate: "",

                mas_hsncode: "",

                mas_saleaccode: "",

                mas_purchaseaccode: "",

                mas_ratecalculator: "",

                mas_uom: "",

                mas_qtyin: "",

                mas_size: ""

            }],
        cashheaders: [
        "vdate",
                "vtype",
                "vno",
                "valpha",
                "vcode",
                "vacode",
                "vamt",
                "others",
                "vamtcode",
                "vdesc",
                "vbillno",
                "vbdate",
                "stype",
                "freight",
                "excise",
                "weight",
                "pkgs",
                "tax",
                "counter",
                "sdisc",
                "etype",
                "exfor",
                "rate",
                "btype",
                "stkcode",
                "conv",
                "plarg",
                "entno",
                "pb_wt",
                "srno1",
                "freight1",
                "weighing",
                "pla",
                "tds_frt",
                "tdsrate",
                "ppcode",
                "cess",
                "vbillno1",
                "vbdate1",
                "vamt1",
                "duedate",
                "cl_date",
                "emcode",
                "mon",
                "vacode1",
                "hcess",
                "trpt",
                "intial",
                "weight_ch",
                "vamt_ch",
                "vdate_ch",
                "vacode_ch",
                "record",
                "vhead_ch",
                "vhead",
                "remarks",
                "tick",
                "credit",
                "debit",
                "pcess",
                "tcs_cess",
                "tcs_hcess",
                "vat",
                "exp1",
                "exp2",
                "exp3",
                "exp4",
                "exp5",
                "exp6",
                "exp7",
                "exp8",
                "exp9",
                "exp1_rate",
                "exp2_rate",
                "exp3_rate",
                "exp4_rate",
                "exp5_rate",
                "exp6_rate",
                "exp7_rate",
                "exp8_rate",
                "exp9_rate",
                "exp10_rate",
                "rem1",
                "rem2",
                "rem3",
                "rem4",
                "transport",
                "order",
                "order_date",
                "agent",
                "broker",
                "cd_rate",
                "cd",
                "sch_rate",
                "scheme",
                "srv_rate",
                "srv_tax",
                "gr",
                "inv_tm",
                "rev_tm",
                "inv_dt",
                "rev_dt",
                "rem5",
                "rem6",
                "rem7",
                "rem8",
                "cvd",
                "exrate",
                "cessrate",
                "hcrate",
                "cvdrate",
                "exp_before",
                "exp_after",
                "total",
                "b_tpt",
                "sub_total",
                "party_code",
                "tax_rate",
                "exp10",
                "loose",
                "spec",
                "pckng",
                "wf",
                "wwf",
                "tx_from",
                "tx_upto",
                "tx_type",
                "ssr",
                "vat_post",
                "led_post",
                "ex_post",
                "bill",
                "stk_post",
                "opening",
                "purr",
                "sale",
                "prdd",
                "issuee",
                "closing",
                "stk_code",
                "rateins",
                "srates",
                "qpps",
                "tcs",
                "tcs_rate",
                "tcs1_rate",
                "tcs2_rate",
                "saletype",
                "purtype",
                "ahead",
                "add1",
                "add2",
                "city",
                "tin",
                "phone",
                "cash_name",
                "cash_add1",
                "cash_city",
                "tax0_sale",
                "tax1_sale",
                "p_vdate",
                "p_vno",
                "p_valpha",
                "p_counter",
                "unit_ex",
                "unit_cs",
                "unit_hs",
                "unit_cv",
                "cd1",
                "cd1_rate",
                "tariff",
                "user_name",
                "exp1_ex",
                "exp2_ex",
                "weights",
                "emistatus",
                "p_pageno",
                "p_entry",
                "taxsurr",
                "o_vdate",
                "o_vno",
                "o_valpha",
                "o_counter",
                "exp1_exr",
                "exp2_exr",
                "rem9",
                "rem10",
                "rem11",
                "exp01",
                "exp01code",
                "p_vbillno",
                "usname",
                "usrate",
                "usvamt",
                "cardno",
                "cashrec",
                "bank",
                "bcode",
                "exp3_ex",
                "ctax",
                "ctax_rate",
                "stax",
                "stax_rate",
                "itax"
       
      ],
      selected: [],
      tableList: [
        "vs-th: Component",
        "vs-tr: Component",
        "vs-td: Component",
        "thread: Slot",
        "tbody: Slot",
        "header: Slot"
      ],
      filterbar2: "",
      filteredUsers: [],
      users: [],
      narrations: [],
      filteredNarrations: [],
      newAccountName: " ",
      newCityName: " ",
      newGSTIN: " ",
      newAddress: " ",
      newContact: " ",
      newMobile: " ",
     

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],
      vattypelist: "",
      billcashlist: [
        { text: "Bill", value: "bill" },
        { text: "Cash Memo", value: "cashmemo" }
      ],
      taxtypelist: "",
      popupHeaders: [
        { title: "Account Name", show: true, headerUse: "accountname" },
        { title: "City Name", show: true, headerUse: "cityname" },
        { title: "Address", show: true, headerUse: "address" },
        { title: "GSTIN", show: true, headerUse: "gstin" },
        { title: "Contact No", show: true, headerUse: "contactno" },
        { title: "Mobile", show: true, headerUse: "mobileno" }
      ],
      activeWindowsList: [],
      popupDropdownSelected: "s_name",
      popupSelectedRow: 0,
      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
     
      popupActive3: false,
      popupActive4: false,
      popupActive5: false,
      popupActive6: false,
      oldNarrationToEdit: "",
      modifiedNarration: "",
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false,
      autocopyNarration: "Data From Last Form",
     debitorcredit:""
    
    };
  },
  components: {
    datepicker,
    modalpurchasesetup,
    modalnarration,
    modal
  },
  methods: {
popSerial(){
  this.srnos.pop({counter:""})
},
 getContinuousPrevData() {

            var user = sessionStorage.getItem("user");

            var companyName = JSON.parse(user)[0].companyname;



            var n = {

                note: "prev",

                reqIndex: this.dbIndex,

                companyname: companyName,

                heading: this.heading

            };

            // alert(JSON.stringify(n));



            let that = this;

            axios

                .post("http://localhost:2000/GetPurchaseContinuous", n)

                .then(response => {

                    // alert(JSON.stringify(response.data));



                    //this.DuplicateNotify(JSON.stringify(response.data));

                    let resp = JSON.stringify(response.data);

                    let s = resp.slice(0, -1);

                    s = s.substring(1);

                    if (s == "outofbounds") {

                        alert("out Of bounds");

                    } else {

                        resp = JSON.parse(resp);



                        var list = [];

                        for (let v = 0; v < resp.tableData.length; v++) {

                            var obj = {};



                            for (let b = 0; b < Object.keys(resp.tableData[v]).length; b++) {

                                let m = "head" + b.toString();

                                obj[m] =

                                    resp.tableData[v][Object.keys(this.conditionalColumn)[b]];

                            }

                            list.push(obj);

                        }

                        that.cashVauchers = list;



                        //alert(JSON.stringify(resp.tableData)+"   \n\n\n comeon:"+JSON.stringify(that.cashVauchers))
that.purchase1b_supplier = resp.purchase1b_supplier;
          that.purchase1b_city = resp.purchase1b_city;
          that.purchase1b_gstno = resp.purchase1b_gstno;
          that.purchase1b_billno = resp.purchase1b_billno;
          that.purchase1b_billdate = resp.purchase1b_billdate;
          that.purchase1b_terms = resp.purchase1b_terms;
          that.purchase1b_taxtype = resp.purchase1b_taxtype;
          that.purchase1b_selfinv = resp.purchase1b_selfinv;
          that.purchase1b_billcash = resp.purchase1b_billcash;
          that.purchase1b_gstr2astatus = resp.purchase1b_gstr2astatus;
          that.purchase1b_transport = resp.purchase1b_transport;
          that.purchase1b_broker = resp.purchase1b_broker;
          that.purchase1b_inputdt = resp.purchase1b_inputdt;
          that.purchase1b_duedate = resp.purchase1b_duedate;
          that.purchase1b_grno = resp.purchase1b_grno;
          that.purchase1b_vehicle = resp.purchase1b_vehicle;
          that.purchase1b_totalgst = resp.purchase1b_totalgst;
          that.purchase1b_adjustadvancers = resp.purchase1b_adjustadvancers;
          that.purchase1b_cess1 = resp.purchase1b_cess1;
          that.purchase1b_cess2 = resp.purchase1b_cess2;
          that.purchase1b_subtotal = resp.purchase1b_subtotal;
          that.purchase1b_addless = resp.purchase1b_addless;
          that.purchase1b_cgst = resp.purchase1b_cgst;
          that.purchase1b_sgst = resp.purchase1b_sgst;
          that.purchase1b_igst = resp.purchase1b_igst;
          that.purchase1b_expenses = resp.purchase1b_expenses;
          that.purchase1b_grandtotal = resp.purchase1b_grandtotal;

      that.expense1_1 = resp.expense1_1
      that.expense1_2 = resp.expense1_2
      that.expense1_3 = resp.expense1_3
      that.expense1_4 = resp.expense1_4
      that.expense1_5 = resp.expense1_5
      that.expense1_6 = resp.expense1_6
      that.expense1_7 = resp.expense1_7
      that.expense1_8 = resp.expense1_8
      that.expense1_9 = resp.expense1_9
      that.expense1_10 = resp.expense1_10
      that.expense1_11 = resp.expense1_11
      that.expense1_12 = resp.expense1_12

      that.expense2_1 = resp.expense2_1
      that.expense2_2 = resp.expense2_2
      that.expense2_3 = resp.expense2_3
      that.expense2_4 = resp.expense2_4
      that.expense2_5 = resp.expense2_5
      that.expense2_6 = resp.expense2_6
      that.expense2_7 = resp.expense2_7
      that.expense2_8 = resp.expense2_8
      that.expense2_9 = resp.expense2_9
      that.expense2_10 = resp.expense2_10
      that.expense2_11 = resp.expense2_11
      that.expense2_12 = resp.expense2_12
      that.expense2_13= resp.expense2_13
      that.expense2_14= resp.expense2_14


      that.man_supplier= resp.man_supplier;
      that.man_billno= resp.man_billno;
      that.man_billdate=  resp.man_billdate;
      that.man_weight=  resp.man_weight;
      that.man_pageno= resp.man_pageno;
      that.man_rate=  resp.man_rate;
      that.man_entryno= resp.man_entryno;
      that.man_assvalue=  resp.man_assvalue;
      that.man_impgoods= resp.man_impgoods;
      that.man_bed1=  resp.man_bed1;
      that.man_bed2= resp.man_bed2;
      that.man_cess1= resp.man_cess1;
      that.man_cess2=  resp.man_cess2;
      that.man_hcess1=  resp.man_hcess1;
      that.man_hcess2= resp.man_hcess2;
      that.man_aduty1=  resp.man_aduty1;
      that.man_aduty2=  resp.man_aduty2;
      that.man_vatcst1=  resp.man_vatcst1;
      that.man_vatcst2=  resp.man_vatcst2;
                        that.dbIndex = resp.index;

                        that.voucherno = resp.voucherno;

                        that.date = resp.date;



                        that.dbIndex = resp.index;

                        that.voucherno = resp.voucherno;

                        that.date = resp.date;

                    }

                })

                .catch(error => {

                    alert(error);

                });

        },

 getContinuousFirstData() {

            var user = sessionStorage.getItem("user");

            var companyName = JSON.parse(user)[0].companyname;



            let that = this;

            var n = {

                note: "first",

                reqIndex: this.dbIndex,

                companyname: companyName,

                heading: this.heading

            };

            // alert(JSON.stringify(n));

            axios

                .post("http://localhost:2000/GetPurchaseContinuous", n)

                .then(response => {

                    // alert(JSON.stringify(response.data));



                    //this.DuplicateNotify(JSON.stringify(response.data));

                    let resp = JSON.stringify(response.data);

                    let s = resp.slice(0, -1);

                    s = s.substring(1);

                    if (s == "outofbounds") {

                        alert("out Of bounds");

                    } else {

                        resp = JSON.parse(resp);



                        var list = [];

                        for (let v = 0; v < resp.tableData.length; v++) {

                            var obj = {};



                            for (let b = 0; b < Object.keys(resp.tableData[v]).length; b++) {

                                let m = "head" + b.toString();

                                obj[m] =

                                    resp.tableData[v][Object.keys(this.conditionalColumn)[b]];

                            }

                            list.push(obj);

                        }

                        that.cashVauchers = list;

                        //alert(JSON.stringify(resp.tableData)+"   \n\n\n comeon:"+JSON.stringify(that.cashVauchers))



                         that.purchase1b_supplier = resp.purchase1b_supplier;
          that.purchase1b_city = resp.purchase1b_city;
          that.purchase1b_gstno = resp.purchase1b_gstno;
          that.purchase1b_billno = resp.purchase1b_billno;
          that.purchase1b_billdate = resp.purchase1b_billdate;
          that.purchase1b_terms = resp.purchase1b_terms;
          that.purchase1b_taxtype = resp.purchase1b_taxtype;
          that.purchase1b_selfinv = resp.purchase1b_selfinv;
          that.purchase1b_billcash = resp.purchase1b_billcash;
          that.purchase1b_gstr2astatus = resp.purchase1b_gstr2astatus;
          that.purchase1b_transport = resp.purchase1b_transport;
          that.purchase1b_broker = resp.purchase1b_broker;
          that.purchase1b_inputdt = resp.purchase1b_inputdt;
          that.purchase1b_duedate = resp.purchase1b_duedate;
          that.purchase1b_grno = resp.purchase1b_grno;
          that.purchase1b_vehicle = resp.purchase1b_vehicle;
          that.purchase1b_totalgst = resp.purchase1b_totalgst;
          that.purchase1b_adjustadvancers = resp.purchase1b_adjustadvancers;
          that.purchase1b_cess1 = resp.purchase1b_cess1;
          that.purchase1b_cess2 = resp.purchase1b_cess2;
          that.purchase1b_subtotal = resp.purchase1b_subtotal;
          that.purchase1b_addless = resp.purchase1b_addless;
          that.purchase1b_cgst = resp.purchase1b_cgst;
          that.purchase1b_sgst = resp.purchase1b_sgst;
          that.purchase1b_igst = resp.purchase1b_igst;
          that.purchase1b_expenses = resp.purchase1b_expenses;
          that.purchase1b_grandtotal = resp.purchase1b_grandtotal;

      that.expense1_1 = resp.expense1_1
      that.expense1_2 = resp.expense1_2
      that.expense1_3 = resp.expense1_3
      that.expense1_4 = resp.expense1_4
      that.expense1_5 = resp.expense1_5
      that.expense1_6 = resp.expense1_6
      that.expense1_7 = resp.expense1_7
      that.expense1_8 = resp.expense1_8
      that.expense1_9 = resp.expense1_9
      that.expense1_10 = resp.expense1_10
      that.expense1_11 = resp.expense1_11
      that.expense1_12 = resp.expense1_12

      that.expense2_1 = resp.expense2_1
      that.expense2_2 = resp.expense2_2
      that.expense2_3 = resp.expense2_3
      that.expense2_4 = resp.expense2_4
      that.expense2_5 = resp.expense2_5
      that.expense2_6 = resp.expense2_6
      that.expense2_7 = resp.expense2_7
      that.expense2_8 = resp.expense2_8
      that.expense2_9 = resp.expense2_9
      that.expense2_10 = resp.expense2_10
      that.expense2_11 = resp.expense2_11
      that.expense2_12 = resp.expense2_12
      that.expense2_13= resp.expense2_13
      that.expense2_14= resp.expense2_14


      that.man_supplier= resp.man_supplier;
      that.man_billno= resp.man_billno;
      that.man_billdate=  resp.man_billdate;
      that.man_weight=  resp.man_weight;
      that.man_pageno= resp.man_pageno;
      that.man_rate=  resp.man_rate;
      that.man_entryno= resp.man_entryno;
      that.man_assvalue=  resp.man_assvalue;
      that.man_impgoods= resp.man_impgoods;
      that.man_bed1=  resp.man_bed1;
      that.man_bed2= resp.man_bed2;
      that.man_cess1= resp.man_cess1;
      that.man_cess2=  resp.man_cess2;
      that.man_hcess1=  resp.man_hcess1;
      that.man_hcess2= resp.man_hcess2;
      that.man_aduty1=  resp.man_aduty1;
      that.man_aduty2=  resp.man_aduty2;
      that.man_vatcst1=  resp.man_vatcst1;
      that.man_vatcst2=  resp.man_vatcst2;
                        that.dbIndex = resp.index;

                        that.voucherno = resp.voucherno;

                        that.date = resp.date;

                        that.firstDateis = resp.date;

                    }

                })

                .catch(error => {

                    alert(error);

                });

        },




 getContinuousNextData() {

            var user = sessionStorage.getItem("user");

            var companyName = JSON.parse(user)[0].companyname;

            let that = this;

            var n = {

                note: "next",

                reqIndex: this.dbIndex,

                companyname: companyName,

                heading: this.heading

            };

            // alert(JSON.stringify(n));

            axios

                .post("http://localhost:2000/GetPurchaseContinuous", n)

                .then(response => {

                    // alert(JSON.stringify(response.data));



                    //this.DuplicateNotify(JSON.stringify(response.data));

                    let resp = JSON.stringify(response.data);

                    let s = resp.slice(0, -1);

                    s = s.substring(1);

                    if (s == "outofbounds") {

                        alert("out Of bounds");

                    } else {

                        resp = JSON.parse(resp);



                        var list = [];

                        for (let v = 0; v < resp.tableData.length; v++) {

                            var obj = {};



                            for (let b = 0; b < Object.keys(resp.tableData[v]).length; b++) {

                                let m = "head" + b.toString();

                                obj[m] =

                                    resp.tableData[v][Object.keys(this.conditionalColumn)[b]];

                            }

                            list.push(obj);

                        }

                        that.cashVauchers = list;

                        //alert(JSON.stringify(resp.tableData)+"   \n\n\n comeon:"+JSON.stringify(that.cashVauchers))


   that.purchase1b_supplier = resp.purchase1b_supplier;
          that.purchase1b_city = resp.purchase1b_city;
          that.purchase1b_gstno = resp.purchase1b_gstno;
          that.purchase1b_billno = resp.purchase1b_billno;
          that.purchase1b_billdate = resp.purchase1b_billdate;
          that.purchase1b_terms = resp.purchase1b_terms;
          that.purchase1b_taxtype = resp.purchase1b_taxtype;
          that.purchase1b_selfinv = resp.purchase1b_selfinv;
          that.purchase1b_billcash = resp.purchase1b_billcash;
          that.purchase1b_gstr2astatus = resp.purchase1b_gstr2astatus;
          that.purchase1b_transport = resp.purchase1b_transport;
          that.purchase1b_broker = resp.purchase1b_broker;
          that.purchase1b_inputdt = resp.purchase1b_inputdt;
          that.purchase1b_duedate = resp.purchase1b_duedate;
          that.purchase1b_grno = resp.purchase1b_grno;
          that.purchase1b_vehicle = resp.purchase1b_vehicle;
          that.purchase1b_totalgst = resp.purchase1b_totalgst;
          that.purchase1b_adjustadvancers = resp.purchase1b_adjustadvancers;
          that.purchase1b_cess1 = resp.purchase1b_cess1;
          that.purchase1b_cess2 = resp.purchase1b_cess2;
          that.purchase1b_subtotal = resp.purchase1b_subtotal;
          that.purchase1b_addless = resp.purchase1b_addless;
          that.purchase1b_cgst = resp.purchase1b_cgst;
          that.purchase1b_sgst = resp.purchase1b_sgst;
          that.purchase1b_igst = resp.purchase1b_igst;
          that.purchase1b_expenses = resp.purchase1b_expenses;
          that.purchase1b_grandtotal = resp.purchase1b_grandtotal;

      that.expense1_1 = resp.expense1_1
      that.expense1_2 = resp.expense1_2
      that.expense1_3 = resp.expense1_3
      that.expense1_4 = resp.expense1_4
      that.expense1_5 = resp.expense1_5
      that.expense1_6 = resp.expense1_6
      that.expense1_7 = resp.expense1_7
      that.expense1_8 = resp.expense1_8
      that.expense1_9 = resp.expense1_9
      that.expense1_10 = resp.expense1_10
      that.expense1_11 = resp.expense1_11
      that.expense1_12 = resp.expense1_12

      that.expense2_1 = resp.expense2_1
      that.expense2_2 = resp.expense2_2
      that.expense2_3 = resp.expense2_3
      that.expense2_4 = resp.expense2_4
      that.expense2_5 = resp.expense2_5
      that.expense2_6 = resp.expense2_6
      that.expense2_7 = resp.expense2_7
      that.expense2_8 = resp.expense2_8
      that.expense2_9 = resp.expense2_9
      that.expense2_10 = resp.expense2_10
      that.expense2_11 = resp.expense2_11
      that.expense2_12 = resp.expense2_12
      that.expense2_13= resp.expense2_13
      that.expense2_14= resp.expense2_14


      that.man_supplier= resp.man_supplier;
      that.man_billno= resp.man_billno;
      that.man_billdate=  resp.man_billdate;
      that.man_weight=  resp.man_weight;
      that.man_pageno= resp.man_pageno;
      that.man_rate=  resp.man_rate;
      that.man_entryno= resp.man_entryno;
      that.man_assvalue=  resp.man_assvalue;
      that.man_impgoods= resp.man_impgoods;
      that.man_bed1=  resp.man_bed1;
      that.man_bed2= resp.man_bed2;
      that.man_cess1= resp.man_cess1;
      that.man_cess2=  resp.man_cess2;
      that.man_hcess1=  resp.man_hcess1;
      that.man_hcess2= resp.man_hcess2;
      that.man_aduty1=  resp.man_aduty1;
      that.man_aduty2=  resp.man_aduty2;
      that.man_vatcst1=  resp.man_vatcst1;
      that.man_vatcst2=  resp.man_vatcst2;




                        that.dbIndex = resp.index;

                        that.voucherno = resp.voucherno;

                        that.date = resp.date;

                    }

                })

                .catch(error => {

                    alert(error);

                });

        },



        getContinuousLastData() {

            var user = sessionStorage.getItem("user");

           // alert(this.heading);

            var companyName = JSON.parse(user)[0].companyname;



            var n = {

                note: "last",

                reqIndex: this.dbIndex,

                companyname: companyName,

                heading: this.heading

            };

            let that = this;

            // alert(JSON.stringify(n));

            axios

                .post("http://localhost:2000/GetPurchaseContinuous", n)

                .then(response => {

                    let resp = JSON.stringify(response.data);

                    let s = resp.slice(0, -1);

                    s = s.substring(1);

                    if (s == "outofbounds") {

                        alert("out Of bounds");

                    } else {

                        resp = JSON.parse(resp);



                        var list = [];

                        for (let v = 0; v < resp.tableData.length; v++) {

                            var obj = {};



                            for (let b = 0; b < Object.keys(resp.tableData[v]).length; b++) {

                                let m = "head" + b.toString();

                                obj[m] =

                                    resp.tableData[v][Object.keys(this.conditionalColumn)[b]];

                            }

                            list.push(obj);

                        }

                        that.cashVauchers = list;

                        //alert(JSON.stringify(resp.tableData)+"   \n\n\n comeon:"+JSON.stringify(that.cashVauchers))



                        that.purchase1b_supplier = resp.purchase1b_supplier;
          that.purchase1b_city = resp.purchase1b_city;
          that.purchase1b_gstno = resp.purchase1b_gstno;
          that.purchase1b_billno = resp.purchase1b_billno;
          that.purchase1b_billdate = resp.purchase1b_billdate;
          that.purchase1b_terms = resp.purchase1b_terms;
          that.purchase1b_taxtype = resp.purchase1b_taxtype;
          that.purchase1b_selfinv = resp.purchase1b_selfinv;
          that.purchase1b_billcash = resp.purchase1b_billcash;
          that.purchase1b_gstr2astatus = resp.purchase1b_gstr2astatus;
          that.purchase1b_transport = resp.purchase1b_transport;
          that.purchase1b_broker = resp.purchase1b_broker;
          that.purchase1b_inputdt = resp.purchase1b_inputdt;
          that.purchase1b_duedate = resp.purchase1b_duedate;
          that.purchase1b_grno = resp.purchase1b_grno;
          that.purchase1b_vehicle = resp.purchase1b_vehicle;
          that.purchase1b_totalgst = resp.purchase1b_totalgst;
          that.purchase1b_adjustadvancers = resp.purchase1b_adjustadvancers;
          that.purchase1b_cess1 = resp.purchase1b_cess1;
          that.purchase1b_cess2 = resp.purchase1b_cess2;
          that.purchase1b_subtotal = resp.purchase1b_subtotal;
          that.purchase1b_addless = resp.purchase1b_addless;
          that.purchase1b_cgst = resp.purchase1b_cgst;
          that.purchase1b_sgst = resp.purchase1b_sgst;
          that.purchase1b_igst = resp.purchase1b_igst;
          that.purchase1b_expenses = resp.purchase1b_expenses;
          that.purchase1b_grandtotal = resp.purchase1b_grandtotal;

      that.expense1_1 = resp.expense1_1
      that.expense1_2 = resp.expense1_2
      that.expense1_3 = resp.expense1_3
      that.expense1_4 = resp.expense1_4
      that.expense1_5 = resp.expense1_5
      that.expense1_6 = resp.expense1_6
      that.expense1_7 = resp.expense1_7
      that.expense1_8 = resp.expense1_8
      that.expense1_9 = resp.expense1_9
      that.expense1_10 = resp.expense1_10
      that.expense1_11 = resp.expense1_11
      that.expense1_12 = resp.expense1_12

      that.expense2_1 = resp.expense2_1
      that.expense2_2 = resp.expense2_2
      that.expense2_3 = resp.expense2_3
      that.expense2_4 = resp.expense2_4
      that.expense2_5 = resp.expense2_5
      that.expense2_6 = resp.expense2_6
      that.expense2_7 = resp.expense2_7
      that.expense2_8 = resp.expense2_8
      that.expense2_9 = resp.expense2_9
      that.expense2_10 = resp.expense2_10
      that.expense2_11 = resp.expense2_11
      that.expense2_12 = resp.expense2_12
      that.expense2_13= resp.expense2_13
      that.expense2_14= resp.expense2_14


      that.man_supplier= resp.man_supplier;
      that.man_billno= resp.man_billno;
      that.man_billdate=  resp.man_billdate;
      that.man_weight=  resp.man_weight;
      that.man_pageno= resp.man_pageno;
      that.man_rate=  resp.man_rate;
      that.man_entryno= resp.man_entryno;
      that.man_assvalue=  resp.man_assvalue;
      that.man_impgoods= resp.man_impgoods;
      that.man_bed1=  resp.man_bed1;
      that.man_bed2= resp.man_bed2;
      that.man_cess1= resp.man_cess1;
      that.man_cess2=  resp.man_cess2;
      that.man_hcess1=  resp.man_hcess1;
      that.man_hcess2= resp.man_hcess2;
      that.man_aduty1=  resp.man_aduty1;
      that.man_aduty2=  resp.man_aduty2;
      that.man_vatcst1=  resp.man_vatcst1;
      that.man_vatcst2=  resp.man_vatcst2;

                        that.dbIndex = resp.index;

                        that.lastIndex = resp.index;

                       // alert(this.lastIndex);

                        that.voucherno = resp.voucherno;

                        that.date = resp.date;

                        alert(that.date)

                        that.lastDateis = resp.date;

                    }

                    // alert(JSON.stringify(response.data));



                    //this.DuplicateNotify(JSON.stringify(response.data));



                    // alert('set lastAccode = '+ resp.stock_accounts[resp.stock_accounts.length - 1].Name)



                    // alert(this.popupBodyData[0].HSNCode);

                })

                .catch(error => {

                    alert(error);

                });

        },




     showLedgerPopup(p){
   if(p>=0)
  {this.debitorcredit=p+""
  }
   if(p+""=="-2")
   this.debitorcredit="cust"
    if(p+""=="-1")
   this.debitorcredit="transporter"

   if(p=="purchase1b_supplier")
   { this.debitorcredit="purchase1b_supplier"}
 
 
  this.popupActive2=true
  this.modalOpen=true
  this.$refs.childComponentLedger.setValue("true")
},
 onChildClick (value) {
      
       const words=value.split(':');
       if(this.debitorcredit=="cust")
      this.salegst_custname = words[0]
      
      else if(this.debitorcredit=="transporter")
      this.salegstpopup2_12=words[1]
      
     

      else if(this.debitorcredit=="purchase1b_supplier")
      {this.purchase1b_supplier=words[0];
      }

       else if(parseInt(this.debitorcredit)>=0)
      {this.cashVauchers[parseInt(this.debitorcredit)].purchase1b_productname=words[0]}
      this.popupActive2=false
    },

      showdescNar(k){
      
 alert(k)
        this.$refs.childComponent.setValue(k)
    this.modalOpenNarration=true
this.popupActiveNarration=true
    },
    focusedElement(valu)
  {
   this.currentrow=valu
   
   
   },
    onChildClickNarration(valu){
      
      if(this.modalOpenNarration==true)
      
      { const words=valu.split(':');
     
       if((words[1]+"")=="description")
       {
         if(parseInt(this.currentrow)>=0)
         this.cashVauchers[this.currentrow].purchase1b_description=words[0]
        
 
       }
       else{
        if(this.currentrow=="gstno") 
         {this.purchase1b_gstno=words[0]+""
         }
         else if(this.currentrow=="supplier")
         {this.purchase1b_supplier=words[0]+""}
       }

       this.popupActiveNarration=false
        this.modalOpenNarration=false
       
      }
    // this.shortfunctionsecond(valu)
    },
     openSetupModal(){
       this.popupActivepurchaseSetup=true
  this.modalpurchasesetupOpen=true
    this.activeWindowsList.push("popupActivepurchaseSetup");
    },
    billcashcheck() {
    
      if (this.purchase1b_billcash == "cashmemo"&& this.buttondis==false) {
        this.manufacturerpop = true;
      }
    },
    voucherChange() {
      this.addButtonClicked = "false";
     
      var date, voucherval;
      var that = this;
      voucherval = that.voucherno;
      date = that.date;

      var a;
      var flag = 0;
      that.purchasegstdata.data.filter(function(item, index) {
        if (item[date] + "" != "undefined") {
          //alert("hey")
          a = JSON.stringify(item[date]);
          //alert(item[date].length+"")
          if (item[date].length < parseInt(that.voucherno + "")) {
            //alert("no")
            if (flag == 0) {
              that.voucherno = that.original;
              alert("No data found for this voucher no");
            }
          } else {
            //alert("yes")
            that.initializeData(
              that.purchasegstdata,
              that,
              date,
              a,
              index,
              parseInt(voucherval + "") - 1
            );
            that.original = that.voucherno;
            flag = 1;
          }
        }
      });

      if (that.searchclicked != "true") {
        that.disDate = true;
        that.disVoucher = true;
      }
    },
    lastPage() {
      this.addButtonClicked = "false";
      this.searchclicked = "false";
      this.disAdd = false;
      this.disDate = true;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.buttonen = false;
      this.buttondis = true;

      var that = this;

 if (this.isContinuous == true) {

                this.getContinuousLastData();

            } 
            else 
            {
 var json = that.purchasegstdata;

      var lastdate = Object.keys(
        that.purchasegstdata.data[that.purchasegstdata.data.length - 1]
      )[0];
      var len2 =
        json.data[that.purchasegstdata.data.length - 1][lastdate].length;
      var a = JSON.stringify(
        that.purchasegstdata.data[that.purchasegstdata.data.length - 1][
          lastdate
        ]
      );

      that.initializeData(
        json,
        that,
        lastdate,
        a,
        that.purchasegstdata.data.length - 1,
        len2 - 1
      );

            }

     
    },
    firstPage() {
      this.addButtonClicked = "false";
      this.disAdd = false;

      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.buttonen = false;
      this.buttondis = true;
      this.disDate = true;

      var that = this;

      var firstdate = Object.keys(that.purchasegstdata.data[0])[0];
if (this.isContinuous == true) {

                this.getContinuousFirstData();

            }
            else{ var a = JSON.stringify(that.purchasegstdata.data[0][firstdate]);
      var json = that.purchasegstdata;
      ////alert(index2+" is index2")
      that.initializeData(json, that, firstdate, a, 0, 0);
      }

     
    },
    nextPage() {
      this.addButtonClicked = "false";
      this.searchclicked = "false";
      this.disAdd = false;
      this.disDate = true;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.buttonen = false;
      this.buttondis = true;
      this.disVoucher = true;
if (this.isContinuous == true) {

                this.getContinuousNextData();

            }
            else{
 var checkC = 0;

      var date = this.date + "";

      var that = this;
      var voucherval = parseInt(this.voucherno + "");

      //  var len=this.cashformdata.data.length;

      ////alert("hi2"+voucherval)
      var json = JSON.parse(JSON.stringify(this.purchasegstdata));

      ////alert(this.cashformdata+"")
      json.data.filter(function(item, index) {
        if (item[date] + "" == "undefined") {
          ////alert("hi")
        } else {
          ////alert("inhere "+that.originalvoucherno)
          item[date].filter(function(item2, index2) {
            if (
              parseInt(voucherval + "") + 1 <=
              parseInt(that.originalvoucherno + "")
            ) {
              if (parseInt(voucherval + "") + 1 == item2.voucherno) {
                ////alert("object found")

                ////alert(JSON.stringify(that.cashformdata.data[index][that.datepicker]))
                var a = JSON.stringify(that.purchasegstdata.data[index][date]);

                ////alert(index2+" is index2")
                that.initializeData(json, that, date, a, index, index2);

                ////alert(that.cashformdata.data[index][that.datepicker][index2].voucherno)
                that.voucherno =
                  that.purchasegstdata.data[index][date][index2].voucherno;

                ////alert(that.voucherno)
              }
            } else {
              ////alert("second Option"+index)
              if (checkC < 1) {
                var prevdate = Object.keys(
                  that.purchasegstdata.data[index + 1]
                )[0];
                a = JSON.stringify(
                  that.purchasegstdata.data[index + 1][prevdate]
                );

                that.initializeData(json, that, prevdate, a, index + 1, "", 1);
              }
              checkC++;
            }
          });
        }
      });

            }

     
    },
    previousPage() {
      // Enter pressed

      this.searchclicked = "false";
      this.addButtonClicked = "false";
      this.disAdd = false;
      this.disDate = true;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.buttonen = false;
      this.buttondis = true;
      this.disVoucher = true;

if (this.isContinuous == true) this.getContinuousPrevData();
else {
   var checkC = 0;

      // alert("hi")
      var date = this.date + "";

      // alert("hi2")
      var that = this;
      var voucherval = parseInt(this.voucherno + "");

      //  var len=this.cashformdata.data.length;

      //alert("voucher val : "+voucherval)
      var json = JSON.parse(JSON.stringify(this.purchasegstdata));

      ////alert("hi2")

      //alert(this.cashformdata+"")
      json.data.filter(function(item, index) {
        ////alert("yo")

        // alert(item[date]+"")
        if (item[date] + "" == "undefined") {
          //   alert("undef item yo")
        } else {
          //   alert("inhere")
          item[date].filter(function(item2, index2) {
            if (parseInt(voucherval + "") - 1 != 0) {
              if (parseInt(voucherval + "") - 1 == item2.voucherno) {
                // alert("object found")

                // alert(JSON.stringify(that.cashformdata.data[index][that.datepicker]))
                var a = JSON.stringify(that.purchasegstdata.data[index][date]);

                //  alert(index2+" is index2")
                //alert("datepicker: " + that.datepicker)
                that.initializeData(json, that, date, a, index, index2, -1);

                //   alert(that.purchasegstdata.data[index][that.datepicker][index2].voucherno)
                that.voucherno =
                  that.purchasegstdata.data[index][date][index2].voucherno;

                //  alert(that.voucherno)
              }
            } else {
              ////alert("second Option"+index)
              if (checkC < 1) {
                var prevdate = Object.keys(
                  that.purchasegstdata.data[index - 1]
                )[0];
                a = JSON.stringify(
                  that.purchasegstdata.data[index - 1][prevdate]
                );

                that.initializeData(json, that, prevdate, a, index - 1, "", -1);
              }
              checkC++;
            }
          });
        }
      });
}

     
    },
    Delete() {
      this.addButtonClicked = "false";
      //alert(this.companyname)
      this.$vs.dialog({
        type: "confirm",
        color: "danger",
        title: `Confirm`,
        text: "Are you sure you want to delete this record?",
        accept: this.acceptAlertDelete
      });
    },

    acceptAlertDelete() {
      this.addButtonClicked = "false";
      var that = this;
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var value = {
        date: this.date,
        voucherno: this.voucherno,
        companyname: companyName
      };
      axios
        .post("/deletePurchaseGst", value)
        .then(response => {
          var data = JSON.stringify(response.data);

          var json = JSON.parse(data);
          that.creditnotedata = json;
          window.location.reload();
          that.$vs.notify({
            color: "danger",
            title: "Deleted image",
            text: "The selected image was successfully deleted"
          });
        })
        .catch(error => {
          alert(error);
        });
    },
    Search() {
      //  alert('called search')
      this.searchclicked = "true";
      this.buttondis = false;
      this.disDate = false;
      this.disVoucher = false;

      this.buttonen = true;
      this.disSave = true;
      this.originalvoucherno = this.voucherno;
      this.buttondis = true;
    },
    Edit() {
      this.titleAction = "EDIT";

      this.buttondis = false;

      this.disVoucher = true;
      this.disDate = true;
      this.buttonen = true;
      this.disCopy = true;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = false;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.disAdd = true;
    },
    exit() {
      this.addButtonClicked = "false";
      this.buttondis = false;
      this.disAdd = false;
      this.buttonen = false;
      this.disVoucher = true;
      this.disDate = true;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.buttondis = true;
    },
    loseDateFocus() {
     
      this.searchclicked = "false";
      if (this.addButtonClicked == "true") {
        this.disSave = false;
        this.disAdd = true;
        if (this.purchase1b_supplier != "")
          this.voucherno = parseInt(this.voucherno) + 1;
      else{
 if (this.isContinuous == true) {

                        if (this.firstDateis.localeCompare(this.date) == 1) {

                            this.date = this.lastDateis;

                            this.newdisable();

                        } else if (

                            this.lastDateis.localeCompare(this.date) == -1 ||

                            this.lastDateis.localeCompare(this.date) == 0

                        ) {

                            this.voucherno = this.lastIndex + 2;

                        } else {

                            this.date = this.lastDateis;

                            this.newdisable();

                        }
          }
      }
          

       this.cashVauchers = [{

                    //UPDATE1   // DECLARATION OF CASHVAUCHERS, i'm marking this to find this bugger faster

                    head0: "",

                    head1: "",

                    head2: "",

                    head3: "",

                    head4: "",

                    head5: "",

                    head6: "",

                    head7: "",

                    head8: "",

                    head9: "",

                    head10: "",

                    head11: "",

                    head12: "",

                    head13: "",

                    head14: "",

                    head15: "",

                    head16: "",

                    head17: "",

                    head18: "",

                    head19: "",

                    head20: "",

                    head21: "",

                    head22: "",

                    head23: "",

                    head24: "",

                    head25: "",

                    head26: "",

                    head27: "",

                    head28: "",

                    head29: "",

                    head30: "",

                    head31: "",

                    head32: "",

                    head33: "",

                    head34: "",

                    head35: "",

                    head36: "",

                    head37: "",

                    head38: "",

                    head39: "",

                    head40: "",

                    head41: "",

                    head42: "",

                    head43: "",

                    head44: "",

                    head45: "",

                    head46: "",

                    head47: "",

                    head48: "",

                    head49: "",

                    head50: "",

                    head51: "",

                    head52: "",

                    head53: "",

                    head54: "",

                    head55: "",

                    head56: "",

                    head57: "",

                    head58: "",

                    head59: "",

                    head60: "",

                    head61: "",

                    head62: "",

                    head63: "",

                    head64: "",

                    head65: "",

                    head66: "",

                    head67: "",

                    head68: "",

                    head69: "",

                    head70: "",

                    head71: "",

                    head72: "",

                    head73: "",

                    head74: "",

                    head75: "",

                    head76: "",

                    head77: "",

                    head78: "",

                    head79: "",

                    head80: "",

                    head81: "",

                    head82: "",

                    head83: "",

                    head84: "",

                    head85: "",

                    head86: "",

                    head87: "",

                    head88: "",

                    head89: "",

                    head90: "",

                    head91: "",

                    head92: "",

                    head93: "",

                    head94: "",

                    head95: "",

                    head96: "",

                    head97: "",

                    head98: "",

                    head99: "",

                    head100: "",

                    head101: "",

                    head102: "",

                    head103: "",

                    head104: "",

                    head105: "",

                    head106: "",

                    head107: "",

                    head108: "",

                    head109: "",

                    head110: "",

                    head111: "",

                    head112: "",

                    head113: "",

                    head114: "",

                    head115: "",

                    head116: "",

                    head117: "",

                    head118: "",

                    head119: "",

                    head120: "",

                    head121: "",

                    head122: "",

                    head123: "",

                    head124: "",

                    head125: "",

                    head126: "",

                    head127: "",

                    head128: "",

                    head129: "",

                    head130: "",

                    head131: "",

                    head132: "",

                    head133: "",

                    head134: "",

                    head135: "",

                    head136: "",

                    head137: "",

                    head138: "",

                    head139: "",

                    head140: "",

                    head141: "",

                    head142: "",

                    head143: "",

                    head144: "",

                    head145: "",

                    head146: "",

                    head147: "",

                    head148: "",

                    head149: "",

                    head150: "",

                    head151: "",

                    head152: "",

                    head153: "",

                    head154: "",

                    head155: "",

                    head156: "",

                    head157: "",

                    head158: "",

                    head159: "",

                    head160: "",

                    head161: "",

                    head162: "",

                    head163: "",

                    head164: "",

                    head165: "",

                    head166: "",

                    head167: "",

                    head168: "",

                    head169: "",

                    head170: "",

                    head171: "",

                    head172: "",

                    head173: "",

                    head174: "",

                    head175: "",

                    head176: "",

                    head177: "",

                    head178: "",

                    head179: "",

                    head180: "",

                    head181: "",

                    head182: "",

                    head183: "",

                    head184: "",

                    head185: "",

                    head186: "",

                    head187: "",

                    head188: "",

                    head189: "",

                    head190: "",

                    head191: "",

                    head192: "",

                    head193: "",

                    head194: "",

                    head195: "",

                    head196: "",

                    head197: "",

                    head198: "",

                    head199: "",

                    head200: "",

                    head201: "",

                    head202: "",

                    head203: "",

                    head204: "",

                    head205: "",

                    head206: "",

                    head207: "",

                    head208: "",



                    currentmrp: "",

                    updatemrp: "",

                    disc: "",

                    discrs: "",

                    splcd: "",

                    splcdrs: "",

                    cdrate: "",

                    cdrate1: "",

                    cdrate2: "",

                    cdaftergstactive: "",

                    expenseLabour_rate: "",

                    expenseLabour_value: "",

                    expensePostage_rate: "",

                    expensePostage_value: "",

                    expenseDiscount_rate: "",

                    expenseDiscount_value: "",

                    expenseFreight_rate: "",

                    expenseFreight_value: "",

                    expense5_rate: "",

                    expense5_value: "",

                    expenseTCS1_rate: "",

                    expenseTCS1_value: "",



                    mas_accode: "",

                    mas_name: "",

                    mas_groupname: "",

                    mas_mrp: "",

                    mas_salerate: "",

                    mas_totalgst: "",

                    mas_cgst: "",

                    mas_sgst: "",

                    mas_cessqty: "",

                    mas_cessrate: "",

                    mas_hsncode: "",

                    mas_saleaccode: "",

                    mas_purchaseaccode: "",

                    mas_ratecalculator: "",

                    mas_uom: "",

                    mas_qtyin: "",

                    mas_size: ""

                }];
        var that = this;

        ////alert(this.voucherno)
        this.rowlength = 1;

        that.purchase1b_supplier = "";
        that.purchase1b_city = "";
        that.purchase1b_gstno = "";
        that.purchase1b_billno = "";
        that.purchase1b_billdate = "";
        that.purchase1b_terms = "";

        that.purchase1b_taxtype = "";

        that.purchase1b_billcash = "";
        that.purchase1b_selfinv = "";

        that.purchase1b_gstr2astatus = "";

        that.purchase1b_transport = "";
        that.purchase1b_broker = "";
        that.purchase1b_inputdt = "";

        that.purchase1b_duedate = "";
        that.purchase1b_adjustadvancers = "";

        that.purchase1b_vehicle = "";

        that.purchase1b_grno = "";

        that.purchase1b_totalgst = "";
        that.purchase1b_cess1 = "";
        that.purchase1b_cess2 = "";
        that.purchase1b_subtotal = "";
        that.purchase1b_addless = "";
        that.purchase1b_cgst = "";
        that.purchase1b_sgst = "";

        that.purchase1b_igst = "";
        that.purchase1b_expenses = "";
        that.purchase1b_grandtotal = "";


        
      that.expense1_1 = "";
      that.expense1_2 = "";
      that.expense1_3 = "";
      that.expense1_4 = "";
      that.expense1_5 = "";
      that.expense1_6 = "";
      that.expense1_7 = "";
      that.expense1_8 = "";
      that.expense1_9 = "";
      that.expense1_10 = "";
      that.expense1_11 = "";
      that.expense1_12 = "";

      that.expense2_1 = "";
      that.expense2_2 = "";
      that.expense2_3 = "";
      that.expense2_4 = "";
      that.expense2_5 = "";
      that.expense2_6 = "";
      that.expense2_7 = "";
      that.expense2_8 = "";
      that.expense2_9 = "";
      that.expense2_10 = "";
      that.expense2_11 = "";
      that.expense2_12 = "";
      that.expense2_13= "";
      that.expense2_14= "";

      that.man_supplier= "";
      that.man_billno= "";
      that.man_billdate=  "";
      that.man_weight=  "";
      that.man_pageno= "";
      that.man_rate=  "";
      that.man_entryno= "";
      that.man_assvalue=  "";
      that.man_impgoods= "";
      that.man_bed1=  "";
      that.man_bed2= "";
      that.man_cess1= "";
      that.man_cess2=  "";
      that.man_hcess1=  "";
      that.man_hcess2= "";
      that.man_aduty1=  "";
      that.man_aduty2=  "";
      that.man_vatcst1=  "";
      that.man_vatcst2=  "";

      }
    },
    dateChange() {
      var that = this;

      if (that.searchclicked != "true") {
        that.buttondis = false;
        that.disEdit = true;
        that.disAdd = false;

        that.disCopy = true;
        that.disDelete = true;

        that.disFirst = true;
        that.disLast = true;
        that.disNext = true;

        that.disSearch = true;
        that.disPrinter = true;
        that.disPrevious = true;
        that.disExit = false;
        that.buttonen = true;
      }
      // Enter pressed
if (this.isContinuous == false) {
      var date = that.date;

      var lastdate = [];
      var len = that.purchasegstdata.data.length;

      ////alert("here")

      var a;
      var flag = 0;
      for (let j = 0; j < len; j++) {
        lastdate[j] = Object.keys(that.purchasegstdata.data[j])[0];
        if (that.date + "" == lastdate[j] + "") {
          a = JSON.stringify(that.purchasegstdata.data[j][that.date]);

 var js = JSON.parse(a);



                        if (

                            this.date + "" == this.now + "" &&

                            this.addButtonClicked + "" == "true"

                        ) {

                            that.originalvoucherno = js[0].voucherno;



                            this.voucherno = parseInt(this.originalvoucherno + "") + 1;

                            if (this.voucherno >= 1) {

                                //  console.log("new");

                            } else {

                                this.voucherno = 1;

                            }

                        } else

                            that.initializeData(that.purchasegstdata, that, date, a, j, "", -1);




          



          ////alert(j+"here")
          flag == 1;
          break;
        } else {
          a = "undefined";
          if (j == len - 1 && flag == 0)
            that.initializeData(that.purchasegstdata, that, date, a, j, "", -1);
        }
      }

    }
    },
    initializeData(json, that, date, a, j, index2, status) {
      //var lastdate=[]

      ////alert("date"+ date)
      that.date = date;

      for(let m=0; m<150;m++)
        this.popSerial()

      ////alert(a+" "+"undefined")
      if (a + "" != "undefined") {
        ////alert("called")

        var len2 = json.data[j][date].length;

        ////alert("len2 "+len2)
        if ((index2 + "" == "" || index2 + "" == "undefined") && status == -1) {
          index2 = len2 - 1;
        } else if (
          (index2 + "" == "" || index2 + "" == "undefined") &&
          status == 1
        ) {
          index2 = 0;
        }

        ////alert(JSON.stringify(json.data[j][date]))

        ////alert(lastdate + "index2 is "+index2)

        var final = JSON.parse(JSON.stringify(json.data[j][date][index2]));
        //  that.cashVauchers = j.tableData;

        that.purchase1b_supplier = final.data.purchase1b_supplier;
        that.purchase1b_city = final.data.purchase1b_city;
        that.purchase1b_gstno = final.data.purchase1b_gstno;
        that.purchase1b_billno = final.data.purchase1b_billno;
        that.purchase1b_billdate = final.data.purchase1b_billdate;
        that.purchase1b_terms = final.data.purchase1b_terms;
        that.purchase1b_taxtype = final.data.purchase1b_taxtype;
        that.purchase1b_selfinv = final.data.purchase1b_selfinv;
        that.purchase1b_billcash = final.data.purchase1b_billcash;
        that.purchase1b_gstr2astatus = final.data.purchase1b_gstr2astatus;
        that.purchase1b_transport = final.data.purchase1b_transport;
        that.purchase1b_broker = final.data.purchase1b_broker;
        that.purchase1b_inputdt = final.data.purchase1b_inputdt;
        that.purchase1b_duedate = final.data.purchase1b_duedate;
        that.purchase1b_grno = final.data.purchase1b_grno;
        that.purchase1b_vehicle = final.data.purchase1b_vehicle;
        that.purchase1b_totalgst = final.data.purchase1b_totalgst;
        that.purchase1b_adjustadvancers = final.data.purchase1b_adjustadvancers;
        that.purchase1b_cess1 = final.data.purchase1b_cess1;
        that.purchase1b_cess2 = final.data.purchase1b_cess2;
        that.purchase1b_subtotal = final.data.purchase1b_subtotal;
        that.purchase1b_addless = final.data.purchase1b_addless;
        that.purchase1b_cgst = final.data.purchase1b_cgst;
        that.purchase1b_sgst = final.data.purchase1b_sgst;
        that.purchase1b_igst = final.data.purchase1b_igst;
        that.purchase1b_expenses = final.data.purchase1b_expenses;
        that.purchase1b_grandtotal = final.data.purchase1b_grandtotal;
        
      that.expense1_1 = final.data.expense1_1
      that.expense1_2 = final.data.expense1_2
      that.expense1_3 = final.data.expense1_3
      that.expense1_4 = final.data.expense1_4
      that.expense1_5 = final.data.expense1_5
      that.expense1_6 = final.data.expense1_6
      that.expense1_7 = final.data.expense1_7
      that.expense1_8 = final.data.expense1_8
      that.expense1_9 = final.data.expense1_9
      that.expense1_10 = final.data.expense1_10
      that.expense1_11 = final.data.expense1_11
      that.expense1_12 = final.data.expense1_12

      that.expense2_1 = final.data.expense2_1
      that.expense2_2 = final.data.expense2_2
      that.expense2_3 = final.data.expense2_3
      that.expense2_4 = final.data.expense2_4
      that.expense2_5 = final.data.expense2_5
      that.expense2_6 = final.data.expense2_6
      that.expense2_7 = final.data.expense2_7
      that.expense2_8 = final.data.expense2_8
      that.expense2_9 = final.data.expense2_9
      that.expense2_10 = final.data.expense2_10
      that.expense2_11 = final.data.expense2_11
      that.expense2_12 = final.data.expense2_12
      that.expense2_13= final.data.expense2_13
      that.expense2_14= final.data.expense2_14


      that.man_supplier= final.data.man_supplier;
      that.man_billno= final.data.man_billno;
      that.man_billdate=  final.data.man_billdate;
      that.man_weight=  final.data.man_weight;
      that.man_pageno= final.data.man_pageno;
      that.man_rate=  final.data.man_rate;
      that.man_entryno= final.data.man_entryno;
      that.man_assvalue=  final.data.man_assvalue;
      that.man_impgoods= final.data.man_impgoods;
      that.man_bed1=  final.data.man_bed1;
      that.man_bed2= final.data.man_bed2;
      that.man_cess1= final.data.man_cess1;
      that.man_cess2=  final.data.man_cess2;
      that.man_hcess1=  final.data.man_hcess1;
      that.man_hcess2= final.data.man_hcess2;
      that.man_aduty1=  final.data.man_aduty1;
      that.man_aduty2=  final.data.man_aduty2;
      that.man_vatcst1=  final.data.man_vatcst1;
      that.man_vatcst2=  final.data.man_vatcst2;

        var voucherval = final.voucherno;
        if (index2 == len2 - 1) that.originalvoucherno = voucherval;
        else {
          that.originalvoucherno = json.data[j][date].length;
        }
        document.getElementById("voucherno").value = voucherval;
        that.voucherno = voucherval;
        that.original = that.voucherno;
var list=[]
for(let v=0;v<final.tableData.length;v++)
{var obj={}

for(let b=0;b<Object.keys(final.tableData[v]).length;b++)
{
let m = 'head' + b.toString();


obj[m]=final.tableData[v][Object.keys(this.conditionalColumn)[b]]
}
list.push(obj)
}

this.cashVauchers=list

 for (let t = 0; t < final.tableData.length; t++) {
   this.addNewSerial()
            that.srnos[t].counter=t+1
 }
 this.rowlength=final.tableData.length;
    
      } else {
        that.voucherno = 1;
        that.purchase1b_supplier = "";
        that.purchase1b_city = "";
        that.purchase1b_gstno = "";
        that.purchase1b_billno = "";
        that.purchase1b_billdate = "";
        that.purchase1b_terms = "";

        that.purchase1b_taxtype = "";

        that.purchase1b_billcash = "";
        that.purchase1b_selfinv = "";

        that.purchase1b_gstr2astatus = "";

        that.purchase1b_transport = "";
        that.purchase1b_broker = "";
        that.purchase1b_inputdt = "";

        that.purchase1b_duedate = "";
        that.purchase1b_adjustadvancers = "";

        that.purchase1b_vehicle = "";

        that.purchase1b_grno = "";

        that.purchase1b_totalgst = "";
        that.purchase1b_cess1 = "";
        that.purchase1b_cess2 = "";
        that.purchase1b_subtotal = "";
        that.purchase1b_addless = "";
        that.purchase1b_cgst = "";
        that.purchase1b_sgst = "";

        that.purchase1b_igst = "";
        that.purchase1b_expenses = "";
        that.purchase1b_grandtotal = "";

      that.expense1_1 = "";
      that.expense1_2 = "";
      that.expense1_3 = "";
      that.expense1_4 = "";
      that.expense1_5 = "";
      that.expense1_6 = "";
      that.expense1_7 = "";
      that.expense1_8 = "";
      that.expense1_9 = "";
      that.expense1_10 = "";
      that.expense1_11 = "";
      that.expense1_12 = "";

      that.expense2_1 = "";
      that.expense2_2 = "";
      that.expense2_3 = "";
      that.expense2_4 = "";
      that.expense2_5 = "";
      that.expense2_6 = "";
      that.expense2_7 = "";
      that.expense2_8 = "";
      that.expense2_9 = "";
      that.expense2_10 = "";
      that.expense2_11 = "";
      that.expense2_12 = "";
      that.expense2_13= "";
      that.expense2_14= "";

      that.man_supplier= "";
      that.man_billno= "";
      that.man_billdate=  "";
      that.man_weight=  "";
      that.man_pageno= "";
      that.man_rate=  "";
      that.man_entryno= "";
      that.man_assvalue=  "";
      that.man_impgoods= "";
      that.man_bed1=  "";
      that.man_bed2= "";
      that.man_cess1= "";
      that.man_cess2=  "";
      that.man_hcess1=  "";
      that.man_hcess2= "";
      that.man_aduty1=  "";
      that.man_aduty2=  "";
      that.man_vatcst1=  "";
      that.man_vatcst2=  "";

        if (that.searchclicked != "true") that.disAdd = true;
    that.rowlength=1

    
 
   that.addNewSerial()
            that.srnos[0].counter=1
 
      }
    },
    enableSave() {
      this.disSave = false;
    },
    tabKeyTrig(p) {
      // alert("triggrerted")
      let id = p.slice(0, -1);
      let k = p.substring(p.length - 1, p.length);
      if (id == "receipt") {
        //alert("triggrerted")
        if (this.cashVauchers[k].receipt == "") {
          //alert("kahli")
          let s = "2" + parseInt(k);

          //alert(s)
          document.getElementById(s).focus();
          this.$forceUpdate();
        } else {
          let s = "discount";
          s += k;
          document.getElementById(s).focus();
        }
      }
    },

    updateTotals() {
      this.paymentTotal = 0.0;
      this.receiptTotal = 0.0;
      this.discountTotal = 0.0;
      for (let i = 0; i < this.cashVauchers.length; i++) {
        if (this.cashVauchers[i].payment != "") {
          this.paymentTotal += parseFloat(this.cashVauchers[i].payment);
        }

        if (this.cashVauchers[i].receipt != "") {
          this.receiptTotal += parseFloat(this.cashVauchers[i].receipt);
        }

        if (this.cashVauchers[i].discount != "") {
          this.discountTotal += parseFloat(this.cashVauchers[i].discount);
        }
      }

      if (this.paymentTotal + this.receiptTotal > 0) {
        this.disSave = false;
      } else {
        this.disSave = true;
      }
      // alert(this.paymentTotal + " " + this.receiptTotal + " " + this.discountTotal);
      this.$forceUpdate();
    },

    narrationModify2() {
      let n = 0;
      this.narrations.forEach(y => {
        if (y.gstin == this.oldNarrationToEdit) {
          this.narrations[n].gstin = this.modifiedNarration;
        }
        n++;
      });
      this.spdata = this.narrations;

      this.spdata = [];
      //alert(this.spdata)
      for (let i = 0; i < this.narrations.length; i++) {
        this.spdata.push(this.narrations[i].gstin + "");
      }
      this.popupActive6 = false;
    },
    narrationModify() {
      var indexList = [];
      //alert(indexList);
      for (var x = 0; x < this.filteredNarrations.length; x++) {
        let p = "narrationCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.filteredNarrations[x]);
          document.getElementById(p).checked = false;
        }
      }
      //alert("reached here ")
      this.modifiedNarration = indexList[0].gstin;
      this.popupActive6 = true;
      this.activeWindowsList.push("popupActive6");

      // alert("reached here too")
      document.getElementById("modifyNarrationBox").focus();
      // alert("reached here too")
      this.$forceUpdate();
      // alert("To be added after permission  check is done");
    },
    narrationDelete() {
      var indexList = [];
      //alert(indexList);
      for (var x = 0; x < this.filteredNarrations.length; x++) {
        let p = "narrationCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.filteredNarrations[x]);
          document.getElementById(p).checked = false;
        }
      }

      indexList.forEach(x => {
        var n = 0;
        this.narrations.forEach(y => {
          if (y.id == x.id) {
            this.narrations.splice(n, 1);
          }
          n++;
        });
      });
      this.spdata = [];
      //alert(this.spdata)
      for (let i = 0; i < this.narrations.length; i++) {
        this.spdata.push(this.narrations[i].gstin + "");
      }
      // alert(indexList);

      //document.getElementById(p).checked == true ?alert( document.getElementById(p).value) : alert("lauda");
    },
    AddNewDetails() {
      var newId = this.users[this.users.length - 1].id + 1;
      var p = {
        id: newId,
        accountname: this.newAccountName.slice(1),
        cityname: this.newCityName,
        address: this.newAddress,
        gstin: this.newGSTIN,
        contactno: this.newContact,
        mobile: this.newMobile
      };
      this.users.push(p);
      // alert("pooooop" + this.users[this.users.length - 1].accountname);
      this.newAccountName = " ";
      this.newCityName = " ";
      this.newGSTIN = " ";
      this.newAddress = " ";
      this.newContact = " ";
      this.newMobile = " ";

      this.popupActive4 = false;
      this.$forceUpdate();
    },
    AddNewNarration() {
      var newId = this.narrations[this.narrations.length - 1].id + 1;
      var p = {
        id: newId,
        accountname: " ",
        cityname: "",
        address: " ",
        gstin: this.newNarration,
        contactno: " ",
        mobile: " "
      };
      this.narrations.push(p);
      // alert("pooooop" + this.users[this.users.length - 1].accountname);
      this.newNarration = " ";

      this.popupActive5 = false;
      this.spdata = [];
      //alert(this.spdata)
      for (let i = 0; i < this.narrations.length; i++) {
        this.spdata.push(this.narrations[i].gstin + "");
      }
      this.$forceUpdate();
    },
    deletePopup() {
      this.selected.forEach(x => {
        var p = 0;
        this.users.forEach(y => {
          if (y.id == x.id) {
            this.users.splice(p, 1);
          }
          p++;
        });
      });
      this.selected = [];

      
    },
    caseScence(k) {
      var str = this.cashVauchers[k].narration;
      var splitStr = str.toLowerCase().split(" ");
      for (var i = 0; i < splitStr.length; i++) {
        splitStr[i] =
          splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
      }
      this.cashVauchers[k].narration = splitStr.join(" ");
    },
    changeHeaders() {
      this.CheckBox1 != null
        ? (this.popupHeaders[0].show = true)
        : (this.popupHeaders[0].show = false);
      this.CheckBox2 != null
        ? (this.popupHeaders[1].show = true)
        : (this.popupHeaders[1].show = false);
      this.CheckBox3 != null
        ? (this.popupHeaders[2].show = true)
        : (this.popupHeaders[2].show = false);
      this.CheckBox4 != null
        ? (this.popupHeaders[3].show = true)
        : (this.popupHeaders[3].show = false);
      this.CheckBox5 != null
        ? (this.popupHeaders[4].show = true)
        : (this.popupHeaders[4].show = false);
      this.CheckBox6 != null
        ? (this.popupHeaders[5].show = true)
        : (this.popupHeaders[5].show = false);

      this.$forceUpdate();
      //alert( +"   "+ this.CheckBox2 +"   " + this.CheckBox3 +"   "+ this.CheckBox4+"   " + this.CheckBox5 +"   "+ this.CheckBox6 );
    },
    isShow(k) {
      return this.popupHeaders[k].show;
    },
    isnarration(n) {
      if (n == 1) return true;
      else return false;
    },
    popupKeyUp() {
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (this.popupSelectedRow == 0) {
        this.filteredUsers.length < 100
          ? (this.popupSelectedRow = this.filteredUsers.length)
          : (this.popupSelectedRow = 15);
      }
      this.popupSelectedRow = this.popupSelectedRow - 1;
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
    navPopupKeyUp() {
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (this.popupSelectedRow == 0) {
        this.filteredUsers.length < 100
          ? (this.popupSelectedRow = this.filteredUsers.length)
          : (this.popupSelectedRow = 15);
      }
      this.popupSelectedRow = this.popupSelectedRow - 1;
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },

    popupKeyDown() {
      // alert(this.popupSelectedRow);
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (
        this.popupSelectedRow == this.filteredUsers.length - 1 ||
        this.popupSelectedRow >= 15
      ) {
        this.popupSelectedRow = -1;
      }
      this.popupSelectedRow = this.popupSelectedRow + 1;
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
    navPopupKeyDown() {
      // alert(this.popupSelectedRow);
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (this.popupSelectedRow == this.filteredUsers.length - 1) {
        this.popupSelectedRow = -1;
      }
      this.popupSelectedRow = this.popupSelectedRow + 1;
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
    filteredList() {
      // alert("p");
      let p = document.getElementById("filterbar").value.toLowerCase();
      var searchtag = "accountname";
      this.filteredUsers = [];

      if (p == "") {
        this.filteredUsers = this.users;
      } else {
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            //alert("reached");
            searchtag = this.users[x].accountname.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = this.users[x].cityname.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].address.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].gstin.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].contactno.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].mobile.toLowerCase();
          }

          if (searchtag.indexOf(p) != -1) {
            //alert(name);
            this.filteredUsers.push(this.users[x]);
          }
        }
      }
      this.popupSelectedRow = 0;
    },
    filteredList2() {
      // alert("p");
      let p = this.filterbar2.toLowerCase();
      var searchtag = "accountname";
      this.filteredNarrations = [];

      if (p == "") {
        this.filteredNarrations = this.narrations;
      } else {
        for (var x in this.narrations) {
          //let id = this.users[x].id.toLowerCase();
          searchtag = this.narrations[x].gstin.toLowerCase();

          if (searchtag.indexOf(p) == 0) {
            // alert(searchtag);
            this.filteredNarrations.push(this.narrations[x]);
          }
        }
      }
      this.popupSelectedRow = 0;
    },

    searchedList(p) {
      //alert(p);
      if (p + "" != "-1") {
        //alert("popup")
        this.rowNumberIndicator = p;
        p = this.cashVauchers[this.rowNumberIndicator].accountno;
        // alert(p+" is awesome")
        this.searchbar = p + "";
        this.popupSelectedRow = 0;

        this.popupActive2 = true;
        this.activeWindowsList.push("popupActive2");

        document.getElementById("searchbar").focus();

        document.getElementById(
          "popupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";

        this.$forceUpdate();
      } else {
        p = document.getElementById("searchbar").value.toLowerCase();
        //alert(p);
      }

      var searchtag = "accountname";

      this.filteredUsers = [];

      // alert(searchtag);

      if (p == "") {
        //  alert("p=khali")
        this.filteredUsers = this.users;
      } else {
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          //searchtag = this.users[x].accountname.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            //alert("reached");
            searchtag = this.users[x].accountname.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = this.users[x].cityname.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].address.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].gstin.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].contactno.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].mobile.toLowerCase();
          }

          if (this.selectedDropdown == "")
            searchtag = this.users[x].accountname.toLowerCase();
          var search, p2;
          search = searchtag.trim();
          p2 = p.trim();
          if (search.indexOf(p2.toLowerCase()) == 0) {
            // alert(searchtag+" heya");

            this.filteredUsers.push(this.users[x]);
          }
        }
      }
    },

    // get collection
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },
    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    getData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var that = this;
      

for(let m=0; m<150;m++)
        this.popSerial()
   
      var exp = {
        companyname: companyName,
        directory: "purchasegst.json"
      };
      var voucherval;
      //alert("seinding this to get data: " +JSON.stringify(exp))
      axios
        .post("/getPurchaseGstData", exp)
        .then(response => {
        
          var data = JSON.stringify(response.data);

          var json = JSON.parse(data);
          that.purchasegstdata = json;

          var len = json.data.length;

          ////alert(len-1)

          var lastdate = Object.keys(json.data[len - 1])[0];
          var len2 = json.data[len - 1][lastdate].length;
          that.date = lastdate;
          that.lastDateis = lastdate;

          ////alert(JSON.stringify(json.data[len-1][lastdate]))

          ////alert(lastdate)

          var j = JSON.parse(
            JSON.stringify(json.data[len - 1][lastdate][len2 - 1])
          );

          ////alert(JSON.stringify(json.data[len-1][lastdate][len2-1]))

          //   var j=  JSON.parse(JSON.stringify(item[dateis][item[dateis].length-1]))
          //
          ////alert(JSON.stringify(item[dateis][item[dateis].length-1]))

          voucherval = j.voucherno;

          document.getElementById("voucherno").value = voucherval;
          that.voucherno = voucherval;
          that.originalvoucherno = voucherval;
           

          

var list=[]
for(let v=0;v<j.tableData.length;v++)
{var obj={}

for(let b=0;b<Object.keys(j.tableData[v]).length;b++)
{
let m = 'head' + b.toString();
obj[m]=j.tableData[v][Object.keys(this.conditionalColumn)[b]]
}
list.push(obj)
}
          that.cashVauchers = list;

   for (let t = 0; t < j.tableData.length; t++) {
    
             this.addNewSerial()
            that.srnos[t].counter=t+1
   }

   that.rowlength=j.tableData.length;
   

          this.purchase1b_supplier = j.data.purchase1b_supplier;
          this.purchase1b_city = j.data.purchase1b_city;
          this.purchase1b_gstno = j.data.purchase1b_gstno;
          this.purchase1b_billno = j.data.purchase1b_billno;
          this.purchase1b_billdate = j.data.purchase1b_billdate;
          this.purchase1b_terms = j.data.purchase1b_terms;
          this.purchase1b_taxtype = j.data.purchase1b_taxtype;
          this.purchase1b_selfinv = j.data.purchase1b_selfinv;
          this.purchase1b_billcash = j.data.purchase1b_billcash;
          this.purchase1b_gstr2astatus = j.data.purchase1b_gstr2astatus;
          this.purchase1b_transport = j.data.purchase1b_transport;
          this.purchase1b_broker = j.data.purchase1b_broker;
          this.purchase1b_inputdt = j.data.purchase1b_inputdt;
          this.purchase1b_duedate = j.data.purchase1b_duedate;
          this.purchase1b_grno = j.data.purchase1b_grno;
          this.purchase1b_vehicle = j.data.purchase1b_vehicle;
          this.purchase1b_totalgst = j.data.purchase1b_totalgst;
          this.purchase1b_adjustadvancers = j.data.purchase1b_adjustadvancers;
          this.purchase1b_cess1 = j.data.purchase1b_cess1;
          this.purchase1b_cess2 = j.data.purchase1b_cess2;
          this.purchase1b_subtotal = j.data.purchase1b_subtotal;
          this.purchase1b_addless = j.data.purchase1b_addless;
          this.purchase1b_cgst = j.data.purchase1b_cgst;
          this.purchase1b_sgst = j.data.purchase1b_sgst;
          this.purchase1b_igst = j.data.purchase1b_igst;
          this.purchase1b_expenses = j.data.purchase1b_expenses;
          this.purchase1b_grandtotal = j.data.purchase1b_grandtotal;

      this.expense1_1 = j.data.expense1_1
      this.expense1_2 = j.data.expense1_2
      this.expense1_3 = j.data.expense1_3
      this.expense1_4 = j.data.expense1_4
      this.expense1_5 = j.data.expense1_5
      this.expense1_6 = j.data.expense1_6
      this.expense1_7 = j.data.expense1_7
      this.expense1_8 = j.data.expense1_8
      this.expense1_9 = j.data.expense1_9
      this.expense1_10 = j.data.expense1_10
      this.expense1_11 = j.data.expense1_11
      this.expense1_12 = j.data.expense1_12

      this.expense2_1 = j.data.expense2_1
      this.expense2_2 = j.data.expense2_2
      this.expense2_3 = j.data.expense2_3
      this.expense2_4 = j.data.expense2_4
      this.expense2_5 = j.data.expense2_5
      this.expense2_6 = j.data.expense2_6
      this.expense2_7 = j.data.expense2_7
      this.expense2_8 = j.data.expense2_8
      this.expense2_9 = j.data.expense2_9
      this.expense2_10 = j.data.expense2_10
      this.expense2_11 = j.data.expense2_11
      this.expense2_12 = j.data.expense2_12
      this.expense2_13= j.data.expense2_13
      this.expense2_14= j.data.expense2_14


      this.man_supplier= j.data.man_supplier;
      this.man_billno= j.data.man_billno;
      this.man_billdate=  j.data.man_billdate;
      this.man_weight=  j.data.man_weight;
      this.man_pageno= j.data.man_pageno;
      this.man_rate=  j.data.man_rate;
      this.man_entryno= j.data.man_entryno;
      this.man_assvalue=  j.data.man_assvalue;
      this.man_impgoods= j.data.man_impgoods;
      this.man_bed1=  j.data.man_bed1;
      this.man_bed2= j.data.man_bed2;
      this.man_cess1= j.data.man_cess1;
      this.man_cess2=  j.data.man_cess2;
      this.man_hcess1=  j.data.man_hcess1;
      this.man_hcess2= j.data.man_hcess2;
      this.man_aduty1=  j.data.man_aduty1;
      this.man_aduty2=  j.data.man_aduty2;
      this.man_vatcst1=  j.data.man_vatcst1;
      this.man_vatcst2=  j.data.man_vatcst2;


        })
        .catch(error => {
          
          alert(error);
        });
    },


        saveContinuous() {

         //   alert("cont");

            



            var user = sessionStorage.getItem("user");

            var companyName = JSON.parse(user)[0].companyname;



            let tablebuff = [];

            let modelbuff = {};

            let ilen = this.cashVauchers.length;



            for (let z = 0; z < ilen; z++) {

                modelbuff = {};

                for (let i = 0; i < 199; i++) {

                    let m = "head" + i.toString();

                    // //alert("ummmed ki value: " +  this.cashVauchers[0][m])

                    modelbuff[Object.keys(this.conditionalColumn)[i]] = this.cashVauchers[

                        z

                    ][m];

                }

                tablebuff.push(modelbuff);

            }



            // alert("at this point, AcCode is: " + this.Accode);

            var n = {

                dataAll: {
                  voucherno: this.voucherno,

                    date: this.date,

                     purchase1b_supplier: this.purchase1b_supplier,
        purchase1b_city: this.purchase1b_city,
        purchase1b_gstno: this.purchase1b_gstno,
        purchase1b_billno: this.purchase1b_billno,
        purchase1b_billdate: this.purchase1b_billdate,
        purchase1b_terms: this.purchase1b_terms,
        purchase1b_taxtype: this.purchase1b_taxtype,
        purchase1b_selfinv: this.purchase1b_selfinv,
        purchase1b_billcash: this.purchase1b_billcash,
        purchase1b_gstr2astatus: this.purchase1b_gstr2astatus,
        purchase1b_transport: this.purchase1b_transport,
        purchase1b_broker: this.purchase1b_broker,
        purchase1b_inputdt: this.purchase1b_inputdt,
        purchase1b_duedate: this.purchase1b_duedate,
        purchase1b_grno: this.purchase1b_grno,
        purchase1b_vehicle: this.purchase1b_vehicle,
        purchase1b_totalgst: this.purchase1b_totalgst,
        purchase1b_adjustadvancers: this.purchase1b_adjustadvancers,
        purchase1b_cess1: this.purchase1b_cess1,
        purchase1b_cess2: this.purchase1b_cess2,
        purchase1b_subtotal: this.purchase1b_subtotal,
        purchase1b_addless: this.purchase1b_addless,
        purchase1b_cgst: this.purchase1b_cgst,
        purchase1b_sgst: this.purchase1b_sgst,
        purchase1b_igst: this.purchase1b_igst,
        purchase1b_expenses: this.purchase1b_expenses,
        purchase1b_grandtotal: this.purchase1b_grandtotal,
        expense1_1: this.expense1_1,
        expense1_2: this.expense1_2,
        expense1_3: this.expense1_3,
        expense1_4: this.expense1_4,
        expense1_5: this.expense1_5,
        expense1_6: this.expense1_6,
        expense1_7: this.expense1_7,
        expense1_8: this.expense1_8,
        expense1_9: this.expense1_9,
        expense1_10: this.expense1_10,
        expense1_11: this.expense1_11,
        expense1_12: this.expense1_12,

        expense2_1: this.expense2_1,
        expense2_2: this.expense2_2,
        expense2_3: this.expense2_3,
        expense2_4: this.expense2_4,
        expense2_5: this.expense2_5,
        expense2_6: this.expense2_6,
        expense2_7: this.expense2_7,
        expense2_8: this.expense2_8,
        expense2_9: this.expense2_9,
        expense2_10: this.expense2_10,
        expense2_11: this.expense2_11,
        expense2_12: this.expense2_12,
        expense2_13: this.expense2_13,
        expense2_14: this.expense2_14,

      man_supplier: this.man_supplier,
      man_billno: this.man_billno,
      man_billdate:  this.man_billdate,
      man_weight:  this.man_weight,
      man_pageno: this.man_pageno,
      man_rate:  this.man_rate,
      man_entryno: this.man_entryno,
      man_assvalue:  this.man_assvalue,
      man_impgoods: this.man_impgoods,
      man_bed1:  this.man_bed1,
      man_bed2: this.man_bed2,
      man_cess1: this.man_cess1,
      man_cess2:  this.man_cess2,
      man_hcess1:  this.man_hcess1,
      man_hcess2: this.man_hcess2,
      man_aduty1:  this.man_aduty1,
      man_aduty2:  this.man_aduty2,
      man_vatcst1:  this.man_vatcst1,
      man_vatcst2:  this.man_vatcst2,

                    tableData: tablebuff

                },

                companyname: companyName,

                isEditingOld: this.isEditingOld,

                heading: this.heading

            };



            //alert(JSON.stringify(n));

            axios

                .post("http://localhost:2000/SavePurchaseContinuous", n)

                .then(response => {

                    // alert(JSON.stringify(response.data));



                    //this.DuplicateNotify(JSON.stringify(response.data));

                    let resp = JSON.stringify(response.data.dooda);

                    resp = resp.slice(0, -1);

                    resp = resp.substring(1);



                    this.dbIndex = parseInt(this.voucherno) - 1;

                    if (resp == "duplicate") {

                        //alert("duplicate");

                        this.RedAlert("Duplicate Name Not Allowed !");

                    } else {

                        // alert(" saved");

                        this.GreenAlert("Saved New Stock Account Successfully");

                    }



                    //this.Savenotify();

                    // alert("saved")

                })

                .catch(error => {

                    alert(error);

                });



            this.buttondis = true;



            this.buttonen = false;

            this.disAdd = false;

            this.disCopy = false;

            this.disDelete = false;

            this.disEdit = false;

            this.disFirst = false;

            this.disLast = false;

            this.disNext = false;

            this.disSave = true;

            this.disSearch = false;

            this.disPrinter = false;

            this.disPrevious = false;

            this.disExit = false;



            this.isEditingOld = false;

        },


    save() {
      if(this.isContinuous==true)
this.saveContinuous()
else{
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var that = this;
      var exportData = { data: [] };
      var datee = this.date;
      var mydata = {};
      var alldata = {
        purchase1b_supplier: this.purchase1b_supplier,
        purchase1b_city: this.purchase1b_city,
        purchase1b_gstno: this.purchase1b_gstno,
        purchase1b_billno: this.purchase1b_billno,
        purchase1b_billdate: this.purchase1b_billdate,
        purchase1b_terms: this.purchase1b_terms,
        purchase1b_taxtype: this.purchase1b_taxtype,
        purchase1b_selfinv: this.purchase1b_selfinv,
        purchase1b_billcash: this.purchase1b_billcash,
        purchase1b_gstr2astatus: this.purchase1b_gstr2astatus,
        purchase1b_transport: this.purchase1b_transport,
        purchase1b_broker: this.purchase1b_broker,
        purchase1b_inputdt: this.purchase1b_inputdt,
        purchase1b_duedate: this.purchase1b_duedate,
        purchase1b_grno: this.purchase1b_grno,
        purchase1b_vehicle: this.purchase1b_vehicle,
        purchase1b_totalgst: this.purchase1b_totalgst,
        purchase1b_adjustadvancers: this.purchase1b_adjustadvancers,
        purchase1b_cess1: this.purchase1b_cess1,
        purchase1b_cess2: this.purchase1b_cess2,
        purchase1b_subtotal: this.purchase1b_subtotal,
        purchase1b_addless: this.purchase1b_addless,
        purchase1b_cgst: this.purchase1b_cgst,
        purchase1b_sgst: this.purchase1b_sgst,
        purchase1b_igst: this.purchase1b_igst,
        purchase1b_expenses: this.purchase1b_expenses,
        purchase1b_grandtotal: this.purchase1b_grandtotal,
        expense1_1: this.expense1_1,
        expense1_2: this.expense1_2,
        expense1_3: this.expense1_3,
        expense1_4: this.expense1_4,
        expense1_5: this.expense1_5,
        expense1_6: this.expense1_6,
        expense1_7: this.expense1_7,
        expense1_8: this.expense1_8,
        expense1_9: this.expense1_9,
        expense1_10: this.expense1_10,
        expense1_11: this.expense1_11,
        expense1_12: this.expense1_12,

        expense2_1: this.expense2_1,
        expense2_2: this.expense2_2,
        expense2_3: this.expense2_3,
        expense2_4: this.expense2_4,
        expense2_5: this.expense2_5,
        expense2_6: this.expense2_6,
        expense2_7: this.expense2_7,
        expense2_8: this.expense2_8,
        expense2_9: this.expense2_9,
        expense2_10: this.expense2_10,
        expense2_11: this.expense2_11,
        expense2_12: this.expense2_12,
        expense2_13: this.expense2_13,
        expense2_14: this.expense2_14,

      man_supplier: this.man_supplier,
      man_billno: this.man_billno,
      man_billdate:  this.man_billdate,
      man_weight:  this.man_weight,
      man_pageno: this.man_pageno,
      man_rate:  this.man_rate,
      man_entryno: this.man_entryno,
      man_assvalue:  this.man_assvalue,
      man_impgoods: this.man_impgoods,
      man_bed1:  this.man_bed1,
      man_bed2: this.man_bed2,
      man_cess1: this.man_cess1,
      man_cess2:  this.man_cess2,
      man_hcess1:  this.man_hcess1,
      man_hcess2: this.man_hcess2,
      man_aduty1:  this.man_aduty1,
      man_aduty2:  this.man_aduty2,
      man_vatcst1:  this.man_vatcst1,
      man_vatcst2:  this.man_vatcst2,

      };

       let tablebuff = [];
      let modelbuff = {};
      let ilen = this.cashVauchers.length;

      for(let z =0; z<ilen; z++)
      {modelbuff = {};
        for(let i =0; i<199; i++)
      {
        let m = 'head' + i.toString();
       // //alert("ummmed ki value: " +  this.cashVauchers[0][m])
        modelbuff[Object.keys(this.conditionalColumn)[i]] = this.cashVauchers[z][m]
      }
      tablebuff.push(modelbuff)
      }

      mydata[datee] = [
        {
          voucherno: this.voucherno + "",
          tableData: tablebuff,
          data: alldata
        }
      ];

      exportData.data.push(mydata);

      var value = {
        companyname: companyName,
        exportdata: JSON.stringify(exportData),
        date: datee,
        voucherno: this.voucherno
      };
      alert("request");
      axios
        .post("/SavePurchaseGst", value)
        .then(response => {
          var data = JSON.stringify(response.data);
          that.purchasegstdata = JSON.parse(data);
          that.purchasegstdata.data.filter(function(item) {
            if (item[datee] + "" != "undefined") {
              ////alert("in here"+item[date])
              that.originalvoucherno = item[datee].length;

              ////alert("this is original"+that.originalvoucherno)
            }
          });
        })
        .catch(error => {
          alert(error);
        });
      this.buttondis = true;
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;

      document.getElementById("addButton").focus();
      (this.buttonActiveList = [
        "active",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ]),
        this.$forceUpdate();
}
    },
    // Add button
    newdisable() {
      this.searchclicked = "false";
      this.addButtonClicked = "true";
      this.disVoucher = true;
      this.disDate = false;
      this.disCopy = true;
      this.disDelete = true;
      this.disAdd = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = true;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.titleAction = "NEW";
      this.buttondis = false;
      this.disAdd = true;
      this.titleAction = "NEW";

  if (this.isContinuous == false) {

                if (this.date == this.lastDateis && this.date != this.now) {

                    this.date = this.now + "";

                    this.dateChange();

                } else {

                    // alert("angrezi")

                    this.voucherno = parseInt(this.originalvoucherno + "") + 1;

                    if (this.voucherno >= 1) {

                        //  console.log("new");

                    } else {

                        this.voucherno = 1;

                    }

                }

            } 
else
     { if (this.date == this.lastDateis && this.date != this.now) {
        
          this.date = this.now + "";

          this.dateChange();
        }
       
       this.voucherno = parseInt(this.lastIndex + "") + 2;
     }


for(let m=0; m<150;m++)
  this.popSerial()

this.rowlength=0;

this.addNewRow();

this.srnos[0].counter=1

       this.cashVauchers = [{

                //UPDATE1   // DECLARATION OF CASHVAUCHERS, i'm marking this to find this bugger faster

                head0: "",

                head1: "",

                head2: "",

                head3: "",

                head4: "",

                head5: "",

                head6: "",

                head7: "",

                head8: "",

                head9: "",

                head10: "",

                head11: "",

                head12: "",

                head13: "",

                head14: "",

                head15: "",

                head16: "",

                head17: "",

                head18: "",

                head19: "",

                head20: "",

                head21: "",

                head22: "",

                head23: "",

                head24: "",

                head25: "",

                head26: "",

                head27: "",

                head28: "",

                head29: "",

                head30: "",

                head31: "",

                head32: "",

                head33: "",

                head34: "",

                head35: "",

                head36: "",

                head37: "",

                head38: "",

                head39: "",

                head40: "",

                head41: "",

                head42: "",

                head43: "",

                head44: "",

                head45: "",

                head46: "",

                head47: "",

                head48: "",

                head49: "",

                head50: "",

                head51: "",

                head52: "",

                head53: "",

                head54: "",

                head55: "",

                head56: "",

                head57: "",

                head58: "",

                head59: "",

                head60: "",

                head61: "",

                head62: "",

                head63: "",

                head64: "",

                head65: "",

                head66: "",

                head67: "",

                head68: "",

                head69: "",

                head70: "",

                head71: "",

                head72: "",

                head73: "",

                head74: "",

                head75: "",

                head76: "",

                head77: "",

                head78: "",

                head79: "",

                head80: "",

                head81: "",

                head82: "",

                head83: "",

                head84: "",

                head85: "",

                head86: "",

                head87: "",

                head88: "",

                head89: "",

                head90: "",

                head91: "",

                head92: "",

                head93: "",

                head94: "",

                head95: "",

                head96: "",

                head97: "",

                head98: "",

                head99: "",

                head100: "",

                head101: "",

                head102: "",

                head103: "",

                head104: "",

                head105: "",

                head106: "",

                head107: "",

                head108: "",

                head109: "",

                head110: "",

                head111: "",

                head112: "",

                head113: "",

                head114: "",

                head115: "",

                head116: "",

                head117: "",

                head118: "",

                head119: "",

                head120: "",

                head121: "",

                head122: "",

                head123: "",

                head124: "",

                head125: "",

                head126: "",

                head127: "",

                head128: "",

                head129: "",

                head130: "",

                head131: "",

                head132: "",

                head133: "",

                head134: "",

                head135: "",

                head136: "",

                head137: "",

                head138: "",

                head139: "",

                head140: "",

                head141: "",

                head142: "",

                head143: "",

                head144: "",

                head145: "",

                head146: "",

                head147: "",

                head148: "",

                head149: "",

                head150: "",

                head151: "",

                head152: "",

                head153: "",

                head154: "",

                head155: "",

                head156: "",

                head157: "",

                head158: "",

                head159: "",

                head160: "",

                head161: "",

                head162: "",

                head163: "",

                head164: "",

                head165: "",

                head166: "",

                head167: "",

                head168: "",

                head169: "",

                head170: "",

                head171: "",

                head172: "",

                head173: "",

                head174: "",

                head175: "",

                head176: "",

                head177: "",

                head178: "",

                head179: "",

                head180: "",

                head181: "",

                head182: "",

                head183: "",

                head184: "",

                head185: "",

                head186: "",

                head187: "",

                head188: "",

                head189: "",

                head190: "",

                head191: "",

                head192: "",

                head193: "",

                head194: "",

                head195: "",

                head196: "",

                head197: "",

                head198: "",

                head199: "",

                head200: "",

                head201: "",

                head202: "",

                head203: "",

                head204: "",

                head205: "",

                head206: "",

                head207: "",

                head208: "",



                currentmrp: "",

                updatemrp: "",

                disc: "",

                discrs: "",

                splcd: "",

                splcdrs: "",

                cdrate: "",

                cdrate1: "",

                cdrate2: "",

                cdaftergstactive: "",

                expenseLabour_rate: "",

                expenseLabour_value: "",

                expensePostage_rate: "",

                expensePostage_value: "",

                expenseDiscount_rate: "",

                expenseDiscount_value: "",

                expenseFreight_rate: "",

                expenseFreight_value: "",

                expense5_rate: "",

                expense5_value: "",

                expenseTCS1_rate: "",

                expenseTCS1_value: "",



                mas_accode: "",

                mas_name: "",

                mas_groupname: "",

                mas_mrp: "",

                mas_salerate: "",

                mas_totalgst: "",

                mas_cgst: "",

                mas_sgst: "",

                mas_cessqty: "",

                mas_cessrate: "",

                mas_hsncode: "",

                mas_saleaccode: "",

                mas_purchaseaccode: "",

                mas_ratecalculator: "",

                mas_uom: "",

                mas_qtyin: "",

                mas_size: ""

            }];
      var that = this;

      ////alert(this.voucherno)
      this.rowlength = 1;

      that.purchase1b_supplier = "";
      that.purchase1b_city = "";
      that.purchase1b_gstno = "";
      that.purchase1b_billno = "";
      that.purchase1b_billdate = "";
      that.purchase1b_terms = "";

      that.purchase1b_taxtype = "";

      that.purchase1b_billcash = "";
      that.purchase1b_selfinv = "";

      that.purchase1b_gstr2astatus = "";

      that.purchase1b_transport = "";
      that.purchase1b_broker = "";
      that.purchase1b_inputdt = "";

      that.purchase1b_duedate = "";
      that.purchase1b_adjustadvancers = "";

      that.purchase1b_vehicle = "";

      that.purchase1b_grno = "";

      that.purchase1b_totalgst = "";
      that.purchase1b_cess1 = "";
      that.purchase1b_cess2 = "";
      that.purchase1b_subtotal = "";
      that.purchase1b_addless = "";
      that.purchase1b_cgst = "";
      that.purchase1b_sgst = "";

      that.purchase1b_igst = "";
      that.purchase1b_expenses = "";
      that.purchase1b_grandtotal = "";
    
    // CLearing everything on new for now, not sure if I have to or not.

      that.expense1_1 = "",
      that.expense1_2 = "",
      that.expense1_3 = "",
      that.expense1_4 = "",
      that.expense1_5 = "",
      that.expense1_6 = "",
      that.expense1_7 = "",
      that.expense1_8 = "",
      that.expense1_9 = "",
      that.expense1_10 = "",
      that.expense1_11 = "",
      that.expense1_12 = "",

      that.expense2_1 = "",
      that.expense2_2 = "",
      that.expense2_3 = "",
      that.expense2_4 = "",
      that.expense2_5 = "",
      that.expense2_6 = "",
      that.expense2_7 = "",
      that.expense2_8 = "",
      that.expense2_9 = "",
      that.expense2_10 = "",
      that.expense2_11 = "",
      that.expense2_12 = "",
      that.expense2_13= "",
      that.expense2_14= "",
      
      that.man_supplier= "";
      that.man_billno= "";
      that.man_billdate=  "";
      that.man_weight=  "";
      that.man_pageno= "";
      that.man_rate=  "";
      that.man_entryno= "";
      that.man_assvalue=  "";
      that.man_impgoods= "";
      that.man_bed1=  "";
      that.man_bed2= "";
      that.man_cess1= "";
      that.man_cess2=  "";
      that.man_hcess1=  "";
      that.man_hcess2= "";
      that.man_aduty1=  "";
      that.man_aduty2=  "";
      that.man_vatcst1=  "";
      that.man_vatcst2=  "";
      

      // for (var i = 0; i < 4; i++) {
      //   this.addNewRow();
      // }

      this.buttonActiveList = [
        "active",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ];

      this.$forceUpdate();
      this.focusq();
    },
    focusq() {
      document.getElementById("datepicker").focus();
    },

    handleSelected(k) {
      // alert(this.rowNumberIndicator)
      this.cashVauchers[this.rowNumberIndicator].accountno = this.filteredUsers[
        k
      ].accountname;
      //  alert(this.filteredUsers[k].accountname);
      this.popupActive2 = false;
      document.getElementById("1" + this.rowNumberIndicator).focus();
      this.$forceUpdate();
    },
    handleSelected2() {
      let finder = this.selected2.id;
      //alert(finder);
      let k = 0;
      let n = 0;
      let id = "narrationCheck";
      for (var y in this.filteredNarrations) {
        // alert(y.id);
        if (this.filteredNarrations[y].id == finder) {
          n = k;
        }
        k++;
      }
      //alert(n);

      id += n;
      document.getElementById(id).checked = true;
      this.selected2 = [];
    },

    setAccountNo(j) {
      var ele = "accountno";
      ele = ele + this.rowNumberIndicator;
      document.getElementById(ele).value = this.selectedAccountNo;
      this.selectedAccountNo = this.popupDataList[j].memberId;
      this.cashVauchers[
        this.rowNumberIndicator
      ].accountno = this.selectedAccountNo;
      this.popupActive2 = false;
    },

    paymentInputTrig(id) {
      // alert("pooped big time");
      var val = "3";
      val = val + id;

      if (this.cashVauchers[id].payment == "") {
        document.getElementById(val).disabled = false;
      } else {
        document.getElementById(val).disabled = true;
      }

      this.updateTotals();
    },

    receiptInputTrig(id) {
      var val = "2";
      val = val + id;

      if (this.cashVauchers[id].receipt == "") {
        document.getElementById(val).disabled = false;
      } else {
        document.getElementById(val).disabled = true;
      }

      this.updateTotals();
    },
    discountInputTrig() {
      //alert("called this");
      this.updateTotals();
      // alert("called this too");
    },
    showAddPopup() {
      this.popupActive4 = true;
      this.activeWindowsList.push("popupActive4");
      this.$forceUpdate();
    },
    showAddPopupNarration() {
      this.popupActive5 = true;
      this.activeWindowsList.push("popupActive5");
      document.getElementById("newNarrationBox").focus();
    },
    showNavPopup() {
      this.filterbar2 = "";

      this.filteredList2();

      this.popupActive3 = true;
      this.activeWindowsList.push("popupActive3");
      document.getElementById("filterbar2").focus();

      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";

      this.$forceUpdate();
    },
    showPopup(k) {
      // this.handleSearch = this.cashVauchers[this.date].accountno;
      // var str = this.cashVauchers[this.rowNumberIndicator].accountno;
      // var splitStr = str.toLowerCase().split(" ");
      // for (var i = 0; i < splitStr.length; i++) {
      //   splitStr[i] =
      //     splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
      // }

      // this.searchbar = splitStr.join(" ");
      this.rowNumberIndicator = k;
      let p = this.cashVauchers[this.rowNumberIndicator].accountno;

      this.searchbar = p + "";

      this.filteredUsers = [];

      if (p == "") {
        this.filteredUsers = this.users;
      } else {
        for (var x in this.users) {
          //  var id = this.users[x].id.toLowerCase();
          //  var name = this.users[x].name.toLowerCase();
          var accountname = this.users[x].accountname.toLowerCase();
          // var email = this.users[x].email.toLowerCase();
          // var website = this.users[x].website.toLowerCase();
          // alert(username+email+website);
          this.selectedDropdown = "accountname";
          if (accountname.indexOf(p) == 0) {
            //alert(name);
            this.filteredUsers.push(this.users[x]);
          }
        }
      }

      this.popupActive2 = true;
      this.activeWindowsList.push("popupActive2");
      document.getElementById("searchbar").focus();

      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";

      this.$forceUpdate();
    },
addNewSerial()
{this.srnos.push({counter: ""})
},

    addNewRow() {
      this.addNewSerial();
     this.cashVauchers.push({
        //UPDATE1   // DECLARATION OF CASHVAUCHERS, i'm marking this to find this bugger faster

        head0: "",

        head1: "",

        head2: "",

        head3: "",

        head4: "",

        head5: "",

        head6: "",

        head7: "",

        head8: "",

        head9: "",

        head10: "",

        head11: "",

        head12: "",

        head13: "",

        head14: "",

        head15: "",

        head16: "",

        head17: "",

        head18: "",

        head19: "",

        head20: "",

        head21: "",

        head22: "",

        head23: "",

        head24: "",

        head25: "",

        head26: "",

        head27: "",

        head28: "",

        head29: "",

        head30: "",

        head31: "",

        head32: "",

        head33: "",

        head34: "",

        head35: "",

        head36: "",

        head37: "",

        head38: "",

        head39: "",

        head40: "",

        head41: "",

        head42: "",

        head43: "",

        head44: "",

        head45: "",

        head46: "",

        head47: "",

        head48: "",

        head49: "",

        head50: "",

        head51: "",

        head52: "",

        head53: "",

        head54: "",

        head55: "",

        head56: "",

        head57: "",

        head58: "",

        head59: "",

        head60: "",

        head61: "",

        head62: "",

        head63: "",

        head64: "",

        head65: "",

        head66: "",

        head67: "",

        head68: "",

        head69: "",

        head70: "",

        head71: "",

        head72: "",

        head73: "",

        head74: "",

        head75: "",

        head76: "",

        head77: "",

        head78: "",

        head79: "",

        head80: "",

        head81: "",

        head82: "",

        head83: "",

        head84: "",

        head85: "",

        head86: "",

        head87: "",

        head88: "",

        head89: "",

        head90: "",

        head91: "",

        head92: "",

        head93: "",

        head94: "",

        head95: "",

        head96: "",

        head97: "",

        head98: "",

        head99: "",

        head100: "",

        head101: "",

        head102: "",

        head103: "",

        head104: "",

        head105: "",

        head106: "",

        head107: "",

        head108: "",

        head109: "",

        head110: "",

        head111: "",

        head112: "",

        head113: "",

        head114: "",

        head115: "",

        head116: "",

        head117: "",

        head118: "",

        head119: "",

        head120: "",

        head121: "",

        head122: "",

        head123: "",

        head124: "",

        head125: "",

        head126: "",

        head127: "",

        head128: "",

        head129: "",

        head130: "",

        head131: "",

        head132: "",

        head133: "",

        head134: "",

        head135: "",

        head136: "",

        head137: "",

        head138: "",

        head139: "",

        head140: "",

        head141: "",

        head142: "",

        head143: "",

        head144: "",

        head145: "",

        head146: "",

        head147: "",

        head148: "",

        head149: "",

        head150: "",

        head151: "",

        head152: "",

        head153: "",

        head154: "",

        head155: "",

        head156: "",

        head157: "",

        head158: "",

        head159: "",

        head160: "",

        head161: "",

        head162: "",

        head163: "",

        head164: "",

        head165: "",

        head166: "",

        head167: "",

        head168: "",

        head169: "",

        head170: "",

        head171: "",

        head172: "",

        head173: "",

        head174: "",

        head175: "",

        head176: "",

        head177: "",

        head178: "",

        head179: "",

        head180: "",

        head181: "",

        head182: "",

        head183: "",

        head184: "",

        head185: "",

        head186: "",

        head187: "",

        head188: "",

        head189: "",

        head190: "",

        head191: "",

        head192: "",

        head193: "",

        head194: "",

        head195: "",

        head196: "",

        head197: "",

        head198: "",

        head199: "",

        head200: "",

        head201: "",

        head202: "",

        head203: "",

        head204: "",

        head205: "",

        head206: "",

        head207: "",

        head208: "",

        currentmrp: "",

        updatemrp: "",

        disc: "",

        discrs: "",

        splcd: "",

        splcdrs: "",

        cdrate: "",

        cdrate1: "",

        cdrate2: "",

        cdaftergstactive: "",

        expenseLabour_rate: "",

        expenseLabour_value: "",

        expensePostage_rate: "",

        expensePostage_value: "",

        expenseDiscount_rate: "",

        expenseDiscount_value: "",

        expenseFreight_rate: "",

        expenseFreight_value: "",

        expense5_rate: "",

        expense5_value: "",

        expenseTCS1_rate: "",

        expenseTCS1_value: "",

        mas_accode: "",

        mas_name: "",

        mas_groupname: "",

        mas_mrp: "",

        mas_salerate: "",

        mas_totalgst: "",

        mas_cgst: "",

        mas_sgst: "",

        mas_cessqty: "",

        mas_cessrate: "",

        mas_hsncode: "",

        mas_saleaccode: "",

        mas_purchaseaccode: "",

        mas_ratecalculator: "",

        mas_uom: "",

        mas_qtyin: "",

        mas_size: ""
      });
      
    this.srnos[parseInt(this.rowlength)].counter= parseInt(this.rowlength)+1;
          this.rowlength++;

          
    },
    enterKeyTrig(p) {
      var id = p.slice(0, -1);
      var k = p.substring(p.length - 1, p.length);
      k = parseInt(k);

      var val = "saveButton";
      var pal = "exitButton";

      //alert(JSON.stringify(this.cashVauchers[k].accountno));
      // console.log(id);

      if (id == "accountno") {
        if (this.cashVauchers[k].accountno == "") {
          if (
            this.paymentTotal == 0 &&
            this.receiptTotal == 0 &&
            this.discountTotal == 0
          ) {
            document.getElementById(val).focus();
            alert("on Exit button ");
            this.disExit = false;
          } else {
            document.getElementById(pal).focus();

            this.disSave = false;
          }

          this.$forceUpdate();
        }
      } else if (id == "narration") {
        if (this.cashVauchers[k].narration == "") {
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "payment") {
        if (this.cashVauchers[k].payment == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "receipt") {
        if (this.cashVauchers[k].receipt == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }

      if (id == "discount") {
        if (k == this.cashVauchers.length - 1) {
          this.cashVauchers.push({
            //UPDATE3
            purchase1b_productname: "",
            purchase1b_description: "",
            purchase1b_pcs: "",
            purchase1b_qty: "",
            purchase1b_rate: "",
            purchase1b_amount: "",
            purchase1b_others: "",
            purchase1b_ctax: "",
            purchase1b_stax: "",
            purchase1b_itax: ""
          });

          this.addNotify();
        } else if (this.cashVauchers[k].discount == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }
    },
    deleteNotify() {
      this.$vs.notify({
        text: "Row is deleted",
        color: "danger",
        iconPack: "feather",
        icon: "icon-trash"
      });
    },
    addNotify() {
      this.$vs.notify({
        text: "Row is Added",
        color: "primary",
        iconPack: "feather",
        icon: "icon-plus"
      });
    },
    findIndex(index, cashVaucher) {
      var idx = this.cashVauchers.indexOf(cashVaucher);
      return idx;
    },
    moveDown(p, k) {
      var val = p + (k + 1);
      document.getElementById(val).focus();
    },
    moveUp(p, k) {
      var val = p + (k - 1);
      document.getElementById(val).focus();
    },
    moveRight(p, k) {
      var checkPay = this.cashVauchers[k].payment;
      var checkRec = this.cashVauchers[k].receipt;

      if (checkPay != "" && parseInt(p) == 2) {
        document.getElementById("4" + k).focus();
      }
      if (checkRec != "" && parseInt(p) == 1) {
        document.getElementById("3" + k).focus();
      } else {
        var val = parseInt(p) + 1 + (k + "");
        document.getElementById(val).focus();
      }
    },
    moveLeft(p, k) {
      var checkPay = this.cashVauchers[k].payment;
      var checkRec = this.cashVauchers[k].receipt;

      if (checkPay != "" && parseInt(p) == 4) {
        document.getElementById("2" + k).focus();
      }
      if (checkRec != "" && parseInt(p) == 3) {
        document.getElementById("1" + k).focus();
      } else {
        var val = parseInt(p) - 1 + (k + "");
        document.getElementById(val).focus();
      }
    },
    moveFocus(index) {
      if (this.elements[index]) {
        this.elements[index].focus();
      }
      console.log("b");
    },
    moveNext(p) {
      var id = p.slice(0, -1);
      var k = p.substring(p.length - 1, p.length);
      var val = "";

      if (id == "accountno") {
        if (this.cashVauchers[k].accountno == "") {
          val = "narration" + k;
          document.getElementById(val).focus();
        }
      } else if (id == "narration") {
        if (this.cashVauchers[k].narration == "") {
          val = "payment" + k;
          document.getElementById(val).focus();
        }
      } else if (id == "payment") {
        if (this.cashVauchers[k].payment == "") {
          val = "receipt" + k;
          document.getElementById(val).focus();
        }
      } else if (id == "receipt") {
        if (this.cashVauchers[k].receipt == "") {
          val = "discount" + k;
          document.getElementById(val).focus();
        }
      }

      if (id == "discount") {
        if (this.cashVauchers[k].discount == "") {
          k = parseInt(k);
          val = "accountno" + (k + 1);
          document.getElementById(val).focus();
        }
      }
    },
    movePrev(p) {
      var id = p.slice(0, -1);
      var k = p.substring(p.length - 1, p.length);
      var val = "";

      if (id == "accountno") {
        if (this.cashVauchers[k].accountno == "") {
          k = parseInt(k);
          val = "discount" + (k - 1);
          document.getElementById(val).focus();
        }
      } else if (id == "narration") {
        if (this.cashVauchers[k].narration == "") {
          val = "accountno" + k;
          document.getElementById(val).focus();
        }
      } else if (id == "payment") {
        if (this.cashVauchers[k].payment == "") {
          val = "narration" + k;
          document.getElementById(val).focus();
        }
      } else if (id == "receipt") {
        if (this.cashVauchers[k].receipt == "") {
          val = "payment" + k;
          document.getElementById(val).focus();
        }
      }
      if (id == "discount") {
        if (this.cashVauchers[k].discount == "") {
          val = "receipt" + k;
          document.getElementById(val).focus();
        }
      }
    },
    // Delete Single Row
    deleteRow(index, cashVaucher) {
      var idx = this.cashVauchers.indexOf(cashVaucher);
      console.log(idx, index);
      if (idx > -1) {
        this.cashVauchers.splice(idx, 1);
        this.srnos.splice(idx,1);

      }

      for(let i=0;i<this.rowlength-1;i++)
      {
        this.srnos[i].counter=i+1
      }


      --this.rowlength
      
      this.deleteNotify();
    },
    // Remove Row one by one in last
    pop() {

      this.popSerial()
      this.cashVauchers.pop({
        //UPDATE4
        purchase1b_productname: "",
        purchase1b_description: "",
        purchase1b_pcs: "",
        purchase1b_qty: "",
        purchase1b_rate: "",
        purchase1b_amount: "",
        purchase1b_others: "",
        purchase1b_ctax: "",
        purchase1b_stax: "",
        purchase1b_itax: ""
      });

      this.rowlength--;

      this.deleteNotify();
    },

    //Show data in Table
    saveInvoice() {
      console.log(this.cashVauchers[1].accountno);
      alert(JSON.stringify(this.cashVauchers));
    },
    // Add
    totaladd(cashVaucher) {
      if (
        this.cashVauchers[0].discount != "" &&
        this.cashVauchers[0].narration != "" &&
        this.cashVauchers[0].accountno != ""
      ) {
        this.disSave = false;
      } else {
        this.disSave = true;
      }
      var total =
        parseFloat(cashVaucher.payment) * parseFloat(cashVaucher.discount);
      this.totalcount = total;
    },

    onlyNumber($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
        // 46 is dot
        return $event.preventDefault();
      } else return null;
    },
    DateFormate($event) {
      var len = $event.length;
      alert("called" + "---" + $event + len);

      if (len == 2 || len == 5) {
        this.date = this.date + "-";
      } else {
        this.date = this.date;
      }
    }
    // },
    //   capitalize(str) {
    //   return str.slice(0,1).toUpperCase() + str.slice(1,str.length)
    // }

    }
,

  created() {
    this.voucherno = 0;
    this.buttonActiveList[0] = "active";
    this.date = this.now + "";
    this.disAdd = false;

    var user = sessionStorage.getItem("user");
    var companyName = JSON.parse(user)[0].companyname;
    alert(companyName);
    var type = JSON.parse(user)[0].type;
    if (type == "user") {
      var Role = sessionStorage.getItem("role");
      //  var permissions = JSON.parse(Role)[0].rolename.permission[0].roletype;
      var perm = JSON.parse(Role);
      var Add = perm[0].rolename.permission[0].roletype.Add;
      var modify = perm[0].rolename.permission[0].roletype.modify;
      var del = perm[0].rolename.permission[0].roletype.delete;
      alert(Add + " " + modify + " " + del);
    }
 let seriesindex = sessionStorage.getItem("purchaseseriesindex")
 alert(seriesindex)
 alert("what")
      var value1 = { companyname: companyName, seriesindex: seriesindex};


    
    axios
      .post("/getPurchaseSeriesData", value1)
      .then(response => {
         let data = JSON.stringify(response.data);

         var jsonBoi = JSON.parse(data);
        //this.narrations = json.narration;

        //alert("Jake peralta:" + data );

        //this.conditionalColumn = jsonBoi.saleseriesdata[0].columndata ;
        this.cashheaders = [];
        this.cashheaders = jsonBoi.keys;  
        this.conditionalColumn = jsonBoi.columndata
        alert("cond col "+JSON.stringify(this.conditionalColumn) )
        this.conditionalValues = jsonBoi.values
        this.conditionalLabels = jsonBoi.labeldata2
        this.conditionalOrder = jsonBoi.orderdata
        this.conditionalWidth=jsonBoi.widthdata
        this.heading = jsonBoi.heading
        this.isContinuous=jsonBoi.cont
        alert(this.isContinuous)
        // alert("condval: " + JSON.parse(JSON.stringify(jsonBoi.columndata)))
        this.wid0=this.conditionalWidth[Object.keys(this.conditionalWidth)[0]]
        this.wid1=this.conditionalWidth[Object.keys(this.conditionalWidth)[1]]
        this.wid2=this.conditionalWidth[Object.keys(this.conditionalWidth)[2]]
        this.wid3=this.conditionalWidth[Object.keys(this.conditionalWidth)[3]]
        this.wid4=this.conditionalWidth[Object.keys(this.conditionalWidth)[4]]
        this.wid5=this.conditionalWidth[Object.keys(this.conditionalWidth)[5]]
        this.wid6=this.conditionalWidth[Object.keys(this.conditionalWidth)[6]]
        this.wid7=this.conditionalWidth[Object.keys(this.conditionalWidth)[7]]
        this.wid8=this.conditionalWidth[Object.keys(this.conditionalWidth)[8]]
        this.wid9=this.conditionalWidth[Object.keys(this.conditionalWidth)[9]]
        this.wid10=this.conditionalWidth[Object.keys(this.conditionalWidth)[10]]
        this.wid11=this.conditionalWidth[Object.keys(this.conditionalWidth)[11]]
        this.wid12=this.conditionalWidth[Object.keys(this.conditionalWidth)[12]]
        this.wid13=this.conditionalWidth[Object.keys(this.conditionalWidth)[13]]
        this.wid14=this.conditionalWidth[Object.keys(this.conditionalWidth)[14]]
        this.wid15=this.conditionalWidth[Object.keys(this.conditionalWidth)[15]]
        this.wid16=this.conditionalWidth[Object.keys(this.conditionalWidth)[16]]
        this.wid17=this.conditionalWidth[Object.keys(this.conditionalWidth)[17]]
        this.wid18=this.conditionalWidth[Object.keys(this.conditionalWidth)[18]]
        this.wid19=this.conditionalWidth[Object.keys(this.conditionalWidth)[19]]
        this.wid20=this.conditionalWidth[Object.keys(this.conditionalWidth)[20]]
        this.wid21=this.conditionalWidth[Object.keys(this.conditionalWidth)[21]]
        this.wid22=this.conditionalWidth[Object.keys(this.conditionalWidth)[22]]
        this.wid23=this.conditionalWidth[Object.keys(this.conditionalWidth)[23]]
        this.wid24=this.conditionalWidth[Object.keys(this.conditionalWidth)[24]]
        this.wid25=this.conditionalWidth[Object.keys(this.conditionalWidth)[25]]
        this.wid26=this.conditionalWidth[Object.keys(this.conditionalWidth)[26]]
        this.wid27=this.conditionalWidth[Object.keys(this.conditionalWidth)[27]]
        this.wid28=this.conditionalWidth[Object.keys(this.conditionalWidth)[28]]
        this.wid29=this.conditionalWidth[Object.keys(this.conditionalWidth)[29]]
        this.wid30=this.conditionalWidth[Object.keys(this.conditionalWidth)[30]]
        this.wid31=this.conditionalWidth[Object.keys(this.conditionalWidth)[31]]
        this.wid32=this.conditionalWidth[Object.keys(this.conditionalWidth)[32]]
        this.wid33=this.conditionalWidth[Object.keys(this.conditionalWidth)[33]]
        this.wid34=this.conditionalWidth[Object.keys(this.conditionalWidth)[34]]
        this.wid35=this.conditionalWidth[Object.keys(this.conditionalWidth)[35]]
        this.wid36=this.conditionalWidth[Object.keys(this.conditionalWidth)[36]]
        this.wid37=this.conditionalWidth[Object.keys(this.conditionalWidth)[37]]
        this.wid38=this.conditionalWidth[Object.keys(this.conditionalWidth)[38]]
        this.wid39=this.conditionalWidth[Object.keys(this.conditionalWidth)[39]]
        this.wid40=this.conditionalWidth[Object.keys(this.conditionalWidth)[40]]
        this.wid41=this.conditionalWidth[Object.keys(this.conditionalWidth)[41]]
        this.wid42=this.conditionalWidth[Object.keys(this.conditionalWidth)[42]]
        this.wid43=this.conditionalWidth[Object.keys(this.conditionalWidth)[43]]
        this.wid44=this.conditionalWidth[Object.keys(this.conditionalWidth)[44]]
        this.wid45=this.conditionalWidth[Object.keys(this.conditionalWidth)[45]]
        this.wid46=this.conditionalWidth[Object.keys(this.conditionalWidth)[46]]
        this.wid47=this.conditionalWidth[Object.keys(this.conditionalWidth)[47]]
        this.wid48=this.conditionalWidth[Object.keys(this.conditionalWidth)[48]]
        this.wid49=this.conditionalWidth[Object.keys(this.conditionalWidth)[49]]
        this.wid50=this.conditionalWidth[Object.keys(this.conditionalWidth)[50]]
        this.wid51=this.conditionalWidth[Object.keys(this.conditionalWidth)[51]]
        this.wid52=this.conditionalWidth[Object.keys(this.conditionalWidth)[52]]
        this.wid53=this.conditionalWidth[Object.keys(this.conditionalWidth)[53]]
        this.wid54=this.conditionalWidth[Object.keys(this.conditionalWidth)[54]]
        this.wid55=this.conditionalWidth[Object.keys(this.conditionalWidth)[55]]
        this.wid56=this.conditionalWidth[Object.keys(this.conditionalWidth)[56]]
        this.wid57=this.conditionalWidth[Object.keys(this.conditionalWidth)[57]]
        this.wid58=this.conditionalWidth[Object.keys(this.conditionalWidth)[58]]
        this.wid59=this.conditionalWidth[Object.keys(this.conditionalWidth)[59]]
        this.wid60=this.conditionalWidth[Object.keys(this.conditionalWidth)[60]]
        this.wid61=this.conditionalWidth[Object.keys(this.conditionalWidth)[61]]
        this.wid62=this.conditionalWidth[Object.keys(this.conditionalWidth)[62]]
        this.wid63=this.conditionalWidth[Object.keys(this.conditionalWidth)[63]]
        this.wid64=this.conditionalWidth[Object.keys(this.conditionalWidth)[64]]
        this.wid65=this.conditionalWidth[Object.keys(this.conditionalWidth)[65]]
        this.wid66=this.conditionalWidth[Object.keys(this.conditionalWidth)[66]]
        this.wid67=this.conditionalWidth[Object.keys(this.conditionalWidth)[67]]
        this.wid68=this.conditionalWidth[Object.keys(this.conditionalWidth)[68]]
        this.wid69=this.conditionalWidth[Object.keys(this.conditionalWidth)[69]]
        this.wid70=this.conditionalWidth[Object.keys(this.conditionalWidth)[70]]
        this.wid71=this.conditionalWidth[Object.keys(this.conditionalWidth)[71]]
        this.wid72=this.conditionalWidth[Object.keys(this.conditionalWidth)[72]]
        this.wid73=this.conditionalWidth[Object.keys(this.conditionalWidth)[73]]
        this.wid74=this.conditionalWidth[Object.keys(this.conditionalWidth)[74]]
        this.wid75=this.conditionalWidth[Object.keys(this.conditionalWidth)[75]]
        this.wid76=this.conditionalWidth[Object.keys(this.conditionalWidth)[76]]
        this.wid77=this.conditionalWidth[Object.keys(this.conditionalWidth)[77]]
        this.wid78=this.conditionalWidth[Object.keys(this.conditionalWidth)[78]]
        this.wid79=this.conditionalWidth[Object.keys(this.conditionalWidth)[79]]
        this.wid80=this.conditionalWidth[Object.keys(this.conditionalWidth)[80]]
        this.wid81=this.conditionalWidth[Object.keys(this.conditionalWidth)[81]]
        this.wid82=this.conditionalWidth[Object.keys(this.conditionalWidth)[82]]
        this.wid83=this.conditionalWidth[Object.keys(this.conditionalWidth)[83]]
        this.wid84=this.conditionalWidth[Object.keys(this.conditionalWidth)[84]]
        this.wid85=this.conditionalWidth[Object.keys(this.conditionalWidth)[85]]
        this.wid86=this.conditionalWidth[Object.keys(this.conditionalWidth)[86]]
        this.wid87=this.conditionalWidth[Object.keys(this.conditionalWidth)[87]]
        this.wid88=this.conditionalWidth[Object.keys(this.conditionalWidth)[88]]
        this.wid89=this.conditionalWidth[Object.keys(this.conditionalWidth)[89]]
        this.wid90=this.conditionalWidth[Object.keys(this.conditionalWidth)[90]]
        this.wid91=this.conditionalWidth[Object.keys(this.conditionalWidth)[91]]
        this.wid92=this.conditionalWidth[Object.keys(this.conditionalWidth)[92]]
        this.wid93=this.conditionalWidth[Object.keys(this.conditionalWidth)[93]]
        this.wid94=this.conditionalWidth[Object.keys(this.conditionalWidth)[94]]
        this.wid95=this.conditionalWidth[Object.keys(this.conditionalWidth)[95]]
        this.wid96=this.conditionalWidth[Object.keys(this.conditionalWidth)[96]]
        this.wid97=this.conditionalWidth[Object.keys(this.conditionalWidth)[97]]
        this.wid98=this.conditionalWidth[Object.keys(this.conditionalWidth)[98]]
        this.wid99=this.conditionalWidth[Object.keys(this.conditionalWidth)[99]]
        this.wid100=this.conditionalWidth[Object.keys(this.conditionalWidth)[100]]
        this.wid101=this.conditionalWidth[Object.keys(this.conditionalWidth)[101]]
        this.wid102=this.conditionalWidth[Object.keys(this.conditionalWidth)[102]]
        this.wid103=this.conditionalWidth[Object.keys(this.conditionalWidth)[103]]
        this.wid104=this.conditionalWidth[Object.keys(this.conditionalWidth)[104]]
        this.wid105=this.conditionalWidth[Object.keys(this.conditionalWidth)[105]]
        this.wid106=this.conditionalWidth[Object.keys(this.conditionalWidth)[106]]
        this.wid107=this.conditionalWidth[Object.keys(this.conditionalWidth)[107]]
        this.wid108=this.conditionalWidth[Object.keys(this.conditionalWidth)[108]]
        this.wid109=this.conditionalWidth[Object.keys(this.conditionalWidth)[109]]
        this.wid110=this.conditionalWidth[Object.keys(this.conditionalWidth)[110]]
        this.wid111=this.conditionalWidth[Object.keys(this.conditionalWidth)[111]]
        this.wid112=this.conditionalWidth[Object.keys(this.conditionalWidth)[112]]
        this.wid113=this.conditionalWidth[Object.keys(this.conditionalWidth)[113]]
        this.wid114=this.conditionalWidth[Object.keys(this.conditionalWidth)[114]]
        this.wid115=this.conditionalWidth[Object.keys(this.conditionalWidth)[115]]
        this.wid116=this.conditionalWidth[Object.keys(this.conditionalWidth)[116]]
        this.wid117=this.conditionalWidth[Object.keys(this.conditionalWidth)[117]]
        this.wid118=this.conditionalWidth[Object.keys(this.conditionalWidth)[118]]
        this.wid119=this.conditionalWidth[Object.keys(this.conditionalWidth)[119]]
        this.wid120=this.conditionalWidth[Object.keys(this.conditionalWidth)[120]]
        this.wid121=this.conditionalWidth[Object.keys(this.conditionalWidth)[121]]
        this.wid122=this.conditionalWidth[Object.keys(this.conditionalWidth)[122]]
        this.wid123=this.conditionalWidth[Object.keys(this.conditionalWidth)[123]]
        this.wid124=this.conditionalWidth[Object.keys(this.conditionalWidth)[124]]
        this.wid125=this.conditionalWidth[Object.keys(this.conditionalWidth)[125]]
        this.wid126=this.conditionalWidth[Object.keys(this.conditionalWidth)[126]]
        this.wid127=this.conditionalWidth[Object.keys(this.conditionalWidth)[127]]
        this.wid128=this.conditionalWidth[Object.keys(this.conditionalWidth)[128]]
        this.wid129=this.conditionalWidth[Object.keys(this.conditionalWidth)[129]]
        this.wid130=this.conditionalWidth[Object.keys(this.conditionalWidth)[130]]
        this.wid131=this.conditionalWidth[Object.keys(this.conditionalWidth)[131]]
        this.wid132=this.conditionalWidth[Object.keys(this.conditionalWidth)[132]]
        this.wid133=this.conditionalWidth[Object.keys(this.conditionalWidth)[133]]
        this.wid134=this.conditionalWidth[Object.keys(this.conditionalWidth)[134]]
        this.wid135=this.conditionalWidth[Object.keys(this.conditionalWidth)[135]]
        this.wid136=this.conditionalWidth[Object.keys(this.conditionalWidth)[136]]
        this.wid137=this.conditionalWidth[Object.keys(this.conditionalWidth)[137]]
        this.wid138=this.conditionalWidth[Object.keys(this.conditionalWidth)[138]]
        this.wid139=this.conditionalWidth[Object.keys(this.conditionalWidth)[139]]
        this.wid140=this.conditionalWidth[Object.keys(this.conditionalWidth)[140]]
        this.wid141=this.conditionalWidth[Object.keys(this.conditionalWidth)[141]]
        this.wid142=this.conditionalWidth[Object.keys(this.conditionalWidth)[142]]
        this.wid143=this.conditionalWidth[Object.keys(this.conditionalWidth)[143]]
        this.wid144=this.conditionalWidth[Object.keys(this.conditionalWidth)[144]]
        this.wid145=this.conditionalWidth[Object.keys(this.conditionalWidth)[145]]
        this.wid146=this.conditionalWidth[Object.keys(this.conditionalWidth)[146]]
        this.wid147=this.conditionalWidth[Object.keys(this.conditionalWidth)[147]]
        this.wid148=this.conditionalWidth[Object.keys(this.conditionalWidth)[148]]
        this.wid149=this.conditionalWidth[Object.keys(this.conditionalWidth)[149]]
        this.wid150=this.conditionalWidth[Object.keys(this.conditionalWidth)[150]]
        this.wid151=this.conditionalWidth[Object.keys(this.conditionalWidth)[151]]
        this.wid152=this.conditionalWidth[Object.keys(this.conditionalWidth)[152]]
        this.wid153=this.conditionalWidth[Object.keys(this.conditionalWidth)[153]]
        this.wid154=this.conditionalWidth[Object.keys(this.conditionalWidth)[154]]
        this.wid155=this.conditionalWidth[Object.keys(this.conditionalWidth)[155]]
        this.wid156=this.conditionalWidth[Object.keys(this.conditionalWidth)[156]]
        this.wid157=this.conditionalWidth[Object.keys(this.conditionalWidth)[157]]
        this.wid158=this.conditionalWidth[Object.keys(this.conditionalWidth)[158]]
        this.wid159=this.conditionalWidth[Object.keys(this.conditionalWidth)[159]]
        this.wid160=this.conditionalWidth[Object.keys(this.conditionalWidth)[160]]
        this.wid161=this.conditionalWidth[Object.keys(this.conditionalWidth)[161]]
        this.wid162=this.conditionalWidth[Object.keys(this.conditionalWidth)[162]]
        this.wid163=this.conditionalWidth[Object.keys(this.conditionalWidth)[163]]
        this.wid164=this.conditionalWidth[Object.keys(this.conditionalWidth)[164]]
        this.wid165=this.conditionalWidth[Object.keys(this.conditionalWidth)[165]]
        this.wid166=this.conditionalWidth[Object.keys(this.conditionalWidth)[166]]
        this.wid167=this.conditionalWidth[Object.keys(this.conditionalWidth)[167]]
        this.wid168=this.conditionalWidth[Object.keys(this.conditionalWidth)[168]]
        this.wid169=this.conditionalWidth[Object.keys(this.conditionalWidth)[169]]
        this.wid170=this.conditionalWidth[Object.keys(this.conditionalWidth)[170]]
        this.wid171=this.conditionalWidth[Object.keys(this.conditionalWidth)[171]]
        this.wid172=this.conditionalWidth[Object.keys(this.conditionalWidth)[172]]
        this.wid173=this.conditionalWidth[Object.keys(this.conditionalWidth)[173]]
        this.wid174=this.conditionalWidth[Object.keys(this.conditionalWidth)[174]]
        this.wid175=this.conditionalWidth[Object.keys(this.conditionalWidth)[175]]
        this.wid176=this.conditionalWidth[Object.keys(this.conditionalWidth)[176]]
        this.wid177=this.conditionalWidth[Object.keys(this.conditionalWidth)[177]]
        this.wid178=this.conditionalWidth[Object.keys(this.conditionalWidth)[178]]
        this.wid179=this.conditionalWidth[Object.keys(this.conditionalWidth)[179]]
        this.wid180=this.conditionalWidth[Object.keys(this.conditionalWidth)[180]]
        this.wid181=this.conditionalWidth[Object.keys(this.conditionalWidth)[181]]
        this.wid182=this.conditionalWidth[Object.keys(this.conditionalWidth)[182]]
        this.wid183=this.conditionalWidth[Object.keys(this.conditionalWidth)[183]]
        this.wid184=this.conditionalWidth[Object.keys(this.conditionalWidth)[184]]
        this.wid185=this.conditionalWidth[Object.keys(this.conditionalWidth)[185]]
        this.wid186=this.conditionalWidth[Object.keys(this.conditionalWidth)[186]]
        this.wid187=this.conditionalWidth[Object.keys(this.conditionalWidth)[187]]
        this.wid188=this.conditionalWidth[Object.keys(this.conditionalWidth)[188]]
        this.wid189=this.conditionalWidth[Object.keys(this.conditionalWidth)[189]]
        this.wid190=this.conditionalWidth[Object.keys(this.conditionalWidth)[190]]
        this.wid191=this.conditionalWidth[Object.keys(this.conditionalWidth)[191]]
        this.wid192=this.conditionalWidth[Object.keys(this.conditionalWidth)[192]]
        this.wid193=this.conditionalWidth[Object.keys(this.conditionalWidth)[193]]
        this.wid194=this.conditionalWidth[Object.keys(this.conditionalWidth)[194]]
        this.wid195=this.conditionalWidth[Object.keys(this.conditionalWidth)[195]]
        this.wid196=this.conditionalWidth[Object.keys(this.conditionalWidth)[196]]
        this.wid197=this.conditionalWidth[Object.keys(this.conditionalWidth)[197]]
        this.wid198=this.conditionalWidth[Object.keys(this.conditionalWidth)[198]]
        this.wid199=this.conditionalWidth[Object.keys(this.conditionalWidth)[199]]
        this.wid200=this.conditionalWidth[Object.keys(this.conditionalWidth)[200]]
        this.wid201=this.conditionalWidth[Object.keys(this.conditionalWidth)[201]]
        this.wid202=this.conditionalWidth[Object.keys(this.conditionalWidth)[202]]
        this.wid203=this.conditionalWidth[Object.keys(this.conditionalWidth)[203]]
        this.wid204=this.conditionalWidth[Object.keys(this.conditionalWidth)[204]]
        this.wid205=this.conditionalWidth[Object.keys(this.conditionalWidth)[205]]
        this.wid206=this.conditionalWidth[Object.keys(this.conditionalWidth)[206]]
        this.wid207=this.conditionalWidth[Object.keys(this.conditionalWidth)[207]]
     //   this.wid208=this.conditionalWidth[Object.keys(this.conditionalWidth)[208]]
       this.totalwidth=0; 
for(let m=0;m<209;m++)
{
  if(this.conditionalWidth[Object.keys(this.conditionalWidth)[m]]+""!="undefined")
  {if(this.conditionalColumn[Object.keys(this.conditionalColumn)[m]]+""=="true")
    this.totalwidth=parseInt(this.totalwidth)+parseInt(this.conditionalWidth[Object.keys(this.conditionalWidth)[m]])
  }
}




        alert(this.wid0)
        alert("total"+this.totalwidth)
        if(this.isContinuous==true)
        {alert("cont")
          this.getContinuousFirstData()
      this.getContinuousLastData()
        }
      else
      this.getData()
        //alert(JSON.stringify(this.cashheaders))
        //alert(JSON.stringify(this.conditionalColumn))
        
      })
      .catch(error => {
        alert(error);
      });


    let value3 = { companyname: companyName, note: "purchase" };
    axios
      .post("/getTaxDropdown", value3)
      .then(response => {
        var data = JSON.stringify(response.data);
        alert(data);
        // alert(data);
        var json = JSON.parse(data);

        this.taxtypelist = json.taxtypelist;
        this.vattypelist = json.vattypelist;
      })
      .catch(error => {
        alert(error);
      });


    // alert(this.narrations[0].gstin);
    this.selectedDropdown = "accountname";
    document.getElementById("addButton").focus();
  },
  computed: {
     now: function() {
      var today = new Date();
      var m;
      if (today.getMonth() + 1 > 9) m = today.getMonth() + 1;
      else {
        m = "0" + (today.getMonth() + 1);
      }
      var k;
      if (today.getDate() + 1 > 9) 
      k = today.getDate();
      else {
        k = "0" + today.getDate();
      }

      var date = today.getFullYear() + "-" + m + "-" + k;
      return date;
    },
    currentday: function() {
      var today = new Date();
      var weekday = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ];
      var currenday = weekday[today.getDay()];
      return currenday;
    }
  },
  mounted() {
    this.disAdd = false;
    this.disCopy = false;
    this.disDelete = false;
    this.disEdit = false;
    this.disFirst = false;
    this.disLast = false;
    this.disNext = false;
    this.disDate = true;
    this.disVoucher = true;
    this.disSave = true;
    this.disSearch = false;
    this.disPrinter = false;
    this.disPrevious = false;
    this.disExit = false;
    document.getElementById("addButton").focus();
    let that = this;

    this.titleAction = "VIEW";

    

    window.addEventListener("keyup", function(event) {
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
        let i = that.activeWindowsList[that.activeWindowsList.length - 1];

        if (i == "popupActive2") {
          that.popupActive2 = false;
        }

        if (i == "popupActive3") {
          that.popupActive3 = false;
        }
        if (i == "popupActive4") {
          that.popupActive4 = false;
        }
        if (i == "popupActive5") {
          that.popupActive5 = false;
        }
        if (i == "popupActive6") {
          that.popupActive6 = false;
        }
        // if (that.popupActive2 == true) {
        //   that.popupActive2 = false;
        //   that.cashVauchers[that.rowNumberIndicator].accountno = "";
        //   that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        // }
        // if (that.popupActive3 == true) {
        //   that.popupActive3 = false;
        //   that.cashVauchers[that.rowNumberIndicator].narration = "";
        //   that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        // }
        that.activeWindowsList.pop();
      }
      if (event.keyCode === 40) {
        // up arrow
        if (that.popupActive2 == true) {
          that.popupKeyDown();
          //  alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        if (that.popupActive3 == true) {
          that.navPopupKeyDown();
          //  alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }

      if (event.keyCode === 38) {
        // down arrow
        if (that.popupActive2 == true) {
          that.popupKeyUp();
          // alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        if (that.popupActive3 == true) {
          that.navPopupKeyUp();
          // alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }

      if (event.keyCode === 13) {
        // enter
        if (that.popupActive2 == true) {
          that.cashVauchers[that.rowNumberIndicator].accountno =
            that.filteredUsers[that.popupSelectedRow].accountname;
          that.popupActive2 = false;
          // alert(that.rowNumberIndicator);
          document.getElementById("1" + that.rowNumberIndicator).focus();
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        if (that.popupActive3 == true) {
          that.cashVauchers[that.rowNumberIndicator].narration =
            that.filteredNarrations[that.popupSelectedRow].gstin;
          that.popupActive3 = false;
          // alert(that.rowNumberIndicator);
          document.getElementById("2" + that.rowNumberIndicator).focus();
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
    });
  }

  // get data copied

  //  that.cashVauchers = j.tableData;
  //           this.date = lastdate;
  //        this.purchase1b_supplier = j.data.purchase1b_supplier;
  //        this.purchase1b_city = j.data.purchase1b_city;
  //        this.purchase1b_gstno = j.data.purchase1b_gstno;
  //        this.purchase1b_billno = j.data.purchase1b_billno;
  //        this.purchase1b_billdate = j.data.purchase1b_billdate;
  //        this.purchase1b_terms = j.data.purchase1b_terms;
  //        this.purchase1b_taxtype = j.data.purchase1b_taxtype;
  //        this.purchase1b_selfinv = j.data.purchase1b_selfinv;
  //        this.purchase1b_billcash = j.data.purchase1b_billcash;
  //        this.purchase1b_gstr2astatus = j.data.purchase1b_gstr2astatus;
  //        this.purchase1b_transport = j.data.purchase1b_transport
  //        this.purchase1b_broker = j.data.purchase1b_broker
  //        this.purchase1b_inputdt = j.data.purchase1b_inputdt;
  //        this.purchase1b_duedate = j.data.purchase1b_duedate;
  //        this.purchase1b_grno = j.data.purchase1b_grno;
  //        this.purchase1b_vehicle = j.data.purchase1b_vehicle;
  //        this.purchase1b_totalgst = j.data.purchase1b_totalgst;
  //        this.purchase1b_adjustadvancers = j.data.purchase1b_adjustadvancers;
  //        this.purchase1b_cess1 = j.data.purchase1b_cess1;
  //        this.purchase1b_cess2 = j.data.purchase1b_cess2;
  //        this.purchase1b_subtotal = j.data.purchase1b_subtotal;
  //        this.purchase1b_addless = j.data.purchase1b_addless;
  //        this.purchase1b_cgst = j.data.purchase1b_cgst;
  //        this.purchase1b_sgst = j.data.purchase1b_sgst;
  //        this.purchase1b_igst = j.data.purchase1b_igst;
  //        this.purchase1b_expenses = j.data.purchase1b_expenses;
  //        this.purchase1b_grandtotal = j.data.purchase1b_grandtotal;

  // Save() copied

  // purchase1b_supplier : this.purchase1b_supplier,
  //      purchase1b_city : this.purchase1b_city,
  //      purchase1b_gstno : this.purchase1b_gstno,
  //      purchase1b_billno : this.purchase1b_billno,
  //      purchase1b_billdate : this.purchase1b_billdate,
  //      purchase1b_terms : this.purchase1b_terms,
  //      purchase1b_taxtype : this.purchase1b_taxtype,
  //      purchase1b_selfinv : this.purchase1b_selfinv,
  //      purchase1b_billcash : this.purchase1b_billcash,
  //      purchase1b_gstr2astatus : this.purchase1b_gstr2astatus,
  //      purchase1b_transport : this.purchase1b_transport,
  //      purchase1b_broker : this.purchase1b_broker,
  //      purchase1b_inputdt : this.purchase1b_inputdt,
  //      purchase1b_duedate : this.purchase1b_duedate,
  //      purchase1b_grno : this.purchase1b_grno,
  //      purchase1b_vehicle : this.purchase1b_vehicle,
  //      purchase1b_totalgst : this.purchase1b_totalgst,
  //      purchase1b_adjustadvancers : this.purchase1b_adjustadvancers,
  //      purchase1b_cess1 : this.purchase1b_cess1,
  //      purchase1b_cess2 : this.purchase1b_cess2,
  //      purchase1b_subtotal : this.purchase1b_subtotal,
  //      purchase1b_addless : this.purchase1b_addless,
  //      purchase1b_cgst : this.purchase1b_cgst,
  //      purchase1b_sgst : this.purchase1b_sgst,
  //      purchase1b_igst : this.purchase1b_igst,
  //      purchase1b_expenses : this.purchase1b_expenses,
  //      purchase1b_grandtotal :  this.purchase1b_grandtotal,
};
</script>
<style>
@import "/@syncfusion/ej2-base/styles/material.css";
@import "/@syncfusion/ej2-inputs/styles/material.css";
@import "/@syncfusion/ej2-vue-dropdowns/styles/material.css";
</style>




