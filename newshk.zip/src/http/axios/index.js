import axios from "../../axios.js"

export default axios
