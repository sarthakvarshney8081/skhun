/*=========================================================================================
  File Name: sidebarItems.js
  Description: Sidebar Items list. Add / Remove menu items from here.
  Strucutre:
          url     => router path
          name    => name to display in sidebar
          slug    => router path name
          icon    => Feather Icon component/icon name
          tag     => text to display on badge
          tagColor  => class to apply on badge element
          i18n    => Internationalization
          submenu   => submenu of current item (current item will become dropdown )
                NOTE: Submenu don't have any icon(you can add icon if u want to display)
          isDisabled  => disable sidebar item/group
  ----------------------------------------------------------------------------------------
  Item Name: Shkun Accountin Software
  Author: Pixinvent
  Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/


export default [
  // {
  //   url: "/apps/email",
  //   name: "Email",
  //   slug: "email",
  //   icon: "MailIcon",
  //   i18n: "Email",
  // },
  {
    url: null,
    name: "Dashboard",
    tag: "2",
    tagColor: "warning",
    icon: "HomeIcon",
    i18n: "Dashboard",
    submenu: [
      {
        url: '/dashboard/analytics',
        name: "Analytics",
        icon: "GridIcon",
        slug: "dashboard-analytics",
        i18n: "Analytics",
      },
      {
        url: '/dashboard/company',
        name: "Company",
        icon: "PackageIcon",
        slug: "dashboard-ecommerce",
        i18n: "Company",

        submenu: [
          {
            url: '/dashboard/company',
            name: "Company List",
            slug: "company-list",
            i18n: "Company List",
          },
          {
            url: '/dashboard/company-add',
            name: "Add Company",
            slug: "add-company",
            i18n: "Add Company",
          },
          {
            url: '/dashboard/companyinfo',
            name: " Company Info",
            slug: "Company Info",
            i18n: "Company Info",
          },
          
        ]

        
      },

      {
        url: '/dashboard/company',
        name: "Company",
        icon: "UserIcon",
        slug: "dashboard-ecommerce",
        i18n: "Staff",

        submenu: [
          {
            url: '/dashboard/user',
            name: "User",
            slug: "user",
            i18n: "User",
          },
          {
            url: '/dashboard/role',
            name: "Role",
            slug: "role",
            i18n: "Role",
          },
        ]

        
      },
    ]
  },


  

  {

    
    url: null,
    name: "Transaction",
    icon: "ListIcon",
    i18n: "Transaction",
    submenu: [

      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Sale GST",
      },

      
      {
        url: "/dashboard/purchasegstforms",
        name: "Purchase GST",
        slug: "purchase-GST",
        i18n: "Purchase GST",
      },




      {
        name: "Cash",
        slug: "cash",
        i18n: "Cash",

        submenu: [
          {
            url: "/dashboard/cashvoucher",
            name: "Cash Voucher",
            slug: "cash-voucher",
            i18n: "Cash Voucher",
          },
          {
            url: "/dashboard/cashreceipt",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Receipt Book",
          },
        ]
      },
      {
        url: "/dashboard/journal",
        name: "Journal",
        slug: "journal",
        i18n: "Journal",
      },
      {
        url: "/dashboard/bank",
        name: "Bank",
        slug: "bank",
        i18n: "Bank",
      },
      {
        url: "/dashboard/tdsvouchar",
        name: "TDS Vouchar",
        slug: "tds-vouchar",
        i18n: "TDS Vouchar",
      },
      {
        url: "/dashboard/newledger",
        name: "New Ledger Accounts",
        slug: "nes-ledger",
        i18n: "New Ledeger Accounts",
      },
      {
        url: "/dashboard/newstockacc",
        name: "New Stock Accounts",
        slug: "new-stock",
        icon: "MailIcon",
        i18n: "New Stock Accounts",
      },
      
      {
        url: "/dashboard/definehsn",
        name: "Define HSN For GST Purpose",
        slug: "hsn-gst",
        i18n: "Define HSN For GST Purpose",
      },
      {
        url: "/dashboard/productionchart",
        name: "Production Chart",
        slug: "product-chart",
        i18n: "Production Chart",
      },

      {
        url: "/dashboard/stocktransfer",
        name: "Stock Transfer",
        slug: "stock-trans",
        i18n: "Stock Transfer",
      },
      {
        url: "/dashboard/annexure",
        name: "Annexure",
        slug: "annexure",
        i18n: "Annexure",
      },
      {
        name: "Inventory",
        slug: "inventory",
        i18n: "Inventory",

        submenu: [
          {
            url: "/dashboard/inventory",
            name: "Cash Voucher",
            slug: "cash-voucher",
            i18n: "Sale Challan Vat System",
          },
          {
            url: "/dashboard/inveorderstatpur",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Order Status Purchase",
          },
          {
            url: "/dashboard/inveorderstatsale",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Order Status Sale",
          },
          {
            url: "/dashboard/invematerialissueform",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Material Issue Form",
          },
          {
            url: "/dashboard/invematerialrec",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Material Rec.Form",
          },
          {
            url: "/dashboard/inveproduction",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Production Setup",
          },
          {
            url: "/dashboard/inveconsumption",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Consumption Report",
          },
          {
            url: "/dashboard/invematerialtest",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Material Test Form",
          },
          {
            url: "/dashboard/invejobworklist",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Job Work Receipt",
          },
          {
            url: "/dashboard/invependingchallansale",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Pending Challan Sale",
          },
          {
            url: "/dashboard/invependigcallanpurchase",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Pending Challan Pur",
          },
          {
            url: "/dashboard/inveledgerpost",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Ledger Post Setup",
          },
        ]
      },

      {
        name: "Banking",
        slug: "banking",
        i18n: "Banking",

        submenu: [
          {
            url: "/dashboard/bankpass",
            name: "Bank Passbook",
            slug: "bank-passbook",
            i18n: "Bank Passbook",
          },
          {
            url: "/dashboard/Recolliation",
            name: "Recolliation",
            slug: "Recolliation",
            i18n: "Reconciliation",
          },
          {
            url: "/dashboard/stockmargin",
            name: "Stock Margin Repor",
            slug: "stock-margin",
            i18n: "Stock Margin Report",
          },
        ]
      },
      {
        name: "Goods Return",
        slug: "goods-return",
        i18n: "Goods Return",
        submenu: [
          {
            url: "/dashboard/cashvoucher",
            name: "Cash Voucher",
            slug: "cash-voucher",
            i18n: "Purchase Return",
          },
          {
            url: "/dashboard/cashreceipt",
            name: "Receipt Book",
            slug: "receipt-book",
            i18n: "Sale Return",
          },
          {
            url: "/dashboard/creditnote",
            name: "Credit Note",
            slug: "credit-note",
            i18n: "Credit Note",
          },
          
          {
            url: "/dashboard/debitnote",
            name: "Debit Note",
            slug: "debit-note",
            i18n: "Debit Note",
          },  
          {
            url: "/dashboard/cashreceiptform",
            name: "Cash Receipt Form",
            slug: "cash-re-book",
            i18n: "Cash Receipt Form",
          },
          
        ]
      },
      
      {
        url: "/dashboard/salegstchallan",
        name: "Sale GST Challan",
        slug: "sale-gst-challan",
        i18n: "Sale GST Challan",
      },

     

        
      
    ]
  },










  {

    
    url: null,
    name: "Report",
    icon: "ListIcon",
    i18n: "Report",
    submenu: [

      {
        url: "/dashboard/accountstatement",
        name: "Account Statement",
        slug: "acc-state",
        i18n: "Account Statement",
      },
      {
        url: "/dashboard/trialbal",
        name: "Trial Balance",
        slug: "trial-bal",
        i18n: "Trial Balance",
      },
      {
        url: "/dashboard/balancesheet",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Balance Sheet",
      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Books..",

        submenu: [
          {
            url: '/dashboard/bookcash',
            name: "Sale",
            slug: "salee",
            i18n: "Cash",
          },
          {
              url: '/dashboard/bookjournal',
              name: "Ledger Print",
              slug: "ledger-print",
              i18n: "Journal",
          },
          {
                url: '/dashboard/bookbank',
                name: "Cash",
                slug: "cash",
                i18n: "Bank",
          },
          {
            url: '/dashboard/booksale',
            name: "Cash",
            slug: "cash",
            i18n: "Sale",
          },
          {
            url: '/dashboard/bookpurchase',
            name: "Cash",
            slug: "cash",
            i18n: "Purchase",
          },
          {
            url: '/dashboard/booktds',
            name: "Cash",
            slug: "cash",
            i18n: "TDS",
          },
          {
            url: '/dashboard/bookrecieptbook',
            name: "Cash",
            slug: "cash",
            i18n: "Receipt Book",
          },
          {
            url: '/dashboard/bookvoucherprint',
            name: "Cash",
            slug: "cash",
            i18n: "Vouchar Printing",
          },
          ]
      },
     


      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Summary",

        submenu: [
          {
            url: '/dashboard/summerysale',
            name: "Sale",
            slug: "salee",
            i18n: "Sale",
          },
          {
              url: '/dashboard/summerypurchase',
              name: "Ledger Print",
              slug: "ledger-print",
              i18n: "Purchase",
          },
          {
                url: '/dashboard/sumcash',
                name: "Cash",
                slug: "cash",
                i18n: "Cash",
          },
          ]



      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Ledger",

        submenu: [
          {
            url: '/dashboard/ledgerprint',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Ledger Print",
          },
          {
            url: '/dashboard/ledgerindex',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Ledger Index Print",
          },
          {
            url: '/dashboard/ledgersummary',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Ledger Summary",
          },
          
        ]
      },


      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Outstanding Reports",

        submenu: [
          {
            url: '/dashboard/outdebitors',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Debtors",
          },
          {
            url: '/dashboard/outcreditors',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Creditors",
          },
          {
            url: '/dashboard/outgroupsummery',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Group Summary",
          },
          
        ]
      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Stock",

        submenu: [
          {
            url: '/dashboard/stockreport',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Particular Item",
          },
          {
            url: '/dashboard/stocksumm',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Summary",
          },
          {
            url: '/dashboard/stockledger',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Stock Ledger",
          },
          {
            url: '/dashboard/stocksummary',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Group Summary",
          },
          {
            url: '/dashboard/stockotherdet',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Other Detail",
          },
          {
            url: '/dashboard/stockpartywise',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Party Wise Stock",
          },
          {
            url: '/dashboard/stockproducregis',
            name: "Production Register",
            slug: "Production-Register",
            i18n: "Production Register",
          },
          {
            url: '/dashboard/stockpices',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Stock Pieces",
          },


        ]



      },
      // {
      //   url: "/dashboard/sale-gst",
      //   name: "Sale GST",
      //   slug: "sale-GST",
      //   i18n: "Exice",

      //   submenu: [
      //     {
      //       url: '/dashboard/exciseregister',
      //       name: "Ledger Print",
      //       slug: "ledger-print",
      //       i18n: "Excise Register",
      //     },
      //     {
      //       url: '/dashboard/excisestockregister',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Excise Stock Register",
      //     },
      //     {
      //       url: '/dashboard/excisereport',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Excise Reports",
      //     },
      //     {
      //       url: '/dashboard/excisedutytransaction',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Duty Transaction",
      //     },
      //     {
      //       url: '/dashboard/ledgerindex',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Ledger A/C Wise Duty",
      //     },
      //     {
      //       url: '/dashboard/ledgerindex',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Development Commissioner",
      //     },
      //     {
      //       url: '/dashboard/exisecurrentreport',
      //       name: "Ledger Index",
      //       slug: "ledger-index",
      //       i18n: "Current Report",
      //     },
          
      //   ]




      // },
       {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Gst Reports",

        submenu: [
          {
            url: '/dashboard/gstrepmonthly',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Monthaly Forms",
          },
          {
            url: '/dashboard/gstrepgstled',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "GST Ledger",
          },
          {
            url: '/dashboard/gstrepworksheet',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Worksheet",
          },
          {
            url: '/dashboard/gstrepwisegstdet',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Party Wise GST Detail",
          },
          {
            url: '/dashboard/gstreppartywisegstsumm',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Party Wise GST Summary",
          },
          {
            url: '/dashboard/gstrepaccwiserep',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Account Wise GST Detail",
          },
          {
            url: '/dashboard/gstrepotherdet',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Other Detail",
          },
          {
            url: '/dashboard/gstrepyearlygst',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Yearly GSTR-9",
          },
          {
            url: '/dashboard/tdscommission',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Tax Wise Summary",

            submenu: [
              {
                url: '/dashboard/tdsform1',
                name: "Ledger Print",
                slug: "ledger-print",
                i18n: "Sale",
              },
              {
                url: '/dashboard/tdsform1',
                name: "Ledger Print",
                slug: "ledger-print",
                i18n: "Purchase",
              },
            ]
          },
          
          
        ]




      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "TDS Reports",

        submenu: [
          {
            url: '/dashboard/tdsform16',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Form 16 - A",
          },
          {
            url: '/dashboard/tdsform26',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Form 26 - Q",
          },
          {
            url: '/dashboard/tdscommission',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Commission List",
          },
         
          
          
        ]

      },
      {
        url: "/dashboard/TCS Reports",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "TCS Reports",
      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Income Tax Reports",

        submenu: [
          {
            url: '/dashboard/sumcashc',
            name: "Sale",
            slug: "salee",
            i18n: "Purchase Reports",
            submenu: [
              {
                url: '/dashboard/incompurpartywise',
                name: "Sale",
                slug: "salee",
                i18n: "Party Wise Summary",
              },
              {
                  url: '/dashboard/incompurpartysumm',
                  name: "Ledger Print",
                  slug: "ledger-print",
                  i18n: "A/C Wise Summary",
              },
              {
                    url: '/dashboard/incompurchprowisepur',
                    name: "Cash",
                    slug: "cash",
                    i18n: "Product Wise Purchase",
              },
              
              {
                url: '/dashboard/incompurchprowisedetail',
                name: "Cash",
                slug: "cash",
                i18n: "Product Wise Details",
              },
                {
                  url: '/dashboard/purchasestatewisesummary',
                  name: "Cash",
                  slug: "cash",
                  i18n: "State Wise Summary",
                },
                  {
                    url: '/dashboard/incompurbroker',
                    name: "Cash",
                    slug: "cash",
                    i18n: "Broker Wise Summary",
              
          },
              ]
          },
          {
              url: '/dashboard/ledgerprint',
              name: "Ledger Print",
              slug: "ledger-print",
              i18n: "Sale Reports",

              submenu: [
                {
                  url: '/dashboard/salepartywisesummary',
                  name: "Sale",
                  slug: "salee",
                  i18n: "Party Wise Summary",
                },
                {
                    url: '/dashboard/incomsaleaccountwise',
                    name: "Ledger Print",
                    slug: "ledger-print",
                    i18n: "A/C Wise Summary",
                },
                {
                      url: '/dashboard/productwisesale',
                      name: "Cash",
                      slug: "cash",
                      i18n: "Product Wise Sale",
                },
                {
                  url: '/dashboard/incomsaleproductwisedet',
                  name: "Cash",
                  slug: "cash",
                  i18n: "Product Wise Details",
                },
                {
                  url: '/dashboard/incomsaleotherreport',
                  name: "Cash",
                  slug: "cash",
                  i18n: "Other Reports",
                },
                  {
                    url: '/dashboard/icomsalestatewisesumm',
                    name: "Cash",
                    slug: "cash",
                    i18n: "State Wise Summary",
                  },
                    {
                      url: '/dashboard/incomsaleagentwise',
                      name: "Cash",
                      slug: "cash",
                      i18n: "Agent Wise Summary",
                
            },
                ]
          },
        
          ]
      },
      {
        url: "/dashboard/servicetaxlist",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Service Tax List",
      },
      {
        url: "/dashboard/sale-gst",
        name: "Sale GST",
        slug: "sale-GST",
        i18n: "Other",


        submenu: [
          {
            url: '/dashboard/tdsform16',
            name: "Ledger Print",
            slug: "ledger-print",
            i18n: "Interest Calculation",

            submenu: [
              {
                url: '/dashboard/otherintcalindv',
                name: "Ledger Print",
                slug: "ledger-print",
                i18n: "Individual Interest",   
              },
              {
                url: '/dashboard/otherintcalgroup',
                name: "Ledger Print",
                slug: "ledger-print",
                i18n: "Group Interest",   
              },
            ]
          },
          {
            url: '/dashboard/othercformlist',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "C Form List",
          },
          {
            url: '/dashboard/otherdailymargin',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Daily Margin Report",
          },
          {
            url: '/dashboard/othershortagelist',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Shortage List",
          },
          {
            url: '/dashboard/othercomprep',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Company Reporst",
          },
          {
            url: '/dashboard/otherdiscountrep',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Discount Reports",
          },
          {
            url: '/dashboard/otherexcelformat',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Excel Format",
          },
          {
            url: '/dashboard/otherinvoiceprinting',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Invoice Printing",
          },
          {
            url: '/dashboard/otherconsignmentnote',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Consignment Note",
          },
          {
            url: '/dashboard/otherpollutionrep',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Pollution Report",
          },
          {
            url: '/dashboard/othercashinoice',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Cash Invoice",
          },
          {
            url: '/dashboard/otherosalereport',
            name: "Ledger Index",
            slug: "ledger-index",
            i18n: "Other Sale Report",
          },
         
          
          
        ]
      },
      {
        url: "/dashboard/checklist",
        name: "Check List",
        slug: "Check List",
        i18n: "Check List",
      },
      
    ]
  },


  {
    header: "About",
    icon: "PackageIcon",
    i18n: "About",
    items: [

      {
        url: "#",
        name: "About Us",
        slug: "sale-GST",
        icon: "MailIcon",
        i18n: "About Us",
      },
      
    ]
  },
  
]

