<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.active-item {
  background-color: #bcd4ec;
}

.vs-table--thead {
  background: #453e90;
}

#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

.vs-popup {
  width: 800px !important;
}

.vs-button {
  display: inline-block;
}

.tdInputsmall {
  width: 100px;
  height: 25px;
}

.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>
<template>
<div class="modal">
  <div class="vx-card p-6">
    <vs-popup
      classContent="popup-example"
      title="Account Form(press esc to close)"
      button-close-hidden="true"
      :active.sync="popupActive2"
    >
      <modal
        v-model="modalOpen"
        v-on:childToParent="onChildClick"
        :SearchText="searchlabel"
        ref="childComponentLedger"
      />
    </vs-popup>

    <vs-popup
      classContent="popup-example"
      title="Account Form"
      :active.sync="popupActiveStock"
      button-close-hidden="true"
    >
      <modalStock
        v-model="modalOpenStock"
        v-on:childToParent="onChildClick"
        :SearchText="searchlabel"
        ref="childComponentStock"
      />
    </vs-popup>

    <vs-popup
      classContent="popup-example"
      title="Narrations"
      name="popupActive3"
      button-close-hidden="true"
      :active.sync="popupActiveNarration"
    >
      <modalnarration
        ref="childComponent"
        :parentData="narrationtypename"
        v-on:spdatareceived="onspdatareceived"
        v-model="modalOpenNarration"
        v-on:childToParentNarration="onChildClickNarration"
        :SearchText="searchlabel"
      />
    </vs-popup>

    <vs-popup classContent="popup-example" title="Stock Items" :active.sync="searchPopup">
      <div class="search-wrapper" align="center" :id="filterbar">
        <tr>
          <td>
            <label>
              <b>
                <font size="5">Stock Items</font>
              </b>
            </label>
          </td>
        </tr>
      </div>
      <br />

      <div>
        <vs-table multiple v-model="selected" :data="popupFilteredData">
          <template slot="header">
            <h3>Users</h3>
          </template>

          <template slot="thead">
            <vs-th v-for="heads in popupHeaders" :key="heads">{{heads}}</vs-th>
          </template>

          <template slot-scope="{data}">
            <vs-tr
              :data="tr"
              :key="indextr"
              v-for="(tr, indextr) in data"
              :class="{'active-item': currentItem === indextr}"
            >
              <vs-td :data="data[indextr].Name">{{data[indextr].Name}}</vs-td>

              <vs-td :data="data[indextr].HSNCode">{{data[indextr].HSNCode}}</vs-td>

              <vs-td :data="data[indextr].Tax">{{data[indextr].Tax}}</vs-td>

              <vs-td :data="data[indextr].GroupName">{{data[indextr].GroupName}}</vs-td>
              <vs-td :data="data[indextr].Accode"></vs-td>
              <vs-td :data="data[indextr].SaleRate">{{data[indextr].SaleRate}}</vs-td>

              <vs-td :data="data[indextr].MRP">{{data[indextr].MRP}}</vs-td>
              <vs-td :data="data[indextr].ClsStockin">{{data[indextr].ClsStockin}}</vs-td>
              <vs-td :data="data[indextr].QtyinUOM">{{data[indextr].QtyinUOM}}</vs-td>
            </vs-tr>
          </template>
        </vs-table>
      </div>
      <div>
        <tr>
          <td>
            <label>Search:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              width="120"
              type="text"
              id="searchbar"
              v-model="searchbar"
              @input="searchedList()"
            />
          </td>
          <td style="padding-left:10px;">
            <select v-model="selectedDropdown">
              <option disabled value>Please select one</option>
              <option value="accountname">Search By Name</option>
              <option value="cityname">Search By City</option>
              <option value="address">Search By Address</option>
              <option value="gstin">Search By GSTIN</option>
              <option value="contactno">Search By Contact</option>
              <option value="mobile">Search By Mobile</option>
            </select>
          </td>
          <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              title="Add"
              color="primary"
              id="addButtonPopup"
              @click="addFromPopup()"
            >Add</vs-button>
          </td>
          <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Modify"
              color="primary"
              id="modifyButtonPopup"
              @click="modifyFromPopup()"
            >Modify</vs-button>
          </td>
          <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Delete"
              color="primary"
              id="deleteButtonPopup"
              @click="deleteFromPopup()"
            >Delete</vs-button>
          </td>

          <td>
            <label>Filter:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              size="small"
              type="text"
              id="filterbar"
              v-model="filterbar"
              @input="filteredList()"
            />
          </td>
        </tr>
      </div>
      <!-- Popup Inside a popup for adding an entry -->
      <vs-popup
        classContent="popup-example"
        title="Add New Ledger Account"
        :active.sync="popupActive4"
      >
        <br />

        <div>
          <vs-tr>
            <vs-td size="medium">
              AccountName:
              <focus-trap v-model="acnameFocus" ref="focusTrap">
                <vs-input class="w-full" size="medium" type="text" v-model="AcName" />
              </focus-trap>
            </vs-td>
            <vs-td size="medium">
              CityName:
              <vs-input class="w-full" size="medium" type="text" v-model="City" />
            </vs-td>
          </vs-tr>
          <vs-tr>
            <vs-td size="medium">
              Address:
              <vs-input class="w-full" size="medium" type="text" v-model="Address2" />
            </vs-td>
            <vs-td size="medium">
              GSTIN:
              <vs-input class="w-full" size="medium" type="text" v-model="DGSTNo" />
            </vs-td>
          </vs-tr>
          <vs-tr>
            <vs-td size="medium">
              Contact:
              <vs-input class="w-full" size="medium" type="text" v-model="ContactNo" />
            </vs-td>
            <vs-td size="medium">
              Mobile:
              <vs-input class="w-full" size="medium" type="numbers" v-model="Mobile" />
            </vs-td>
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add New Account Details"
                color="primary"
                id="deleteButtonPopup"
                @keyup.right="buttonNext('saveButton')"
                @keyup.left="buttonPrev('saveButton')"
                @click="AddNewDetails()"
              >Add New Account</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
    </vs-popup>
    <vs-popup
      classContent="popup-example"
      title="New Ledger Acc Form Setup"
      name="setupForm"
      button-close-hidden="false"
      :active.sync="setupForm"
    >
      <vs-tr>
        <vs-td>A/C Code:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_accode" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_accode"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_accode"
          />
        </vs-td>
        <vs-td style="padding-left:15px">A/C Name:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_acname" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_acname"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_acname"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Op Stock in Qty:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_opstockqty" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_opstockqty"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_opstockqty"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Box:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_box" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_box"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_box"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Op Stock in Rs.:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_opstockrs" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_opstockrs"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_opstockrs"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Group Name:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_groupname" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_groupname"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_groupname"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Purchase Rate :</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_purchaserate" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_purchaserate"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_purchaserate"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Less %:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_less1" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_less1"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_less1"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>M.R.P :</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_mrp" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_mrp"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_mrp"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Less %</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_less2" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_less2"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_less2"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Sale Rate:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_salerate" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_salerate"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_salerate"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Total GST @:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_totalgst" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_totalgst"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_totalgst"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>C.GST @:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_cgst" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_cgst"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_cgst"
          />
        </vs-td>
        <vs-td style="padding-left:15px">S.GST @:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_sgst" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_sgst"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_sgst"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Cess Qty:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_cessqty" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_cessqty"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_cessqty"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Cess @:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_cess" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_cess"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_cess"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Purchase A/c:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_purchaseac" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_purchaseac"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_purchaseac"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Sale A/c:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_saleac" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_saleac"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_saleac"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Size:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_size" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_size"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_size"
          />
        </vs-td>
        <vs-td style="padding-left:15px">HSN Code:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_hsncode" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_hsncode"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_hsncode"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_previoussale"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Scheme @:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_scheme" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_scheme"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_scheme"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Expiry Dt.:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_expirydt" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_expirydt"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_expirydt"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Rate Calculator:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_ratecalculator" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_ratecalculator"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_ratecalculator"
          />
        </vs-td>
        <vs-td style="padding-left:15px">CLS Stock in:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_clsstockin" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_clsstockin"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_clsstockin"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Qty. in:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_qtyin" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_qtyin"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_qtyin"
          />
        </vs-td>
        <vs-td style="padding-left:15px">UOM:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_uom" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_uom"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_uom"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Stock Calculator:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_stockcalculator" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_stockcalculator"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_stockcalculator"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Type of Goods:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_typeofgoods" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="ch_typeofgoods"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_typeofgoods"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Stk Vadah8asuation:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_stkvaluation" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_stkvaluation"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_stkvaluation"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Qty Per Pc/Case:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_qtyperpc" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_qtyperpc"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_qtyperpc"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Tariff Heading:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_tariffheading" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_tariffheading"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_tariffheading"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Min.Stock Level:</vs-td>

        <vs-td>
          <vs-checkbox v-model="ch_minstocklevel" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_minstocklevel"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_minstocklevel"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>GST Type:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_gsttype" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_gsttype"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_gsttype"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Production Sr. No:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_productionsrno" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_productionsrno"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_productionsrno"
          />
        </vs-td>
      </vs-tr>

      <vs-tr>
        <vs-td>Unit No.:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_unitno" />
        </vs-td>
        <vs-td>
          <vs-input
            size="small"
            class="w-full"
            type="text"
            label-placeholder="label text"
            v-model="lt_unitno"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_unitno"
          />
        </vs-td>
        <vs-td style="padding-left:15px">Percentage:</vs-td>
        <vs-td>
          <vs-checkbox v-model="ch_percentage" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_percentage"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="Default value"
            v-model="dv_percentage"
          />
        </vs-td>
      </vs-tr>
      <vs-tr>
        <vs-td style="padding-left:15px">Max.Stock Level:</vs-td>

        <vs-td>
          <vs-checkbox v-model="ch_maxstocklevel" />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="label text"
            v-model="lt_maxstocklevel"
          />
        </vs-td>
        <vs-td>
          <vs-input
            class="w-full"
            size="small"
            type="text"
            label-placeholder="default value"
            v-model="dv_maxstocklevel"
          />
        </vs-td>
      </vs-tr>
      <vs-tr align="right">
        <vs-td>
          <vs-button size="medium" title="Save" @click="SaveStockSetup" color="primary">Save</vs-button>
        </vs-td>
      </vs-tr>
    </vs-popup>

    <!-- product details popup definition starts -->

    <vs-popup classContent="popup-example" title :active.sync="miscActive">
      <div style="overflow-x:auto;">
        <div class="vx-card p-6" style>
          <!--header START-->
          <table width="100%" border="0" class="tables">
            <tr>
              <td width="25%"></td>
              <td width="50%">
                <center>
                  <h1 class="text-primary">
                    Scheme Details
                    <br />
                    <h4>
                      <font color="grey">{{titleAction}}</font>
                    </h4>
                  </h1>
                </center>
              </td>
              <td width="25%" align="right"></td>
            </tr>
            <br />
          </table>

          <div class="flex mb-4" style="padding-top:20px;">
            <div
              class="w-1/2 bg-grid-color-secondary h-12 flex"
              style="height:100% !important; width:100% !important; padding-bottom:20px; margin-right:17%;"
            >
              <table style="table-layout:fixed; width:100%;">
                <tr>
                  <td>
                    <b>Scheme on Qty</b>
                    <table style="table-layout:fixed; width:100%;">
                      <tr>
                        <td></td>
                        <td>
                          <b>Qty</b>
                        </td>
                        <td>
                          <b>Scheme Rs</b>
                        </td>
                      </tr>
                      <tr>
                        <td>1</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_qty1"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_schemers1"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_qty2"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_schemers2"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_qty3"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_schemers3"
                            style="width:180px;  margin-top:10px;"
                           
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_qty4"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_schemers4"
                            style="width:180px;  margin-top:10px;"
                           
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_qty5"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_schemers5"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td>
                    <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
                      <tr>
                        <td class="overlap">ER-6 Type</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_er6type"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">Pr.Code.1</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_prcode1"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">Pr.Code.2</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_prcode2"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">Pr.Code.3</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_prcode3"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">Pr.Code.4</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_prcode4"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">Pr.Code.5</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_prcode5"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </div>
            <div
              class="w-1/2 bg-grid-color-secondary h-12 flex"
              style="height:100% !important; width:100% !important; padding-bottom:20px;"
              :disabled="buttondis"
            >
              <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
                <tr>
                  <td>
                    <table style="table-layout:fixed; width:100%;">
                      <b>Scheme on Value</b>
                      <tr>
                        <td>
                          <b>Exp/Scheme</b>
                        </td>
                        <td>
                          <b>Value</b>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_exp1"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_value1"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_exp2"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_value2"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_exp3"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_value3"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_exp4"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_value4"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_exp5"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_value5"
                            style="width:180px;  margin-top:10px;"
                           
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td>
                    <table style="table-layout:fixed; width:100%;">
                      <tr>
                        <td class="overlap">Register Name</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_registername"
                            style="width:180px;  margin-top:10px;"
                            
                          />
                        </td>
                      </tr>
                      <tr>
                        <td class="overlap">C.S. Trading A/c No.</td>
                        <td>
                          <vs-input
                            class="w-full"
                            size="small"
                            v-model="schemedetails_cstradingacno"
                            style="width:180px;  margin-top:10px;"
                           
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </div>
          </div>

          <div class="flex mb-4" style="padding-top:20px;">
            <table style="width:80%;">
              <tr>
                <td>
                  A/c Description
                  &nbsp;
                </td>
                <td>
                  <vs-textarea v-model="schemedetails_acdescription" />
                </td>
              </tr>
            </table>
          </div>

          <div align="right">
            <br />

            <br />
            <!-- Button set start-->
            <div align="left">
              <vs-button
                style="float:right; display:inline-block;"
                class="button margin"
                @click="save()"
              >Auto Stock Setup</vs-button>

              <vs-button
                style="float:right; display:inline-block;"
                id="ratedefinebutton"
                class="button margin"
                @click="showRateDefinePopup()"
              >Rate Define</vs-button>

              <vs-button
                style="float:right; display:inline-block;"
                class="button margin"
                @click="save()"
              >Back</vs-button>
            </div>
            <!-- Button set end -->
          </div>

          <br />
          <br />
          <br />
        </div>
      </div>

      <vs-popup classContent="popup-example" title :active.sync="rateDefineActive">
      <table width="100%" border="0" class="tables">
        <tr>
          <td width="25%"></td>
          <td width="50%">
            <center>
              <h1 class="text-primary">
                Define Period Wise Product Rates
                <br />
                <h4>
                  <font color="grey">{{titleAction}}</font>
                </h4>
              </h1>
            </center>
          </td>
          <td width="25%" align="right">
            Today {{now}}
            <br />
            {{currentday}}
          </td>
        </tr>
        <br />
      </table>
      <!--header END-->

      <!-- Table Start -->
      <div style="overflow-x:auto;">
        <table id="customers" :data="tabledata">
          <tr>
            <th
              d="headerid"
              v-for="(cashheader,key) in cashheaders"
              class="bg-primary"
              :key="`input${key}`"
            >
              {{cashheader}}
              <!-- <vs-button
                v-show="isnarration(key)"
                :disabled="buttondis"
                type="button"
                value="settings"
                :id="settings"
                @click="showdescNar('cashnarration')"
              ></vs-button> -->
            </th>
          </tr>
          <tr v-for="(cashVaucher, k) in cashVauchers" :key="k">
            <td scope="row" width="16%">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.accountno"
                :id="'0' + k"
               
               
              />
            </td>

            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.partno"
                :id="'1' + k"
                
              />
            </td>
            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.orderno"
                
                :id="'2' + k"
              
              />
            </td>
            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.amendmentno"
               
                :id="'3' + k"
       
              />
            </td>
            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.datefrom"
                
                :id="'4' + k"
         
              />
            </td>
            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.dateupto"
                
                :id="'5' + k"
            
              />
            </td>
            <td class="tdInputsmall">
              <vs-input
                class="w-full"
                size="small"
                v-model="cashVaucher.rate"
                
                :id="'6' + k"
         
              />
            </td>
            <td align="center" class="tdDeletebutton">
              <vs-button
                size="small"
                icon-pack="feather"
                icon="icon-trash"
                color="danger"
                style="margin:3px;"
                @click="deleteRow(k, cashVaucher)"
              ></vs-button>
            </td>
          </tr>
        </table>
      </div>
      <!-- Table End -->
      <br />
    <div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()">
        <i class="fa fa-plus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="pop">
        <i class="fa fa-minus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div>
      <br />

      <div align="right">
        <br />

        <br />
        <!-- Button set start-->
        <div align="left" id="tries">
          <vs-button
            :color="getColor('addButton')"
            type="filled"
            title="Add"
            id="addButton"
            icon-pack="feather"
            icon="icon-file-plus"
            @keyup.right="buttonNext('addButton')"
            @keyup.left="buttonPrev('addButton ')"
            @click="newdisable"
            :disabled="disAdd"
          />
          <vs-button
            title="Next"
            :color="getColor('nextButton')"
            icon-pack="feather"
            icon="icon-chevrons-right"
            :disabled="disNext"
            id="nextButton"
            class="button margin"
            @keyup.right="buttonNext('nextButton')"
            @keyup.left="buttonPrev('nextButton')"
            @click="nextPage"
          />
          <vs-button
            title="Previous"
            :color="getColor('previousButton')"
            type="filled"
            icon-pack="feather"
            icon="icon-chevrons-left"
            :disabled="disPrevious"
            id="previousButton"
            class="button margin"
            @keyup.right="buttonNext('previousButton')"
            @keyup.left="buttonPrev('previousButton')"
            @click="previousPage"
          />
          <vs-button
            title="Last"
            icon-pack="feather"
            icon="icon-arrow-right"
            :color="getColor('lastButton')"
            :disabled="disLast"
            id="lastButton"
            class="button margin"
            @keyup.right="buttonNext('lastButton')"
            @keyup.left="buttonPrev('lastButton')"
            @click="lastPage"
          />

          <vs-button
            title="First"
            icon-pack="feather"
            icon="icon-arrow-left"
            :color="getColor('firstButton')"
            :disabled="disFirst"
            id="firstButton"
            class="button margin"
            @keyup.right="buttonNext('firstButton')"
            @keyup.left="buttonPrev('firstButton')"
            @click="firstPage"
          />

          <vs-button
            title="Delete"
            icon-pack="feather"
            icon="icon-trash"
            :color="getColor('deleteButton')"
            :disabled="disDelete"
            id="deleteButton"
            class="button margin"
            @keyup.right="buttonNext('deleteButton')"
            @keyup.left="buttonPrev('deleteButton')"
            @click="Delete()"
          />
          <vs-button
            title="Exit"
            icon-pack="feather"
            icon="icon-x"
            :color="getColor('exitButton')"
            :disabled="disExit"
            id="exitButton"
            ref="exitButton"
            class="button margin"
            @keyup.right="buttonNext('exitButton')"
            @keyup.left="buttonPrev('exitButton')"
            @click="exit"
          />
          <vs-button
            style="float:right; display:inline-block;"
            title="Exit"
            color="primary"
            icon-pack="feather"
            icon="icon-x"
            :disabled="disExit"
            id="exitButton"
            ref="exitButton"
            class="button margin"
            @keyup.right="buttonNext('exitButton')"
            @keyup.left="buttonPrev('exitButton')"
            @click="exit"
          ></vs-button>
        </div>
        <!-- Button set end -->
      </div>
    </vs-popup>

    </vs-popup>

    <!-- product details Popup definition ends -->

    <vs-popup classContent="popup-example" title :active.sync="productDetailActive">
      <table width="100%" border="0" class="tables">
        <tr>
          <td width="33%"></td>
          <td width="50%">
            <center>
              <h1>
                <font color="#7367f0">Specification of Product</font>
              </h1>
            </center>
          </td>
          <td width="33%"></td>
        </tr>
      </table>
      <br />

      <br />
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6">
          <span align="center ">Manufacturer</span>
        </div>

        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            v-model="product_manufacturer"
            id="product_manufacturer"
            size="small"
            
            style="width:180px; height:24px;"
            placeholder
          />
        </div>
        <div class="vx-col sm:w-1/6" align="right">
          <span style="padding-left:45px">Market By</span>
        </div>

        <div class="vx-col sm:w-1/6 w-full" style="padding-left:100px">
          <vs-input
            v-model="product_marketby1"
            id="product_marketby1"
            size="small"
            style="width:180px; height:24px;"
            placeholder
            @keypress="onlyNumber"
          />
        </div>
      </div>
      <br />
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6">
          <span>Market By</span>
        </div>
        <div class="vx-col sm:w-1/5">
          <vs-input
            v-model="product_marketby2"
            id="product_marketby2"
            size="small"
            style="width:180px; height:24px;"
            placeholder
          />
        </div>
        <div class="vx-col sm:w-1/6">
          <span style="padding-left:50px">CIR No.</span>
        </div>
        <div class="vx-col sm:w-1/6" style="padding-left:70px">
          <vs-input
            v-model="product_cirno"
            id="product_cirno"
            size="small"
            style="width:180px; height:24px;"
            placeholder
          />
        </div>
      </div>
      <br />
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6">
          <span>Crop Name</span>
        </div>
        <div class="vx-col sm:w-1/6">
          <vs-input
            v-model="prodcut_cropno"
            id="prodcut_cropno"
            size="small"
           
            style="width:180px; height:24px;"
            placeholder
          />
        </div>
      </div>

      <div align="center" style>
        <div class="right" align="center">
          <br />
          <vs-button id="saveButton">Save</vs-button>
        </div>
      </div>
    </vs-popup>

<vs-popup  classContent="popup-example" title :active.sync="zoneDetailActive">
  <div>
        <tr style="height:50px" >
        <td >Zone Name</td>
        <td ><vs-input  size="small"  v-model="zone_zone" /></td>
        <td>Rate</td>
        <td><vs-input size="small"  v-model="zone_rate"/></td>
        </tr>
        <br/>
        <vs-table v-model="selected2" @selected="handleSelected2" :data="zoneDetailsData">
          
          <template slot="thead">
        <vs-th>
          Select
        </vs-th>
        <vs-th>
          Zone Name
        </vs-th>
        <vs-th>
          Rate
        </vs-th>
        <vs-th>
          Actions
        </vs-th>
       </template>
          
          <template slot-scope="{data}">
            <vs-tr
              :data="tr"
              :key="indextr"
              v-for="(tr, indextr) in data"
              :id="'zoneListItem'+indextr"
            >
              <vs-td size="small">
                <ul class="centerx">
                  <input type="checkbox" :id="'zoneCheck'+indextr" value="kuch" />
                </ul>
              </vs-td>
              <vs-td size="small">{{ data[indextr].zone }}</vs-td>
              <vs-td size="small">{{ data[indextr].rate }}</vs-td>
              <vs-td size="small"><vs-button
              size="small"
              title="Modify"
              color="primary"
              id="modifyButtonPopup"
              @click="zoneModify(indextr)"
            >Modify</vs-button></vs-td>
            </vs-tr>
          </template>
        </vs-table>
      </div>
      <br/>
      <div>
        <tr>
          <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              title="Add"
              color="primary"
              id="narAddButtonPopup"
              @click="showAddZonePopup()"
            >Add</vs-button>
          </td>
        
          <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Delete"
              color="primary"
              id="deleteButtonPopup"
              @click="narrationDelete()"
            >Delete</vs-button>
          </td>
            <td class="tdInputsmall" style="padding-left:10px;">
          
          </td>
            <td class="tdInputsmall" style="padding-left:10px;">
          
          </td>
            <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Delete"
              color="primary"
              @click="saveZoneDetails"  
            >save</vs-button>
          </td>
        </tr>
      </div>
      <vs-popup
        classContent="popup"
        title="Add new zone"
        :active.sync="popupActive5"
        id="popupActive5"
        name="popupActive5"
      >
        <br />
        <div>
          <vs-tr>
            <vs-td>
              Zone Name:
              <vs-input
                class="tdInputsmall"
                type="text"
                id="newNarr"
                ref="newNarr"
                v-model="new_zone_zone"
                
              />
            </vs-td>
              &nbsp;

            <vs-td>
              Rate:
              <vs-input
                class="tdInputsmall"
                type="text"
                id="newNarr"
                ref="newNarr"
                v-model="new_zone_rate"
               
              />
            </vs-td>
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="addNewZone()"
              >Add Zone</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
      <vs-popup classContent="popup" title="Modify Zone Details" :active.sync="popupActive6">
        <br />

        <div>
          <vs-tr>
            <vs-td >
              Zone to Modify:
              <vs-input  type="text" v-model="changed_zone_zone" id="changed_zone_zone"   style="width:700px; height:20px;"/>
            </vs-td>
          </vs-tr>
          <br/>
          <vs-tr>
            <vs-td >
              Rate to Modify:
              <vs-input  type="text" v-model="changed_zone_rate" id="changed_zone_rate"   style="width:700px; height:20px;"/>
            </vs-td>
         
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="zoneModify2()"
              >Modify Zone Details</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
</vs-popup>
    
    <tr width="100%">
      <td width="50%" align="left"></td>
      <td width="50%">
        <h1 class="text-primary">
          Stock Item Menu
          <br />
          <h4>
            <font color="grey">{{titleActions}}</font>
          </h4>
        </h1>
      </td>
      <td align="right" width="20%">
        <vs-button color="primary" type="border" @click="showSetupForm()">Setup</vs-button>
      </td>
    </tr>

    <br />
    <div class="vs-row" w="3">
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/2 w-full" style="padding-left:150px">
          <div class="center con-checkbox">
            <vs-checkbox
              val="CarryProductDescription"
              v-model="carryproductdescription"
              :disabled="cpdDisable"
            >Carry Product Description</vs-checkbox>
            <span class="data">{{ options }}</span>
          </div>
        </div>
      </div>
      <br />
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_accode}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="Accode" :disabled="buttondis_Accode" />
        </div>
        <div class="vx-col sm:w-1/4 w-full">
          <vs-checkbox val="LinkWithLedger" v-model="options" :disabled="buttondis">Link With Ledger</vs-checkbox>
        </div>
        <div class="vx-col sm:w-1/4 w-full">
          <vs-checkbox val="StockRegister" v-model="options" :disabled="buttondis">Stock Register</vs-checkbox>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_acname}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            id="nam"
            @input="nameInputTrig"
            @change="caseSense('Name')"
            v-model="Name"
            :disabled="buttondis_Name"
          />
        </div>
        <div class="vx-col sm:w-1/4 w-full"></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox val="Active" v-model="options" :disabled="buttondis">Active</vs-checkbox>
        </div>
      </div>

      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_opstockqty}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="OpStockinQty"
            @keypress="onlyNumber"
            :disabled="buttondis_OpStockinQty"
          />
        </div>
      </div>

      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_box}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Box"
            @keypress="onlyNumber"
            :disabled="buttondis_Box"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>
            <vs-button
              type="filled"
              title="Zone Detail"
              id="zonedetailbutton"
              @click="showZoneDetailPopup"
              autofocus="true"
            >Zone Detail</vs-button>
          </span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>
            <vs-button
              type="filled"
              title="Product Detail"
              id="productdetailbutton"
              @click="showProductDetailPopup"
              autofocus="true"
            >Product Detail</vs-button>
          </span>
        </div>
      </div>

      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_opstockrs}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="OpStockinRs"
            @keypress="onlyNumber"
            :disabled="buttondis_OpStockinRs"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_scheme}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="Scheme" :disabled="buttondis_Scheme" />
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_groupname}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <ejs-tooltip id="tooltip" content="press right alt for narration" position="BottomLeft">
            <vs-input
              class="w-full"
              size="small"
              v-model="GroupName"
              @focus="onFocus('Group')"
              @input="upper('GroupName')"
              :disabled="buttondis_GroupName"
            />
          </ejs-tooltip>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_expirydt}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="ExpiryDt"
            id="ExpiryDt"
            :disabled="buttondis_ExpiryDt"
          />
          <br />
          <vs-checkbox val="CarryProductDescription" v-model="options" :disabled="buttondis">On Qty</vs-checkbox>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_purchaserate}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="PurchaseRate"
            @keypress="onlyNumber"
            :disabled="buttondis_PurchaseRate"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_ratecalculator}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="RateCalculater"
            class="w-full select-large"
            label
            :disabled="buttondis_RateCalculater"
          >
            <vs-select-item :key="index" value="default" text="Default" class="w-full" />
            <vs-select-item :key="index" value="wt/Qty" text="Wt/Qty" class="w-full" />
            <vs-select-item :key="index" value="pc/pkgs" text="Pc/Pkgs" class="w-full" />
            <vs-select-item :key="index" value="specific" text="Specific" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_less1}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Less"
            @keypress="onlyNumber"
            :disabled="buttondis_Less"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_clsstockin}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="ClsStockin"
            class="w-full select-large"
            label
            :disabled="buttondis_ClsStockin"
          >
            <vs-select-item :key="index" value="wt/Qty" text="Wt/Qty" class="w-full" />
            <vs-select-item :key="index" value="pieces/case" text="Pieces/Case" class="w-full" />
            <vs-select-item :key="index" value="default" text="Default" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_mrp}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="MRP"
            @keypress="onlyNumber"
            :disabled="buttondis_MRP"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_qtyin}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="QtyinUOM"
            class="w-full select-large"
            label
            :disabled="buttondis_QtyinUOM"
          >
            <vs-select-item :key="index" value="m.tons" text="M.Tons" class="w-full" />
            <vs-select-item :key="index" value="qtls" text="Qtls" class="w-full" />
            <vs-select-item :key="index" value="kg" text="Kg" class="w-full" />
            <vs-select-item :key="index" value="ltrs" text="Ltrs" class="w-full" />
            <vs-select-item :key="index" value="case" text="Case" class="w-full" />
            <vs-select-item :key="index" value="box" text="Box" class="w-full" />
            <vs-select-item :key="index" value="packet" text="Packet" class="w-full" />
            <vs-select-item :key="index" value="pcs" text="Pcs" class="w-full" />
            <vs-select-item :key="index" value="pair" text="Pair" class="w-full" />
            <vs-select-item :key="index" value="dozen" text="Dozen" class="w-full" />
            <vs-select-item :key="index" value="lari" text="Lari" class="w-full" />
            <vs-select-item :key="index" value="drum" text="Drum" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_less2}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Less2"
            @keypress="onlyNumber"
            :disabled="buttondis_Less2"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_uom}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select v-model="Uom2" class="w-full select-large" label :disabled="buttondis_Uom2">
            <vs-select-item
              :key="index"
              :value="item.value"
              :text="item.text"
              v-for="(item,index) in qomlist"
              class="w-full"
            />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_salerate}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="SaleRate"
            @keypress="onlyNumber"
            :disabled="buttondis_SaleRate"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_stockcalculator}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="StockCalculater"
            class="w-full select-large"
            label
            :disabled="buttondis_StockCalculater"
          >
            <vs-select-item :key="index" value="wt/Qty" text="Wt/Qty" class="w-full" />
            <vs-select-item :key="index" value="pc/packet" text="Pc/Packet" class="w-full" />
            <vs-select-item :key="index" value="default" text="Default" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_totalgst}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="TotalGST"
            @keypress="onlyNumber"
            @change="gstdiv"
            :disabled="buttondis_TotalGST"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_typeofgoods}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="TypeofGoods"
            class="w-full select-large"
            label
            :disabled="buttondis_TypeofGoods"
          >
            <vs-select-item :key="index" value="rawmaterial" text="Raw Material" class="w-full" />
            <vs-select-item
              :key="index"
              value="finishedproduct"
              text="Finished Product"
              class="w-full"
            />
            <vs-select-item
              :key="index"
              value="semifinishedproduct"
              text="Semi Finished Product"
              class="w-full"
            />
            <vs-select-item :key="index" value="byeproduct" text="Bye Product" class="w-full" />
            <vs-select-item :key="index" value="wastage" text="Wastage" class="w-full" />
            <vs-select-item :key="index" value="consumable" text="Consumable" class="w-full" />
            <vs-select-item :key="index" value="othergoods" text="Other Goods" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_cgst}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="CGST"
            @keypress="onlyNumber"
            :disabled="buttondis_CGST"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_stkvaluation}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="StkValuation"
            class="w-full select-large"
            label
            :disabled="buttondis_StkValuation"
          >
            <vs-select-item :key="index" value="purchaserate" text="Purchase Rate" class="w-full" />
            <vs-select-item :key="index" value="salerate" text="Sale Rate" class="w-full" />
            <vs-select-item :key="index" value="none" text="none" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_cessqty}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="CessQty"
            @keypress="onlyNumber"
            :disabled="buttondis_CessQty"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_qtyperpc}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="QtyPerPcCase"
            @keypress="onlyNumber"
            :disabled="buttondis_QtyPerPcCase"
          />
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_sgst}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="SGST"
            @keypress="onlyNumber"
            :disabled="buttondis_SGST"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_tariffheading}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="TariffHeading"
            @input="upper('TariffHeading')"
            :disabled="buttondis_TariffHeading"
          />
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_cess}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="Cess" :disabled="buttondis_Cess" />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_minstocklevel}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="MinStockLevel"
            @keypress="onlyNumber"
            :disabled="buttondis_MinStockLevel"
          />
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_purchaseac}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <ejs-tooltip id="tooltip" content="press right alt for narration" position="BottomLeft">
            <vs-input
              class="w-full"
              size="small"
              :value="PurchaseAc"
              v-model="PurchaseAc"
              @change="v=>PurchaseAc=JSON.stringify(v) "
              @focus="onFocus('PurchaseAc')"
              @input="salepurchaseinput('purchase')"
              v-on:keydown.18.prevent="openLedger"
              :disabled="buttondis_PurchaseAc"
            />
          </ejs-tooltip>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_maxstocklevel}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="MaxStockLevel"
            @keypress="onlyNumber"
            :disabled="buttondis_MaxStockLevel"
          />
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_saleac}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <ejs-tooltip id="tooltip" content="press right alt for narration" position="BottomLeft">
            <vs-input
              class="w-full"
              size="small"
              v-model.lazy="SaleAc"
              @focus="onFocus('SaleAc')"
              @input="salepurchaseinput('sale')"
              v-on:keydown.18.prevent="openLedger"
              id="SaleAc"
              :disabled="buttondis_SaleAc"
            />
          </ejs-tooltip>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_gsttype}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select
            v-model="GSTType"
            class="w-full select-large"
            label
            :disabled="buttondis_GSTType"
            id="GSTType"
          >
            <vs-select-item :key="index" value="taxable" text="Taxable" class="w-full" />
            <vs-select-item :key="index" value="nongst" text="Non Gst" class="w-full" />
            <vs-select-item :key="index" value="othergoods" text="Other Goods" class="w-full" />
            <vs-select-item :key="index" value="services" text="Services" class="w-full" />
            <vs-select-item :key="index" value="exempted" text="Exempted" class="w-full" />
          </vs-select>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_size}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Size"
            id="Size"
            @input="upper('Size')"
            :disabled="buttondis_Size"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full"></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-button class="mr-3 mb-2" :disabled="buttondis" @click="showMiscPopup">Miscellaneous</vs-button>
        </div>
      </div>

      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_hsncode}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="HSNCode" :disabled="buttondis_HSNCode" />
        </div>
        <div class="vx-col sm:w-1/6 w-full"></div>
        <div class="vx-col sm:w-1/4 w-full">
          <vs-checkbox
            val="AddtoProductionCard"
            v-model="options"
            :disabled="buttondis"
          >Add to Production Card</vs-checkbox>
        </div>
      </div>
      <div class="vx-row mb-4">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px"></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-button class="mr-3 mb-2" :disabled="buttondis">F2-List</vs-button>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_productionsrno}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="ProductionSrNo"
            :disabled="buttondis_ProductionSrNo"
          />
        </div>
      </div>

      <div class="vx-row mb-4">
        <!-- <div class="vx-col sm:w-1/4 w-full" >
          <span>{{lt_previouspurchase}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="PreviousPurchase" :disabled="buttondis_PreviousPurchase" />
        </div>-->
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_unitno}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="UnitNo" :disabled="buttondis_UnitNo" />
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <span>{{lt_percentage}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Percentage"
            :disabled="buttondis_Percentage"
          />
        </div>
      </div>

      <div class="vx-row mb-4">
        <!-- <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>{{lt_previoussale}}</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="PreviousSale" :disabled="buttondis_PreviousSale" />
        </div>-->
      </div>
    </div>
    <br />
    <div align="left">
      <vs-button
        :color="getColor('addButton')"
        type="filled"
        title="Add"
        id="addButton"
        icon-pack="feather"
        icon="icon-file-plus"
        :disabled="disAdd"
        @keyup.right="buttonNext('addButton')"
        @keyup.left="buttonPrev('addButton')"
        @click="newdisable"
        autofocus="true"
      />
      <vs-button
        title="Edit"
        type="filled"
        icon-pack="feather"
        icon="icon-edit-1"
        :disabled="disEdit"
        :color="getColor('editButton')"
        id="editButton"
        class="button margin"
        @keyup.right="buttonNext('editButton')"
        @keyup.left="buttonPrev('editButton')"
        @keyup.enter="editButton()"
        @click="onEdit"
      />
      <vs-button
        title="Previous"
        type="filled"
        icon-pack="feather"
        icon="icon-chevrons-left"
        :disabled="disPrevious"
        :color="getColor('previousButton')"
        id="previousButton"
        class="button margin"
        @keyup.right="buttonNext('previousButton')"
        @keyup.left="buttonPrev('previousButton')"
        @click="getPrevData()"
      />
      <vs-button
        title="Next"
        icon-pack="feather"
        icon="icon-chevrons-right"
        :disabled="disNext"
        :color="getColor('nextButton')"
        id="nextButton"
        class="button margin"
        @keyup.right="buttonNext('nextButton')"
        @keyup.left="buttonPrev('nextButton')"
        @click="getNextData()"
      />
      <vs-button
        title="First"
        icon-pack="feather"
        icon="icon-arrow-left"
        :disabled="disFirst"
        id="firstButton"
        :color="getColor('firstButton')"
        class="button margin"
        @keyup.right="buttonNext('firstButton')"
        @keyup.left="buttonPrev('firstButton')"
        @click="getFirstData"
      />
      <vs-button
        title="Last"
        icon-pack="feather"
        icon="icon-arrow-right"
        :disabled="disLast"
        :color="getColor('lastButton')"
        id="lastButton"
        class="button margin"
        @keyup.right="buttonNext('lastButton')"
        @keyup.left="buttonPrev('lastButton')"
        @click="getLastData"
      />
      <vs-button
        title="Search"
        icon-pack="feather"
        icon="icon-search"
        :disabled="disSearch"
        :color="getColor('searchButton')"
        id="searchButton"
        class="button margin"
        @keyup.right="buttonNext('searchButton')"
        @keyup.left="buttonPrev('searchButton')"
        @click="search"
      />

      <vs-button
        title="Printer"
        icon-pack="feather"
        icon="icon-printer"
        :disabled="disPrinter"
        :color="getColor('printButton')"
        id="printButton"
        class="button margin"
        @keyup.right="buttonNext('printButton')"
        @keyup.left="buttonPrev('printButton')"
        @click="print"
      />
      <vs-button
        title="Delete"
        icon-pack="feather"
        icon="icon-trash"
        :disabled="disDelete"
        :color="getColor('deleteButton')"
        id="deleteButton"
        class="button margin"
        @keyup.right="buttonNext('deleteButton')"
        @keyup.left="buttonPrev('deleteButton')"
        @click="deleteData"
      />
      <vs-button
        title="Exit"
        icon-pack="feather"
        icon="icon-x"
        :disabled="disExit"
        :color="getColor('exitButton')"
        id="exitButton"
        class="button margin"
        @keyup.right="buttonNext('exitButton')"
        @keyup.left="buttonPrev('exitButton')"
        @click="onExit()"
      />
      <vs-button
        title="Details"
        icon-pack="feather"
        icon="icon-info"
        :disabled="disCopy"
        :color="getColor('moveButton')"
        id="moveButton"
        class="button margin"
        @keyup.right="buttonNext('moveButton')"
        @keyup.left="buttonPrev('moveButton')"
        @click="submit"
      />
      <vs-button
        style="float:right; display:inline-block;"
        title="Save"
        :color="getColor('saveButton')"
        :disabled="disSave"
        id="saveButton"
        class="button margin"
        @keyup.right="buttonNext('saveButton')"
        @keyup.left="buttonPrev('saveButton')"
        @click="save()"
      >Save</vs-button>
    </div>
  </div>
</div>
</template>

<script>
import axios from "axios";
import { FocusTrap } from "focus-trap-vue";
import Vue from "vue";
import modal from "@/components/Ledgerpopup.vue";
import modalnarration from "@/components/NarrationsModal.vue";
import modalStock from "@/components/stockPopup.vue";
import { TooltipPlugin } from "@syncfusion/ej2-vue-popups";
Vue.use(TooltipPlugin);
import "@syncfusion/ej2-base/styles/material.css";
import "@syncfusion/ej2-vue-popups/styles/material.css";
Vue.component("FocusTrap", FocusTrap);
export default {
  name: "Modal",
  data() {
    return {
      indexZoneModify : "",
      changed_zone_zone: "",
      new_zone_zone: "",
      new_zone_rate: "",
      zoneDetailsData: [],
      schemedetails_qty1: "",
      schemedetails_qty2: "",
      schemedetails_qty3: "",
      schemedetails_qty4: "",
      schemedetails_qty5: "",
      schemedetails_schemers1: "",
      schemedetails_schemers2: "",
      schemedetails_schemers3: "",
      schemedetails_schemers4: "",
      schemedetails_schemers5: "",
      schemedetails_er6type: "",
      schemedetails_prcode1: "",
      schemedetails_prcode2: "",
      schemedetails_prcode3: "",
      schemedetails_prcode4: "",
      schemedetails_prcode5: "",
      schemedetails_exp1: "",
      schemedetails_exp2: "",
      schemedetails_exp3: "",
      schemedetails_exp4: "",
      schemedetails_exp5: "",
      schemedetails_value1: "",
      schemedetails_value2: "",
      schemedetails_value3: "",
      schemedetails_value4: "",
      schemedetails_value5: "",
      schemedetails_registername: "",
      schemedetails_cstradingacno: "",
      schemedetails_acdescription: "",
      product_manufacturer: "",
      product_marketby1: "",
      product_marketby2: "",
      product_cirno: "",
      prodcut_cropno: "",
      zone_zone : "",
      zone_rate: "",
      //The cashvaucher and cashheader are used inside in a popup. DO NO DELETE marking redundant. DO NOT.

      cashVauchers: [
        {
          accountno: "",
          partno: [],
          orderno: "",
          amendmentno: "",
          datefrom: "",
          dateupto:"",
          rate:"",
           weight: "",
          billno: "",
          date:   "",  
          vehicle: "",
          stkitem:"",
          recno:  "",      
         from:  "",   
         upto:  "",   
         txtype:  ""       }
      ],
      cashheaders: [
        "Account Name",
        "Part No.",
        "Order No.",
        "Amendment No.",
        "Date_From",
        "Date_Upto",
        "Rate",
        "Delete"
      ],
      miscActive: false,
      rateDefineActive: false,
      zoneDetailActive: false,
      productDetailActive: false,
      purchaseaccode: "",
      saleaccode: "",
      popupActiveStock: false,
      modalOpenStock: false,
      latestCode: 0,
      counter: 0,
      buttondis_Percentage: true,
      buttondis_Accode: true,
      buttondis_Name: true,
      buttondis_OpStockinQty: true,
      buttondis_Box: true,
      buttondis_OpStockinRs: true,
      buttondis_Scheme: true,
      buttondis_GroupName: true,
      buttondis_ExpiryDt: true,
      buttondis_PurchaseRate: true,
      buttondis_RateCalculater: true,
      buttondis_Less: true,
      buttondis_ClsStockin: true,
      buttondis_MRP: true,
      buttondis_QtyinUOM: true,
      buttondis_Uom2: true,
      buttondis_Less2: true,
      buttondis_SaleRate: true,
      buttondis_StockCalculater: true,
      buttondis_TotalGST: true,
      buttondis_TypeofGoods: true,
      buttondis_CGST: true,
      buttondis_StkValuation: true,
      buttondis_CessQty: true,
      buttondis_QtyPerPcCase: true,
      buttondis_SGST: true,
      buttondis_TariffHeading: true,
      buttondis_Cess: true,
      buttondis_MinStockLevel: true,
      buttondis_PurchaseAc: true,
      buttondis_MaxStockLevel: true,
      buttondis_SaleAc: true,
      buttondis_GSTType: true,
      buttondis_Size: true,
      buttondis_HSNCode: true,
      buttondis_ProductionSrNo: true,
      buttondis_PreviousPurchase: true,
      buttondis_UnitNo: true,
      buttondis_PreviousSale: true,

      ch_accode: true,
      ch_acname: true,
      ch_opstockqty: true,
      ch_opstockrs: true,
      ch_box: true,
      ch_groupname: true,
      ch_purchaserate: true,
      ch_less1: true,
      ch_mrp: true,
      ch_less2: true,
      ch_salerate: true,
      ch_totalgst: true,
      ch_cgst: true,
      ch_cessqty: true,
      ch_sgst: true,
      ch_cess: true,
      ch_purchaseac: true,
      ch_saleac: true,
      ch_size: true,
      ch_hsncode: true,
      ch_previouspurchase: true,
      ch_previoussale: true,
      ch_scheme: true,
      ch_expirydt: true,
      ch_ratecalculator: true,
      ch_clsstockin: true,
      ch_qtyin: true,
      ch_uom: true,
      ch_stockcalculator: true,
      ch_typeofgoods: true,
      ch_stkvaluation: true,
      ch_qtyperpc: true,
      ch_tariffheading: true,
      ch_minstocklevel: true,
      ch_maxstocklevel: true,
      ch_gsttype: true,
      ch_productionsrno: true,
      ch_unitno: true,
      ch_percentage: true,

      lt_accode: "A/c Code",
      lt_acname: "Name",
      lt_opstockqty: "Op.Stock in Qty",
      lt_opstockrs: "Op.Stock in Rs",
      lt_box: "Box",
      lt_groupname: "Group Name",
      lt_purchaserate: "Purchase Rate",
      lt_less1: "Less%",
      lt_mrp: "M.R.P",
      lt_less2: "Less%",
      lt_salerate: "Sale Rate",
      lt_totalgst: "Total GST @",
      lt_cgst: "C.GST @",
      lt_cessqty: "Cess Qty",
      lt_sgst: "S.GST @",
      lt_cess: "Cess @",
      lt_purchaseac: "Purchase A/c",
      lt_saleac: "Sale A/c",
      lt_size: "Size",
      lt_hsncode: "HSN Code",
      lt_scheme: "Scheme @",
      lt_expirydt: "Expiry Dt",
      lt_ratecalculator: "Rate Calculator",
      lt_clsstockin: "Cls Stock in",
      lt_qtyin: "Qty.in",
      lt_uom: "UOM",
      lt_stockcalculator: "Stock Calculator",
      lt_typeofgoods: "Type of Goods",
      lt_stkvaluation: "Stk Valuation",
      lt_qtyperpc: "Qty Per Pc/Case",
      lt_tariffheading: "Tariff Heading",
      lt_minstocklevel: "Min.Stock Level",
      lt_maxstocklevel: "Max. Stock Level",
      lt_gsttype: "GST Type",
      lt_productionsrno: "Production Sr.No",
      lt_unitno: "Unit No.",
      lt_percentage: "Percentage",

      dv_accode: "",
      dv_acname: "",
      dv_opstockqty: "",
      dv_opstockrs: "",
      dv_box: "",
      dv_groupname: "",
      dv_purchaserate: "",
      dv_less1: "",
      dv_mrp: "",
      dv_less2: "",
      dv_salerate: "",
      dv_totalgst: "",
      dv_cgst: "",
      dv_cessqty: "",
      dv_sgst: "",
      dv_cess: "",
      dv_purchaseac: "",
      dv_saleac: "",
      dv_size: "",
      dv_hsncode: "",
      dv_previouspurchase: "",
      dv_previoussale: "",
      dv_scheme: "",
      dv_expirydt: "",
      dv_ratecalculator: "",
      dv_clsstockin: "",
      dv_qtyin: "",
      dv_uom: "",
      dv_stockcalculator: "",
      dv_typeofgoods: "",
      dv_stkvaluation: "",
      dv_qtyperpc: "",
      dv_tariffheading: "",
      dv_minstocklevel: "",
      dv_maxstocklevel: "",
      dv_gsttype: "",
      dv_productionsrno: "",
      dv_unitno: "",
      dv_percentage: "",

      setupForm: false,
      cpdDisable: false,
      popupActiveNarration: false,
      modalOpenNarration: false,
      currentfield: "",
      modalOpen: false,
      popupActive2: false,
      titleActions: "View",
      Accode: "",
      Name: "",
      OpStockinQty: "",
      Box: "",
      OpStockinRs: "",
      Scheme: "",
      GroupName: "",
      ExpiryDt: "",
      PurchaseRate: "",
      RateCalculater: "",
      Less: "",
      ClsStockin: "",
      MRP: "",
      QtyinUOM: "",
      Uom2: "",
      Less2: "",
      SaleRate: "",
      StockCalculater: "",
      TotalGST: "",
      TypeofGoods: "",
      CGST: "",
      StkValuation: "",
      CessQty: "",
      QtyPerPcCase: "",
      SGST: "",
      TariffHeading: "",
      Cess: "",
      MinStockLevel: "",
      PurchaseAc: "",
      MaxStockLevel: "",
      SaleAc: "",
      GSTType: "",
      Size: "",
      HSNCode: "",
      ProductionSrNo: "",
      PreviousPurchase: "",
      UnitNo: "",
      PreviousSale: "",
      Percentage: "",
      disAdd: true,
      disCopy: false,
      disDelete: false,
      disEdit: false,
      disFirst: false,
      disLast: false,
      disNext: false,
      disSave: true,
      disSearch: false,
      disPrinter: false,
      disPrevious: false,
      disExit: false,
      buttondis: true,
      accodeDis: true,
      isEditingOld: false,
      lastAcCode: "",
      dbIndex: -999,
      carryproductdescription: "",
      searchbar: "",
      filterbar: "",
      popupBodyData: [],
      popupFilteredData: [],
      acnameFocus: false,
      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],
      popupHeaders: [
        "A/c Name",
        "HSN Code",
        "Tax Rate",
        "Group Name",
        "Cd",
        "Sale Price",
        "M.R.P",
        "CLS. Stock",
        "Unit"
      ],
      qomlist: [
        {
          text: "BAG-BAGS",
          value: "bag"
        },
        {
          text: "BAL-BALE",
          value: "bal"
        },
        {
          text: "BDL-BUNDLES",
          value: "bdl"
        },
        {
          text: "BKL-BUCKLES",
          value: "bkl"
        },
        {
          text: "BOU-BILLION OF UNITS",
          value: "bou"
        },
        {
          text: "BOX-BOX",
          value: "box"
        },
        {
          text: "BTL-BOTTLES",
          value: "btl"
        },
        {
          text: "BUN-BUNCHES",
          value: "bun"
        },
        {
          text: "CAN-CANS",
          value: "can"
        },
        {
          text: "CBM-CUBIC METERS",
          value: "cbm"
        },
        {
          text: "CCM-CUBIC CENTIMMETERS",
          value: "ccm"
        },
        {
          text: "CMS-CENTIMETERS",
          value: "cms"
        },
        {
          text: "CTN-CARTONS",
          value: "ctn"
        },
        {
          text: "DOZ-DOZENS",
          value: "doz"
        },
        {
          text: "DRM-DRUMS",
          value: "drm"
        },
        {
          text: "GGK-GREAT GROSS",
          value: "ggk"
        },
        {
          text: "GMS-GRAMMES",
          value: "gms"
        },
        {
          text: "GRS-GROSS",
          value: "grs"
        },
        {
          text: "GYD-GROSS YARDS",
          value: "gyd"
        },
        {
          text: "KGS-KILOGRAMS",
          value: "kgs"
        },
        {
          text: "KLR-KILOLITRE",
          value: "klr"
        },
        {
          text: "KME-KILOMETRE",
          value: "kme"
        },
        {
          text: "MLT-MILLILITRE",
          value: "mlt"
        },
        {
          text: "MTR-METERS",
          value: "mtr"
        },
        {
          text: "NOS-NUMBERS",
          value: "nos"
        },
        {
          text: "PAC-PACKS",
          value: "pac"
        },
        {
          text: "PCS-PIECES",
          value: "pcs"
        },
        {
          text: "PRS-PAIRS",
          value: "prs"
        },
        {
          text: "QTL-QUINTAL",
          value: "qtl"
        },
        {
          text: "ROL-ROLLS",
          value: "rol"
        },
        {
          text: "SET-SETS",
          value: "sett"
        },
        {
          text: "SQF-SQUARE FEET",
          value: "sqf"
        },
        {
          text: "SQM-SQUARE METERS",
          value: "sqm"
        },
        {
          text: "SQY-SQUARE YARDS",
          value: "sqy"
        },
        {
          text: "TBS-TABLETS",
          value: "tbs"
        },
        {
          text: "TGM-TEN GROSS",
          value: "tgm"
        },
        {
          text: "THD-THOUSANDS",
          value: "thd"
        },
        {
          text: "TON-TONNES",
          value: "ton"
        },
        {
          text: "TUB-TUBES",
          value: "tub"
        },
        {
          text: "UGS-US-GALLONS",
          value: "ugs"
        },
        {
          text: "UNT-UNITS",
          value: "unt"
        },
        {
          text: "YDS-YARDS",
          value: "yds"
        }
      ],
      selected: [],
      searchPopup: false,
      popupActive3: false,
      popupActive5: false,
      popupActive6: false,
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false,
      currentItem: 0,
      items: [
        {
          id: 1,
          text: "some text"
        },
        {
          id: 2,
          text: "some other text"
        },
        {
          id: 3,
          text: "last text"
        }
      ]
    };
  },
  components: {
    modal,
    modalnarration,
    modalStock
  },

  methods: {
     zoneModify(k) {  
     this.indexZoneModify = k;
       this.changed_zone_zone = this.zoneDetailsData[k].zone 
      this.changed_zone_rate = this.zoneDetailsData[k].rate
      this.popupActive6 = true;
    },
     zoneModify2() {
     let ind = this.indexZoneModify;    
      this.zoneDetailsData[ind].zone =this.changed_zone_zone  
      this.zoneDetailsData[ind].rate = this.changed_zone_rate 
      this.popupActive6 = false;

    },
    addNewZone(){
      let modell = {'zone': "", 'rate': ""}
      modell.zone = this.new_zone_zone;
      modell.rate = this.new_zone_rate
      this.zoneDetailsData.push(modell)
      this.popupActive5 = false;
    },
    showMiscPopup(){
      this.miscActive = true;
    },
showAddZonePopup(){
  this.new_zone_zone = "",
  this.new_zone_rate = "",
  this.popupActive5 = true;
},

   addNewRow() {
      this.cashVauchers.push({
        accountno: "",
        narration: [],
        payment: "",
        receipt: "",
        discount: ""
      });

      this.rowlength++;
    },
    pop() {
      this.cashVauchers.pop({
        accountno: "",
        narration: [],
        payment: "",
        receipt: "",
        discount: ""
      });

      this.deleteNotify();
    },
    deleteRow(index, cashVaucher) {
      var idx = this.cashVauchers.indexOf(cashVaucher);
      console.log(idx, index);
      if (idx > -1) {
        this.cashVauchers.splice(idx, 1);
      }
      this.rowlength--;
      this.deleteNotify();
    },
    showRateDefinePopup() {
      this.rateDefineActive = true;
    },
    showZoneDetailPopup() {
      this.zoneDetailActive = true;
    },
    showProductDetailPopup() {
      this.productDetailActive = true;
    },
    salepurchaseinput(value) {
      if (value == "sale") {
        if (this.SaleAc.length == 1) this.openLedger();
      } else {
        if (this.PurchaseAc.length == 1) this.openLedger();
      }
    },
    search() {
      this.shortfunctionsecond("popupActiveStock", "true", "comp");
    },

    gstdiv() {
      var a = this.TotalGST;
      var b = a / 2;
      this.SGST = b;
      this.CGST = b;
    },

    initializedefault() {
      this.Accode = this.dv_accode;
      if (this.lastAcCode != 0) {
        this.Accode = parseInt(this.lastAcCode + "") + 1;
      } else {
        this.AcCode = "100000";
      }
      this.Name = this.dv_acname;

      this.OpStockinQty = this.dv_opstockqty;
      this.Box = this.dv_box;
      this.OpStockinRs = this.dv_opstockrs;
      this.Scheme = this.dv_scheme;
      this.GroupName = this.dv_groupname;
      this.ExpiryDt = this.dv_expirydt;
      this.PurchaseRate = this.dv_purchaserate;
      this.RateCalculater = this.dv_ratecalculator;
      this.Less = this.dv_less1;
      this.ClsStockin = this.dv_clsstockin;
      this.MRP = this.dv_mrp;
      this.QtyinUOM = this.dv_qtyin;
      this.Uom2 = this.dv_uom;
      this.Less2 = this.dv_less2;
      this.SaleRate = this.dv_salerate;
      this.StockCalculater = this.dv_stockcalculator;
      this.TotalGST = this.dv_totalgst;
      this.TypeofGoods = this.dv_typeofgoods;
      this.CGST = this.dv_cgst;
      this.StkValuation = this.dv_stkvaluation;
      this.CessQty = this.dv_cessqty;
      this.QtyPerPcCase = this.dv_qtyperpc;
      this.SGST = this.dv_sgst;
      this.TariffHeading = this.dv_tariffheading;
      this.Cess = this.dv_cess;
      this.MinStockLevel = this.dv_minstocklevel;
      this.PurchaseAc = this.dv_purchaseac;
      this.MaxStockLevel = this.dv_maxstocklevel;
      this.SaleAc = this.dv_saleac;
      this.GSTType = this.dv_gsttype;
      this.Size = this.dv_size;
      this.HSNCode = this.dv_hsncode;
      this.ProductionSrNo = this.dv_productionsrno;
      this.PreviousPurchase = this.dv_previouspurchase;
      this.UnitNo = this.dv_unitno;
      this.PreviousSale = this.dv_previoussale;
      this.Percentage = this.dv_percentage;
       this.schemedetails_qty2 = "";
       this.schemedetails_qty3 = "";
       this.schemedetails_qty4 = "";
       this.schemedetails_qty5 = "";
       this.schemedetails_schemers1 = "";
       this.schemedetails_schemers2 = "";
       this.schemedetails_schemers3 = "";
       this.schemedetails_schemers4 = "";
       this.schemedetails_schemers5 = "";
       this.schemedetails_er6type = "";
       this.schemedetails_prcode1 = "";
       this.schemedetails_prcode2 = "";
       this.schemedetails_prcode3 = "";
       this.schemedetails_prcode4 = "";
       this.schemedetails_prcode5 = "";
       this.schemedetails_exp1 = "";
       this.schemedetails_exp2 = "" ;
       this.schemedetails_exp3 = "";
       this.schemedetails_exp4 = "";
       this.schemedetails_exp5 = "";
       this.schemedetails_value1 = "";
       this.schemedetails_value2 = "";
       this.schemedetails_value3 = "";
       this.schemedetails_value4 = "";
       this.schemedetails_value5 = "";
       this.schemedetails_registername = "";
       this.schemedetails_cstradingacno = "";
       this.schemedetails_acdescription = "";
      this.product_manufacturer = "";
      this.product_marketby1 ="";
      this.product_marketby2 = "";
      this.product_cirno = "";
      this.prodcut_cropno = "";
      this.cashVauchers = "";
    },
    getstocksetup() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var exp = {
        companyname: companyName,
        directory: "stocksetup.json"
      };

      axios
        .post("/getstocksetup", exp)
        .then(response => {
          var data = JSON.stringify(response.data);
          var json = JSON.parse(data);

          this.ch_accode = json.ch_accode;
          this.ch_acname = json.ch_acname;
          this.ch_opstockqty = json.ch_opstockqty;
          this.ch_opstockrs = json.ch_opstockrs;
          this.ch_box = json.ch_box;
          this.ch_groupname = json.ch_groupname;
          this.ch_purchaserate = json.ch_purchaserate;
          this.ch_less1 = json.ch_less1;
          this.ch_mrp = json.ch_mrp;
          this.ch_less2 = json.ch_less2;
          this.ch_salerate = json.ch_salerate;
          this.ch_totalgst = json.ch_totalgst;
          this.ch_cgst = json.ch_cgst;
          this.ch_cessqty = json.ch_cessqty;
          this.ch_sgst = json.ch_sgst;
          this.ch_cess = json.ch_cess;
          this.ch_purchaseac = json.ch_purchaseac;
          this.ch_saleac = json.ch_saleac;
          this.ch_size = json.ch_size;
          this.ch_hsncode = json.ch_hsncode;
          this.ch_previouspurchase = json.ch_previouspurchase;
          this.ch_previoussale = json.ch_previoussale;
          this.ch_scheme = json.ch_scheme;
          this.ch_expirydt = json.ch_expirydt;
          this.ch_ratecalculator = json.ch_ratecalculator;
          this.ch_clsstockin = json.ch_clsstockin;
          this.ch_qtyin = json.ch_qtyin;
          this.ch_uom = json.ch_uom;
          this.ch_stockcalculator = json.ch_stockcalculator;
          this.ch_typeofgoods = json.ch_typeofgoods;
          this.ch_stkvaluation = json.ch_stkvaluation;
          this.ch_qtyperpc = json.ch_qtyperpc;
          this.ch_tariffheading = json.ch_tariffheading;
          this.ch_minstocklevel = json.ch_minstocklevel;
          this.ch_maxstocklevel = json.ch_maxstocklevel;
          this.ch_gsttype = json.ch_gsttype;
          this.ch_productionsrno = json.ch_productionsrno;
          this.ch_unitno = json.ch_unitno;
          this.ch_percentage = json.ch_percentage;

          this.lt_accode = json.lt_accode;
          this.lt_acname = json.lt_acname;
          this.lt_opstockqty = json.lt_opstockqty;
          this.lt_opstockrs = json.lt_opstockrs;
          this.lt_box = json.lt_box;
          this.lt_groupname = json.lt_groupname;
          this.lt_purchaserate = json.lt_purchaserate;
          this.lt_less1 = json.lt_less1;
          this.lt_mrp = json.lt_mrp;
          this.lt_less2 = json.lt_less2;
          this.lt_salerate = json.lt_salerate;
          this.lt_totalgst = json.lt_totalgst;
          this.lt_cgst = json.lt_cgst;
          this.lt_cessqty = json.lt_cessqty;
          this.lt_sgst = json.lt_sgst;
          this.lt_cess = json.lt_cess;
          this.lt_purchaseac = json.lt_purchaseac;
          this.lt_saleac = json.lt_saleac;
          this.lt_size = json.lt_size;
          this.lt_hsncode = json.lt_hsncode;
          this.lt_previouspurchase = json.lt_previouspurchase;
          this.lt_previoussale = json.lt_previoussale;
          this.lt_scheme = json.lt_scheme;
          this.lt_expirydt = json.lt_expirydt;
          this.lt_ratecalculator = json.lt_ratecalculator;
          this.lt_clsstockin = json.lt_clsstockin;
          this.lt_qtyin = json.lt_qtyin;
          this.lt_uom = json.lt_uom;
          this.lt_stockcalculator = json.lt_stockcalculator;
          this.lt_typeofgoods = json.lt_typeofgoods;
          this.lt_stkvaluation = json.lt_stkvaluation;
          this.lt_qtyperpc = json.lt_qtyperpc;
          this.lt_tariffheading = json.lt_tariffheading;
          this.lt_minstocklevel = json.lt_minstocklevel;
          this.lt_maxstocklevel = json.lt_maxstocklevel;
          this.lt_gsttype = json.lt_gsttype;
          this.lt_productionsrno = json.lt_productionsrno;
          this.lt_unitno = json.lt_unitno;
          this.lt_percentage = json.lt_percentage;

          this.dv_accode = json.dv_accode;
          this.dv_acname = json.dv_acname;
          this.dv_opstockqty = json.dv_opstockqty;
          this.dv_opstockrs = json.dv_opstockrs;
          this.dv_box = json.dv_box;
          this.dv_groupname = json.dv_groupname;
          this.dv_purchaserate = json.dv_purchaserate;
          this.dv_less1 = json.dv_less1;
          this.dv_mrp = json.dv_mrp;
          this.dv_less2 = json.dv_less2;
          this.dv_salerate = json.dv_salerate;
          this.dv_totalgst = json.dv_totalgst;
          this.dv_cgst = json.dv_cgst;
          this.dv_cessqty = json.dv_cessqty;
          this.dv_sgst = json.dv_sgst;
          this.dv_cess = json.dv_cess;
          this.dv_purchaseac = json.dv_purchaseac;
          this.dv_saleac = json.dv_saleac;
          this.dv_size = json.dv_size;
          this.dv_hsncode = json.dv_hsncode;
          this.dv_previouspurchase = json.dv_previouspurchase;
          this.dv_previoussale = json.dv_previoussale;
          this.dv_scheme = json.dv_scheme;
          this.dv_expirydt = json.dv_expirydt;
          this.dv_ratecalculator = json.dv_ratecalculator;
          this.dv_clsstockin = json.dv_clsstockin;
          this.dv_qtyin = json.dv_qtyin;
          this.dv_uom = json.dv_uom;
          this.dv_stockcalculator = json.dv_stockcalculator;
          this.dv_typeofgoods = json.dv_typeofgoods;
          this.dv_stkvaluation = json.dv_stkvaluation;
          this.dv_qtyperpc = json.dv_qtyperpc;
          this.dv_tariffheading = json.dv_tariffheading;
          this.dv_minstocklevel = json.dv_minstocklevel;
          this.dv_maxstocklevel = json.dv_maxstocklevel;
          this.dv_gsttype = json.dv_gsttype;
          this.dv_productionsrno = json.dv_productionsrno;
          this.dv_unitno = json.dv_unitno;
          this.dv_percentage = json.dv_percentage;
        })
        .catch(error => {
          alert(error);
        });
    },

    SaveStockSetup() {
      var exportData = {
        ch_accode: this.ch_accode,
        ch_acname: this.ch_acname,
        ch_opstockqty: this.ch_opstockqty,
        ch_opstockrs: this.ch_opstockrs,
        ch_box: this.ch_box,
        ch_groupname: this.ch_groupname,
        ch_purchaserate: this.ch_purchaserate,
        ch_less1: this.ch_less1,
        ch_mrp: this.ch_mrp,
        ch_less2: this.ch_less2,
        ch_salerate: this.ch_salerate,
        ch_totalgst: this.ch_totalgst,
        ch_cgst: this.ch_cgst,
        ch_cessqty: this.ch_cessqty,
        ch_sgst: this.ch_sgst,
        ch_cess: this.ch_cess,
        ch_purchaseac: this.ch_purchaseac,
        ch_saleac: this.ch_saleac,
        ch_size: this.ch_size,
        ch_hsncode: this.ch_hsncode,
        ch_previouspurchase: this.ch_previouspurchase,
        ch_previoussale: this.ch_previoussale,
        ch_scheme: this.ch_scheme,
        ch_expirydt: this.ch_expirydt,
        ch_ratecalculator: this.ch_ratecalculator,
        ch_clsstockin: this.ch_clsstockin,
        ch_qtyin: this.ch_qtyin,
        ch_uom: this.ch_uom,
        ch_stockcalculator: this.ch_stockcalculator,
        ch_typeofgoods: this.ch_typeofgoods,
        ch_stkvaluation: this.ch_stkvaluation,
        ch_qtyperpc: this.ch_qtyperpc,
        ch_tariffheading: this.ch_tariffheading,
        ch_minstocklevel: this.ch_minstocklevel,
        ch_maxstocklevel: this.ch_maxstocklevel,
        ch_gsttype: this.ch_gsttype,
        ch_productionsrno: this.ch_productionsrno,
        ch_unitno: this.ch_unitno,
        ch_percentage: this.ch_percentage,

        lt_accode: this.lt_accode,
        lt_acname: this.lt_acname,
        lt_opstockqty: this.lt_opstockqty,
        lt_opstockrs: this.lt_opstockrs,
        lt_box: this.lt_box,
        lt_groupname: this.lt_groupname,
        lt_purchaserate: this.lt_purchaserate,
        lt_less1: this.lt_less1,
        lt_mrp: this.lt_mrp,
        lt_less2: this.lt_less2,
        lt_salerate: this.lt_salerate,
        lt_totalgst: this.lt_totalgst,
        lt_cgst: this.lt_cgst,
        lt_cessqty: this.lt_cessqty,
        lt_sgst: this.lt_sgst,
        lt_cess: this.lt_cess,
        lt_purchaseac: this.lt_purchaseac,
        lt_saleac: this.lt_saleac,
        lt_size: this.lt_size,
        lt_hsncode: this.lt_hsncode,
        lt_previouspurchase: this.lt_previouspurchase,
        lt_previoussale: this.lt_previoussale,
        lt_scheme: this.lt_scheme,
        lt_expirydt: this.lt_expirydt,
        lt_ratecalculator: this.lt_ratecalculator,
        lt_clsstockin: this.lt_clsstockin,
        lt_qtyin: this.lt_qtyin,
        lt_uom: this.lt_uom,
        lt_stockcalculator: this.lt_stockcalculator,
        lt_typeofgoods: this.lt_typeofgoods,
        lt_stkvaluation: this.lt_stkvaluation,
        lt_qtyperpc: this.lt_qtyperpc,
        lt_tariffheading: this.lt_tariffheading,
        lt_minstocklevel: this.lt_minstocklevel,
        lt_maxstocklevel: this.lt_maxstocklevel,
        lt_gsttype: this.lt_gsttype,
        lt_productionsrno: this.lt_productionsrno,
        lt_unitno: this.lt_unitno,
        lt_percentage: this.lt_percentage,

        dv_accode: this.dv_accode,
        dv_acname: this.dv_acname,
        dv_opstockqty: this.dv_opstockqty,
        dv_opstockrs: this.dv_opstockrs,
        dv_box: this.dv_box,
        dv_groupname: this.dv_groupname,
        dv_purchaserate: this.dv_purchaserate,
        dv_less1: this.dv_less1,
        dv_mrp: this.dv_mrp,
        dv_less2: this.dv_less2,
        dv_salerate: this.dv_salerate,
        dv_totalgst: this.dv_totalgst,
        dv_cgst: this.dv_cgst,
        dv_cessqty: this.dv_cessqty,
        dv_sgst: this.dv_sgst,
        dv_cess: this.dv_cess,
        dv_purchaseac: this.dv_purchaseac,
        dv_saleac: this.dv_saleac,
        dv_size: this.dv_size,
        dv_hsncode: this.dv_hsncode,
        dv_previouspurchase: this.dv_previouspurchase,
        dv_previoussale: this.dv_previoussale,
        dv_scheme: this.dv_scheme,
        dv_expirydt: this.dv_expirydt,
        dv_ratecalculator: this.dv_ratecalculator,
        dv_clsstockin: this.dv_clsstockin,
        dv_qtyin: this.dv_qtyin,
        dv_uom: this.dv_uom,
        dv_stockcalculator: this.dv_stockcalculator,
        dv_typeofgoods: this.dv_typeofgoods,
        dv_stkvaluation: this.dv_stkvaluation,
        dv_qtyperpc: this.dv_qtyperpc,
        dv_tariffheading: this.dv_tariffheading,
        dv_minstocklevel: this.dv_minstocklevel,
        dv_maxstocklevel: this.dv_maxstocklevel,
        dv_gsttype: this.dv_gsttype,
        dv_productionsrno: this.dv_productionsrno,
        dv_unitno: this.dv_unitno,
        dv_percentage: this.dv_percentage
      };

      //  alert(JSON.stringify(exportData));
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var vall = {
        companyname: companyName,
        exportdata: exportData
      };

      axios
        .post("/savestocksetup", vall)
        .then(response => {
          var data = JSON.stringify(response.data);
          console.log(data);
          window.location.reload();
          //alert("go this response on save " + data);
        })
        .catch(error => {
          alert(error);
        });
    },

    buttondis_true() {
      if (this.ch_accode == true) this.buttondis_Accode = true;

      if (this.ch_percentage == true) this.buttondis_Percentage = true;

      if (this.ch_acname == true) this.buttondis_Name = true;

      if (this.ch_opstockqty == true) this.buttondis_OpStockinQty = true;

      if (this.ch_box == true) this.buttondis_Box = true;

      if (this.ch_opstockrs == true) this.buttondis_OpStockinRs = true;

      if (this.ch_scheme == true) this.buttondis_Scheme = true;

      if (this.ch_groupname == true) this.buttondis_GroupName = true;

      if (this.ch_expirydt == true) this.buttondis_ExpiryDt = true;

      if (this.ch_purchaserate == true) this.buttondis_PurchaseRate = true;

      if (this.ch_ratecalculator == true) this.buttondis_RateCalculater = true;

      if (this.ch_less1 == true) this.buttondis_Less = true;

      if (this.ch_clsstockin == true) this.buttondis_ClsStockin = true;

      if (this.ch_mrp == true) this.buttondis_MRP = true;

      if (this.ch_qtyin == true) this.buttondis_QtyinUOM = true;

      if (this.ch_uom == true) this.buttondis_Uom2 = true;

      if (this.ch_less2 == true) this.buttondis_Less2 = true;

      if (this.ch_salerate == true) this.buttondis_SaleRate = true;

      if (this.ch_stockcalculator == true)
        this.buttondis_StockCalculater = true;

      if (this.ch_totalgst == true) this.buttondis_TotalGST = true;

      if (this.ch_typeofgoods == true) this.buttondis_TypeofGoods = true;

      if (this.ch_cgst == true) this.buttondis_CGST = true;

      if (this.ch_stkvaluation == true) this.buttondis_StkValuation = true;

      if (this.ch_cessqty == true) this.buttondis_CessQty = true;

      if (this.ch_qtyperpc == true) this.buttondis_QtyPerPcCase = true;

      if (this.ch_sgst == true) this.buttondis_SGST = true;

      if (this.ch_tariffheading == true) this.buttondis_TariffHeading = true;

      if (this.ch_cess == true) this.buttondis_Cess = true;

      if (this.ch_minstocklevel == true) this.buttondis_MinStockLevel = true;

      if (this.ch_purchaseac == true) this.buttondis_PurchaseAc = true;

      if (this.ch_maxstocklevel == true) this.buttondis_MaxStockLevel = true;

      if (this.ch_saleac == true) this.buttondis_SaleAc = true;

      if (this.ch_gsttype == true) this.buttondis_GSTType = true;

      if (this.ch_size == true) this.buttondis_Size = true;

      if (this.ch_hsncode == true) this.buttondis_HSNCode = true;

      if (this.ch_productionsrno == true) this.buttondis_ProductionSrNo = true;

      if (this.ch_previouspurchase == true)
        this.buttondis_PreviousPurchase = true;

      if (this.ch_unitno == true) this.buttondis_UnitNo = true;

      if (this.ch_previoussale == true) this.buttondis_PreviousSale = true;
    },

    buttondis_false() {
      if (this.ch_accode == true) this.buttondis_Accode = false;

      if (this.ch_percentage == true) this.buttondis_Percentage = false;

      if (this.ch_acname == true) this.buttondis_Name = false;

      if (this.ch_opstockqty == true) this.buttondis_OpStockinQty = false;

      if (this.ch_box == true) this.buttondis_Box = false;

      if (this.ch_opstockrs == true) this.buttondis_OpStockinRs = false;

      if (this.ch_scheme == true) this.buttondis_Scheme = false;

      if (this.ch_groupname == true) this.buttondis_GroupName = false;

      if (this.ch_expirydt == true) this.buttondis_ExpiryDt = false;

      if (this.ch_purchaserate == true) this.buttondis_PurchaseRate = false;

      if (this.ch_ratecalculator == true) this.buttondis_RateCalculater = false;

      if (this.ch_less1 == true) this.buttondis_Less = false;

      if (this.ch_clsstockin == true) this.buttondis_ClsStockin = false;

      if (this.ch_mrp == true) this.buttondis_MRP = false;

      if (this.ch_qtyin == true) this.buttondis_QtyinUOM = false;

      if (this.ch_uom == true) this.buttondis_Uom2 = false;

      if (this.ch_less2 == true) this.buttondis_Less2 = false;

      if (this.ch_salerate == true) this.buttondis_SaleRate = false;

      if (this.ch_stockcalculator == true)
        this.buttondis_StockCalculater = false;

      if (this.ch_totalgst == true) this.buttondis_TotalGST = false;

      if (this.ch_typeofgoods == true) this.buttondis_TypeofGoods = false;

      if (this.ch_cgst == true) this.buttondis_CGST = false;

      if (this.ch_stkvaluation == true) this.buttondis_StkValuation = false;

      if (this.ch_cessqty == true) this.buttondis_CessQty = false;

      if (this.ch_qtyperpc == true) this.buttondis_QtyPerPcCase = false;

      if (this.ch_sgst == true) this.buttondis_SGST = false;

      if (this.ch_tariffheading == true) this.buttondis_TariffHeading = false;

      if (this.ch_cess == true) this.buttondis_Cess = false;

      if (this.ch_minstocklevel == true) this.buttondis_MinStockLevel = false;

      if (this.ch_purchaseac == true) this.buttondis_PurchaseAc = false;

      if (this.ch_maxstocklevel == true) this.buttondis_MaxStockLevel = false;

      if (this.ch_saleac == true) this.buttondis_SaleAc = false;

      if (this.ch_gsttype == true) this.buttondis_GSTType = false;

      if (this.ch_size == true) this.buttondis_Size = false;

      if (this.ch_hsncode == true) this.buttondis_HSNCode = false;

      if (this.ch_productionsrno == true) this.buttondis_ProductionSrNo = false;

      if (this.ch_previouspurchase == true)
        this.buttondis_PreviousPurchase = false;

      if (this.ch_unitno == true) this.buttondis_UnitNo = false;

      if (this.ch_previoussale == true) this.buttondis_PreviousSale = false;
    },

    showSetupForm() {
      this.setupForm = true;
    },
    showdescNar(k) {
      this.shortfunctionsecond("popupActiveNarration", k, k);
    },
    longfunctionfirst(t) {
      return new Promise(resolve => {
        if (t == "popupActiveNarration") {
          this.modalOpenNarration = true;
          this.popupActiveNarration = true;
          resolve("resolved");
        } else if (t == "popupActiveStock") {
          this.popupActiveStock = true;
          resolve("resolved");
        } else if (t == "popupActive2") {
          this.popupActive2 = true;

          resolve("resolved");
        } else if (t == "popupActive3") {
          this.popupActive3 = true;

          resolve("resolved");
        } else if (t == "areais") {
          setTimeout(() => resolve("done!"), 500);
        } else if (t == "popupActive2") {
          this.popupActive2 = true;

          resolve("resolved");
        } else if (t == "dateprevnext") {
          setTimeout(() => resolve("done!"), 500);
        } else if (t == "modifyLedger") {
          this.popupActiveModifyLedger = true;
          resolve("resolved");
        } else if (t == "drcrpopup") {
          this.drcrpopup = true;

          resolve("resolved");
        }
      });
    },

    onChildClickNarration(valu) {
      if (this.modalOpenNarration == true) {
        if (valu == "closenarration") {
          this.modalOpenNarration = false;
          this.popupActiveNarration = false;
        } else {
          const words = valu.split(":");

          if (this.currentfield == "comboarea") {
            this.comboarea = words[0] + "";

            this.shortfunctionsecond("areais");
          } else if (this.currentfield == "comboemail") {
            this.comboemail = words[0] + "";
            this.shortfunctionsecond("emaildata");
          } else if (this.currentfield == "City") {
            this.City = words[0] + "";
            this.shortfunctionsecond("citydata");
          } else if (this.currentfield == "AcName") {
            this.AcName = words[0] + "";
            this.shortfunctionsecond("acnamedata");
          } else if (this.currentfield == "Distt") {
            this.Distt = words[0] + "";
            this.shortfunctionsecond("disttdata");
          } else if (this.currentfield == "Works") {
            this.Works = words[0] + "";

            this.shortfunctionsecond("worksdata");
          } else if (this.currentfield == "Group") {
            this.GroupName = words[0] + "";
            document.getElementById("ExpiryDt").focus();
          }
          this.popupActiveNarration = false;
          this.modalOpenNarration = false;
        }
      }
      // this.shortfunctionsecond(valu)
    },
    async shortfunctionsecond(g, k, l) {
      if (g == "popupActiveNarration") {
        await this.longfunctionfirst(g);
        this.$refs.childComponent.setValue(k, "stockform" + l);
      } else if (g == "popupActiveStock") {
        await this.longfunctionfirst(g);
        if (this.currentfield == "SaleAc")
          this.$refs.childComponentLedger.setValue(
            k,
            "newstockform" + l,
            this.SaleAc
          );
        else {
          this.$refs.childComponentLedger.setValue(
            k,
            "newstockform" + l,
            this.PurchaseAc
          );
        }
      } else if (g == "popupActive2") {
        await this.longfunctionfirst(g);

        if (this.currentfield == "SaleAc") {
          this.$refs.childComponentLedger.setValue(
            "true",
            "ledgerform" + l,
            this.SaleAc
          );
        } else if (this.currentfield == "PurchaseAc")
          this.$refs.childComponentLedger.setValue(
            "true",
            "ledgerform" + l,
            this.PurchaseAc
          );
      } else if (g == "areais") {
        await this.longfunctionfirst("areais");

        document.getElementById("Quantitiy").focus();
        //this.$refs["areais"].focus()
      } else if (g == "emaildata") {
        const result = await this.longfunctionfirst("areais");

        document.getElementById("TGSTShare").focus();

        console.log(result);
      } else if (g == "citydata") {
        await this.longfunctionfirst("areais");

        document.getElementById("Division").focus();
      } else if (g == "acnamedata") {
        await this.longfunctionfirst("areais");

        document.getElementById("BankACName").focus();
      } else if (g == "disttdata") {
        await this.longfunctionfirst("areais");

        document.getElementById("DGSTNo").focus();
      } else if (g == "editbutton") {
        //alert("here")
        await this.longfunctionfirst(g);
        var p = this.rowlength - 1;
        document.getElementById("0" + p).focus();
      } else if (g == "groupdata") {
        //alert("here")
        await this.longfunctionfirst("areais");
        document.getElementById("PAN").focus();
      } else if (g == "dateprevnext") {
        //alert("here")
        await this.longfunctionfirst("dateprevnext");
        document.getElementById("editButton").focus();
      } else if (g == "worksdata") {
        //alert("here")
        await this.longfunctionfirst("areais");

        document.getElementById("NameAddress1").focus();
      } else if (g == "drcrpopup") {
        await this.longfunctionfirst(g);

        document.getElementById("drcrfilter").focus();
      } else if (g == "popupActive2") {
        await this.longfunctionfirst(g);
        this.$refs.childComponentLedger.setValue(k, "ledgerform" + l, "");
      }
    },
    openLedger() {
      if (this.currentfield == "SaleAc")
        this.shortfunctionsecond("popupActive2", "true", "SaleAc");
      else if (this.currentfield == "PurchaseAc")
        this.shortfunctionsecond("popupActive2", "true", "PurchaseAc");
    },
    onFocus(valu) {
      this.currentfield = valu;
    },
    onChildClick(value) {
      //alert("called")
      if (value == "closeledger") {
        this.popupActive2 = false;
        this.modalOpen = false;
      } else if (value == "closestock") {
        //alert("here")
        this.popupActiveStock = false;
        this.modalOpenStock = false;
      } else {
        const words = value.split(":");

        if (this.currentfield == "SaleAc") {
          this.SaleAc = words[0];
          this.saleaccode = words[1];
          document.getElementById("Size").focus();
        } else if (this.currentfield == "PurchaseAc") {
          this.PurchaseAc = words[0];
          this.purchaseaccode = words[1];
          document.getElementById("SaleAc").focus();
        } else if (this.popupActiveStock == true) {
          this.getSearchData(parseInt(words[3] + ""));
          this.popupActiveStock = false;
          this.modalOpenStock = false;
        }

        if (this.popupActive2 == true) {
          this.popupActive2 = false;
          this.modalOpen = false;
        }
      }
    },
    onlyNumber($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
        // 46 is dot
        return $event.preventDefault();
      } else return null;
    },
    modifyFromPopup() {
      // alert(this.selected)
      this.titleActions = "Edit";
      this.getSelectedData(this.selected[0].Name);
      this.onEdit();
      this.selected = [];
      this.searchPopup = false;
      this.$refs.focusTrap.activate();
      this.acnameFocus = true;
    },
    caseSense(k) {
      var str;
      if (k == "Name") {
        str = this.Name;
      } else if (k == "PurchaseAc") {
        str = this.PurchaseAc;
      } else if (k == "SaleAc") {
        str = this.SaleAc;
      } else {
        console.log("");
      }

      if (str.length > 1) {
        if (
          str[str.length - 2] == "." ||
          str[str.length - 2] == " " ||
          str[str.length - 2] == "!" ||
          str[str.length - 2] == "@" ||
          str[str.length - 2] == "~" ||
          str[str.length - 2] == "#" ||
          str[str.length - 2] == "$" ||
          str[str.length - 2] == "^" ||
          str[str.length - 2] == "&" ||
          str[str.length - 2] == "%" ||
          str[str.length - 2] == "*" ||
          str[str.length - 2] == "(" ||
          str[str.length - 2] == ")" ||
          str[str.length - 2] == "_" ||
          str[str.length - 2] == "-" ||
          str[str.length - 2] == "="
        ) {
          var a = str.charAt(str.length - 1).toUpperCase();
          var rd = str.slice(0, str.length - 1);
          var b = rd + a;
          if (k == "Name") {
            this.Name = b;
          } else if (k == "PurchaseAc") {
            this.PurchaseAc = b;
          } else if (k == "SaleAc") {
            this.SaleAc = b;
          } else {
            console.log("");
          }
        }
      } else {
        if (k == "Name") {
          this.Name = str.toUpperCase();
        } else if (k == "PurchaseAc") {
          this.PurchaseAc = str.toUpperCase();
        } else if (k == "SaleAc") {
          this.SaleAc = str.toUpperCase();
        }
      }
    },
    upper(k) {
      var a;
      if (k == "GroupName") {
        a = this.GroupName;
      } else if (k == "Size") {
        a = this.Size;
      } else if (k == "TariffHeading") {
        a = this.TariffHeading;
      } else {
        console.log(" ");
      }
      var b = a.toUpperCase();
      console.log(b);
      if (k == "GroupName") {
        this.GroupName = b;
      } else if (k == "Size") {
        this.Size = b;
      } else if (k == "TariffHeading") {
        this.TariffHeading = b;
      } else {
        console.log(" ");
      }
    },

    async deleteFromPopup() {
      //alert('sending ' + this.selected[0].Name + ' to search')
      await this.getSelectedData(this.selected[0].Name);
      //alert('found it, now sending it to delete')
      await this.deleteData();
      this.searchPopup = false;
      await this.getData();
      this.$forceUpdate();
      this.searchPopup = true;
    },
    addFromPopup() {
      this.searchPopup = false;
      this.newdisable();
    },
    handleSelected() {
      this.getSelectedData(this.selected.Name);
      this.searchPopup = false;
    },
    searchedList() {
      let inp = this.searchbar;
      inp = inp.toLowerCase();
      //alert(inp);
      if (inp.length < 1) {
        this.popupFilteredData = this.popupBodyData;
      } else {
        this.popupFilteredData = [];
        for (let i = 0; i < this.popupBodyData.length; i++) {
          let str = this.popupBodyData[i].Name;
          str = str.toLowerCase();
          if (str.indexOf(inp) == 0) {
            this.popupFilteredData.push(this.popupBodyData[i]);
          }
        }
      }
    },
    showSearchPopup() {
      this.getData();
      this.popupFilteredData = this.popupBodyData;
      this.searchPopup = true;
    },
    nameInputTrig() {
      if (this.Name.length > 1) {
        this.disSave = false;
      }
    },
    onExit() {
      this.titleActions = "View";
      this.buttondis = true;
      this.buttondis_true();
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.dbIndex = -999;
      this.isEditingOld = false;
      this.accodeDis = true;
      this.getNextData();
      this.cpdDisable = false;
    },

    onEdit() {
      this.titleActions = "Edit";
      this.disAdd = true;
      this.buttondis = false;
      this.buttondis_false();
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = false;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.isEditingOld = true;
    },
    newdisable() {
      this.titleActions = "New";
      this.disAdd = true;
      this.buttondis = false;
      this.buttondis_false();
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = true;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.accodeDis = false;
      this.cpdDisable = true;
      if (this.carryproductdescription == true) {
        alert("carried prod desc");
        this.Accode = parseInt(this.lastAcCode + "") + 1;
      } else {
        this.Accode = parseInt(this.lastAcCode) + 1;
        alert("changed accode is: " + this.Accode);

        this.initializedefault();
      }
    },
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },

    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    deleteData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        idToDelete: this.dbIndex,
        companyname: companyName
      };
      axios
        .post("http://localhost:2000/DeleteStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          let s = resp.slice(0, -1);
          s = s.substring(1);
          //alert(s);
          this.RedAlert(s);
          this.dbIndex = -999;
          this.getLastData();
        })
        .catch(error => {
          alert(error);
        });
    },
    getFirstData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "first",
        reqIndex: this.dbIndex,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          let s = resp.slice(0, -1);
          s = s.substring(1);
          if (s == "outofbounds") {
            alert("out Of bounds");
          } else {
            resp = JSON.parse(resp);
            //  alert("API returned this: " + resp.Name);

            this.dbIndex = resp.index;
            this.Accode = resp.Accode;
            this.Name = resp.Name;
            this.OpStockinQty = resp.OpStockinQty;
            this.Box = resp.Box;
            this.OpStockinRs = resp.OpStockinRs;
            this.Scheme = resp.Scheme;
            this.GroupName = resp.GroupName;
            this.ExpiryDt = resp.ExpiryDt;
            this.PurchaseRate = resp.PurchaseRate;
            this.RateCalculater = resp.RateCalculater;
            this.Less = resp.Less;
            this.ClsStockin = resp.ClsStockin;
            this.MRP = resp.MRP;
            this.QtyinUOM = resp.QtyinUOM;
            this.Uom2 = resp.Uom2;
            this.Less2 = resp.Less2;
            this.SaleRate = resp.SaleRate;
            this.StockCalculater = resp.StockCalculater;
            this.TotalGST = resp.TotalGST;
            this.TypeofGoods = resp.TypeofGoods;
            this.CGST = resp.CGST;
            this.StkValuation = resp.StkValuation;
            this.CessQty = resp.CessQty;
            this.QtyPerPcCase = resp.QtyPerPcCase;
            this.SGST = resp.SGST;
            this.TariffHeading = resp.TariffHeading;
            this.Cess = resp.Cess;
            this.MinStockLevel = resp.MinStockLevel;
            this.PurchaseAc = resp.PurchaseAc;
            this.MaxStockLevel = resp.MaxStockLevel;
            this.SaleAc = resp.SaleAc;
            this.GSTType = resp.GSTType;
            this.Size = resp.Size;
            this.HSNCode = resp.HSNCode;
            this.ProductionSrNo = resp.ProductionSrNo;
            this.PreviousPurchase = resp.PreviousPurchase;
            this.UnitNo = resp.UnitNo;
            this.PreviousSale = resp.PreviousSale;
            this.Percentage = resp.Percentage;
            this.schemedetails_qty1 = resp.schemedetails_qty1;
       this.schemedetails_qty2 = resp.schemedetails_qty2;
       this.schemedetails_qty3 = resp.schemedetails_qty3;
       this.schemedetails_qty4 = resp.schemedetails_qty4;
       this.schemedetails_qty5 = resp.schemedetails_qty5;
       this.schemedetails_schemers1 = resp.schemedetails_schemers1;
       this.schemedetails_schemers2 = resp.schemedetails_schemers2;
       this.schemedetails_schemers3 = resp.schemedetails_schemers3;
       this.schemedetails_schemers4 = resp.schemedetails_schemers4;
       this.schemedetails_schemers5 = resp.schemedetails_schemers5;
       this.schemedetails_er6type = resp.schemedetails_er6type;
       this.schemedetails_prcode1 = resp.schemedetails_prcode1;
       this.schemedetails_prcode2 = resp.schemedetails_prcode2;
       this.schemedetails_prcode3 = resp.schemedetails_prcode3;
       this.schemedetails_prcode4 = resp.schemedetails_prcode4;
       this.schemedetails_prcode5 = resp.schemedetails_prcode5;
       this.schemedetails_exp1 = resp.schemedetails_exp1;
       this.schemedetails_exp2 = resp.schemedetails_exp2 ;
       this.schemedetails_exp3 = resp.schemedetails_exp3;
       this.schemedetails_exp4 = resp.schemedetails_exp4;
       this.schemedetails_exp5 = resp.schemedetails_exp5;
       this.schemedetails_value1 = resp.schemedetails_value1;
       this.schemedetails_value2 = resp.schemedetails_value2;
       this.schemedetails_value3 = resp.schemedetails_value3;
       this.schemedetails_value4 = resp.schemedetails_value4;
       this.schemedetails_value5 = resp.schemedetails_value5;
       this.schemedetails_registername = resp.schemedetails_registername;
       this.schemedetails_cstradingacno = resp.schemedetails_cstradingacno;
       this.schemedetails_acdescription = resp.schemedetails_acdescription;
      this.product_manufacturer = resp.product_manufacturer;
      this.product_marketby1 = resp.product_marketby1;
      this.product_marketby2 = resp.product_marketby2;
      this.product_cirno = resp.product_cirno;
      this.prodcut_cropno = resp.prodcut_cropno;
      this.cashVauchers = resp.product_rates;
          }
        })
        .catch(error => {
          alert(error);
        });
    },
    getLastData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "last",
        reqIndex: this.dbIndex,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          let s = resp.slice(0, -1);
          s = s.substring(1);
          if (s == "outofbounds") {
            alert("out Of bounds");
          } else {
            resp = JSON.parse(resp);
            //  alert("API returned this: " + resp.Name);
            this.lastAcCode = resp.Accode;
            this.dbIndex = resp.index;
            this.Accode = resp.Accode;
            this.Name = resp.Name;
            this.OpStockinQty = resp.OpStockinQty;
            this.Box = resp.Box;
            this.OpStockinRs = resp.OpStockinRs;
            this.Scheme = resp.Scheme;
            this.GroupName = resp.GroupName;
            this.ExpiryDt = resp.ExpiryDt;
            this.PurchaseRate = resp.PurchaseRate;
            this.RateCalculater = resp.RateCalculater;
            this.Less = resp.Less;
            this.ClsStockin = resp.ClsStockin;
            this.MRP = resp.MRP;
            this.QtyinUOM = resp.QtyinUOM;
            this.Uom2 = resp.Uom2;
            this.Less2 = resp.Less2;
            this.SaleRate = resp.SaleRate;
            this.StockCalculater = resp.StockCalculater;
            this.TotalGST = resp.TotalGST;
            this.TypeofGoods = resp.TypeofGoods;
            this.CGST = resp.CGST;
            this.StkValuation = resp.StkValuation;
            this.CessQty = resp.CessQty;
            this.QtyPerPcCase = resp.QtyPerPcCase;
            this.SGST = resp.SGST;
            this.TariffHeading = resp.TariffHeading;
            this.Cess = resp.Cess;
            this.MinStockLevel = resp.MinStockLevel;
            this.PurchaseAc = resp.PurchaseAc;
            this.MaxStockLevel = resp.MaxStockLevel;
            this.SaleAc = resp.SaleAc;
            this.GSTType = resp.GSTType;
            this.Size = resp.Size;
            this.HSNCode = resp.HSNCode;
            this.ProductionSrNo = resp.ProductionSrNo;
            this.PreviousPurchase = resp.PreviousPurchase;
            this.UnitNo = resp.UnitNo;
            this.PreviousSale = resp.PreviousSale;
            this.Percentage = resp.Percentage;
            this.schemedetails_qty1 = resp.schemedetails_qty1;
       this.schemedetails_qty2 = resp.schemedetails_qty2;
       this.schemedetails_qty3 = resp.schemedetails_qty3;
       this.schemedetails_qty4 = resp.schemedetails_qty4;
       this.schemedetails_qty5 = resp.schemedetails_qty5;
       this.schemedetails_schemers1 = resp.schemedetails_schemers1;
       this.schemedetails_schemers2 = resp.schemedetails_schemers2;
       this.schemedetails_schemers3 = resp.schemedetails_schemers3;
       this.schemedetails_schemers4 = resp.schemedetails_schemers4;
       this.schemedetails_schemers5 = resp.schemedetails_schemers5;
       this.schemedetails_er6type = resp.schemedetails_er6type;
       this.schemedetails_prcode1 = resp.schemedetails_prcode1;
       this.schemedetails_prcode2 = resp.schemedetails_prcode2;
       this.schemedetails_prcode3 = resp.schemedetails_prcode3;
       this.schemedetails_prcode4 = resp.schemedetails_prcode4;
       this.schemedetails_prcode5 = resp.schemedetails_prcode5;
       this.schemedetails_exp1 = resp.schemedetails_exp1;
       this.schemedetails_exp2 = resp.schemedetails_exp2 ;
       this.schemedetails_exp3 = resp.schemedetails_exp3;
       this.schemedetails_exp4 = resp.schemedetails_exp4;
       this.schemedetails_exp5 = resp.schemedetails_exp5;
       this.schemedetails_value1 = resp.schemedetails_value1;
       this.schemedetails_value2 = resp.schemedetails_value2;
       this.schemedetails_value3 = resp.schemedetails_value3;
       this.schemedetails_value4 = resp.schemedetails_value4;
       this.schemedetails_value5 = resp.schemedetails_value5;
       this.schemedetails_registername = resp.schemedetails_registername;
       this.schemedetails_cstradingacno = resp.schemedetails_cstradingacno;
       this.schemedetails_acdescription = resp.schemedetails_acdescription;
      this.product_manufacturer = resp.product_manufacturer;
      this.product_marketby1 = resp.product_marketby1;
      this.product_marketby2 = resp.product_marketby2;
      this.product_cirno = resp.product_cirno;
      this.prodcut_cropno = resp.prodcut_cropno;
      this.cashVauchers = resp.product_rates;
          }
        })
        .catch(error => {
          alert(error);
        });
    },
    getPrevData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "prev",
        reqIndex: this.dbIndex,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          let s = resp.slice(0, -1);
          s = s.substring(1);
          if (s == "outofbounds") {
            alert("out Of bounds");
          } else {
            resp = JSON.parse(resp);
            //  alert("API returned this: " + resp.Name);

            this.dbIndex = resp.index;
            this.Accode = resp.Accode;
            this.Name = resp.Name;
            this.OpStockinQty = resp.OpStockinQty;
            this.Box = resp.Box;
            this.OpStockinRs = resp.OpStockinRs;
            this.Scheme = resp.Scheme;
            this.GroupName = resp.GroupName;
            this.ExpiryDt = resp.ExpiryDt;
            this.PurchaseRate = resp.PurchaseRate;
            this.RateCalculater = resp.RateCalculater;
            this.Less = resp.Less;
            this.ClsStockin = resp.ClsStockin;
            this.MRP = resp.MRP;
            this.QtyinUOM = resp.QtyinUOM;
            this.Uom2 = resp.Uom2;
            this.Less2 = resp.Less2;
            this.SaleRate = resp.SaleRate;
            this.StockCalculater = resp.StockCalculater;
            this.TotalGST = resp.TotalGST;
            this.TypeofGoods = resp.TypeofGoods;
            this.CGST = resp.CGST;
            this.StkValuation = resp.StkValuation;
            this.CessQty = resp.CessQty;
            this.QtyPerPcCase = resp.QtyPerPcCase;
            this.SGST = resp.SGST;
            this.TariffHeading = resp.TariffHeading;
            this.Cess = resp.Cess;
            this.MinStockLevel = resp.MinStockLevel;
            this.PurchaseAc = resp.PurchaseAc;
            this.MaxStockLevel = resp.MaxStockLevel;
            this.SaleAc = resp.SaleAc;
            this.GSTType = resp.GSTType;
            this.Size = resp.Size;
            this.HSNCode = resp.HSNCode;
            this.ProductionSrNo = resp.ProductionSrNo;
            this.PreviousPurchase = resp.PreviousPurchase;
            this.UnitNo = resp.UnitNo;
            this.PreviousSale = resp.PreviousSale;
            this.Percentage = resp.Percentage;
            this.schemedetails_qty1 = resp.schemedetails_qty1;
       this.schemedetails_qty2 = resp.schemedetails_qty2;
       this.schemedetails_qty3 = resp.schemedetails_qty3;
       this.schemedetails_qty4 = resp.schemedetails_qty4;
       this.schemedetails_qty5 = resp.schemedetails_qty5;
       this.schemedetails_schemers1 = resp.schemedetails_schemers1;
       this.schemedetails_schemers2 = resp.schemedetails_schemers2;
       this.schemedetails_schemers3 = resp.schemedetails_schemers3;
       this.schemedetails_schemers4 = resp.schemedetails_schemers4;
       this.schemedetails_schemers5 = resp.schemedetails_schemers5;
       this.schemedetails_er6type = resp.schemedetails_er6type;
       this.schemedetails_prcode1 = resp.schemedetails_prcode1;
       this.schemedetails_prcode2 = resp.schemedetails_prcode2;
       this.schemedetails_prcode3 = resp.schemedetails_prcode3;
       this.schemedetails_prcode4 = resp.schemedetails_prcode4;
       this.schemedetails_prcode5 = resp.schemedetails_prcode5;
       this.schemedetails_exp1 = resp.schemedetails_exp1;
       this.schemedetails_exp2 = resp.schemedetails_exp2 ;
       this.schemedetails_exp3 = resp.schemedetails_exp3;
       this.schemedetails_exp4 = resp.schemedetails_exp4;
       this.schemedetails_exp5 = resp.schemedetails_exp5;
       this.schemedetails_value1 = resp.schemedetails_value1;
       this.schemedetails_value2 = resp.schemedetails_value2;
       this.schemedetails_value3 = resp.schemedetails_value3;
       this.schemedetails_value4 = resp.schemedetails_value4;
       this.schemedetails_value5 = resp.schemedetails_value5;
       this.schemedetails_registername = resp.schemedetails_registername;
       this.schemedetails_cstradingacno = resp.schemedetails_cstradingacno;
       this.schemedetails_acdescription = resp.schemedetails_acdescription;
      this.product_manufacturer = resp.product_manufacturer;
      this.product_marketby1 = resp.product_marketby1;
      this.product_marketby2 = resp.product_marketby2;
      this.product_cirno = resp.product_cirno;
      this.prodcut_cropno = resp.prodcut_cropno;
      this.cashVauchers = resp.product_rates;
          }
        })
        .catch(error => {
          alert(error);
        });
    },
    getZoneDetails(){
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        companyname: companyName
      };
      axios
        .post("http://localhost:2000/getZoneDetails", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          let resp = JSON.stringify(response.data);
          let s = JSON.parse(resp);
          this.zoneDetailsData = s;
          alert(s)
        })
        .catch(error => {
          alert(error);
        });
    },

        saveZoneDetails(){
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        companyname: companyName,
        exportdata: this.zoneDetailsData
      };
      axios
        .post("http://localhost:2000/saveZoneDetails", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          let resp = JSON.stringify(response.data);
          let s = JSON.parse(resp);
          alert(s)
        })
        .catch(error => {
          alert(error);
        });
    },

    getNextData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "next",
        reqIndex: this.dbIndex,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          let s = resp.slice(0, -1);
          s = s.substring(1);
          if (s == "outofbounds") {
            alert("out Of bounds");
          } else {
            resp = JSON.parse(resp);
            // alert("API returned this: " + resp.Name);

            this.dbIndex = resp.index;
            this.Accode = resp.Accode;
            this.Name = resp.Name;
            this.OpStockinQty = resp.OpStockinQty;
            this.Box = resp.Box;
            this.OpStockinRs = resp.OpStockinRs;
            this.Scheme = resp.Scheme;
            this.GroupName = resp.GroupName;
            this.ExpiryDt = resp.ExpiryDt;
            this.PurchaseRate = resp.PurchaseRate;
            this.RateCalculater = resp.RateCalculater;
            this.Less = resp.Less;
            this.ClsStockin = resp.ClsStockin;
            this.MRP = resp.MRP;
            this.QtyinUOM = resp.QtyinUOM;
            this.Uom2 = resp.Uom2;
            this.Less2 = resp.Less2;
            this.SaleRate = resp.SaleRate;
            this.StockCalculater = resp.StockCalculater;
            this.TotalGST = resp.TotalGST;
            this.TypeofGoods = resp.TypeofGoods;
            this.CGST = resp.CGST;
            this.StkValuation = resp.StkValuation;
            this.CessQty = resp.CessQty;
            this.QtyPerPcCase = resp.QtyPerPcCase;
            this.SGST = resp.SGST;
            this.TariffHeading = resp.TariffHeading;
            this.Cess = resp.Cess;
            this.MinStockLevel = resp.MinStockLevel;
            this.PurchaseAc = resp.PurchaseAc;
            this.MaxStockLevel = resp.MaxStockLevel;
            this.SaleAc = resp.SaleAc;
            this.GSTType = resp.GSTType;
            this.Size = resp.Size;
            this.HSNCode = resp.HSNCode;
            this.ProductionSrNo = resp.ProductionSrNo;
            this.PreviousPurchase = resp.PreviousPurchase;
            this.UnitNo = resp.UnitNo;
            this.PreviousSale = resp.PreviousSale;
            this.Percentage = resp.Percentage;
            this.schemedetails_qty1 = resp.schemedetails_qty1;
       this.schemedetails_qty2 = resp.schemedetails_qty2;
       this.schemedetails_qty3 = resp.schemedetails_qty3;
       this.schemedetails_qty4 = resp.schemedetails_qty4;
       this.schemedetails_qty5 = resp.schemedetails_qty5;
       this.schemedetails_schemers1 = resp.schemedetails_schemers1;
       this.schemedetails_schemers2 = resp.schemedetails_schemers2;
       this.schemedetails_schemers3 = resp.schemedetails_schemers3;
       this.schemedetails_schemers4 = resp.schemedetails_schemers4;
       this.schemedetails_schemers5 = resp.schemedetails_schemers5;
       this.schemedetails_er6type = resp.schemedetails_er6type;
       this.schemedetails_prcode1 = resp.schemedetails_prcode1;
       this.schemedetails_prcode2 = resp.schemedetails_prcode2;
       this.schemedetails_prcode3 = resp.schemedetails_prcode3;
       this.schemedetails_prcode4 = resp.schemedetails_prcode4;
       this.schemedetails_prcode5 = resp.schemedetails_prcode5;
       this.schemedetails_exp1 = resp.schemedetails_exp1;
       this.schemedetails_exp2 = resp.schemedetails_exp2 ;
       this.schemedetails_exp3 = resp.schemedetails_exp3;
       this.schemedetails_exp4 = resp.schemedetails_exp4;
       this.schemedetails_exp5 = resp.schemedetails_exp5;
       this.schemedetails_value1 = resp.schemedetails_value1;
       this.schemedetails_value2 = resp.schemedetails_value2;
       this.schemedetails_value3 = resp.schemedetails_value3;
       this.schemedetails_value4 = resp.schemedetails_value4;
       this.schemedetails_value5 = resp.schemedetails_value5;
       this.schemedetails_registername = resp.schemedetails_registername;
       this.schemedetails_cstradingacno = resp.schemedetails_cstradingacno;
       this.schemedetails_acdescription = resp.schemedetails_acdescription;
      this.product_manufacturer = resp.product_manufacturer;
      this.product_marketby1 = resp.product_marketby1;
      this.product_marketby2 = resp.product_marketby2;
      this.product_cirno = resp.product_cirno;
      this.prodcut_cropno = resp.prodcut_cropno;
      this.cashVauchers = resp.product_rates;
          }
        })
        .catch(error => {
          alert(error);
        });
    },
    

    getSelectedData(text,view) {
       if(view=="edit")
      this.onEdit()
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      //alert(text);
      var n = {
        note: "selected",
        reqIndex: this.dbIndex,
        companyname: companyName,
        selectedName: text
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          //  alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);

          this.dbIndex = resp.index;
          this.Accode = resp.Accode;
          this.Name = resp.Name;
          this.OpStockinQty = resp.OpStockinQty;
          this.Box = resp.Box;
          this.OpStockinRs = resp.OpStockinRs;
          this.Scheme = resp.Scheme;
          this.GroupName = resp.GroupName;
          this.ExpiryDt = resp.ExpiryDt;
          this.PurchaseRate = resp.PurchaseRate;
          this.RateCalculater = resp.RateCalculater;
          this.Less = resp.Less;
          this.ClsStockin = resp.ClsStockin;
          this.MRP = resp.MRP;
          this.QtyinUOM = resp.QtyinUOM;
          this.Uom2 = resp.Uom2;
          this.Less2 = resp.Less2;
          this.SaleRate = resp.SaleRate;
          this.StockCalculater = resp.StockCalculater;
          this.TotalGST = resp.TotalGST;
          this.TypeofGoods = resp.TypeofGoods;
          this.CGST = resp.CGST;
          this.StkValuation = resp.StkValuation;
          this.CessQty = resp.CessQty;
          this.QtyPerPcCase = resp.QtyPerPcCase;
          this.SGST = resp.SGST;
          this.TariffHeading = resp.TariffHeading;
          this.Cess = resp.Cess;
          this.MinStockLevel = resp.MinStockLevel;
          this.PurchaseAc = resp.PurchaseAc;
          this.MaxStockLevel = resp.MaxStockLevel;
          this.SaleAc = resp.SaleAc;
          this.GSTType = resp.GSTType;
          this.Size = resp.Size;
          this.HSNCode = resp.HSNCode;
          this.ProductionSrNo = resp.ProductionSrNo;
          this.PreviousPurchase = resp.PreviousPurchase;
          this.UnitNo = resp.UnitNo;
          this.PreviousSale = resp.PreviousSale;
          this.Percentage = resp.Percentage;
          this.schemedetails_qty1 = resp.schemedetails_qty1;
       this.schemedetails_qty2 = resp.schemedetails_qty2;
       this.schemedetails_qty3 = resp.schemedetails_qty3;
       this.schemedetails_qty4 = resp.schemedetails_qty4;
       this.schemedetails_qty5 = resp.schemedetails_qty5;
       this.schemedetails_schemers1 = resp.schemedetails_schemers1;
       this.schemedetails_schemers2 = resp.schemedetails_schemers2;
       this.schemedetails_schemers3 = resp.schemedetails_schemers3;
       this.schemedetails_schemers4 = resp.schemedetails_schemers4;
       this.schemedetails_schemers5 = resp.schemedetails_schemers5;
       this.schemedetails_er6type = resp.schemedetails_er6type;
       this.schemedetails_prcode1 = resp.schemedetails_prcode1;
       this.schemedetails_prcode2 = resp.schemedetails_prcode2;
       this.schemedetails_prcode3 = resp.schemedetails_prcode3;
       this.schemedetails_prcode4 = resp.schemedetails_prcode4;
       this.schemedetails_prcode5 = resp.schemedetails_prcode5;
       this.schemedetails_exp1 = resp.schemedetails_exp1;
       this.schemedetails_exp2 = resp.schemedetails_exp2 ;
       this.schemedetails_exp3 = resp.schemedetails_exp3;
       this.schemedetails_exp4 = resp.schemedetails_exp4;
       this.schemedetails_exp5 = resp.schemedetails_exp5;
       this.schemedetails_value1 = resp.schemedetails_value1;
       this.schemedetails_value2 = resp.schemedetails_value2;
       this.schemedetails_value3 = resp.schemedetails_value3;
       this.schemedetails_value4 = resp.schemedetails_value4;
       this.schemedetails_value5 = resp.schemedetails_value5;
       this.schemedetails_registername = resp.schemedetails_registername;
       this.schemedetails_cstradingacno = resp.schemedetails_cstradingacno;
       this.schemedetails_acdescription = resp.schemedetails_acdescription;
      this.product_manufacturer = resp.product_manufacturer;
      this.product_marketby1 = resp.product_marketby1;
      this.product_marketby2 = resp.product_marketby2;
      this.product_cirno = resp.product_cirno;
      this.prodcut_cropno = resp.prodcut_cropno;
      this.cashVauchers = resp.product_rates;
        })
        .catch(error => {
          alert(error);
        });
    },
    getSearchData(ind) {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "all",
        reqIndex: ind,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);

          if (resp.stock_accounts.length > 0) {
            this.lastAcCode =
              resp.stock_accounts[resp.stock_accounts.length - 1].Accode;
          } else {
            this.lastAcCode = 99999;
          }
          // alert('set lastAccode = '+ resp.stock_accounts[resp.stock_accounts.length - 1].Name)
          this.popupBodyData = resp.stock_accounts;
          this.popupFilteredData = this.popupBodyData;
          // alert(this.popupBodyData[0].HSNCode);
        })
        .catch(error => {
          alert(error);
        });
    },

    getData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        note: "all",
        reqIndex: this.dbIndex,
        companyname: companyName
      };
      // alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/GetStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);

          if (resp.stock_accounts.length > 0) {
            this.lastAcCode =
              resp.stock_accounts[resp.stock_accounts.length - 1].Accode;
          } else {
            this.lastAcCode = 99999;
          }
          // alert('set lastAccode = '+ resp.stock_accounts[resp.stock_accounts.length - 1].Name)
          this.popupBodyData = resp.stock_accounts;
          this.popupFilteredData = this.popupBodyData;
          // alert(this.popupBodyData[0].HSNCode);
        })
        .catch(error => {
          alert(error);
        });
    },
    save() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      // alert("at this point, AcCode is: " + this.Accode);
      var n = {
        dataAll: {
          Accode: this.Accode,
          Name: this.Name,
          OpStockinQty: this.OpStockinQty,
          Box: this.Box,
          OpStockinRs: this.OpStockinRs,
          Scheme: this.Scheme,
          GroupName: this.GroupName,
          ExpiryDt: this.ExpiryDt,
          PurchaseRate: this.PurchaseRate,
          RateCalculater: this.RateCalculater,
          Less: this.Less,
          ClsStockin: this.ClsStockin,
          MRP: this.MRP,
          QtyinUOM: this.QtyinUOM,
          Uom2: this.Uom2,
          Less2: this.Less2,
          SaleRate: this.SaleRate,
          StockCalculater: this.StockCalculater,
          TotalGST: this.TotalGST,
          TypeofGoods: this.TypeofGoods,
          CGST: this.CGST,
          StkValuation: this.StkValuation,
          CessQty: this.CessQty,
          QtyPerPcCase: this.QtyPerPcCase,
          SGST: this.SGST,
          TariffHeading: this.TariffHeading,
          Cess: this.Cess,
          MinStockLevel: this.MinStockLevel,
          PurchaseAc: this.PurchaseAc,
          MaxStockLevel: this.MaxStockLevel,
          SaleAc: this.SaleAc,
          GSTType: this.GSTType,
          Size: this.Size,
          HSNCode: this.HSNCode,
          ProductionSrNo: this.ProductionSrNo,
          PreviousPurchase: this.PreviousPurchase,
          UnitNo: this.UnitNo,
          PreviousSale: this.PreviousSale,
          Percentage: this.Percentage,
          SaleAcCode: this.saleaccode,
          PurchaseAcCode: this.purchaseaccode,
          schemedetails_qty1: this.schemedetails_qty1,
      schemedetails_qty2: this.schemedetails_qty2,
      schemedetails_qty3: this.schemedetails_qty3,
      schemedetails_qty4: this.schemedetails_qty4,
      schemedetails_qty5: this.schemedetails_qty5,
      schemedetails_schemers1: this.schemedetails_schemers1,
      schemedetails_schemers2: this.schemedetails_schemers2,
      schemedetails_schemers3: this.schemedetails_schemers3,
      schemedetails_schemers4: this.schemedetails_schemers4,
      schemedetails_schemers5: this.schemedetails_schemers5,
      schemedetails_er6type: this.schemedetails_er6type,
      schemedetails_prcode1: this.schemedetails_prcode1,
      schemedetails_prcode2: this.schemedetails_prcode2,
      schemedetails_prcode3: this.schemedetails_prcode3,
      schemedetails_prcode4: this.schemedetails_prcode4,
      schemedetails_prcode5: this.schemedetails_prcode5,
      schemedetails_exp1: this.schemedetails_exp1,
      schemedetails_exp2: this.schemedetails_exp2,
      schemedetails_exp3: this.schemedetails_exp3,
      schemedetails_exp4: this.schemedetails_exp4,
      schemedetails_exp5: this.schemedetails_exp5,
      schemedetails_value1: this.schemedetails_value1,
      schemedetails_value2: this.schemedetails_value2,
      schemedetails_value3: this.schemedetails_value3,
      schemedetails_value4: this.schemedetails_value4,
      schemedetails_value5: this.schemedetails_value5,
      schemedetails_registername: this.schemedetails_registername,
      schemedetails_cstradingacno: this.schemedetails_cstradingacno,
      schemedetails_acdescription: this.schemedetails_acdescription,
      product_manufacturer: this.product_manufacturer,
      product_marketby1: this.product_marketby1,
      product_marketby2: this.product_marketby2,
      product_cirno: this.product_cirno,
      prodcut_cropno: this.prodcut_cropno,

      product_rates: this.cashVauchers

        },
        companyname: companyName,
        isEditingOld: this.isEditingOld
      };
      //alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/SaveStockAccount", n)
        .then(response => {
          // alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data.dooda);
          resp = resp.slice(0, -1);
          resp = resp.substring(1);

          if (resp == "duplicate") {
            //alert("duplicate");
            this.RedAlert("Duplicate Name Not Allowed !");
          } else {
            // alert(" saved");
            this.GreenAlert("Saved New Stock Account Successfully");
            this.lastAcCode = parseInt(this.lastAcCode + "") + 1;
          }

          //this.Savenotify();
          // alert("saved")
        })
        .catch(error => {
          alert(error);
        });

      alert("Request to save sent!");

      this.buttondis = true;
      this.buttondis_true();
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.accodeDis = true;
      this.cpdDisable = false;
      document.getElementById("addButton").focus();
      (this.buttonActiveList = [
        "active",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ]),
        (this.isEditingOld = false);
      this.$forceUpdate();
    },

    computed: {
      now: function() {
        var today = new Date();
        var date =
          today.getFullYear() +
          "-" +
          (today.getMonth() + 1) +
          "-" +
          today.getDate();
        return date;
      },
      currentday: function() {
        var today = new Date();
        var weekday = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday"
        ];
        var currenday = weekday[today.getDay()];
        return currenday;
      }
    },

    GreenAlert(text) {
      this.$vs.notify({
        title: "Alery",
        text: text,
        iconPack: "feather",
        icon: "icon-alert-circle",
        color: "success"
      });
    },
    RedAlert(text) {
      this.$vs.notify({
        title: "Alert",
        text: text,
        iconPack: "feather",
        icon: "icon-alert-circle",
        color: "danger"
      });
    }
  },
  mounted() {
    let that = this;
    that.dbIndex = -999;

    that.disAdd = false;
    that.getstocksetup();
    that.getLastData();
    that.getZoneDetails();
    document.getElementById("addButton").focus();
    window.addEventListener("keydown", function(event) {
      if (event.keyCode == 38 && that.currentItem > 0) {
        that.currentItem--;
      } else if (
        event.keyCode == 40 &&
        that.currentItem < that.popupBodyData.length - 1
      ) {
        that.currentItem++;
      } else if (event.keyCode == 27) {
        if (that.searchPopup == true) {
          that.searchPopup = false;
        }
        if (that.setupForm == true) {
          that.setupForm = false;
        }
      }

      if (event.keyCode == 18) {
        //alert(that.currentfield)
        if (that.currentfield == "comboarea") {
          that.showdescNar("area");
        } else if (that.currentfield == "Group") {
          that.popupActiveNarration = true;
          that.showdescNar("group");
        } else if (that.currentfield == "Works") {
          that.showdescNar("Works");
        } else if (that.currentfield == "Distt") {
          that.showdescNar("Distt");
        } else if (that.currentfield == "AcName") {
          that.showdescNar("AcName");
        } else if (that.currentfield == "City") {
          that.showdescNar("City");
        } else if (that.currentfield == "comboemail") {
          that.showdescNar("email");
        }
      }

      if (event.keyCode === 80) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newstockacc") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getPrevData();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 78) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newstockacc") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getNextData();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 70) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newstockacc") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getFirstData();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 76) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newstockacc") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getLastData();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
    });
  }
};
</script>
