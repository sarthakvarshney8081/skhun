
<style>
.select-large input.vs-select--input {
  padding: 5px;
}

#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}
.vs-button {
  display: inline-block;
}
.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>

<template>
  <div class="modalpurchasesetup">
    <div class="vx-card p-6" style>
      <!-- popup definition starts -->

 <vs-popup classContent="popup-example" title="Sale Series" :active.sync="popupActivePuchaseSeries" fullscreen >
       <purchaseseriesmodal v-model="modalOpenPurchaseSeries"  :SearchText="searchlabel"  ref="childComponentPurchaseSeries"/>
   </vs-popup>

      <vs-popup classContent="popup-example" title :active.sync="popupActive2">
        <div style="overflow-x:auto;">
          <table class="tables">
            <thead class="bg-primary">
              <tr>
                <th>
                  <p style="color:white;">Member ID</p>
                </th>
                <th>
                  <p style="color:white;">First Name</p>
                </th>
                <th>
                  <p style="color:white;">Middle Name</p>
                </th>
                <th>
                  <p style="color:white;">Last Name</p>
                </th>
                <th>
                  <p style="color:white;">Address</p>
                </th>
                <th>
                  <p style="color:white;">Actions</p>
                </th>
              </tr>
            </thead>

            <tbody>
              <tr scope="row" v-for="(result,j) in popupDataList" :key="j">
                <td>{{result.memberId}}</td>
                <td>{{result.firstName}}</td>
                <td>{{result.middleName}}</td>
                <td>{{result.lastName}}</td>
                <td>{{result.address}}</td>

                <div class="row justify-content-center">
                  <vs-button class="button" size="small" @click="setAccountNo(j)">select</vs-button>
                </div>
              </tr>
            </tbody>
          </table>
        </div>
      </vs-popup>

      <!--  Popup definition ends -->

      <!--header START-->
      <table width="100%" border="0" class="tables">
        <tr>
          <td width="25%"></td>
          <td width="50%">
            <center>
              <h1 class="text-primary">
                Purchase Setup
                <br />
                <h4>
                  <font color="grey">{{titleAction}}</font>
                </h4>
              </h1>
            </center>
          </td>
          <td width="25%" align="right"></td>
        </tr>
        <br />
      </table>

      <div class="flex mb-4" style="padding-top:20px;">
        <div
          class="w-1/2 bg-grid-color-secondary h-12 flex"
          style="height:100% !important; width:100% !important; padding-bottom:20px; margin-right:17%;"
        >
          <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
            <tr>
              <td>Color</td>
              <td>
                <vs-select
                  v-model="purchasesetup_color"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in colorlist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>
            <tr>
              <td class="overlap">Cust. Name</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_custname"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>
            <tr>
              <td class="overlap">Terms</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_terms"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Vehicle No.</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_vehicleno"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>
            <tr>
              <td>Tax Type</td>
              <td>
                <vs-select
                  v-model="purchasesetup_taxtype"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in taxtypelist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td>Bill Cash</td>
              <td>
                <vs-select
                  v-model="purchasesetup_billcash"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in billcashlist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td class="overlap">Duty</td>
              <td>
                <vs-select
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_duty"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in dutylist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td class="overlap">Product</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_product"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 1</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_remno1"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 2</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_remno2"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 3</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_remno3"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Transport</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_transport"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Broker</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_broker"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">GR Number</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_grnumber"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td>Purchase A/c</td>
              <td>
                <vs-select
                  v-model="purchasesetup_purchaseac"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in purchaseaclist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td class="overlap">Cess Code</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_cesscode"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Pur.Import GST</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="purchasesetup_purimportgst"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>
          </table>
        </div>
        <div
          class="w-1/2 bg-grid-color-secondary h-12 flex"
          style="height:100% !important; width:100% !important; padding-bottom:20px;"
          :disabled="buttondis"
        >
          <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
            <tr>
              <td>
                <table>
                  <tr>
                    <td>
                      <a href="#">
                        <font color="red">REGD.DEALER</font>
                      </a>
                    </td>
                    <td>
                      <a href="#">
                        <font color="red">UNREG. DEALER</font>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <a href="#">
                        <font color="red">ITC (DR)</font>
                      </a>
                    </td>
                    <td>
                      <a href="#">
                        <font color="red">ITC REVERS (CR)</font>
                      </a>

                      &nbsp;
                      <a href="#">
                        <font color="red">ITC REVERS (DR)</font>
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table>
                  <tr>
                    <td>
                      <font color="red">C.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_cgstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_cgstac2"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_cgstac3"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <font color="red">S.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_sgstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_sgstac2"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_sgstac3"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <font color="red">I.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_igstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_igstac2"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_igstac3"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table>
                  <tr>
                    <td>TCS A/c</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_tdsac"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>Tcs Cess A/c</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_tcscessac"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>TCS Rate All</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_tcsrateall"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+/-</td>
                    <td>Rate</td>
                  </tr>
                  <tr>
                    <td>CST@</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_csta"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Freight</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_freight"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v2"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Comm.</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_comm"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v3"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Others</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_others"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v4"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Expense 5</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_expense5"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>-P</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v5"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Expense 6</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_expense6"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v6"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Expense 7</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_expense7"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v7"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td>Expense 8</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_expense8"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+V</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup_v8"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <hr />
      <center>Additional Settings</center>
      <hr />
      <div class="flex mb-4" style="padding-top:20px;">
        <table>
          <tr>
            <td>
              <table>
                <tr>
                  <td>Disable Inv. Time</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_disableinvtime"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Disable Rev. Time</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_disablerevtime"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>A/c Name in Led.</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_acnameinled"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Remarks Post</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_remarkspost"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>

                <tr>
                  <td>Cursor Focus to Date</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_cursorfocustodate"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>Show Window Exp. Before Tax</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_showwindowexpbeforetax"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Show Window Exp. After Tax</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_showwindowexpafterttax"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Item Name in Led.</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_itemnameinled"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Extra Remarks</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_extraremarks"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>Round Off</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_roundoff"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Tax Round Off</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_taxroundoff"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Display Item</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_displayitem"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Default Button</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_defaultbutton"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in defaultbuttonlist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Low Sale</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_lowsale"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                Decimals
                <tr>
                  <td>Rate</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_rate"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Bag</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_bag"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Qty</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_qty"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>
                    <font color="red">Display HSN Code</font>
                  </td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_displayhsncode"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>

                <tr>
                  <td>TDS Options</td>
                  <td>
                    <vs-select
                      v-model="purchasesetup_tdsoptions"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Focus after Save</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="purchasesetup_focusaftersave"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </div>

      <div align="right">
        <br />

        <br />
        <!-- Button set start-->
        <div align="left">
          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="save()"
          >Save</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="save()"
          >Tax Structure</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="openPurchaseSeriesPopup"
          >Purchase Series</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="save()"
          >Browse</vs-button>
        </div>
        <!-- Button set end -->
      </div>
      <br />
      <br />
      <br />
    </div>
  </div>
</template>




<script>
import flatPickr from "vue-flatpickr-component";

import "flatpickr/dist/flatpickr.css";
import axios from "@/axios";

import purchaseseriesmodal from "@/components/purchaseseriesmodal.vue";

export default {
  name: "modalpurchasesetup",

  data() {
    return {
      popupActivePuchaseSeries:false,
      modalOpenPurchaseSeries:false,
      configdateTimePicker: {
        allowInput: true,
        dateFormat: "d-m-Y"
      },
      titleAction: "",
      date: null,

      purchasesetup_color: "",
      purchasesetup_custname: "",
      purchasesetup_terms: "",
      purchasesetup_vehicleno: "",
      purchasesetup_taxtype: "",
      purchasesetup_billcash: "",
      purchasesetup_duty: "",
      purchasesetup_product: "",
      purchasesetup_remno1: "",
      purchasesetup_remno2: "",
      purchasesetup_remno3: "",
      purchasesetup_transport: "",
      purchasesetup_broker: "",
      purchasesetup_grnumber: "",
      purchasesetup_purchaseac: "",
      purchasesetup_cesscode: "",
      purchasesetup_purimportgst: "",
      purchasesetup_cgstac1: "",
      purchasesetup_cgstac2: "",
      purchasesetup_cgstac3: "",
      purchasesetup_sgstac1: "",
      purchasesetup_sgstac2: "",
      purchasesetup_sgstac3: "",
      purchasesetup_igstac1: "",
      purchasesetup_igstac2: "",
      purchasesetup_igstac3: "",
      purchasesetup_tcsac: "",
      purchasesetup_tcscessac: "",
      purchasesetup_tcsrateall: "",
      purchasesetup_csta: "",
      purchasesetup_v1: "",
      purchasesetup_v2: "",
      purchasesetup_v3: "",
      purchasesetup_v4: "",
      purchasesetup_v5: "",
      purchasesetup_v6: "",
      purchasesetup_v7: "",
      purchasesetup_v8: "",
      purchasesetup_freight: "",
      purchasesetup_comm: "",
      purchasesetup_others: "",
      purchasesetup_expense5: "",
      purchasesetup_expense6: "",
      purchasesetup_expense7: "",
      purchasesetup_expense8: "",
      purchasesetup_disableinvtime: "",
      purchasesetup_disablerevtime: "",
      purchasesetup_acnameinled: "",
      purchasesetup_remarkspost: "",
      purchasesetup_cursorfocustodate: "",
      purchasesetup_showwindowexpafterttax: "",
      purchasesetup_showwindowexpbeforetax: "",
      purchasesetup_itemnameinled: "",
      purchasesetup_extraremarks: "",
      purchasesetup_roundoff: "",
      purchasesetup_taxroundoff: "",
      purchasesetup_displayitem: "",
      purchasesetup_defaultbutton: "",
      purchasesetup_lowsale: "",
      purchasesetup_rate: "",
      purchasesetup_bag: "",
      purchasesetup_qty: "",
      purchasesetup_displayhsncode: "",
      purchasesetup_tdsoptions: "",
      purchasesetup_focusaftersave: "",

      //Dropdown lists follow

      colorlist: [
        { text: "0.Default Scheme", value: "defaultscheme" },
        { text: "1. Scheme No. 1", value: "schemeno1" },
        { text: "2. Scheme No. 2", value: "schemeno1" },
        { text: "3. Scheme No. 3", value: "schemeno1" },
        { text: "4. Scheme No. 4", value: "schemeno1" },
        { text: "5. Scheme No. 5", value: "schemeno1" },
        { text: "6. Scheme No. 6", value: "schemeno1" }
      ],

      taxtypelist: [
        { text: "Auto", value: "auto" },
        { text: "Taxable Purchase", value: "taxablepurchse" },
        { text: "Out of State", value: "outofstate" },
        { text: "Non Taxable", value: "nontaxable" },
        { text: "Exempted Purchase", value: "exemptedpurchase" },
        { text: "Tax Free Purchase", value: "taxfreepurchase" },
        { text: "Import", value: "import" },
        { text: "Import (Accounts)", value: "import(accounts)" },
        { text: "Capital Goods", value: "capitalgoods" },
        { text: "Consignment", value: "consignment" },
        { text: "E1/E2 Purchase", value: "e1/e1purchase" },
        { text: "Purchase u/s 19 & 20", value: "purchaseus19&20" },
        { text: "H Form Within State", value: "hformwithinstate" },
        { text: "H Form Out of State", value: "hformoutofstate" },
        { text: "Not Eligible for ITC", value: "noteligibleforitc" },
        { text: "Not Applicable", value: "notapplicable" },
        { text: "Taxfree Interstate", value: "taxfreeinterstate" },
        { text: "No Reverse ITC", value: "noreverseitc" },
        { text: "Out of State (URD)", value: "outofstate(urd)" }
      ],

      billcashlist: [
        { text: "Bill", value: "bill" },
        { text: "Cash Memo", value: "cashmemo" }
      ],

      dutylist: [
        { text: "1. Manufacturing Pur", value: "manufacturingpur" },
        { text: "2. Trading Pur", value: "tradingpur" }
      ],

      purchaseaclist: [
        { text: "Including Duty", value: "includingduty" },
        { text: "Excluding Duty", value: "excludingduty" }
      ],

      yesnolist: [
        { text: "Yes", value: "yes" },
        { text: "NO", value: "no" }
      ],

      displayitemlist: [
        { text: "Product Code", value: "productcode" },
        { text: "HSN Code", value: "hsncode" },
        { text: "Product Name", value: "Product Name" }
      ],

      defaultbuttonlist: [
        { text: "Print", value: "print" },
        { text: "Add", value: "add" }
      ],

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],

      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
      popupActive2: false,
      popupActive3: false,
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false
    };
  },

  components: {
    flatPickr,
    purchaseseriesmodal
  },
  methods: {

    
      openPurchaseSeriesPopup(){
     //   alert(this.popupActiveSaleSeries+" ghfg")
      this.popupActivePuchaseSeries=true
      this.modalOpenPurchaseSeries=true
    },
    // get collection
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },
    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },


saveTaxType() {
     
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
    
      var value = {
        companyname: companyName,
        taxTable : this.cashVauchers,
        note:"purchase"
      };
        
console.log(value)
        alert(JSON.stringify(this.cashVauchers))

     

      axios
        .post("/transactions/saveTaxStructure", value)
        .then(function(response) {
          
          alert(response);          
        })
        .catch(error => {
          alert(error);
        });

    },

    getTaxType() {
     
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
   
      var value = {
        companyname: companyName,
        note: "purchase"
        
      };
        let that=this
axios
        .post("/transactions/getTaxStructure", value)
        .then(function(response) {
         var data = JSON.stringify(response.data);

          var json = JSON.parse(data);


         that.cashVauchers= json.completejson.sale.data
         alert(JSON.stringify(json.names))          
        })
        .catch(error => {

          alert(error);
        });

    },


    save() {
     // alert(this.purchasesetup_purchaseac)
      var exportData = {
        date: this.date,
        voucherno: this.voucherno,
        purchasesetup_color: this.purchasesetup_color,
        purchasesetup_custname: this.purchasesetup_custname,
        purchasesetup_terms: this.purchasesetup_terms,
        purchasesetup_vehicleno: this.purchasesetup_vehicleno,
        purchasesetup_taxtype: this.purchasesetup_taxtype,
        purchasesetup_billcash: this.purchasesetup_billcash,
        purchasesetup_purchaseac: this.purchasesetup_purchaseac,
        purchasesetup_duty: this.purchasesetup_duty,
        purchasesetup_product: this.purchasesetup_product,
        purchasesetup_remno1: this.purchasesetup_remno1,
        purchasesetup_remno2: this.purchasesetup_remno2,
        purchasesetup_remno3: this.purchasesetup_remno3,
        purchasesetup_transport: this.purchasesetup_transport,
        purchasesetup_broker: this.purchasesetup_broker,
        purchasesetup_grnumber: this.purchasesetup_grnumber,
        purchasesetup_purimportgst: this.purchasesetup_purimportgst,
        purchasesetup_cgstac1: this.purchasesetup_cgstac1,
        purchasesetup_cgstac2: this.purchasesetup_cgstac2,
        purchasesetup_cgstac3: this.purchasesetup_cgstac3,
        purchasesetup_sgstac1: this.purchasesetup_sgstac1,
        purchasesetup_sgstac2: this.purchasesetup_sgstac2,
        purchasesetup_sgstac3: this.purchasesetup_sgstac3,
        purchasesetup_igstac1: this.purchasesetup_igstac1,
        purchasesetup_igstac2: this.purchasesetup_igstac2,
        purchasesetup_igstac3: this.purchasesetup_igstac3,
        purchasesetup_tcsac: this.purchasesetup_tcsac,
        purchasesetup_tcscessac: this.purchasesetup_tcscessac,
        purchasesetup_tcsrateall: this.purchasesetup_tcsrateall,
        purchasesetup_csta: this.purchasesetup_csta,
        purchasesetup_freight: this.purchasesetup_freight,
        purchasesetup_comm: this.purchasesetup_comm,
        purchasesetup_others: this.purchasesetup_others,
        purchasesetup_expense5: this.purchasesetup_expense5,
        purchasesetup_expense6: this.purchasesetup_expense6,
        purchasesetup_expense7: this.purchasesetup_expense7,
        purchasesetup_expense8: this.purchasesetup_expense8,
        purchasesetup_v1: this.purchasesetup_v1,
        purchasesetup_v2: this.purchasesetup_v2,
        purchasesetup_v3: this.purchasesetup_v3,
        purchasesetup_v4: this.purchasesetup_v4,
        purchasesetup_v5: this.purchasesetup_v5,
        purchasesetup_v6: this.purchasesetup_v6,
        purchasesetup_v7: this.purchasesetup_v7,
        purchasesetup_v8: this.purchasesetup_v8,
        purchasesetup_disableinvtime: this.purchasesetup_disableinvtime,
        purchasesetup_disablerevtime: this.purchasesetup_disablerevtime,
        purchasesetup_acnameinled: this.purchasesetup_acnameinled,
        purchasesetup_remarkspost: this.purchasesetup_remarkspost,
        purchasesetup_cursorfocustodate: this.salesummary2_19,
        purchasesetup_showwindowexpbeforetax: this
          .purchasesetup_showwindowexpbeforetax,
        purchasesetup_showwindowexpafterttax: this
          .purchasesetup_showwindowexpafterttax,

        purchasesetup_itemnameinled: this.purchasesetup_itemnameinled,

        purchasesetup_extraremarks: this.purchasesetup_extraremarks,

        purchasesetup_roundoff: this.purchasesetup_roundoff,

        purchasesetup_taxroundoff: this.purchasesetup_taxroundoff,

        purchasesetup_displayitem: this.purchasesetup_displayitem,

        purchasesetup_defaultbutton: this.purchasesetup_defaultbutton,

        purchasesetup_lowsale: this.purchasesetup_lowsale,

        purchasesetup_rate: this.purchasesetup_rate,

        purchasesetup_bag: this.purchasesetup_bag,

        purchasesetup_qty: this.purchasesetup_qty,

        purchasesetup_displayhsncode: this.purchasesetup_displayhsncode,
        purchasesetup_tdsoptions: this.purchasesetup_tdsoptions,
        purchasesetup_focusaftersave: this.purchasesetup_focusaftersave
      };

    //  alert(JSON.stringify(exportData));
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var vall = {
        companyname: companyName,
        exportdata: exportData,
        note: "purchase"
      };

      axios
        .post("/SaveSpSetup", vall)
        .then(response => {
          var data = JSON.stringify(response.data);
          console.log(data)
          ////alert("go this response on save " + data);
        })
        .catch(error => {
          alert(error);
        });
    },
    // Add button

    getData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var exp = {
        companyname: companyName,
        directory: "sp_setup.json",
        note: "purchase"
      };

      axios
        .post("/getSpSetup", exp)
        .then(response => {
          var data = JSON.stringify(response.data);

          var json = JSON.parse(data);

          (this.date = json.date),
            (this.voucherno = json.voucherno),
            (this.purchasesetup_color = json.purchasesetup_color),
            (this.purchasesetup_custname = json.purchasesetup_custname);
          this.purchasesetup_terms = json.purchasesetup_terms;
          this.purchasesetup_vehicleno = json.purchasesetup_vehicleno;
          this.purchasesetup_taxtype = json.purchasesetup_taxtype;
          this.purchasesetup_billcash = json.purchasesetup_billcash;
          this.purchasesetup_purchaseac = json.purchasesetup_purchaseac;
          this.purchasesetup_duty = json.purchasesetup_duty;
          this.purchasesetup_product = json.purchasesetup_product;
          this.purchasesetup_remno1 = json.purchasesetup_remno1;
          this.purchasesetup_remno2 = json.purchasesetup_remno2;
          this.purchasesetup_remno3 = json.purchasesetup_remno3;
          this.purchasesetup_transport = json.purchasesetup_transport;
          this.purchasesetup_broker = json.purchasesetup_broker;
          this.purchasesetup_grnumber = json.purchasesetup_grnumber;
          this.purchasesetup_purimportgst = json.purchasesetup_purimportgst;
          this.purchasesetup_cgstac1 = json.purchasesetup_cgstac1;
          this.purchasesetup_cgstac2 = json.purchasesetup_cgstac2;
          this.purchasesetup_cgstac3 = json.purchasesetup_cgstac3;
          this.purchasesetup_sgstac1 = json.purchasesetup_sgstac1;
          this.purchasesetup_sgstac2 = json.purchasesetup_sgstac2;
          this.purchasesetup_sgstac3 = json.purchasesetup_sgstac3;
          this.purchasesetup_igstac1 = json.purchasesetup_igstac1;
          this.purchasesetup_igstac2 = json.purchasesetup_igstac2;
          this.purchasesetup_igstac3 = json.purchasesetup_igstac3;
          this.purchasesetup_tcsac = json.purchasesetup_tcsac;

          this.purchasesetup_tcscessac = json.purchasesetup_tcscessac;

          this.purchasesetup_tcsrateall = json.purchasesetup_tcsrateall;
          this.purchasesetup_csta = json.purchasesetup_csta;

          this.purchasesetup_freight = json.purchasesetup_freight;
          this.purchasesetup_comm = json.purchasesetup_comm;
          this.purchasesetup_others = json.purchasesetup_others;
          this.purchasesetup_expense5 = json.purchasesetup_expense5;
          this.purchasesetup_expense6 = json.purchasesetup_expense6;
          this.purchasesetup_expense7 = json.purchasesetup_expense7;
          this.purchasesetup_expense8 = json.purchasesetup_expense8;
          this.purchasesetup_v1 = json.purchasesetup_v1;
          this.purchasesetup_v2 = json.purchasesetup_v2;
          this.purchasesetup_v3 = json.purchasesetup_v3;
          this.purchasesetup_v4 = json.purchasesetup_v4;
          this.purchasesetup_v5 = json.purchasesetup_v5;
          this.purchasesetup_v6 = json.purchasesetup_v6;
          this.purchasesetup_v7 = json.purchasesetup_v7;
          this.purchasesetup_v8 = json.purchasesetup_v8;
          this.purchasesetup_disableinvtime = json.purchasesetup_disableinvtime;
          this.purchasesetup_disablerevtime = json.purchasesetup_disablerevtime;
          this.purchasesetup_acnameinled = json.purchasesetup_acnameinled;
          this.purchasesetup_remarkspost = json.purchasesetup_remarkspost;
          this.salesummary2_19 = json.salesummary2_19;
          this.purchasesetup_showwindowexpbeforetax =
            json.purchasesetup_showwindowexpbeforetax;
          this.purchasesetup_showwindowexpafterttax =
            json.purchasesetup_showwindowexpafterttax;

          this.purchasesetup_itemnameinled = json.purchasesetup_itemnameinled;

          this.purchasesetup_extraremarks = json.purchasesetup_extraremarks;

          this.purchasesetup_roundoff = json.purchasesetup_roundoff;

          this.purchasesetup_taxroundoff = json.purchasesetup_taxroundoff;

          this.purchasesetup_displayitem = json.purchasesetup_displayitem;

          this.purchasesetup_defaultbutton = json.purchasesetup_defaultbutton;

          this.purchasesetup_lowsale = json.purchasesetup_lowsale;

          this.purchasesetup_rate = json.purchasesetup_rate;

          this.purchasesetup_bag = json.purchasesetup_bag;

          this.purchasesetup_qty = json.purchasesetup_qty;

          this.purchasesetup_displayhsncode = json.purchasesetup_displayhsncode;
          this.purchasesetup_tdsoptions = json.purchasesetup_tdsoptions;
          this.purchasesetup_focusaftersave = json.purchasesetup_focusaftersave;
        })
        .catch(error => {
          alert(error);
        });
    },

    moveFocus(index) {
      if (this.elements[index]) {
        this.elements[index].focus();
      }
      console.log("b");
    }
  },
  created() {
    let that = this;
    that.getData();


    
  }
};
</script>





