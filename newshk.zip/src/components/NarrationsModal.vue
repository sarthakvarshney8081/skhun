<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}
#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

#wrapperPopUpAdd {
  width: 100%;
}

.vs-button {
  display: inline-block;
}

.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>

<template>
  <div class="vx-card p-6" style>

    
    <!-- popup definition starts -->
  <div class="modalnarration">
      
      <div class="search-wrapper" name="divpopupActive3">
        <tr>
          <td>
            <label>Search:</label>
          </td>

          <td style="padding-left:10px;" name="tdpopupActive3">
            <vs-input
              class="w-full"
              size="small"
              type="text"
             id="filterbar2"
              ref="filterbar2"
              v-model="filterbar2"
              @input="filteredList2()"
            />
          </td>
        </tr>
      </div>
      <br />

      <div>
        <vs-table v-model="selected2" @selected="handleSelected2" :data="filteredNarrations">
          <template slot-scope="{data}">
            <vs-tr
              :data="tr"
              :key="indextr"
              v-for="(tr, indextr) in data"
              :id="'navPopupListItem'+indextr"
            >
              <vs-td size="small">
                <ul class="centerx">
                  <input type="checkbox" :id="'narrationCheck'+indextr" value="kuch" />
                </ul>
              </vs-td>
              <vs-td size="small">{{ data[indextr].name }}</vs-td>
            </vs-tr>
          </template>
        </vs-table>
      </div>
      <div>
        <tr>
          <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              title="Add"
              color="primary"
              id="narAddButtonPopup"
              @click="showAddPopupNarration()"
            >Add</vs-button>
          </td>
          <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Modify"
              color="primary"
              id="modifyButtonPopup"
              @click="narrationModify()"
            >Modify</vs-button>
          </td>
          <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Delete"
              color="primary"
              id="deleteButtonPopup"
              @click="narrationDelete()"
            >Delete</vs-button>
          </td>
        </tr>
      </div>
      <vs-popup
        classContent="popup"
        title="Add New Narration"
        :active.sync="popupActive5"
        id="popupActive5"
        name="popupActive5"
      >
        <br />
        <div>
          <vs-tr>
            <vs-td>
              Narration:
              <vs-input
                type="text"
                
                id="newNarr"
                ref="newNarr"
                v-model="newNarration"
                size="10"
                style="width:700px; height:20px;"
              />
            </vs-td>
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="AddNewNarration()"
              >Add New Narration</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
      <vs-popup classContent="popup" title="Modify Narration" :active.sync="popupActive6">
        <br />

        <div>
          <vs-tr>
            <vs-td >
              Old Narration Text:
              <vs-input   type="text" v-model="oldNarrationToEdit" id="oldNarrationToEdit"   style="width:700px; height:20px;"/>
            </vs-td>
         
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="narrationModify2()"
              >Modify Narration</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
    

</div>
</div>
</template>
<script>
import axios from "@/axios";

export default {

  name: "modalnarration",

  props: {
    parentData: String,
  },
data(){
return{
  lastNar:"",
  boo:"false",
      currentrow:"",
      jony:false,
      modifyledgerindex: -1,
      popupActiveModifyLedgerInput: "",
      popupActiveModifyLedger: false,
      modalOpen: false,
      rolet: "admin",
      secDate: null,
      secDays: null,
      addPerm: false,
      deletePerm: false,
      modifyPerm: false,
      downArrowPopupActive: false,
      dapWeight: "",
      dapRate: "",
      dapBillno: "",
      dapVehicle: "",
      keyval:"",
      dapStkItem: "",
      dapRecno: "",
      dapTxType: "",
      dap1: "",
      dap2: "",
      dap3: "",
      activeConfirmDelete: false,
      localFields: { text: "Game", value: "Id" },
      localWaterMark: "Select a game",
      autofill: true,
      spdata: [],
      companyname: "",
      original: "",
      allowcustom: true,
      voucherno: "",
      cashformdata: null,
      rowlength: 1,
      sportsData: [
        "Badminton",
        "Basketball",
        "Cricket",
        "Football",
        "Golf",
        "Gymnastics",
        "Hockey",
        "Rugby",
        "Snooker",
        "Tennis"
      ],
      narrationIndex: null,
     
      height11: "250px",
      remoteFields: { text: "FirstName", value: "EmployeeID" },
    
      remoteWaterMark: "Select a name",
      selectedDropdown: "accountname",
      paymentTotal: 0.0,
      receiptTotal: 0.0,
      discountTotal: 0.0,
      disAdd: false,
      disCopy: true,
      disDelete: true,
      disEdit: false,
      disFirst: true,
      disLast: true,
      disNext: true,
      disSave: true,
      disSearch: true,
      disPrinter: true,
      disPrevious: true,
      disExit: false,
      buttonen: false,
      date: null,
      due: null,

      handleSearch: "hello",
      configdateTimePicker: {
        allowInput: true,

        dateFormat: "d-m-Y"
      },
      titleAction: "",

      buttondis: true,
      disVoucher: true,
      disDate: true,
      totalcount: 0,
      cashVauchers: [
        {
          accountno: "",
          narration: [],
          payment: "",
          receipt: "",
          discount: "",
           weight: "",
        billno: "",
        rate:   "",     
        date:   "",  
        vehicle: "",
        stkitem:"",
        recno:  "",      
         from:  "",   
         upto:  "",   
         txtype:  ""       }
      ],
      cashheaders: [
        "Account Name",
        "Narration",
        "Payment",
        "Receipt",
        "Discount",
        "Delete"
      ],
      selected: [],
      tableList: [
        "vs-th: Component",
        "vs-tr: Component",
        "vs-td: Component",
        "thread: Slot",
        "tbody: Slot",
        "header: Slot"
      ],
      filterbar2: "",
      filteredUsers: [],
      tabledata: [],
      users: [],
      narrations: [],
      filteredNarrations: [],
      newAccountName: " ",
      newCityName: " ",
      newGSTIN: " ",
      newAddress: " ",
      newContact: " ",
      newMobile: " ",
      // popup data
      popupDataList: [
        {
          memberId: "99887765",
          firstName: "firstName1",
          middleName: "middlename1",
          lastName: "lastname1",
          address: "address1"
        },
        {
          memberId: "99887764",
          firstName: "firstName2",
          middleName: "middlename2",
          lastName: "lastname2",
          address: "address2"
        },
        {
          memberId: "98766542",
          firstName: "firstName3",
          middleName: "middlename3",
          lastName: "lastname3",
          address: "address3"
        },
        {
          memberId: "99453533",
          firstName: "firstName4",
          middleName: "middlename4",
          lastName: "lastname4",
          address: "address4"
        },
        {
          memberId: "96546464",
          firstName: "firstName5",
          middleName: "middlename5",
          lastName: "lastname5",
          address: "address5"
        },
        {
          memberId: "95465357",
          firstName: "firstName6",
          middleName: "middlename6",
          lastName: "lastname6",
          address: "address6"
        },
        {
          memberId: "95374883",
          firstName: "firstName7",
          middleName: "middlename7",
          lastName: "lastname7",
          address: "address7"
        }
      ],

      // buttonList: [
      //   ["addButton", "inactive"],
      //   ["editButton", "inactive"],
      //   ["previousButton","inactive"],
      //   ["nextButton", "inactive"],
      //   ["firstButton", "inactive"],
      //   ["lastButton","inactive"],
      //   ["searchButton", "inactive"],
      //   ["moveButton", "inactive"],
      //   ["printButton", "inactive"],
      //   ["deleteButton"," inactive"],
      //   ["exitButton", "inactive"],
      //   ["saveButton","inactive"]
      // ],
      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],

      popupHeaders: [
        { title: "Account Name", show: true, headerUse: "accountname" },
        { title: "City Name", show: true, headerUse: "cityname" },
        { title: "Address", show: true, headerUse: "address" },
        { title: "GSTIN", show: true, headerUse: "gstin" },
        { title: "Contact No", show: true, headerUse: "contactno" },
        { title: "Mobile", show: true, headerUse: "mobileno" }
      ],

narpopupstable:false,
      popupDropdownSelected: "s_name",
      popupSelectedRow: 0,
      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
      originalvoucherno: 0,
      popupActive2: false,
      popupActive3: false,
      popupActive4: false,
      popupActive5: false,
      popupActive6: false,
      setId:"",
      oldNarrationToEdit: "",
      modifiedNarration: "",
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false,
      autocopyNarration: "Data From Last Form"
}
},

  created(){
   
  },
  methods:{
     filteredList2() {
      // //alert("p");
      let p = this.filterbar2.trim().toLowerCase();
      var searchtag = "accountname";

          var search;
         
         
      this.filteredNarrations = [];

      if (p == "") {
        this.filteredNarrations = this.narrations;
      } else {
        for (var x in this.narrations) {
          //let id = this.users[x].id.toLowerCase();
          searchtag = this.narrations[x].name.toLowerCase();

 search = searchtag.trim();
 
          if (search.indexOf(p) == 0) {
            // alert(searchtag);
            this.filteredNarrations.push(this.narrations[x]);
          }
        }
      }
      this.popupSelectedRow = 0;
    },
        popupKeyDown() {
      //
      
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (
        this.popupSelectedRow == this.filteredNarrations.length - 1 ||
        this.popupSelectedRow >= 15
      ) {
        this.popupSelectedRow = -1;
      }
      this.popupSelectedRow = this.popupSelectedRow + 1;
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
       popupKeyUp() {
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (this.popupSelectedRow == 0) {
        this.filteredUsers.length < 100
          ? (this.popupSelectedRow = this.filteredNarrations.length)
          : (this.popupSelectedRow = 15);
      }
      this.popupSelectedRow = this.popupSelectedRow - 1;
      document.getElementById(
        "navPopupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
setValue(value,id){

if(parseInt(this.popupSelectedRow+"")>0)
{for(let i=parseInt(this.popupSelectedRow+"");i>0;i--)
{this.popupKeyUp()}}
else if(parseInt(this.popupSelectedRow+"")>0)
{this.popupKeyDown();
this.popupKeyUp()}
  this.boo="true"
 this.setId=id
 document.getElementById("filterbar2").id="filterbar2"+this.setId

 document.getElementById("filterbar2"+this.setId).focus()
  this.narpopupstable=true
  var user = sessionStorage.getItem("user");
   var companyName = JSON.parse(user)[0].companyname;
    this.companyname = companyName;
var that=this
var i
var flag=0;
    
     var value2 = { companyname: companyName, directory: "narration.json" };
 axios
      .post("/user/getCashformData", value2)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
        this.keyval=value

        json.narrations.filter(function(item, index) {
          
          if (item[value] + "" != "undefined") {
            that.narrations = json.narrations[index][value];

            that.filteredNarrations = that.narrations;
            var v = [];

            for (i = 0; i < that.narrations.length; i++) {
              v.push(that.narrations[i].name + "");
              that.spdata = v;
            }
         flag=1;
          }
          else{
            if(flag==0)
            {that.spdata=[]
            that.filteredNarrations=[]
            }
          }
        });
      })
      .catch(error => {
        alert(error);
      });


     
},

 narrationModify2() {
      let n = 0;
      var fin;
      this.narrations.forEach(y => {
        if (y.name == this.lastNar) {
          this.narrations[n].name = this.oldNarrationToEdit;
          fin = n;
        }
        n++;
      });
      this.spdata = this.narrations;
      var that = this;
      this.spdata = [];
      this.filteredNarrations=this.narrations;
      //
      ////alert(this.spdata)
      for (let i = 0; i < this.narrations.length; i++) {
        this.spdata.push(this.narrations[i].name + "");
      }

      
      var input = {
        companyname: this.companyname,
        inputval: this.oldNarrationToEdit,
        key: this.keyval,
        index: fin
      };
      axios.post("/modifyNarration", input).then(response => {
        that.narrations = JSON.parse(JSON.stringify(response.data));
      });
      
 this.popupActive6=false
      this.$emit('spdatareceived',this.spdata);
    },

     longfunctionfirstNarration(t) {
        
       return new Promise(resolve => {
   if(t=="popupActive5")
    {  this.popupActive5 = true;
     
      resolve('resolved');
    }
    else if(t=="popupActive3")
    {this.popupActive3 = true;
      
      resolve('resolved');}
       else if(t=="editbutton")
    { this.buttondis =false 
      
      resolve('resolved');}
        else if(t=="popupActive6")
    { this.popupActive6=true
      resolve('resolved');}
       else if(t=="modifyLedger")
    { this.popupActiveModifyLedger=true
      resolve('resolved');}

     
  
  });
       
   
},
 async shortfunctionsecondNarration(g) {
   if(g=="popupActive5")
  {await this.longfunctionfirstNarration(g);
  
  document.getElementById("newNarr").focus()
  }
  else if(g=="popupActive3")
  {const result= await this.longfunctionfirstNarration(g);
   console.log(result)
  document.getElementById("filterbar2").focus();
}
 else if(g=="editbutton")
  {//alert("here")
    const result= await this.longfunctionfirstNarration(g);
     console.log(result)
    var p=this.rowlength-1
  document.getElementById('0'+p).focus();
}
else if(g=="newvoucher")
  {//alert("here")
    const result= await this.longfunctionfirstNarration("editbutton");
     console.log(result)
   document.getElementById('0'+0).focus();
}
else if(g=="popupActive6")
  {//alert("here")
    const result= await this.longfunctionfirstNarration("popupActive6");
     console.log(result)
    
   document.getElementById("oldNarrationToEdit").focus();
}
else if(g=="modifyLedger")
  {//alert("here")
    const result= await this.longfunctionfirstNarration("modifyLedger");
    console.log(result)
   document.getElementById("modifybox").focus();
}


},

    showAddPopupNarration() {
     
    this.shortfunctionsecondNarration("popupActive5")
 },
    narrationModify() {
      var indexList = [];
      //
      ////alert(indexList);
      for (var x = 0; x < this.filteredNarrations.length; x++) {
        let p = "narrationCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.filteredNarrations[x]);
          document.getElementById(p).checked = false;
        }
      }

      this.oldNarrationToEdit = indexList[0].name;
      
this.lastNar=this.oldNarrationToEdit 
     this.shortfunctionsecondNarration("popupActive6")

      //
      //////alert("To be added after permission  check is done");
    },
     narrationDelete() {
    //  alert(document.getElementById('filterbar2'+this.setId).value+" sd")
      var indexList = [];
      //
      ////alert(indexList);
      for (var x = 0; x < this.filteredNarrations.length; x++) {
        let p = "narrationCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.filteredNarrations[x]);
          document.getElementById(p).checked = false;
        }
      }
 var g;
      indexList.forEach(x => {
        var n = 0;
       
        this.narrations.forEach(y => {
          if (y.name == x.name) {
            this.narrations.splice(n, 1);
            g=n;
          }
          n++;
        });
      });
      this.spdata = [];
      this.filteredNarrations=this.narrations;
      //
      ////alert(this.spdata)
      for (let i = 0; i < this.narrations.length; i++) {
        this.spdata.push(this.narrations[i].name + "");
      }

      var input = {
        companyname: this.companyname,
        inputval: this.modifiedNarration,
        key: this.keyval,
        index: g+1
      };
      var that=this;
      axios.post("/deleteNarration", input).then(response => {
        that.narrations = JSON.parse(JSON.stringify(response.data));
      });

 
     this.$emit('spdatareceived',this.spdata);
    },
    AddNewNarration() {
      // var newId = this.narrations[this.narrations.length - 1].id + 1;

      // var p = {
      //   id: newId,
      //   AcName: " ",
      //   City: "",
      //   Address2: " ",
      //   DGSTNo: this.newNarration,
      //   ContactNo: " ",
      //   Mobile: " "
      // };

      var value = {
        narrations: []
      };
      var that = this;
      var value1 = {
        companyname: this.companyname,
        value: value,
        key: this.keyval,
        data: this.newNarration
      };
      axios
        .post("/addNarration", value1)
        .then(response => {
          //alert(response.data)
          that.narrations = JSON.parse(JSON.stringify(response.data));

          that.filteredNarrations = that.narrations;
          // //
          // //////alert("pooooop" + that.users[that.users.length - 1].accountname);
          that.newNarration = " ";

          that.popupActive5 = false;
          that.spdata = [];
          
          // //
          // ////alert(that.spdata)
          //  ////alert("api called 2")
          for (let i = 0; i < that.narrations.length; i++) {
            that.spdata.push(that.narrations[i].name + "");
           
          }
that.$emit('spdatareceived',that.spdata);
          
        })
        .catch(error => {
          alert(error);
        });
 
      this.$forceUpdate();

      
    },
     isnarration(n) {
      if (n == 1) return true;
      else return false;
    },
  },
mounted(){
   this.titleAction = "VIEW";

    let that = this;

 

    window.addEventListener("keyup", function(event) {
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
     if(that.boo=="true")
   { 
     
       document.getElementById("filterbar2"+that.setId).id="filterbar2"
       that.boo="false"
           that.$emit(
              "childToParentNarration","closenarration"
            );    
     
     if (that.popupActive2 == true) {
          that.popupActive2 = false;
          that.cashVauchers[that.rowNumberIndicator].accountno = "";
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        if (that.popupActive3 == true) {
          that.popupActive3 = false;
          that.cashVauchers[that.rowNumberIndicator].narration = "";
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }

   }
      }
      if (event.keyCode === 40) {
        // down arrow
       
       if(that.boo=="true"){ 
         that.popupKeyDown();
       }
          //
          //////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
   
      }

      if (event.keyCode === 38) {
        // up arrow
        
if(that.boo=="true"&&that.popupActive6==false)          
{that.popupKeyUp();
      that.$forceUpdate();     
      }
          //
          //////alert("poop");
          // Need to force an update cuz changing a variable doesn't load the state automatically
        
        if (that.popupActive3 == true) {
          that.navPopupKeyUp();
          //
          //////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }

      if (event.keyCode === 13) {
        // enter
  
if(that.boo=="true"&&that.popupActive6==false&&that.popupActive5==false)
  {
    document.getElementById("filterbar2"+that.setId).id="filterbar2"
    that.$emit('childToParentNarration', that.filteredNarrations[that.popupSelectedRow].name+":"+that.keyval)
      
   that.boo="false" 
  }
 else if (that.popupActive6==true&&that.popupActive5==false)
 {
   that.narrationModify2()
 }
 else if(that.popupActive5==true&&that.popupActive6==false)
 {that.AddNewNarration()}
        if (that.popupActive2 == true) {
          //alert("clicked")
       
            that.$emit('childToParentNarration',that.filteredNarrations[that.popupSelectedRow].name+":"+that.keyval)
          
          that.popupActive2 = false;
          //
          ////alert(that.rowNumberIndicator);
          document.getElementById("filter" + that.rowNumberIndicator).focus();
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
   
      }
    });


    
}
  

}
</script>
