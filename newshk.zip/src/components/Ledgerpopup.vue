<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}

#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

#wrapperPopUpAdd {
  width: 100%;
}

.vs-button {
  display: inline-block;
}

.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>
   <template>
  <div class="modal">
    <div class="vx-card p-6" style>
      <div class="search-wrapper" align="right" >
        <tr>
          <td style="padding-right:50px;">
            <label>
              <b>
                <font size="5">Ledger Accounts</font>
              </b>
            </label>
          </td>
          <td>
            <label>Filter:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              size="small"
              type="text"
              id="filterbar"
              v-model="filterbar"
              @input="filteredList()"
            />
          </td>
        </tr>
      </div>
      <br />

      <div>
        <vs-table  v-model="selectedhead" :data="tabledata"
        @dblSelection="enterpressed">
          <template slot="thead" style="background-color:primary">
            <vs-th
              v-for=" i in popupHeaders "
              :key="i"
              sort-key="i.headeruse"
              v-show="i.show"
            >{{i.title}}</vs-th>
          </template>

          <template slot-scope="{data}">
            <vs-tr
              :data="tr"
              :key="indextr"
              
              v-for="(tr, indextr) in data"
              
              :id="'popupListItemLedger'+indextr"
            >
              <vs-td v-show="isShow(0)" :data="data[indextr].AcName" :disabled="true">
                {{ data[indextr].AcName }}
                <template slot="edit">
                  <vs-input
                    v-model="data[indextr].AcName"
                    class="w-full"
                    @click="setvalue(indextr)"
                  />
                </template>
              </vs-td>

              <vs-td v-show="isShow(1)" :data="data[indextr].City">
                {{ data[indextr].City }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].City" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(2)" :data="data[indextr].Address2">
                {{ data[indextr].Address2 }}
                <template slot="edit">
                  <vs-input v-model=" data[indextr].Address2" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(3)" :data="data[indextr].DGSTNo">
                {{ data[indextr].DGSTNo }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].DGSTNo" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(4)" :data="data[indextr].ContactNo">
                {{ data[indextr].ContactNo }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].ContactNo" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(5)" :data="data[indextr].Mobile">
                {{ data[indextr].Mobile}}
                <template slot="edit">
                  <vs-input v-model="data[indextr].Mobile" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td>
                <vs-button
                  size="small"
                  title="Select"
                  color="primary"
                  :id="'select'+indextr"
                  @click="handleSelected(indextr)"
                  class="w-full"
                >select</vs-button>
              </vs-td>
            </vs-tr>
          </template>
        </vs-table>

         <vs-pagination v-model="pagenumber"  :total="pagelength" />
      </div>
      <div>
        <tr>
          <td>
            <label>Search:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              width="120"
              type="text"
              id="searchbarledger"
             
              v-model="searchbarledger"
              @input="searchedList(-1)"
              @change="searchedList(-1)"
            />
          </td>
          <td style="padding-left:10px;">
            <select @change="searchedList(-1)" v-model="selectedDropdown">
              <option disabled value>Please select one</option>
              <option value="accountname">Search By Name</option>
              <option value="cityname">Search By City</option>
              <option value="address">Search By Address</option>
              <option value="gstin">Search By GSTIN</option>
              <option value="contactno">Search By Contact</option>
              <option value="mobile">Search By Mobile</option>
            </select>
          </td>
          <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              title="Add"
              color="primary"
              id="addButtonPopup"
              @keyup.right="buttonNext('saveButton')"
              @keyup.left="buttonPrev('saveButton')"
              @click="showAddPopup()"
            >Add</vs-button>
          </td>

           <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              
              title="Edit"
              color="primary"
              id="addButtonPopup"
              @keyup.right="buttonNext('saveButton')"
              @keyup.left="buttonPrev('saveButton')"
              @click="EditSelectedRow"
            >Edit</vs-button>
          </td>
          <!-- <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Modify"
              color="primary"
              id="modifyButtonPopup"
              @keyup.right="buttonNext('saveButton')"
              @keyup.left="buttonPrev('saveButton')"
              @click="save()"
            >Modify</vs-button>
          </td>-->

          <td>
            <vs-collapse>
              <vs-collapse-item>
                <div slot="header">
                  Settings
                  <!-- <vs-button color="#FFFFFF" type="filled" size="small">
                    <vs-icon icon="settings" size="small" color="red"></vs-icon>
                  </vs-button>-->
                </div>
                <ul class="centerx">
                  <li>
                    <vs-checkbox v-model="CheckBox1" vs-value="accountname">Account Name</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox2" vs-value="cityname"></vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox3" vs-value="address">Address</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox4" vs-value="gstin">GSTIN</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox5" vs-value="contactno">Contact No</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox6" vs-value="phoneno">Phone No</vs-checkbox>
                  </li>
                  <li>
                    <vs-button
                      color="primary"
                      type="filled"
                      v-model="submitHeaders"
                      title="Save"
                      @click="changeHeaders"
                    >Save</vs-button>
                  </li>
                </ul>
              </vs-collapse-item>
            </vs-collapse>
          </td>
        </tr>
      </div>

      <!-- Popup Inside a popup for adding an entry -->
      <vs-popup
        classContent="popup-example"
        fullscreen
        button-close-hidden="true"
        title="Add New Ledger Account"
        
        :active.sync="popupActiveLedgerModal"
      >
        <modal-direction v-model="modalOpenLedgerModal" ref="childComponentLedgerModal"></modal-direction>
      </vs-popup>

      <vs-popup
        classContent="popup-example"
        title="Modify Ledger Account"
        :active.sync="popupActiveModifyLedger"
      >
        <br />
        <div>
          <vs-tr>
            <vs-td>
              New Ledger:
              <vs-input
                type="text"
                id="modifybox"
                ref="modifybox"
                v-model="popupActiveModifyLedgerInput"
                size="10"
                style="width:700px; height:20px;"
              />
            </vs-td>
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="AddModifiedLedger()"
              >Add Modified Ledger</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
    </div>
  </div>
</template>


<script>
import axios from "axios";
import ModalDirection from "@/components/ledgermodal2.vue";

export default {
  name: "modal",
  props: {
    SearchText: String
  },
  data() {
    return {
      emptyobj: {
          AcCode: "",
          //AcCode,
          AcName: "",
          //AcNam,
          Address1: "",
          //Address1,
          BankACName: "",
          //BankACName,
          Address2: "",
          //Address2,
          IFSCCode: "",
          //IFSCCode,
          BankACNo: "",
          //BankACNo,
          v: "",
          //v,
          City: "",
          //City,
          state: "",
          //State,
          Division: "",
          //Division,
          PinCode: "",
          //PinCode,
          Collectorate: "",
          //Collectorate,
          Distt: "",
          //Distt,
          DGSTNo: "",
          //DGSTNo,
          SACCode: "",
          //SACCode,
          Distance: "",
          //Distance,
          OpeningBalanceDr: "",
          //OpeningBalanceDr,
          ContactPerson: "",
          //ContactPerson,
          OpeningBalanceCr: "",
          //OpeningBalanceCr,
          InttDepcRate: "",
          //InttDepcRate,
          ContactNo: "",
          //ContactNo,
          TDSRate: "",
          //TDSRate,
          MEmailIDArea: "",
          //comboemail,
          Area: "",
          //comboarea,
          TGSTShare: "",
          //TGSTShare,
          AgentGroup: "",
          //combogroup,
          Quantitiy: "",
          //Quantitiy,
          PAN: "",
          //PAN,
          AadhaarNo: "",
          //AadhaarNo,
          TDSAcNo: "",
          //TDSAcNo,
          CompositionYN: "",
          //CompositionYN,
          Works: "",
          //Works,
          NameAddress1: "",
          //NameAddress1,
          NameAddress2: "",
          //NameAddress2,
          index: "",
          //dbIndex == "" ? null : this.dbIndex
        },
      tabledata:[],
      pagenumber:1,
      pagelength:150,
      CheckBox1: true,
      CheckBox2: true,
      CheckBox3: true,
      CheckBox4: true,
      CheckBox5: true,
      CheckBox6: true,
      selectedhead:[],
      modalOpenLedgerModal:"",
      setId:"",
      modifyledgerindex: -1,
      popupActiveModifyLedgerInput: "",
      popupActiveModifyLedger: false,
      modalOpen: false,

      rolet: "admin",
      secDate: null,
      secDays: null,
      addPerm: false,
      deletePerm: false,
      modifyPerm: false,
      downArrowPopupActive: false,
      dapWeight: "",
      dapRate: "",
      dapBillno: "",
      dapVehicle: "",
      dapStkItem: "",
      dapRecno: "",
      dapTxType: "",
      dap1: "",
      dap2: "",
      dap3: "",
      activeConfirmDelete: false,
      localFields: { text: "Game", value: "Id" },
      localWaterMark: "Select a game",
      autofill: true,
      spdata: [],
      companyname: "",
      original: "",
      allowcustom: true,
      voucherno: "",
      cashformdata: null,
      rowlength: 1,
      sportsData: [
        "Badminton",
        "Basketball",
        "Cricket",
        "Football",
        "Golf",
        "Gymnastics",
        "Hockey",
        "Rugby",
        "Snooker",
        "Tennis"
      ],
      narrationIndex: null,
      data: "",
      height11: "250px",

      remoteWaterMark: "Select a name",
      selectedDropdown: "accountname",
      paymentTotal: 0.0,
      receiptTotal: 0.0,
      discountTotal: 0.0,
      disAdd: false,
      disCopy: true,
      disDelete: true,
      disEdit: false,
      disFirst: true,
      disLast: true,
      disNext: true,
      disSave: true,
      disSearch: true,
      disPrinter: true,
      disPrevious: true,
      disExit: false,
      buttonen: false,
      date: null,
      due: null,

      handleSearch: "hello",
      configdateTimePicker: {
        allowInput: true,

        dateFormat: "d-m-Y"
      },
      titleAction: "",

      buttondis: true,
      disVoucher: true,
      disDate: true,
      totalcount: 0,
      cashVauchers: [
        {
          accountno: "",
          narration: [],
          payment: "",
          receipt: "",
          discount: ""
        }
      ],
      cashheaders: [
        "Account Name",
        "Narration",
        "Payment",
        "Receipt",
        "Discount",
        "Delete"
      ],
      selected: [],
      tableList: [
        "vs-th: Component",
        "vs-tr: Component",
        "vs-td: Component",
        "thread: Slot",
        "tbody: Slot",
        "header: Slot"
      ],
      filterbar2: "",
      filterbar:"",
searchbarledger:"",
      filteredUsers: [],
     
      users: [],
      narrations: [],
      filteredNarrations: [],
      newAccountName: " ",
      newCityName: " ",
      newGSTIN: " ",
      newAddress: " ",
      newContact: " ",
      newMobile: " ",
      // popup data
      popupDataList: [
        {
          memberId: "99887765",
          firstName: "firstName1",
          middleName: "middlename1",
          lastName: "lastname1",
          address: "address1"
        },
        {
          memberId: "99887764",
          firstName: "firstName2",
          middleName: "middlename2",
          lastName: "lastname2",
          address: "address2"
        },
        {
          memberId: "98766542",
          firstName: "firstName3",
          middleName: "middlename3",
          lastName: "lastname3",
          address: "address3"
        },
        {
          memberId: "99453533",
          firstName: "firstName4",
          middleName: "middlename4",
          lastName: "lastname4",
          address: "address4"
        },
        {
          memberId: "96546464",
          firstName: "firstName5",
          middleName: "middlename5",
          lastName: "lastname5",
          address: "address5"
        },
        {
          memberId: "95465357",
          firstName: "firstName6",
          middleName: "middlename6",
          lastName: "lastname6",
          address: "address6"
        },
        {
          memberId: "95374883",
          firstName: "firstName7",
          middleName: "middlename7",
          lastName: "lastname7",
          address: "address7"
        }
      ],

      // buttonList: [
      //   ["addButton", "inactive"],
      //   ["editButton", "inactive"],
      //   ["previousButton","inactive"],
      //   ["nextButton", "inactive"],
      //   ["firstButton", "inactive"],
      //   ["lastButton","inactive"],
      //   ["searchButton", "inactive"],
      //   ["moveButton", "inactive"],
      //   ["printButton", "inactive"],
      //   ["deleteButton"," inactive"],
      //   ["exitButton", "inactive"],
      //   ["saveButton","inactive"]
      // ],
      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],

      popupHeaders: [
        { title: "Account Name", show: true, headerUse: "accountname" },
        { title: "City Name", show: true, headerUse: "cityname" },
        { title: "Address", show: true, headerUse: "address" },
        { title: "GSTIN", show: true, headerUse: "gstin" },
        { title: "Contact No", show: true, headerUse: "contactno" },
        { title: "Mobile", show: true, headerUse: "mobileno" }
      ],

      popupDropdownSelected: "s_name",
      popupSelectedRow: 0,
      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
      originalvoucherno: 0,
     
      popupActive3: false,
      popupActiveLedgerModal: false,
      popupActive5: false,
      popupActive6: false,
      oldNarrationToEdit: "",
      modifiedNarration: "",
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false,
      autocopyNarration: "Data From Last Form",
      boole: "false"
    };
  },
  components: {
    ModalDirection
  },

   watch: {
    "pagenumber": function(newval) {
     var i
    this.tabledata=[]
     for(i=0;i<=7;i++)
     {
     
       if(this.filteredUsers[i+8*(parseInt(newval+"")-1)].AcName+""!="undefined")
     {this.tabledata[i]=this.filteredUsers[i+8*(parseInt(newval+"")-1)]
    
     
     }
     else
     {this.tabledata[i]=this.emptyobj
     }
   
     }
    }
  },
  methods: {
 EditSelectedRow(){

      this.popupActiveLedgerModal=true
     this.$refs.childComponentLedgerModal.getsearchdata(this.tabledata[this.popupSelectedRow].index,"edit"); 
     
    },

    enterpressed(tr)
    {
document.getElementById("searchbarledger"+this.setId).id="searchbarledger"
            this.boole="false"
            alert(this.selected)
          this.$emit(
            "childToParent",
            tr.AcName +
              ":" +
              tr.AcCode+":"+tr.index
          );
    },
    handleSelected(p) {
      //  alert('reached this atleast');
      let that = this;
      that.$emit(
        "childToParent",
        that.filteredUsers[p].AcName +
          ":" +
          that.filteredUsers[p].AcCode +
          ":" +
          that.filteredUsers[p].City +
              ":" +
              that.filteredUsers[p].DGSTNo+":"+ that.filteredUsers[p].PAN
              +":"+ that.filteredUsers[p].index+":"+that.filteredUsers[p].state
      );

    

      // if (that.popupActive2 == true) {
      //  // ////alert("clicked");

      //   that.$emit("childToParent", that.filteredUsers[p].AcName);

      //   that.popupActive2 = false;
      //   //
      //   //////alert(that.rowNumberIndicator);
      //   document.getElementById("filter" + that.rowNumberIndicator).focus();
      //   that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
      // }
    },
    setValue(boo,l,value) {
      alert("l is"+ l)
      if(l!="")
     { this.searchbarledger=value
       this.setId=l
     
       alert(document.getElementById("searchbarledger").value)
    document.getElementById("searchbarledger").id="searchbarledger"+l
    
   document.getElementById("searchbarledger"+l).focus()
     }
   this.boole = boo;
   
   if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }

      this.popupSelectedRow=0

       if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
  

this.pagenumber=2
this.pagenumber=1

this.searchedList(-1)
    },
    popupKeyDownLedgerPopup() {
      //
      
if(document.getElementById("popupListItemLedger" + parseInt(this.popupSelectedRow+1)))
{
  if(   document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }
     
      if (
        this.popupSelectedRow == this.filteredUsers.length - 1 ||
        this.popupSelectedRow > 6

      ) {
       
        this.popupSelectedRow = -1;
     
      }
      
      this.popupSelectedRow = this.popupSelectedRow + 1;
       if(   document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
          document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
   
}
else{
   if( document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ))
      { document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";}
    
  this.popupSelectedRow=0
    if(parseInt(this.pagenumber)+1<=this.pagelength)
        {
          this.pagenumber=parseInt(this.pagenumber)+1
        }
     document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
  
}
    },
    longfunctionfirstLedger(t) {
      return new Promise(resolve => {
        if (t == "popupActive5") {
          this.popupActive5 = true;
          alert(this.jony);
          resolve("resolved");
        } else if (t == "popupActive3") {
          this.popupActive3 = true;

          resolve("resolved");
        } else if (t == "editbutton") {
          this.buttondis = false;

          resolve("resolved");
        } else if (t == "dateprevnext") {
          resolve("resolved");
        } else if (t == "modifyLedger") {
          this.popupActiveModifyLedger = true;
          resolve("resolved");
        }
      });
    },
    async shortfunctionsecondLedger(g) {
      if (g == "modifyLedger") {
        const result = await this.longfunctionfirstLedger("modifyLedger");
        console.log(result);
        document.getElementById("modifybox").focus();
      }
    },
    showAddPopup() {
      alert(this.setId)
  // alert(document.getElementById("searchbarledger"+"salegst2").value)
      this.popupActiveLedgerModal = true;
      this.modalOpenLedgerModal=true
      this.modalOpen = !this.modalOpen;
      this.$forceUpdate();
    },
     changeHeaders() {
      this.CheckBox1 != null
        ? (this.popupHeaders[0].show = true)
        : (this.popupHeaders[0].show = false);
      this.CheckBox2 != null
        ? (this.popupHeaders[1].show = true)
        : (this.popupHeaders[1].show = false);
      this.CheckBox3 != null
        ? (this.popupHeaders[2].show = true)
        : (this.popupHeaders[2].show = false);
      this.CheckBox4 != null
        ? (this.popupHeaders[3].show = true)
        : (this.popupHeaders[3].show = false);
      this.CheckBox5 != null
        ? (this.popupHeaders[4].show = true)
        : (this.popupHeaders[4].show = false);
      this.CheckBox6 != null
        ? (this.popupHeaders[5].show = true)
        : (this.popupHeaders[5].show = false);

      this.$forceUpdate();
      //
      ////alert( +"   "+ this.CheckBox2 +"   " + this.CheckBox3 +"   "+ this.CheckBox4+"   " + this.CheckBox5 +"   "+ this.CheckBox6 );
    },
    isShow(k) {
      return this.popupHeaders[k].show;
    },
    searchedList(p) {
      //
     
      if (p + "" != "-1") {
        //
        var value;
        this.rowNumberIndicator = p;
        value = this.cashVauchers[this.rowNumberIndicator].accountno;
        value = document.getElementById("0" + p).value.toLowerCase();
        //

        ////alert(p+" is awesome")
        this.searchbarledger = value + "";
        this.popupSelectedRow = 0;

        
        document.getElementById("searchbarledger").focus();

        document.getElementById(
          "popupListItemLedger" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";

        this.searching(value);
        this.$forceUpdate();
      } else {
        value = this.searchbarledger.toLowerCase();

        this.searchedListNew(value)
      }
      //
      ////alert(p);
    },

    searchedListNew(value){
          var searchtag = "accountname";

      
      var g=0;
      //
      ////alert(searchtag);

      if (value + "" == "") {
        //
      this.pagenumber=1
      } else {
      let that=this
      
this.users.filter((item,index)=>{
          if (this.selectedDropdown == "accountname") {
            searchtag = item.AcName.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = item.City.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = item.Address2.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = item.DGSTNo.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = item.ContactNo.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = item.ContactNo.toLowerCase();
          }

          if (this.selectedDropdown == "")
            searchtag = item.AcName.toLowerCase();

                var search, p2;
          search = searchtag.trim();
          p2 = value.trim();
          if (search.indexOf(p2.toLowerCase()) == 0) {
            //
            ////alert(searchtag+" heya");
            if(g==0)
            {
               that.pagenumber=parseInt((index)/8)+1
             
if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }


      this.popupSelectedRow=(index)%8


       if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";

      }
 
              g=1}

        
       
          }
         
         
})

       
      }
    },
    searching(value) {
      
       
      var searchtag = "accountname";

      this.filteredUsers = [];
      var g=0;
      //
      ////alert(searchtag);

      if (value + "" == "") {
        //
      this.filteredUsers = this.users;
      } else {
      
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          //searchtag = this.users[x].accountname.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            searchtag = this.users[x].AcName.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = this.users[x].City.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].Address2.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].DGSTNo.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }

          if (this.selectedDropdown == "")
            searchtag = this.users[x].AcName.toLowerCase();
         
         var search, p2;
          search = searchtag.trim();
          p2 = value.trim();
          if (search.indexOf(p2.toLowerCase()) == 0) {
            //
            ////alert(searchtag+" heya");
            if(g==0)
            this.filteredUsers=[]
         this.filteredUsers.push(this.users[x]);
         g=1
       
          }
           else
          {
            if(g==0)
            {this.filteredUsers=[]
            this.filteredUsers=this.users}
          }
        
          
         }


       
      }
 if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }

      this.popupSelectedRow=0

       if(document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
  

    },
    filteredList() {
      
      //////alert("p");
      let p = document.getElementById("filterbar").value.toLowerCase();
      var searchtag = "accountname";
      this.filteredUsers = [];

      if (p == "") {
        this.users.sort();
        
        this.filteredUsers = this.users
      } else {
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            //
            //////alert("reached");
            searchtag = this.users[x].AcName.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = this.users[x].City.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].Address2.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].DGSTNo.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }

          if (searchtag.indexOf(p) != -1) {
            //
            ////alert(name);
            
            this.filteredUsers.push(this.users[x]);
          
          }
        
        }
      }
      this.popupSelectedRow = 0;
    },

    popupKeyUpLedgerPopup() {
      if(document.getElementById("popupListItemLedger" + parseInt(this.popupSelectedRow-1)))
      {
      if(   document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }
    
       if (this.popupSelectedRow == 0) {
        this.filteredUsers.length < 8
          ? (this.popupSelectedRow = this.filteredUsers.length)
          : (this.popupSelectedRow = 8);
      }
      this.popupSelectedRow = this.popupSelectedRow - 1;
     if( document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ))
      {
      document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
    }
    else
    {   
      if( document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ))
      { document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";}
      
      this.popupSelectedRow=0

       while(document.getElementById("popupListItemLedger" + parseInt(this.popupSelectedRow+1)))
    {
      this.popupSelectedRow++
      
    }
    

           if(parseInt(this.pagenumber)-1>0)
        {
          this.pagenumber=parseInt(this.pagenumber)-1
        }

       
  
      document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";


    }
    
    }
    
  ,
    setvalue(p) {
      ////alert("clicked"+p)
      this.popupActiveModifyLedgerInput = this.filteredUsers[p].AcName;
      this.modifyledgerindex = p;
      this.shortfunctionsecondLedger("modifyLedger");
    },

    AddModifiedLedger() {
      var n = {
        companyname: this.companyname,
        newval: this.popupActiveModifyLedgerInput,
        index: this.modifyledgerindex
      };
      var that = this;
      axios.post("/modifyLedgerName", n).then(response => {
        that.filteredUsers[that.modifyledgerindex].AcName =
          that.popupActiveModifyLedgerInput;
        that.popupActiveModifyLedger = false;
        console.log(response);
      });
    }
  },

  created() {
   

    var user = sessionStorage.getItem("user");
    var companyName = JSON.parse(user)[0].companyname;
    this.companyname = companyName;

    alert(companyName);
    var value1 = { companyname: companyName, directory: "ledger_master.json" };

    var that = this;
    axios
      .post("/user/getCashformData", value1)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
        that.users = json.ledgerdata;
    //    alert(JSON.stringify(that.users));
         that.users.sort();
         
         that.filteredUsers =that.users
this.pagelength=Math.ceil(this.filteredUsers.length/8)
             var i
     for(i=0;i<=7;i++)
     {
       this.tabledata[i]=this.filteredUsers[i]
   
     }
      })
      .catch(error => {
        alert(error);
      });
  },

  mounted() {
    this.titleAction = "VIEW";

    let that = this;

    window.addEventListener("keyup", function(event) {
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
      
         
        if (that.boole == "true") {
          alert(that.popupActiveLedgerModal)
         if(that.popupActiveLedgerModal==true)
         {
           that.popupActiveLedgerModal=false
         that.modalOpenLedgerModal=false

         var value1 = { companyname: that.companyname, directory: "ledger_master.json" };
axios
      .post("/user/getCashformData", value1)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
        that.users = json.ledgerdata;
    //    alert(JSON.stringify(that.users));
         that.users.sort();
         
         that.filteredUsers =that.users
      })
      .catch(error => {
        alert(error);
      });


         }
         else {
             document.getElementById("searchbarledger"+that.setId).id="searchbarledger"
            that.boole="false"
        
          that.$emit(
              "childToParent","closeledger"
            );
//           alert( document.getElementById("searchbarledger").value)
// alert( document.getElementById("searchbarledger"+that.setId).value)
//               document.getElementById("searchbarledger"+that.setId).focus()
         }

     
          if (that.popupActive3 == true) {
            that.popupActive3 = false;
            that.cashVauchers[that.rowNumberIndicator].narration = "";
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 40) {
        // down arrow

        if (that.boole == "true") {

           if(that.popupActiveLedgerModal==false)
          {
            that.popupKeyDownLedgerPopup();
          }
          //
          //////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically

          if (that.popupActive3 == true) {
            that.navpopupKeyDownLedgerPopup();
            //
            //////alert("poop");
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }

      if (event.keyCode === 38) {
        // up arrow
        if (that.boole == "true") {
           if(that.modalOpenLedgerModal==false)
          that.popupKeyUpLedgerPopup();
          //
          //////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically

          if (that.popupActive3 == true) {
            that.navpopupKeyUpLedgerPopup();
            //
            //////alert("poop");
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }

      if (event.keyCode === 13) {
        // enter
        if (that.boole == "true") {
        
      
           if(that.popupActiveLedgerModal==false&&that.popupActiveModifyLedger==false)
            {
               
              document.getElementById("searchbarledger"+that.setId).id="searchbarledger"
            that.boole="false"
         
          that.$emit(
            "childToParent",
            that.tabledata[that.popupSelectedRow].AcName +
              ":" +
              that.tabledata[that.popupSelectedRow].AcCode+":"+that.tabledata[that.popupSelectedRow].City
               +
              ":" +
              that.tabledata[that.popupSelectedRow].DGSTNo+":"+that.tabledata[that.popupSelectedRow].PAN
              +":"+ that.tabledata[that.popupSelectedRow].index+":"+that.tabledata[that.popupSelectedRow].state
          );
            }
            else if(that.popupActiveModifyLedger==true)
            {
              that.AddModifiedLedger()
            }

    
        }
      }
    });


 
  }
};
</script>

