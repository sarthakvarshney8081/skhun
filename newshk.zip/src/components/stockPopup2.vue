<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}

#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

#wrapperPopUpAdd {
  width: 100%;
}

.vs-button {
  display: inline-block;
}

.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>
   <template>
  <div class="modal">
    <div class="vx-card p-6" style>
      <div class="search-wrapper" align="right" :id="filterbar">
        <tr>
          <td style="padding-right:50px;">
            <label>
              <b>
                <font size="5">Stock Master</font>
              </b>
            </label>
          </td>
          <td>
            <label>Filter:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              size="small"
              type="text"
              id="filterbar"
              v-model="filterbar"
              @input="filteredList()"
            />
          </td>
        </tr>
      </div>
      <br />

      <div>
        <vs-table
          multiple
          v-model="selected"
          @selected="handleSelected2"
          pagination
          max-items="100"
          :data="filteredUsers"
        >
          <template slot="thead" style="background-color:primary">
            <vs-th
              v-for=" i in popupHeaders "
              :key="i"
              sort-key="i.headeruse"
              v-show="i.show"
            >{{i.title}}</vs-th>
          </template>

          <template slot-scope="{data}">
            <vs-tr
              :data="tr"
              :key="indextr"
              v-for="(tr, indextr) in data"
              :id="'popupListItem'+indextr"
            >
              <vs-td v-show="isShow(0)" :data="data[indextr].Name" :disabled="true">
                {{ data[indextr].Name }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].Name" class="w-full" @click="setvalue(indextr)" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(1)" :data="data[indextr].HSNCode">
                {{ data[indextr].HSNCode }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].HSNCode" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(2)" :data="data[indextr].TotalGST">
                {{ data[indextr].TotalGST }}
                <template slot="edit">
                  <vs-input v-model=" data[indextr].TotalGST" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(3)" :data="data[indextr].GroupName">
                {{ data[indextr].GroupName }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].GroupName" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(4)" :data="data[indextr].Cd">
                {{ data[indextr].Cd }}
                <template slot="edit">
                  <vs-input v-model="data[indextr].Cd" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(5)" :data="data[indextr].SaleRate">
                {{ data[indextr].SaleRate}}
                <template slot="edit">
                  <vs-input v-model="data[indextr].SaleRate" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(6)" :data="data[indextr].MRP">
                {{ data[indextr].MRP}}
                <template slot="edit">
                  <vs-input v-model="data[indextr].MRP" class="w-full" :disabled="true" />
                </template>
              </vs-td>
              <vs-td v-show="isShow(7)" :data="data[indextr].ClsStockin">
                {{ data[indextr].ClsStockin}}
                <template slot="edit">
                  <vs-input v-model="data[indextr].ClsStockin" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td v-show="isShow(8)" :data="data[indextr].QtyinUOM">
                {{ data[indextr].QtyinUOM}}
                <template slot="edit">
                  <vs-input v-model="data[indextr].QtyinUOM" class="w-full" :disabled="true" />
                </template>
              </vs-td>

              <vs-td>
                <vs-button
                  size="small"
                  title="Select"
                  color="primary"
                  :id="'select'+indextr"
                  @click="handleSelected2(indextr)"
                  class="w-full"
                >select</vs-button>
              </vs-td>
            </vs-tr>
          </template>
        </vs-table>
      </div>
      <div>
        <tr>
          <td>
            <label>Search:</label>
          </td>

          <td style="padding-left:10px;">
            <vs-input
              class="w-full"
              width="120"
              type="text"
              id="searchbarstock"
              v-model="searchbarstock"
              @input="searchedList(-1)"
              @change="searchedList(-1)"
            />
          </td>
          <td style="padding-left:10px;">
            <select @change="searchedList(-1)" v-model="selectedDropdown">
              <option disabled value>Please select one</option>
              <option value="accountname">Search By Name</option>
              <option value="cityname">Search By City</option>
              <option value="address">Search By Address</option>
              <option value="gstin">Search By GSTIN</option>
              <option value="contactno">Search By Contact</option>
              <option value="mobile">Search By Mobile</option>
            </select>
          </td>
          <td class="tdInputsmall" style="padding-left:20px;">
            <vs-button
              size="small"
              title="Add"
              color="primary"
              id="addButtonPopup"
              @keyup.right="buttonNext('saveButton')"
              @keyup.left="buttonPrev('saveButton')"
              @click="showAddPopup()"
            >Add</vs-button>
          </td>
          <!-- <td class="tdInputsmall" style="padding-left:10px;">
            <vs-button
              size="small"
              title="Modify"
              color="primary"
              id="modifyButtonPopup"
              @keyup.right="buttonNext('saveButton')"
              @keyup.left="buttonPrev('saveButton')"
              @click="save()"
            >Modify</vs-button>
          </td>-->

          <td>
            <vs-collapse>
              <vs-collapse-item>
                <div slot="header">
                  Settings
                  <!-- <vs-button color="#FFFFFF" type="filled" size="small">
                    <vs-icon icon="settings" size="small" color="red"></vs-icon>
                  </vs-button>-->
                </div>
                <ul class="centerx">
                  <li>
                    <vs-checkbox v-model="CheckBox1" vs-value="accountname">Account Name</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox2" vs-value="cityname">City Name</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox3" vs-value="address">Address</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox4" vs-value="gstin">GSTIN</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox5" vs-value="contactno">Contact No</vs-checkbox>
                  </li>
                  <li>
                    <vs-checkbox v-model="CheckBox6" vs-value="phoneno">Phone No</vs-checkbox>
                  </li>
                  <li>
                    <vs-button
                      color="primary"
                      type="filled"
                      v-model="submitHeaders"
                      title="Save"
                      @click="changeHeaders"
                    >Save</vs-button>
                  </li>
                </ul>
              </vs-collapse-item>
            </vs-collapse>
          </td>
        </tr>
      </div>

      <!-- Popup Inside a popup for adding an entry -->
      <vs-popup classContent="popup-example" fullscreen :active.sync="popupActiveStockModal">
        <modal-direction v-model="modalOpenStockModal"></modal-direction>
      </vs-popup>

      <vs-popup
        classContent="popup-example"
        title="Modify Ledger Account"
        :active.sync="popupActiveModifyLedger"
      >
        <br />
        <div>
          <vs-tr>
            <vs-td>
              New Ledger:
              <vs-input
                type="text"
                id="modifybox"
                ref="modifybox"
                v-model="popupActiveModifyLedgerInput"
                size="10"
                style="width:700px; height:20px;"
              />
            </vs-td>
          </vs-tr>
        </div>
        <br />
        <br />
        <div>
          <tr>
            <td style="padding-left:10px;">
              <vs-button
                size="small"
                title="Add new Narration"
                color="primary"
                id="deleteButtonPopup"
                @click="AddModifiedLedger()"
              >Add Modified Stock Name</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
    </div>
  </div>
</template>


<script>
import axios from "axios";
import ModalDirection from "@/components/stockmodel.vue";

export default {
  name: "modal",
  props: {
    SearchText: String
  },
  data() {
    return {
      searchbarstock:"",
      setId:"",
      modifyledgerindex: -1,
      popupActiveModifyLedgerInput: "",
      popupActiveModifyLedger: false,
      modalOpen: false,

      rolet: "admin",
      secDate: null,
      secDays: null,
      addPerm: false,
      deletePerm: false,
      modifyPerm: false,
      downArrowPopupActive: false,
      dapWeight: "",
      dapRate: "",
      dapBillno: "",
      dapVehicle: "",
      dapStkItem: "",
      dapRecno: "",
      dapTxType: "",
      dap1: "",
      dap2: "",
      dap3: "",
      activeConfirmDelete: false,
      localFields: { text: "Game", value: "Id" },
      localWaterMark: "Select a game",
      autofill: true,
      spdata: [],
      companyname: "",
      original: "",
      allowcustom: true,
      voucherno: "",
      cashformdata: null,
      rowlength: 1,
      sportsData: [
        "Badminton",
        "Basketball",
        "Cricket",
        "Football",
        "Golf",
        "Gymnastics",
        "Hockey",
        "Rugby",
        "Snooker",
        "Tennis"
      ],
      narrationIndex: null,
      data: "",
      height11: "250px",

      remoteWaterMark: "Select a name",
      selectedDropdown: "accountname",
      paymentTotal: 0.0,
      receiptTotal: 0.0,
      discountTotal: 0.0,
      disAdd: false,
      disCopy: true,
      disDelete: true,
      disEdit: false,
      disFirst: true,
      disLast: true,
      disNext: true,
      disSave: true,
      disSearch: true,
      disPrinter: true,
      disPrevious: true,
      disExit: false,
      buttonen: false,
      date: null,
      due: null,

      handleSearch: "hello",
      configdateTimePicker: {
        allowInput: true,

        dateFormat: "d-m-Y"
      },
      titleAction: "",

      buttondis: true,
      disVoucher: true,
      disDate: true,
      totalcount: 0,
      cashVauchers: [
        {
          accountno: "",
          narration: [],
          payment: "",
          receipt: "",
          discount: ""
        }
      ],
      cashheaders: [
        "Account Name",
        "Narration",
        "Payment",
        "Receipt",
        "Discount",
        "Delete"
      ],
      selected: [],
      tableList: [
        "vs-th: Component",
        "vs-tr: Component",
        "vs-td: Component",
        "thread: Slot",
        "tbody: Slot",
        "header: Slot"
      ],
      filterbar2: "",
      filteredUsers: [],
      tabledata: [],
      users: [],
      narrations: [],
      filteredNarrations: [],
      newAccountName: " ",
      newCityName: " ",
      newGSTIN: " ",
      newAddress: " ",
      newContact: " ",
      newMobile: " ",

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],

      popupHeaders: [
        { title: "Account Name", show: true, headerUse: "accountname" },
        { title: "HSN Code", show: true, headerUse: "hsn" },
        { title: "Tax Rate", show: true, headerUse: "taxrate" },
        { title: "Group Name", show: true, headerUse: "groupname" },
        { title: "Cd", show: true, headerUse: "cd" },
        { title: "Sale Price", show: true, headerUse: "saleprice" },
        { title: "M.R.P", show: true, headerUse: "mrp" },
        { title: "CLS. Stock", show: true, headerUse: "clsstock" },
        { title: "Unit", show: true, headerUse: "unit" }
      ],

      popupDropdownSelected: "s_name",
      popupSelectedRow: 0,
      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
      originalvoucherno: 0,
      popupActive2: false,
      popupActive3: false,
      popupActiveStockModal: false,
      modalOpenStockModal:false,
      popupActive5: false,
      popupActive6: false,
      oldNarrationToEdit: "",

      modifiedNarration: "",
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false,
      autocopyNarration: "Data From Last Form",
      boolea: "false"
    };
  },
  components: {
    ModalDirection
  },
  methods: {
    handleSelected2(p) {
      //  alert('reached this atleast');
      let that = this;
     that.$emit(
            "childToParent",
            that.filteredUsers[p].Name +
              ":" +
              that.filteredUsers[p].Accode +
              ":" +
              that.filteredUsers[p].SaleRate
          );

    },
    setValue(boo,l,value) {
    
     
        this.boolea = boo;
    
     this.searchbarstock=value+""
        
if(l!="")
{  
  document.getElementById('searchbarstock').id='searchbarstock'+l
    
this.setId=l
  
document.getElementById('searchbarstock'+this.setId).focus()
 
//this.searchedList(-1)
}
    
    },
    popupKeyDown() {
      //
if(document.getElementById("popupListItem" + parseInt(this.popupSelectedRow+1)))
{
  if(   document.getElementById(
        "popupListItem" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }
     
      if (
        this.popupSelectedRow == this.filteredUsers.length - 1 ||
        this.popupSelectedRow > 6

      ) {
       
        this.popupSelectedRow = -1;
      }
      
      this.popupSelectedRow = this.popupSelectedRow + 1;
       if(   document.getElementById(
        "popupListItem" + this.popupSelectedRow
      )){
          document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
   
}
else{
   if( document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ))
      { document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";}
    
  this.popupSelectedRow=0
     document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
  
}
    },
    longfunctionfirst(t) {
      return new Promise(resolve => {
        if (t == "popupActive5") {
          this.popupActive5 = true;
          alert(this.jony);
          resolve("resolved");
        } else if (t == "popupActive3") {
          this.popupActive3 = true;

          resolve("resolved");
        } else if (t == "editbutton") {
          this.buttondis = false;

          resolve("resolved");
        } else if (t == "dateprevnext") {
          resolve("resolved");
        } else if (t == "modifyLedger") {
          this.popupActiveModifyLedger = true;
          resolve("resolved");
        }
      });
    },
    async shortfunctionsecond(g) {
      if (g == "modifyLedger") {
        const result = await this.longfunctionfirst("modifyLedger");
        console.log(result);
        document.getElementById("modifybox").focus();
      }
    },
    showAddPopup() {
      this.popupActiveStockModal = true;
      this.modalOpen = !this.modalOpen;
      this.$forceUpdate();
    },
    isShow(k) {
      return this.popupHeaders[k].show;
    },
    searchedList(p) {
      //
      if (p + "" != "-1") {
        //
        var value;
        this.rowNumberIndicator = p;
        value = this.cashVauchers[this.rowNumberIndicator].accountno;
        value = document.getElementById("0" + p).value.toLowerCase();
        //

        ////alert(p+" is awesome")
        this.searchbarstock = value + "";
        this.popupSelectedRow = 0;

        this.popupActive2 = true;
        document.getElementById("searchbarstock").focus();

        document.getElementById(
          "popupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";

        this.searching(value);
        this.$forceUpdate();
      } else {
         value = this.searchbarstock.toLowerCase();

        this.searching(value);
      }
      //
      ////alert(p);
    },
    searching(value) {
      var searchtag = "accountname";

      this.filteredUsers = [];
      //
      ////alert(searchtag);
 var g=0;
      if (value + "" == "") {
        this.filteredUsers = this.users;
      } else {
        
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          //searchtag = this.users[x].Name.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            searchtag = this.users[x].Name.toLowerCase();
          }
          if (this.selectedDropdown == "HSN") {
            searchtag = this.users[x].City.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].Address2.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].DGSTNo.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }

          if (this.selectedDropdown == "")
         
            searchtag = this.users[x].Name.toLowerCase();
          var search, p2;
          search = searchtag.trim();
          p2 = value.trim();
          if (search.indexOf(p2.toLowerCase()) == 0) {
          alert(this.users[x].Name)
           if(g==0)
          this.filteredUsers=[]
         
         this.filteredUsers.push(this.users[x]);
         g=1
       
          }  else
          {
            if(g==0)
            {this.filteredUsers=[]
            this.filteredUsers=this.users
            }
          }
        
            document.getElementById(
        "popupListItemLedger" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
         
           document.getElementById(
        "popupListItemLedger" + 0
      ).style.backgroundColor = "#BCD4EC";
        
       
        }
      }
    },
    filteredList() {
      //
      ////alert("p");
      let p = document.getElementById("filterbar").value.toLowerCase();
      var searchtag = "accountname";
      this.filteredUsers = [];

      if (p == "") {
        this.filteredUsers = this.users;
      } else {
        for (var x in this.users) {
          //let id = this.users[x].id.toLowerCase();
          if (this.selectedDropdown == "accountname") {
            //
            ////alert("reached");
            searchtag = this.users[x].AcName.toLowerCase();
          }
          if (this.selectedDropdown == "cityname") {
            searchtag = this.users[x].City.toLowerCase();
          }
          if (this.selectedDropdown == "address") {
            searchtag = this.users[x].Address2.toLowerCase();
          }
          if (this.selectedDropdown == "gstin") {
            searchtag = this.users[x].DGSTNo.toLowerCase();
          }
          if (this.selectedDropdown == "contactno") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }
          if (this.selectedDropdown == "mobile") {
            searchtag = this.users[x].ContactNo.toLowerCase();
          }

          if (searchtag.indexOf(p) != -1) {
            //
            ////alert(name);
            this.filteredUsers.push(this.users[x]);
          }
        }
      }
      this.popupSelectedRow = 0;
    },

    popupKeyUp() {
     if(document.getElementById("popupListItem" + parseInt(this.popupSelectedRow-1)))
      {
      if(   document.getElementById(
        "popupListItem" + this.popupSelectedRow
      )){
        document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      }
      if (this.popupSelectedRow == 0) {
        this.filteredUsers.length < 8
          ? (this.popupSelectedRow = this.filteredUsers.length)
          : (this.popupSelectedRow = 8);
      }
      this.popupSelectedRow = this.popupSelectedRow - 1;
     if( document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ))
      {
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
      }
    }
    else
    {   
      if( document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ))
      { document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";}
      this.popupSelectedRow=0
      while(document.getElementById("popupListItem" + parseInt(this.popupSelectedRow+1)))
    {this.popupSelectedRow++}
      document.getElementById(
        "popupListItem" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    }
    
    },
    setvalue(p) {
      //alert("clicked"+p)
      this.popupActiveModifyLedgerInput = this.filteredUsers[p].Name;
      this.modifyledgerindex = p;
      this.shortfunctionsecond("modifyLedger");
    },

    AddModifiedLedger() {
      var n = {
        companyname: this.companyname,
        newval: this.popupActiveModifyLedgerInput,
        index: this.modifyledgerindex
      };
      var that = this;
      axios.post("/modifyStockName", n).then(response => {
        that.filteredUsers[that.modifyledgerindex].Name =
          that.popupActiveModifyLedgerInput;
        that.popupActiveModifyLedger = false;
        console.log(response);
      });
    }
  },

  created() {
  

    var user = sessionStorage.getItem("user");
    var companyName = JSON.parse(user)[0].companyname;
    this.companyname = companyName;

    alert(companyName);
    var value1 = { companyname: companyName, directory: "stock_master.json" };

    var that = this;
    axios
      .post("/user/getCashformData", value1)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
        that.users = json.stock_accounts;
        alert(JSON.stringify(that.users));
        that.filteredUsers = that.users;
      })
      .catch(error => {
        alert(error);
      });
  },

  mounted() {
    this.titleAction = "VIEW";

    let that = this;

    window.addEventListener("keyup", function(event) {
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
  
        if (that.boolea == "true") {
      document.getElementById("searchbarstock"+that.setId).id="searchbarstock"
            that.boole="false"
        
          that.$emit(
              "childToParent","closestock"
            );

          if (that.popupActive2 == true) {
            that.popupActive2 = false;
            that.cashVauchers[that.rowNumberIndicator].accountno = "";
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
          if (that.popupActive3 == true) {
            that.popupActive3 = false;
            that.cashVauchers[that.rowNumberIndicator].narration = "";
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 40) {
        // down arrow
 
        if (that.boolea == "true") {
         
          that.popupKeyDown();
          //
          ////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically

          if (that.popupActive3 == true) {
            that.navPopupKeyDown();
            //
            ////alert("poop");
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }

      if (event.keyCode === 38) {
        // up arrow
        if (that.boolea == "true") {
          that.popupKeyUp();
          //
          ////alert("poop");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically

          if (that.popupActive3 == true) {
            that.navPopupKeyUp();
            //
            ////alert("poop");
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }

      if (event.keyCode === 13) {
        // enter

        if (that.boolea == "true") {
     
          that.$emit(
            "childToParent",
            that.filteredUsers[that.popupSelectedRow].Name +
              ":" +
              that.filteredUsers[that.popupSelectedRow].Accode +
              ":" +
              that.filteredUsers[that.popupSelectedRow].SaleRate+":"+that.filteredUsers[that.popupSelectedRow].index,JSON.stringify(that.filteredUsers[that.popupSelectedRow])
          );

          if (that.popupActive2 == true) {
            alert("clicked");

            that.$emit(
              "childToParent",
              that.filteredUsers[that.popupSelectedRow].AcName
            );

            that.popupActive2 = false;
            //
            ////alert(that.rowNumberIndicator);
            document.getElementById("filter" + that.rowNumberIndicator).focus();
            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
    });

    alert(
      document.getElementById("datepicker") +
        "gr " +
        document.getElementById("addButton")
    );
    that.setfocus();
  }
};
</script>