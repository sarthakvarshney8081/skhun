
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}
.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}
#wrapper2 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  width: 200px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}
.vs-popup {
  min-width: 800px;
}
.vs-button {
  display: inline-block;
}
.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
}

.column1 {
  float: left;
  width: 75%;
  padding: 10px;
}

.column2 {
  float: right;
  width: 25%;
  padding: 10px;
}

.column3 {
  float: left;
  width: 55%;
  padding: 10px;
}

.column4 {
  float: right;
  width: 45%;
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
<template>
  <div class="modal">
    <div class="vx-card p-6" style>

  <vs-popup classContent="popup-example" title="Account Form(press esc to close)" button-close-hidden="true" :active.sync="popupActive2" >
       <modal v-model="modalOpen" v-on:childToParent="onChildClick" :SearchText="searchlabel"  ref="childComponentLedger"/>
   </vs-popup>
      <vs-popup      
 classContent="popup-example"
      title="Narrations"
      name="popupActive3"
       button-close-hidden="true" 
      :active.sync="popupActiveNarration"
      >
       <modalnarration 
      ref="childComponent"
      :parentData="narrationtypename"
       v-on:spdatareceived="onspdatareceived"
       v-model="modalOpenNarration" v-on:childToParentNarration="onChildClickNarration" :SearchText="searchlabel"/>
   </vs-popup>

      <vs-popup
        classContent="popup"
        title="Annexures"
        :active.sync="drcrpopup"
        id="drcrpopup"
        name="drcrpopup"
      >
        <div class="search-wrapper" name="divpopupActive3">
          <tr>
            <td>
              <label>Search:</label>
            </td>

            <td style="padding-left:10px;" name="tdpopupActive3">
              <vs-input
                class="w-full"
                size="small"
                type="text"
                id="drcrfilter"
                ref="drcrfilter"
                v-model="drcrFilter"
                :autofocus="true"
                @input="drcrFilteredList()"
              />
            </td>
          </tr>
        </div>
        <br />

        <div>
          <vs-table v-model="chosen" @selected="handleClick" :data="drcrFilteredNarrations">
            <template slot-scope="{data}">
              <vs-tr
                :data="tr"
                :key="indextr"
                v-for="(tr, indextr) in data"
                :id="'drcr'+indextr"
              >
                <vs-td size="small">{{ data[indextr].name }}</vs-td>
              </vs-tr>
            </template>
          </vs-table>
        </div>
        <div>
          <tr>
            <td class="tdInputsmall" style="padding-left:20px;">
              <vs-button
                size="small"
                title="Add"
                color="primary"
                id="narAddButtonPopup"
                @click="showAddPopupNarration()"
              >Add</vs-button>
            </td>
            <td class="tdInputsmall" style="padding-left:10px;">
              <vs-button
                size="small"
                title="Modify"
                color="primary"
                id="modifyButtonPopup"
                @click="showAddPopupNarration()"
              >Modify</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>
      <div id="miscpopup">
        <vs-popup
          classContent="popup"
          title="Manufacturer Information"
          :active.sync="miscpopup"
          id="miscpopup"
          name="miscpopup"
        >
          <br />
          <div class="row">
            <div class="column">
              <div class="row">
                <div class="column1">
                  <tr>
                    <vs-td style="padding-right:10px">Payment Limit</vs-td>
                    <vs-td>
                      <vs-input
                        class="w-full"
                        size="small"
                        type="text"
                        v-model="mis_payment_limit"
                      />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Payment Due Days</vs-td>
                    <vs-td>
                      <vs-input
                        class="w-full"
                        size="small"
                        type="text"
                        v-model="mis_payment_due_days"
                      />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Intt. Grace Days</vs-td>
                    <vs-td>
                      <vs-input
                        class="w-full"
                        size="small"
                        type="text"
                        v-model="mis_int_grace_days"
                      />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Sorting Index No.</vs-td>
                    <vs-td>
                      <vs-input
                        class="w-full"
                        size="small"
                        type="text"
                        v-model="mis_sorting_index_no"
                      />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Qty in B.Sheet</vs-td>
                    <vs-td>
                      <vs-input class="w-full" size="small" type="text" v-model="sorting_index_no" />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Tr.Discount</vs-td>
                    <vs-td>
                      <vs-input class="w-full" size="small" type="text" v-model="mis_tr_discount" />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Terms EX/FOR</vs-td>
                    <vs-td>
                      <vs-input class="w-full" size="small" type="text" v-model="mis_terms_exfor" />
                    </vs-td>
                  </tr>

                  <tr>
                    <vs-td style="padding-right:10px">Trading A/c No.</vs-td>
                    <vs-td>
                      <vs-input
                        class="w-full"
                        size="small"
                        type="text"
                        v-model="mis_trading_ac_no"
                      />
                    </vs-td>
                  </tr>
                </div>
                <div class="column2">
                  <br />
                  <br />
                  <br />
                  <br />
                  <br />

                  <tr>
                    <vs-td style="padding-right:10px">
                      <vs-button
                        size="small"
                        title="Save"
                        color="primary"
                        id="misSaveButton"
                        @click="misSave()"
                      >Save</vs-button>
                    </vs-td>
                  </tr>
                </div>
              </div>
              <hr />
              <div class="row">
                <div class="row">
                  <div class="column3">
                    <!-- Bottom left big boxes column -->

                    <tr>
                      <vs-td style="padding-right:10px">Detail for 27-C (TCS)</vs-td>
                    </tr>
                    <br />
                    <br />
                    <tr>
                      <vs-td style="padding-right:10px">Status</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_status" />
                      </vs-td>
                    </tr>

                    <tr>
                      <vs-td style="padding-right:10px">Ward</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_ward" />
                      </vs-td>
                    </tr>

                    <tr>
                      <vs-td style="padding-right:10px">Last Ass</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_last_ass" />
                      </vs-td>
                    </tr>
                  </div>
                  <div class="column4">
                    <!-- Small boxes column -->
                    <br />
                    <br />
                    <tr>
                      <vs-td style="padding-right:10px">Area Code</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_area_code" />
                      </vs-td>
                    </tr>

                    <tr>
                      <vs-td style="padding-right:10px">AO Type</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_ao_type" />
                      </vs-td>
                    </tr>

                    <tr>
                      <vs-td style="padding-right:10px">Range Code</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="mis_range_code" />
                      </vs-td>
                    </tr>

                    <tr>
                      <vs-td style="padding-right:10px">Ao No.</vs-td>
                      <vs-td>
                        <vs-input class="w-full" size="small" type="text" v-model="miss_ao_no" />
                      </vs-td>
                    </tr>
                  </div>
                </div>
              </div>
            </div>
            <div class="column">
              <!-- // File Upload Button -->
              <br />
              <br />
              <br />
              <br />
              <td style="padding-left:30px;">
                <vs-upload type="file" v-modal="filedata" @click="onfileselect" />
              </td>
            </div>
          </div>
        </vs-popup>
        <vs-popup
        classContent="popup-example"
        title="Annexures"
        name="popupActive3"
        :active.sync="popupActive3"
      >
        <div class="search-wrapper" name="divpopupActive3">
          <tr>
            <td>
              <label>Search:</label>
            </td>

            <td style="padding-left:10px;" name="tdpopupActive3">
              <vs-input
                class="w-full"
                size="small"
                type="text"
                id="filterbar"
                ref="filterbar"
                v-model="filterbar"
                @input="filteredList()"
              />
            </td>
          </tr>
        </div>
        <br />

        <div>
          <vs-table v-model="selected" @selected="handleSelected" :data="popupdata">
            <template slot-scope="{data}">
              <vs-tr
                :data="tr"
                :key="indextr"
                v-for="(tr, indextr) in data"
                :id="'annexuresPopupListItem'+indextr"
              >
                <vs-td size="small">
                  <ul class="centerx">
                    <vs-input type="checkbox" :id="'annexureCheck'+indextr" value="kuch" />
                  </ul>
                </vs-td>
                <vs-td size="small">{{ data[indextr].name }}</vs-td>
              </vs-tr>
            </template>
          </vs-table>
        </div>
        <div>
          <tr>
            <td style="padding-left:10px;">
              <select @change="searchedList(-1)" v-model="selectedDropdown">
                <option disabled value>Please select one</option>
                <option value="name">Search By Name</option>
                <option value="cityname">Search By City</option>
                <option value="address">Search By Address</option>
                <option value="gstin">Search By GSTIN</option>
                <option value="contactno">Search By Contact</option>
                <option value="mobile">Search By Mobile</option>
              </select>
            </td>
            <td class="tdInputsmall" style="padding-left:20px;">
              <vs-button
                size="small"
                title="Add"
                color="primary"
                id="narAddButtonPopup"
                @click="showAddPopupNarration()"
              >Add</vs-button>
            </td>
            <td class="tdInputsmall" style="padding-left:10px;">
              <vs-button
                size="small"
                title="Modify"
                color="primary"
                id="modifyButtonPopup"
                @click="narrationModify()"
              >Modify</vs-button>
            </td>
          </tr>
        </div>

        <vs-popup
          classContent="popup"
          title="Add New Narration"
          :active.sync="popupActive5"
          id="popupActive5"
          name="popupActive5"
        >
          <br />
          <div>
            <vs-tr>
              <vs-td>
                Narration:
                <vs-input
                  type="text"
                  id="addBox"
                  :autofocus="'autofocus'"
                  ref="addBox"
                  v-model="newNarration"
                  size="10"
                  style="width:700px; height:20px;"
                />
              </vs-td>
            </vs-tr>
          </div>
          <br />
          <br />
          <div>
            <tr>
              <td style="padding-left:10px;">
                <vs-button
                  size="small"
                  title="Add new Narration"
                  color="primary"
                  v-model="newNarration"
                  id="newNarration"
                  @click="AddNewNarration()"
                >Add New Narration</vs-button>
              </td>
            </tr>
          </div>
        </vs-popup>
        <vs-popup classContent="popup" title="Modify Narration" :active.sync="popupActive6">
          <br />

          <div>
            <vs-tr>
              <vs-td style="width:700px; height:20px;">
                New Narration Text:
                <vs-input
                  style="width:700px; height:20px;"
                  class="w-full"
                  id="modifyNarrationBox"
                  type="text"
                  v-model="modifiedNarration"
                />
              </vs-td>
            </vs-tr>
          </div>
          <br />
          <br />
          <div>
            <tr>
              <td style="padding-left:10px;">
                <vs-button
                  size="small"
                  title="Add new Narration"
                  color="primary"
                  id="deleteButtonPopup"
                  @click="narrationModify2()"
                >Modify Narration</vs-button>
              </td>
            </tr>
          </div>
        </vs-popup>
      </vs-popup>
      </div>
      <table width="100%" border="0" class="tables">
        <tr>
          <td width="25%"></td>
          <td width="50%">
            <center>
              <h1 class="text-primary">
                {{this.annexureText}}
                <br />
                <h4>
                  <font color="grey">{{titleAction}}</font>
                </h4>
              </h1>
            </center>
          </td>
          <td width="25%" align="right">
            Today {{now}}
            <br />
            {{currentday}}
          </td>
        </tr>
        <br />
      </table>
      <br />
      <br />

      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>A/c Code</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="AcCode" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px"></div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>A/c Name</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
       <div id="wrapper2">
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
          
            id="acnamedata"
        :recordDoubleClick="recordDoubleClick"
        v-model="AcName"
        @focus="filtering2('AcName')"
        @input="caseSense('AcName')"
        :disabled="buttondis"
          :enabled="buttonen"
          :dataSource="acnamedata"
              :autofill="true"
              
            ></ejs-combobox>
        </ejs-tooltip>  
      </div>
        </div>
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px"><span>Bank AC Name</span></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="BankACName"
            id="BankACName"
            @input="upper('BankACName')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Address</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Address1"
            @input="caseSense('Address1')"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Bank AC/No.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="BankACNo"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px"></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Address2"
            @input="caseSense('Address2')"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>IFSC Code</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="IFSCCode"
            @input="upper('IFSCCode')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>City</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <div id="wrapper2">
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
          
            id="citydata"
        :recordDoubleClick="recordDoubleClick"
        v-model="City"
        @focus="filtering2('City')"
        @input="caseSense('City')"
        :disabled="buttondis"
          :enabled="buttonen"
          :dataSource="citydata"
              :autofill="true"
              
            ></ejs-combobox>
        </ejs-tooltip>  
      </div>
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Division</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            id="Division"
            v-model="Division"
            @input="caseSense('Division')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px"></div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-button color="primary" type="border" icon="map"></vs-button>
        </div>
      </div>

      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>PinCode</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="PinCode"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Collectorate</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Collectorate"
            @input="caseSense('Collectorate')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Distt.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
         <div id="wrapper2">
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
          
            id="disttdata"
        :recordDoubleClick="recordDoubleClick"
        v-model="Distt"
        @focus="filtering2('Distt')"
        @input="caseSense('Distt')"
        :disabled="buttondis"
          :enabled="buttonen"
          :dataSource="disttdata"
              :autofill="true"
              
            ></ejs-combobox>
        </ejs-tooltip>  
      </div>
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>GST No.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
       <ejs-tooltip id="tooltip" content='Enter GST' >
        <vs-input
          class="w-full"
          size="small"
          v-model="DGSTNo"
          id="DGSTNo"
          @keypress="isGSTvalid"
          @change="upper('DGSTNo')"
          :disabled="buttondis"
        />
         </ejs-tooltip>
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>SAC Code</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="SACCode"
            @input="caseSense('SACCode')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px"></div>
        <div class="vx-col sm:w-1/4 w-full">
          <vs-button color="primary" type="border" icon="check"></vs-button>
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>State</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-select v-model="State" class="w-full select-large" label :disabled="buttondis" autocomplete :color="colorx">
            <vs-select-item
              :key="index"
              :value="item"
              :text="item"
              v-for="(item,index) in states"
              class="w-full"
            />
          </vs-select>
        </div>
        <div class="vx-col sm:w-1/2 w-full" style="padding-left:150px">
          <vs-button class="mr-3 mb-2"  @click="miscPopupOpen">Misc. Information / Attach Image</vs-button>
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Distance</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="Distance"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Opening Balance Dr</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="OpeningBalanceDr"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Contact Person</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="ContactPerson"
            @input="caseSense('ContactPerson')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Opening Balance Cr</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="OpeningBalanceCr"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Intt/Depc.Rate</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="InttDepcRate"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Contact No.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            ref="cono"
            v-model="ContactNo"
            autofocus='a'
            @keypress="onlyNumber"
            @change="con"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>TDS Rate</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="TDSRate"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>M.Email ID</span>
        </div>

        <div class="vx-col sm:w-1/6 w-full">
<div id="wrapper2">
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
          
            id="emaildata"
        :recordDoubleClick="recordDoubleClick"
        v-model="comboemail"
        ref="comboemail"
    
         
        @focus="filtering2('comboemail')"
       @input="caseSense('comboemail')"
  
   
              :success="validateemail"
              success-text="The mail is valid"
              
              :enabled="buttonen"
              :dataSource="emaildata"
              :autofill="true"
              
            ></ejs-combobox>
        </ejs-tooltip>  
      </div>

        </div>

        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>TGST / Share%</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            id="TGSTShare"
            v-model="TGSTShare"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px" >
            <span>Area</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <div id="wrapper2" >
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
              :allowFiltering='true'
            id="areais"
            :filtering="filtering"
        v-model="comboarea"
        ref="areais"
           @focus="filtering2('comboarea')"
          :dataSource="spdata"
          :enabled="buttonen"
              :autofill="true"
            ></ejs-combobox>
        </ejs-tooltip>
      </div>
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Quantity</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            id="Quantitiy"
            v-model="Quantitiy"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Agent / Group</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <div id="wrapper2">
           <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           class="w-full"
              size="small"
                :allowFiltering='true'
                 @focus="filtering2('combogroup')"
            :filtering="filtering"
            :enabled="buttonen"
            id="groupdata"
          v-model="combogroup"
          @input="caseSense('combogroup')"
        :dataSource="groupdata"
              :autofill="true"
            ></ejs-combobox>
           </ejs-tooltip>
      </div>
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span></span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="v"
            @keypress="onlyNumber"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>PAN</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="PAN" @input="panno" :disabled="buttondis" id="PAN" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Aadhaar No.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model="AadhaarNo" @keypress="onlyNumber" @change="addhver" :disabled="buttondis" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>TDS A/c No.</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="TDSAcNo"
            @input="caseSense('TDSAcNo')"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Composition Y/N</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="CompositionYN"
            @input="caseSense('CompositionYN')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Works</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
        <div id="wrapper2">
        <ejs-tooltip id="tooltip" content='press right alt for narration' >
           <ejs-combobox
           
                 class="w-full"
              size="small"
          
            id="worksdata"
        :recordDoubleClick="recordDoubleClick"
        v-model="Works"
        @focus="filtering2('Works')"
        @input="caseSense('Works')"
        :disabled="buttondis"
          :enabled="buttonen"
          :dataSource="worksdata"
              :autofill="true"
              
            ></ejs-combobox>
        </ejs-tooltip>  
      </div>
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Name & Address</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            id="NameAddress1"
            v-model="NameAddress1"
            @input="caseSense('NameAddress1')"
            :disabled="buttondis"
          />
        </div>
        <div class="vx-col sm:w-1/6 w-full"></div>
        <div class="vx-col sm:w-1/4 w-full">
          <vs-button
            type="filled"
            title="Dr. Group"
            id="drgroup"
            autofocus="true"
            v-show="showdrcr"
            @click="showdrcrpopup('d')"
          >Dr. group</vs-button>&nbsp;
          <vs-button
            type="filled"
            title="Cr. Group"
            id="crgroup"
            autofocus="true"
            v-show="showdrcr"
            @click="showdrcrpopup('c')"
          >Cr. group</vs-button>
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Name & Address</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            v-model="NameAddress2"
            @input="caseSense('NameAddress2')"
            :disabled="buttondis"
          />
        </div>
      </div>
      <br />
      <br />
      <div align="left">
        <vs-button
          :color="getColor('addButton')"
          type="filled"
          title="Add"
          id="addButton"
          icon-pack="feather"
          icon="icon-file-plus"
          @keyup.right="buttonNext('addButton')"
          @keyup.left="buttonPrev('addButton')"
          @click="newdisable"
          :disabled="disAdd"
          :autofocus="true"
        />
        <vs-button
          title="Edit"
          type="filled"
          icon-pack="feather"
          icon="icon-edit-1"
          :disabled="disEdit"
          :color="getColor('editButton')"
          id="editButton"
          class="button margin"
          @keyup.right="buttonNext('editButton')"
          @keyup.left="buttonPrev('editButton')"
          @click="editButton()"
        />
        <vs-button
          title="Previous"
          type="filled"
          icon-pack="feather"
          icon="icon-chevrons-left"
          :disabled="disPrevious"
          :color="getColor('previousButton')"
          id="previousButton"
          class="button margin"
          @keyup.right="buttonNext('previousButton')"
          @keyup.left="buttonPrev('previousButton')"
          @click="getData('prev')"
        />
        <vs-button
          title="Next"
          icon-pack="feather"
          icon="icon-chevrons-right"
          :disabled="disNext"
          :color="getColor('nextButton')"
          id="nextButton"
          class="button margin"
          @keyup.right="buttonNext('nextButton')"
          @keyup.left="buttonPrev('nextButton')"
          @click="getData('next')"
        />
        <vs-button
          title="First"
          icon-pack="feather"
          icon="icon-arrow-left"
          :disabled="disFirst"
          id="firstButton"
          :color="getColor('firstButton')"
          class="button margin"
          @keyup.right="buttonNext('firstButton')"
          @keyup.left="buttonPrev('firstButton')"
          @click="getFirst"
        />
        <vs-button
          title="Last"
          icon-pack="feather"
          icon="icon-arrow-right"
          :disabled="disLast"
          :color="getColor('lastButton')"
          id="lastButton"
          class="button margin"
          @keyup.right="buttonNext('lastButton')"
          @keyup.left="buttonPrev('lastButton')"
          @click="getLast"
        />
        <vs-button
          title="Search"
          icon-pack="feather"
          icon="icon-search" 
          :disabled="disSearch"
          :color="getColor('searchButton')"
          id="searchButton"
          class="button margin"
          @keyup.right="buttonNext('searchButton')"
          @keyup.left="buttonPrev('searchButton')"
          @click="search"
        />

        <vs-button
          title="Printer"
          icon-pack="feather"
          icon="icon-printer"
          :disabled="disPrinter"
          :color="getColor('printButton')"
          id="printButton"
          class="button margin"
          @keyup.right="buttonNext('printButton')"
          @keyup.left="buttonPrev('printButton')"
          @click="print"
        />
        <vs-button
          title="Delete"
          icon-pack="feather"
          icon="icon-trash"
          :disabled="disDelete"
          :color="getColor('deleteButton')"
          id="deleteButton"
          class="button margin"
          @keyup.right="buttonNext('deleteButton')"
          @keyup.left="buttonPrev('deleteButton')"
          @click="onDelete"
        />
        <vs-button
          title="Exit"
          icon-pack="feather"
          icon="icon-x"
          :disabled="disExit"
          :color="getColor('exitButton')"
          id="exitButton"
          class="button margin"
          @keyup.right="buttonNext('exitButton')"
          @keyup.left="buttonPrev('exitButton')"
          @click="onExit"
        />
        <vs-button
          style="float:right; display:inline-block;"
          title="Save"
          :color="getColor('saveButton')"
          :disabled="disSave"
          id="saveButton"
          class="button margin"
          @keyup.right="buttonNext('saveButton')"
          @keyup.left="buttonPrev('saveButton')"
          @click="save()"
        >Save</vs-button>
      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import Vue from "vue";
import { TooltipPlugin } from "@syncfusion/ej2-vue-popups";
Vue.use(TooltipPlugin);
import { ComboBoxPlugin } from "@syncfusion/ej2-vue-dropdowns";
import { CheckBoxPlugin } from "@syncfusion/ej2-vue-buttons";
import { Query, DataManager, WebApiAdaptor } from "@syncfusion/ej2-data";
import modal from "@/components/Ledgerpopup.vue";
import modalnarration from "@/components/NarrationsModal.vue";
import "@syncfusion/ej2-base/styles/material.css";
import "@syncfusion/ej2-inputs/styles/material.css";
import "@syncfusion/ej2-vue-dropdowns/styles/material.css";
import "@syncfusion/ej2-base/styles/material.css";
import "@syncfusion/ej2-vue-popups/styles/material.css";
Vue.use(ComboBoxPlugin);
Vue.use(CheckBoxPlugin);
var remoteData = new DataManager({
  url:
    "https://ej2services.syncfusion.com/production/web-services/api/Employees",
  adaptor: new WebApiAdaptor(),
  crossDomain: true
});
export default {
  name: "Modal2",
  data() {
    return {
      State:"",
colorx:"#103767",
gstwisestates:{
  "1" :	"JAMMU AND KASHMIR",
"2" :	"HIMACHAL PRADESH",
"3" 	:"PUNJAB",
"4" :	"CHANDIGARH",
"5" :	"UTTARAKHAND",
"6" :	"HARYANA",
"7" :	"DELHI",
"8" :	"RAJASTHAN",
"9" :	"UTTAR PRADESH",
"10" :	"BIHAR",
"11" :	"SIKKIM",
"12" :	"ARUNACHAL PRADESH (Old)",
"13" :	"NAGALAND",
"14" :	"MANIPUR",
"15" :	"MIZORAM",
"16" :	"TRIPURA",
"17" :	"MEGHLAYA",
"18" :	"ASSAM",
"19" :	"WEST BENGAL",
"20" :	"JHARKHAND",
"21" :	"ODISHA",
"22" :	"CHATTISGARH",
"23" :	"MADHYA PRADESH",
"24" :	"GUJARAT",
"25" :	"DAMAN AND DIU",
"26" :	"DADRA AND NAGAR HAVELI",
"27" :	"MAHARASHTRA",
"28" :	"ANDHRA PRADESH",
"29" :	"KARNATAKA",
"30" :	"GOA",
"31" :	"LAKSHWADEEP",
"32" :	"KERALA",
"33" :	"TAMIL NADU",
"34" :	"PUDUCHERRY",
"35" :	"ANDAMAN AND NICOBAR ISLANDS",
"36" :	"TELANGANA",
"37" :	"ANDHRA PRADESH (NEW)",
},
states:[
  
    "Andaman and Nicobar Islands",
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Delhi",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Ladakh",
    "Lakshadweep",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Puducherry",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal"

],

      searchindex:0,
      modalOpen:false,
    
      titleAction: "",
      finalind:0,
      comboarea:"",
      combogroup:"",
      comboemail:"",
      popupActiveNarration:false,
      modalOpenNarration:false,
      miscpopup: false,
        drcrNarrations: [],
      drcrFilteredNarrations: [],
        popupSelectedRow: 0,
      drcrFilter: "",
      chosen: "",
      drcrpopup: false,
      showdrcr: false,
      reload: "false",
      oldNarrationToEdit: "",
      modifiedNarration: "",
      annexurecalled: "",
      currentfield: "",
      emaildata:[],
      citydata:[],
      acnamedata:[],
      disttdata:[],
      worksdata:[],
      groupdata:[],
      agentdata:[],
      companyname: "",
      newNarration: "",
      popupdata: null,
      field: "",
      filterbar2: "",
      filteredUsers: [],
      tabledata: [],
      users: [],
      narrations: [],
          filteredAreaNarrations: [],
      filteredEmailNarrations: [],
      filteredCityNarrations: [],
      filteredAcNameNarrations: [],
      filteredDisttNarrations: [],
      filteredWorksNarrations: [],
      filteredGroupNarrations: [],
      popupActiveNarr: false,
      dat: remoteData,
      spdata: ["hey", "sfsdf@gmail.com"],
      AcCode: "",
      AcName: "",
      query: new Query()
        .select(["FirstName", "EmployeeID"])
        .take(10)
        .requiresCount(),
      Address1: "",
      BankACName: "",
      Address2: "",
      AadhaarNo: "",
      IFSCCode: "",
      City: "",
      Division: "",
      PinCode: "",
      Collectorate: "",
      Distt: "",
      DGSTNo: "",
      SACCode: "",
      Distance: "",
      OpeningBalanceDr: "",
      ContactPerson: "",
      OpeningBalanceCr: "",
      InttDepcRate: "",
      ContactNo: "",
      TDSRate: "",
      MEmailIDArea: "",
      TGSTShare: "",
      AgentGroup: "",
      Quantitiy: "",
      v: "",
      a: false,
      BankACNo: "",
      PAN: "",
      TDSAcNo: "",
      CompositionYN: "",
      Works: "",
      NameAddress1: "",
      NameAddress2: "",
      dbIndex: "",
      bufferIndex: "",
      requiredIndex: -999,
      disAdd: false,
      disCopy: false,
      disDelete: false,
      disEdit: false,
      disFirst: false,
      disLast: false,
      disNext: false,
      disSave: true,
      disSearch: false,
      disPrinter: false,
      disPrevious: false,
      disExit: false,
      buttondis: true,
      annexureText: "LOANS & ADVANCES",
      selected: "",


      
      mis_payment_limit: "",
      mis_payment_due_days: "",
      mis_int_grace_days: "",
      mis_sorting_index_no: "",
      mis_qty_in_bsheet: "",
      mis_tr_discount: "",
      mis_terms_exfor: "",
      mis_trading_ac_no: "",
      mis_status: "",
      mis_ward: "",
      mis_last_ass: "",
      mis_area_code: "",
      mis_range_code: "",
      mis_ao_no: "",
      filedata: "",

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],
      filteredAnnexures: [],
      annexures: [],
      selectedDropdown: "name",
      popupActive2: false,
      popupActive3: false,
      popupActive4: false,
      popupActive5: false,
      popupActive6: false,
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false
    };
  },
components:{
   modalnarration,
  modal
},
  methods: {
 
    search(){
    
      this.shortfunctionsecond("popupActive2","true","comp")
    },
    getsearchdata(ind,view){
      if(view=="edit")
      this.editButton()
 var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      
      var n = {
        companyname: companyName,
        requiredIndex: ind
      };
      // //alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/getLedger", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            this.AcCode = resp.AcCode;
            this.AcName = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
             this.State=resp.state
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.MEmailIDArea = resp.MEmailIDArea;
            this.TGSTShare = resp.TGSTShare;
            this.AgentGroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });
    },
 getFirst() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      
      var n = {
        companyname: companyName,
        requiredIndex: 0
      };
      // //alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/getLedger", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            this.AcCode = resp.AcCode;
            this.AcName = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
             this.State=resp.state
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.MEmailIDArea = resp.MEmailIDArea;
            this.TGSTShare = resp.TGSTShare;
            this.AgentGroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },

        getLast() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
     
      var n = {
        companyname: companyName,
        requiredIndex:  -999 
      };
      // //alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/getLedger", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            this.AcCode = resp.AcCode;
            this.AcName = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
             this.State=resp.state
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.MEmailIDArea = resp.MEmailIDArea;
            this.TGSTShare = resp.TGSTShare;
            this.AgentGroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },
  
 onspdatareceived(value){
      alert(value[0])
      if(this.currentfield=="comboarea")
      {  
       this.groupdata=value;
        this.shortfunctionsecond("areais")}
       else if(this.currentfield=="comboemail")
       {this.emaildata=value
        this.shortfunctionsecond("emaildata")}
       else if(this.currentfield=="City")
       {this.citydata=value
        this.shortfunctionsecond("citydata")}
      else if(this.currentfield=="AcName")
       {this.acnamedata=value
        this.shortfunctionsecond("acnamedata")}
      else if(this.currentfield=="Distt")
       {this.disttdata=value
        this.shortfunctionsecond("disttdata")}
      else if(this.currentfield=="Works")
       {this.worksdata=value
       
        this.shortfunctionsecond("worksdata")}
       else if(this.currentfield=="combogroup")
       {this.groupdata=value
        this.shortfunctionsecond("groupdata")}
     

    },
     longfunctionfirst(t) {
        
       return new Promise(resolve => {
         if(t=="popupActiveNarration")
         {this.modalOpenNarration=true
this.popupActiveNarration=true
resolve('resolved');}
   else if(t=="popupActive5")
    {  this.popupActive5 = true;
      alert(this.jony)
      resolve('resolved');
    }
    else if(t=="popupActive3")
    {this.popupActive3 = true;
      
      resolve('resolved');}
      else if(t=="areais")
    {
    setTimeout(() => resolve("done!"), 500)}
       else if(t=="popupActive2")
    { this.popupActive2=true
      
      resolve('resolved');}
        else if(t=="dateprevnext")
    { setTimeout(() => resolve("done!"), 500)
      }
       else if(t=="modifyLedger")
    { this.popupActiveModifyLedger=true
      resolve('resolved');}
       else if (t == "drcrpopup") {
          this.drcrpopup = true;

          resolve("resolved");
        }
     
  
  });
       
   
},

 async shortfunctionsecond(g,k,l) {
   if(g=="popupActiveNarration")
   { await this.longfunctionfirst(g);  
     this.$refs.childComponent.setValue(k,"ledgerform"+l)
     }
  else if(g=="popupActive5")
  { await this.longfunctionfirst(g);
  document.getElementById("newNarrationBox").focus()
  }

  else if(g=="areais")
  {
     await this.longfunctionfirst("areais");

   document.getElementById("Quantitiy").focus()
   //this.$refs["areais"].focus()
    
}
  else if(g=="emaildata")
  { const result= await this.longfunctionfirst("areais");
  
         document.getElementById("TGSTShare").focus()
  

 
  console.log(result)
}
else if(g=="citydata")
  { await this.longfunctionfirst("areais");
 
  document.getElementById("Division").focus();
}
else if(g=="acnamedata")
  { await this.longfunctionfirst("areais");

  document.getElementById("BankACName").focus();
}
else if(g=="disttdata")
  { await this.longfunctionfirst("areais");

  document.getElementById("DGSTNo").focus();
}
 else if(g=="editbutton")
  {alert("here")
     await this.longfunctionfirst(g);
    var p=this.rowlength-1
  document.getElementById('0'+p).focus();
}
else if(g=="groupdata")
  {alert("here")
     await this.longfunctionfirst("areais");
   document.getElementById("PAN").focus();
}
else if(g=="dateprevnext")
  {alert("here")
     await this.longfunctionfirst("dateprevnext");
   document.getElementById("editButton").focus();
}
else if(g=="worksdata")
  {alert("here")
     await this.longfunctionfirst("areais");
    
   document.getElementById("NameAddress1").focus();
}
 else  if (g == "drcrpopup") {
        await this.longfunctionfirst(g);

        document.getElementById("drcrfilter").focus();
      }
        else if(g=="popupActive2")
  {
    await this.longfunctionfirst(g);
     this.$refs.childComponentLedger.setValue(k,"ledgerform"+l,"")
  }


},
  onChildClick (value) {
       //alert("called")
       if(value=="closeledger")
       {this.popupActive2=false
      this.modalOpen=false;
      
      }
     else{  const words=value.split(':');
     this.searchindex=parseInt(words[2]+"");
     this.getsearchdata(this.searchindex)
       if(this.popupActive2==true)
      {this.popupActive2=false
      this.modalOpen=false;
      }
     }
    },
  onChildClickNarration(valu){
      
      if(this.modalOpenNarration==true)
      { 
        if(valu=="closenarration")
        {
          this.modalOpenNarration=false
          this.popupActiveNarration=false
        }
        else{
        const words=valu.split(':');
     
     if(this.currentfield=="comboarea") 
         {this.comboarea=words[0]+""
        
         this.shortfunctionsecond("areais")
         }
         else if(this.currentfield=="comboemail")
         {this.comboemail=words[0]+""
        this.shortfunctionsecond("emaildata") }
        else if(this.currentfield=="City")
         {this.City=words[0]+""
        this.shortfunctionsecond("citydata") }
        else if(this.currentfield=="AcName")
         {this.AcName=words[0]+""
        this.shortfunctionsecond("acnamedata") }
        else if(this.currentfield=="Distt")
         {this.Distt=words[0]+""
        this.shortfunctionsecond("disttdata") }
        else if(this.currentfield=="Works")
         {this.Works=words[0]+""
        
        this.shortfunctionsecond("worksdata") }
         else if(this.currentfield=="combogroup")
         {this.combogroup=words[0]+""
         this.shortfunctionsecond("groupdata")}
 this.popupActiveNarration=false
        this.modalOpenNarration=false
}
      }
    // this.shortfunctionsecond(valu)
    },
     showdescNar(k){

     this.shortfunctionsecond("popupActiveNarration",k,k)
    },
  popupKeyDown() {
   //   alert('keyudown')
      document.getElementById(
        "drcr" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (
        this.popupSelectedRow == this.drcrFilteredNarrations.length - 1 
      ) {
        this.popupSelectedRow = 0;
      }
     else {
        this.popupSelectedRow = this.popupSelectedRow + 1;
     }
      document.getElementById(
        "drcr" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
    popupKeyUp() {
      //alert('keyup')
      document.getElementById(
        "drcr" + this.popupSelectedRow
      ).style.backgroundColor = "#FFFFFF";
      if (this.popupSelectedRow == 0) {
        this.drcrFilteredNarrations.length < 100
          ? (this.popupSelectedRow = this.drcrFilteredNarrations.length)
          : (this.popupSelectedRow = 15);
      }
      else{
        this.popupSelectedRow = this.popupSelectedRow - 1;
      }
      document.getElementById(
        "drcr" + this.popupSelectedRow
      ).style.backgroundColor = "#BCD4EC";
    },
    
 
    drcrFilteredList() {
      let inp = this.drcrFilter;
      inp = inp.toLowerCase();

      if (inp.length < 1) {
        this.drcrFilteredNarrations = this.drcrNarrations;
      } else {
        this.drcrFilteredNarrations = [];
        for (let i = 0; i < this.drcrNarrations.length; i++) {
          //alert(this.drcrNarrations[i].name)
          let str = this.drcrNarrations[i].name;
          str = str.toLowerCase();
          if (str.indexOf(inp) == 0) {
            this.drcrFilteredNarrations.push(this.drcrNarrations[i]);
          }
        }
      }
      this.popupSelectedRow = 0;
    },
    showdrcrpopup(text) {
      this.drcrNarrations = [];
      this.drcrFilter = "";
      for (let i in this.annexures) {
        if (text == "d" && this.annexures[i].debit == "D") {
          this.drcrNarrations.push(this.annexures[i]);
        }

        if (text == "c" && this.annexures[i].debit == "C") {
          this.drcrNarrations.push(this.annexures[i]);
        }
      }
      this.drcrFilteredNarrations = this.drcrNarrations;
      //alert(JSON.stringify(this.drcrFilteredNarrations))

      this.shortfunctionsecond("drcrpopup");
    },
    misSave() {
      this.miscpopup = false;
    },
    onfileselect(event) {
      var input = event.target;
      // Ensure that you have a file before attempting to read it
      if (input.files && input.files[0]) {
        // create a new FileReader to read this image and convert to base64 format
        var reader = new FileReader();
      }
      reader.onload = e => {
        // Note: arrow function used here, so that "this.imageData" refers to the imageData of Vue component
        // Read image as base64 and set to imageData
        this.filedata = e.target.result;
        var img = this.filedata;

        console.log("hello" + img);
      };

      reader.readAsDataURL(input.files[0]);
      alert(this.filedata + reader);
    },
    miscPopupOpen() {
      this.miscpopup = true;
    },
    openMap() {
      let user = sessionStorage.getItem("user");
      let city = JSON.parse(user)[0].city;
      //alert(city);
      // https://www.google.com/maps/dir/Jammu/Chandigarh/
      if (this.City != "") {
        let theURL =
          "https://www.google.com/maps/dir/" + this.City + "/" + city + "/";
        window.open(theURL);
      } else {
        alert("Please enter a city to search in maps");
      }
    },
    onlyNumber($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
        // 46 is dot
        return $event.preventDefault();
      } else return null;
    },
    
    validateemail() {
      var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(this.emaildata);
    },
    recordDoubleClick: function(e) {
      // you can show Dialog component here
      alert("dblclick");
      console.log(e);
    },
    reloadPage() {
      window.location.reload();
    },
    con()
    {
      var a=this.ContactNo;
      
      if(a.length===10)
      {
       this.ContactNo="+91"+a;
      }
      else if(a.length<10)
      {
        alert("enter 10 digit no");
        this.ContactNo="";
        this.a=true;
        
        
        this.$refs.cono.$el.focus();
        
      }
      else
      {
        alert("enter 10 digit no");
        this.ContactNo="";
        this.a=true;
        this.$refs.cono.$el.focus();
      }
    },
    addhver()
    {
      var a=this.AadhaarNo;
      
      if(a.length===12)
      {
       return 0;
      }
      else if(a.length<10)
      {
        alert("enter 12 digit aadhaar no");
        this.AadhaarNo="";
        this.a=true;
        
        
        this.$refs.cono.$el.focus();
        
      }
      else
      {
        alert("enter 12 digit aadhaar no");
        this.AadhaarNo="";
        this.a=true;
        this.$refs.cono.$el.focus();
      }
    },

    caseSense(k) {
      var str;
      if (k == "AcName") {
        str = this.AcName;
      } else if (k == "Address1") {
        str = this.Address1;
      } else if (k == "Address2") {
        str = this.Address2;
      } else if (k == "City") {
        str = this.City;
      } else if (k == "Collectorate") {
        str = this.Collectorate;
      } else if (k == "Distt") {
        str = this.Distt;
      } else if (k == "SACCode") {
        str = this.SACCode;
      } else if (k == "ContactPerson") {
        str = this.ContactPerson;
      } else if (k == "comboemail") {
        str = this.comboemail;
      } else if (k == "combogroup") {
        str = this.combogroup;
      } else if (k == "TDSAcNo") {
        str = this.TDSAcNo;
      } else if (k == "CompositionYN") {
        str = this.CompositionYN;
      } else if (k == "BankACName") {
        str = this.BankACName;
      } else if (k == "Division") {
        str = this.Division;
      } else if (k == "Works") {
        str = this.Works;
      } else if (k == "NameAddress1") {
        str = this.NameAddress1;
      } else if (k == "NameAddress2") {
        str = this.NameAddress2;
      } else {
        console.log(" ");
      }
      if (str.length > 1) {
        //var arr = str.split("");
        if (
          str[str.length - 2] == "." ||
          str[str.length - 2] == " " ||
          str[str.length - 2] == "!" ||
          str[str.length - 2] == "@" ||
          str[str.length - 2] == "~" ||
          str[str.length - 2] == "#" ||
          str[str.length - 2] == "$" || str[str.length - 2] == "%" ||
          str[str.length - 2] == "^" ||
          str[str.length - 2] == "&" ||
          str[str.length - 2] == "*" ||
          str[str.length - 2] == "(" ||
          str[str.length - 2] == ")" ||
          str[str.length - 2] == "_" ||
          str[str.length - 2] == "-" ||
          str[str.length - 2] == "=" ||
          str[str.length - 2] == "+"
        ) {
          var a = str.charAt(str.length - 1).toUpperCase();
          //console.log(a);
          var rd = str.slice(0, str.length - 1);
          console.log("rd is == " + rd);
          console.log(rd + a);

          var b = rd + a;
          if (k == "AcName") {
            this.AcName = b;
          } else if (k == "Address1") {
            this.Address1 = b;
          } else if (k == "Address2") {
            this.Address2 = b;
          } else if (k == "City") {
            this.City = b;
          } else if (k == "Collectorate") {
            this.Collectorate = b;
          } else if (k == "Distt") {
            this.Distt = b;
          } else if (k == "SACCode") {
            this.SACCode = b;
          } else if (k == "ContactPerson") {
            this.ContactPerson = b;
          } else if (k == "comboemail") {
            this.comboemail = b;
          } else if (k == "combogroup") {
            this.combogroup = b;
          } else if (k == "TDSAcNo") {
            this.TDSAcNo = b;
          } else if (k == "CompositionYN") {
            this.CompositionYN = b;
          } else if (k == "BankACName") {
            this.BankACName = b;
          } else if (k == "Division") {
            this.Division = b;
          } else if (k == "Works") {
            this.Works = b;
          } else if (k == "NameAddress1") {
            this.NameAddress1 = b;
          } else if (k == "NameAddress2") {
            this.NameAddress2 = b;
          } else {
            console.log(" ");
          }
          document.getElementById("myID").value = rd + a;
        }
      } else {
        if (k == "AcName") {
          this.AcName = str.toUpperCase();
        } else if (k == "Address1") {
          this.Address1 = str.toUpperCase();
        } else if (k == "Address2") {
          this.Address2 = str.toUpperCase();
        } else if (k == "City") {
          this.City = str.toUpperCase();
        } else if (k == "Collectorate") {
          this.Collectorate = str.toUpperCase();
        } else if (k == "Distt") {
          this.Distt = str.toUpperCase();
        } else if (k == "SACCode") {
          this.SACCode = str.toUpperCase();
        } else if (k == "ContactPerson") {
          this.ContactPerson = str.toUpperCase();
        } else if (k == "comboemail") {
          this.comboemail = str.toUpperCase();
        } else if (k == "combogroup") {
          this.combogroup = str.toUpperCase();
        } else if (k == "TDSAcNo") {
          this.TDSAcNo = str.toUpperCase();
        } else if (k == "CompositionYN") {
          this.CompositionYN = str.toUpperCase();
        } else if (k == "BankACName") {
          this.BankACName = str.toUpperCase();
        } else if (k == "Division") {
          this.Division = str.toUpperCase();
        } else if (k == "Works") {
          this.Works = str.toUpperCase();
        } else if (k == "NameAddress1") {
          this.NameAddress1 = str.toUpperCase();
        } else if (k == "NameAddress2") {
          this.NameAddress2 = str.toUpperCase();
        } else {
          console.log(" ");
        }
        document.getElementById("myID").value = str.toUpperCase();
      }
    },
    gstcheck() {
      var input = this.DGSTNo;

      if (/\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/.test(input)) {
        console.log("HI");
        this.checkValid = false;
        this.checkvalidation = true;
      } else {
        alert("Enter Valid ");
      }
    },
    upper(k) {
      var a;
      if (k == "PinCode") {
        a = this.PinCode;
      } else if (k == "BankACName") {
        a = this.BankACName;
      } else if (k == "DGSTNo") {
        a = this.DGSTNo;
      }
      else if(k=="IFSCCode")
      {
        a=this.IFSCCode
      } 
      else {
        console.log(" ");
      }
      var b = a.toUpperCase();
      console.log(b);
      if (k == "PinCode") {
        this.PinCode = b;
      } else if (k == "BankACName") {
        this.BankACName = b;
      } else if (k == "DGSTNo") {
        this.DGSTNo = b;
      }
      else if(k=="IFSCCode")
      {
        this.IFSCCode=b;
      }  
      else {
        console.log(" ");
      }
    },
    panno() {
      var b = this.DGSTNo.substring(3, 12);
      this.PAN = b;
    },

    narrationModify2() {
      let n = 0;
      //alert("hey")
      var fin;
      this.popupdata.forEach(y => {
        if (y.name == this.oldNarrationToEdit) {
          this.popupdata[n].name = this.modifiedNarration;
          fin = n;
        }
        n++;
      });
      if (this.field == "area") {
        this.spdata = this.popupdata;
        this.spdata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.spdata.push(this.popupdata[i].name + "");
        }
      } else if (this.field == "email") {
        this.emaildata = this.popupdata;
        this.emaildata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.emaildata.push(this.popupdata[i].name + "");
        }
      } else if (this.field == "group") {
        this.groupdata = this.popupdata;
        this.groupdata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.groupdata.push(this.popupdata[i].name + "");
        }
      }

      var that = this;
      //
      ////alert(this.spdata)
      var input = {
        companyname: this.companyname,
        inputval: this.modifiedNarration,
        key: this.field,
        index: fin
      };
      axios.post("/modifyNarration", input).then(response => {
        that.narrations = JSON.parse(JSON.stringify(response.data));
        //alert(JSON.stringify(response.data))
        if (that.field == "area") {
          that.filteredAreaNarrations = that.narrations;
        } else if (that.field == "email") {
          that.filteredEmailNarrations = that.narrations;
        } else if (that.field == "group") {
          that.filteredGroupNarrations = that.narrations;
        }
      });
      this.popupActive6 = false;
    },
    narrationModify() {
      var indexList = [];
      //
      ////alert(indexList);
      //alert("heya")
      for (var x = 0; x < this.popupdata.length; x++) {
        let p = "annexureCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.popupdata[x]);
          document.getElementById(p).checked = false;
        }
      }

      this.oldNarrationToEdit = indexList[0].name;
      this.popupActive6 = true;
      this.modifiedNarration = indexList[0].name;
      document.getElementById("modifyNarrationBox").focus();

      //
      ////alert("To be added after permission  check is done");
    },

    AddNewNarration() {
      //alert("api called 1 "+ this.newNarration)

      var value = {
        narrations: []
      };
      var that = this;
      var value1 = {
        companyname: this.companyname,
        value: value,
        key: that.field,
        data: this.newNarration
      };
      axios
        .post("/addNarration", value1)
        .then(response => {
          //alert(response.data)
          that.narrations = JSON.parse(JSON.stringify(response.data));
          //alert(that.narrations)

          // //
          // ////alert("pooooop" + that.users[that.users.length - 1].accountname);
          that.newNarration = " ";

          that.popupActive5 = false;

          that.spdata = [];
          that.emaildata = [];
          that.groupdata = [];
          that.agentdata = [];

          if (that.field + "" == "area") {
            //alert("in area")
            that.filteredAreaNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.spdata.push(that.narrations[i].name + "");
              that.popupdata = that.filteredAreaNarrations;
            }
          } else if (that.field + "" == "email") {
            //alert("in filtered")
            that.filteredEmailNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.emaildata.push(that.narrations[i].name + "");
            }
            that.popupdata = that.filteredEmailNarrations;
          } else if (that.field + "" == "group") {
            //alert("in group")
            that.filteredGroupNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.groupdata.push(that.narrations[i].name + "");
            }
            that.popupdata = that.filteredGroupNarrations;
          }
          // //
          // ////alert(that.spdata)
          //  //alert("api called 2")
        })
        .catch(error => {
          alert(error);
        });

      this.$forceUpdate();
    },
    filtering: function(e) {
    
      if (e.text !== "") {
        var str = e.text;
        var splitStr = str.toLowerCase().split(" ");
        for (var i = 0; i < splitStr.length; i++) {
          splitStr[i] =
            splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }

        if (this.currentfield == "comboarea")
          document.getElementById("areais").value = splitStr.join(" ");
        else document.getElementById("groupdata").value = splitStr.join(" ");
      }
    },
    filtering2(name) {
      this.currentfield = name + "";
      
    },
    showAddPopup() {
      this.popupActive4 = true;

      this.$forceUpdate();
    },
    showAddPopupNarration() {
      this.popupActive5 = true;

      this.$nextTick(() => {
        this.$refs.addBox.focus();
      });
    },
    handleSelected() {
      if (this.annexurecalled != "1") {
        let finder = this.selected2.id;
        //
        ////alert(finder);
        let k = 0;
        let n = 0;
        let id = "annexureCheck";
        for (var y in this.popupdata) {
          //
          ////alert(y.id);
          if (this.popupdata[y].id == finder) {
            n = k;
          }
          k++;
        }
        //
        ////alert(n);

        id += n;
        document.getElementById(id).checked = true;
        this.selected2 = [];
      } else {
        //alert("this")
        this.popupActive3 = false;
        this.annexureText = this.selected.name;
        this.annexurecalled = "0";
      }
    },
    filteredList() {
      ////alert("p");
      let p = document.getElementById("filterbar").value.toLowerCase();
      var searchtag = "name";
      this.filteredAnnexures = [];

      if (p == "") {
        this.filteredAnnexures = this.annexures;
      } else {
        for (var x in this.annexures) {
          //let id = this.users[x].id.toLowerCase();
          searchtag = this.annexures[x].name.toLowerCase();

          if (searchtag.indexOf(p) == 0) {
            //
            ////alert(name);
            this.filteredAnnexures.push(this.annexures[x]);
          }
        }
      }
    },
    isGSTvalid($event) {
      // alert("no");
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      var n = this.DGSTNo + "";

      if (n.length <= 1) {
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          // 46 is dot
        
          return $event.preventDefault();
   
        } else {
          console.log("khali");
        }
      } else if (n.length > 1 && n.length <= 6) {
        if (keyCode <= 122 && keyCode >= 97) {
          // 46 is dot

          this.upper("DGSTNo");
        } else {
          return $event.preventDefault();
        }
      } else if (n.length > 6 && n.length <= 10) {
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          // 46 is dot
          return $event.preventDefault();
        } else {
          console.log("khali");
        }
      } else if (n.length > 10 && n.length <= 14) {
        {
          if (keyCode <= 122 && keyCode >= 97) {
            // 46 is dot
            this.upper("DGSTNo");
          } else {
            return $event.preventDefault();
          }
        }
      } else {
        this.upper("DGSTNo");
        return $event.preventDefault();
      }

      if (this.DGSTNo.length > 1 && this.DGSTNo.length <= 12)
        this.PAN = this.DGSTNo.substring(2, this.DGSTNo.length + 1);

       if(this.DGSTNo.length==2)
        {var code=parseInt(this.DGSTNo.substring(0,2)+"")+""
        
          this.State= this.gstwisestates[code]}
    },
    newdisable() {
      this.titleAction = "New";
     this.annexurecalled = "1";
      this.disAdd = true;
      this.buttondis = false;
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = true;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
       this.AcCode=""
       this.AcName=""

this.Address1=""
    
    this.BankACName=""

this.Address2=""

this.IFSCCode=""

this.State=""
  this. BankACNo=""
  this.City=""
this.v=""
this.Division=""
  this.PinCode=""
        
        this.Collectorate=""
          this.Distt=""
          this.DGSTNo=""
          this.SACCode=""

this.Distance=""
          
           this.OpeningBalanceDr=""
          
          this.ContactPerson=""
         
           this.OpeningBalanceCr=""
        
        this.InttDepcRate=""
  
  this.ContactNo=""
    this.TDSRate=""
        
        this.comboemail=""
          this.comboarea=""
  
  this.TGSTShare=""
    
    this.combogroup=""
  
  this.Quantity=""
    this.PAN=""
  
  this.AadhaarNo=""
    this.TDSAcNo=""
          
          this.CompositionY
            this.Works=""
        
        this.NameAddress1=""
        
        this.NameAddress2=""
          this.dbIndex = this.dbIndex == "" ? null : this.dbIndex

      this.field = "cashnarration";
      this.popupdata = this.filteredAnnexures;
      this.popupActive3 = true;
    },
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },

    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    save() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      this.disSave = false;

      var n = {
        dataAll: {
          AcCode: this.AcCode,
          AcName: this.AcName,
          Address1: this.Address1,
          BankACName: this.BankACName,
          Address2: this.Address2,
          IFSCCode: this.IFSCCode,
          BankACNo: this.BankACNo,
          v: this.v,
          City: this.City,
          state:this.State,
          Division: this.Division,
          PinCode: this.PinCode,
          Collectorate: this.Collectorate,
          Distt: this.Distt,
          DGSTNo: this.DGSTNo,
          SACCode: this.SACCode,
          Distance: this.Distance,
          OpeningBalanceDr: this.OpeningBalanceDr,
          ContactPerson: this.ContactPerson,
          OpeningBalanceCr: this.OpeningBalanceCr,
          InttDepcRate: this.InttDepcRate,
          ContactNo: this.ContactNo,
          TDSRate: this.TDSRate,
          MEmailIDArea: this.comboemail,
          Area: this.comboarea,
          TGSTShare: this.TGSTShare,
          AgentGroup: this.combogroup,
          Quantitiy: this.Quantitiy,
          PAN: this.PAN,
          AadhaarNo: this.AadhaarNo,
          TDSAcNo: this.TDSAcNo,
          CompositionYN: this.CompositionYN,
          Works: this.Works,
          NameAddress1: this.NameAddress1,
          NameAddress2: this.NameAddress2,
          index: this.dbIndex == "" ? null : this.dbIndex
        },
        companyname: companyName
      };

      // //alert(JSON.stringify(n));

      axios
        .post("http://localhost:2000/saveLedger", n)
        .then(response => {
          ////alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data.dooda);
          resp = resp.slice(0, -1);
          resp = resp.substring(1);

          if (resp == "duplicate") {
            this.DuplicateNotify();
          } else {
            this.Savenotify();
          }

          //this.Savenotify();
          // //alert("saved")
        })
        .catch(error => {
          alert(error);
        });

      

      this.buttondis = true;
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = false;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;

      document.getElementById("addButton").focus();
      (this.buttonActiveList = [
        "active",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ]),
        this.$forceUpdate();
    },

    getData(text) {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      let ch;
      if (text == "prev") {
        ch = parseInt(this.requiredIndex) - 1;
      }
      if (text == "next") {
        ch = parseInt(this.requiredIndex) + 1;
      }
      if (text == "init") {
        this.requiredIndex = -999;
      }
      var n = {
        companyname: companyName,
        requiredIndex: this.requiredIndex == -999 ? -999 : ch
      };
      // //alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/getLedger", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            this.AcCode = resp.AcCode;
            this.AcName = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
            this.State=resp.state
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.comboemail = resp.MEmailIDArea;
            this.comboarea=resp.Area
            this.TGSTShare = resp.TGSTShare;
            this.combogroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },

    onDelete() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      ////alert(this.group);

      var n = {
        indexToDelete: this.bufferIndex,
        companyname: companyName
      };
      ////alert("Sending these to delete: " + JSON.stringify(n));
      axios
        .post("http://localhost:2000/deleteLedger", n)
        .then(response => {
          ////alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          resp = resp.slice(0, -1);
          resp = resp.substring(1);
          console.log(resp);
          window.location.href="/dashboard/newledgervue"
        })
        .catch(error => {
          alert(error);
        });
    },
 onExit() {
      this.buttondis = true;
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.dbIndex = -999;
      this.titleAction = "View"
      this.getLast();
    },

    editButton() {
      this.titleAction="Edit"
    // alert(document.getElementById("emaildata").value)
      this.dbIndex = this.bufferIndex;
      // //alert(this.dbIndex);
      this.buttondis = false;
      this.buttonen = true;
      this.disSave = false;
      this.showdrcr = true;
      this.disAdd = true;
      this.buttondis = false;
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = false;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.isEditingOld = true;

       
    },

    computed: {
      now: function() {
        var today = new Date();
        var date =
          today.getFullYear() +
          "-" +
          (today.getMonth() + 1) +
          "-" +
          today.getDate();
        return date;
      },
      currentday: function() {
        var today = new Date();
        var weekday = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday"
        ];
        var currenday = weekday[today.getDay()];
        return currenday;
      }
    },

    enterKeyTrig(p) {
      var id = p.slice(0, -1);
      var k = p.substring(p.length - 1, p.length);
      k = parseInt(k);

      var val = "saveButton";

      ////alert(JSON.stringify(this.cashVauchers[k].accountno));
      // console.log(id);

      if (id == "accountno") {
        if (this.cashVauchers[k].accountno == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "narration") {
        if (this.cashVauchers[k].narration == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "payment") {
        if (this.cashVauchers[k].payment == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "receipt") {
        if (this.cashVauchers[k].receipt == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }

      if (id == "discount") {
        if (k == this.cashVauchers.length - 1) {
          this.cashVauchers.push({
            accountno: "",
            narration: "",
            payment: "",
            receipt: "",
            discount: ""
          });

          this.addNotify();
        } else if (this.cashVauchers[k].discount == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }
    },
    Savenotify() {
      this.$vs.notify({
        title: "Success",
        text: "Saved Annexure Data Successfully",
        iconPack: "feather",
        icon: "icon-//alert-circle",
        color: "success"
      });
    },
    DuplicateNotify() {
      this.$vs.notify({
        title: "Error",
        text: "Duplicate Name not allowed!",
        iconPack: "feather",
        icon: "icon-//alert-circle",
        color: "danger"
      });
    }
  },
  created() {
 

    this.reload = sessionStorage.getItem("reload");
    this.buttonen = false;

    var user = sessionStorage.getItem("user");

    var companyName = JSON.parse(user)[0].companyname;

    this.companyname = companyName;
    //alert(companyName)
    var type = JSON.parse(user)[0].type;

    if (type == "user") {
      var Role = sessionStorage.getItem("role");
      //  var permissions = JSON.parse(Role)[0].rolename.permission[0].roletype;
      var perm = JSON.parse(Role);
      var Add = perm[0].rolename.permission[0].roletype.Add;
      var modify = perm[0].rolename.permission[0].roletype.modify;
      var del = perm[0].rolename.permission[0].roletype.delete;

      console.log(Add + " " + modify + " " + del);
    }
var v=[]
    let that = this;
    var i;
     var value1 = { companyname: companyName, directory: "ledger_master.json" };
 axios
      .post("/user/getCashformData", value1)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
       // this.users = json.ledgerdata;
      //  alert(JSON.stringify(json.ledgerdata))
        
          for (i = 0; i < json.ledgerdata.length; i++) {
              v.push(json.ledgerdata[i].AcName + "");
              that.acnamedata = v;
            }
       
        this.filteredUsers = this.users;
      })
      .catch(error => {
        alert(error);
      });

    var value2 = { companyname: companyName, directory: "narration.json" };
    axios
      .post("/user/getCashformData", value2)
      .then(response => {
        //alert("api 1")
        var data = JSON.stringify(response.data);
        //alert("api called 1" +data)
        var json = JSON.parse(data);

        json.narrations.filter(function(item, index) {
          if (item["area"] + "" != "undefined") {
            that.narrations = json.narrations[index]["area"];

            that.filteredAreaNarrations = that.narrations;
             v = [];

            for (i = 0; i < that.narrations.length; i++) {
              v.push(that.narrations[i].name + "");
              that.spdata = v;
            }
          }


  if(item["City"]+""!="undefined")
  {
  
    
        that.filteredCityNarrations = json.narrations[index]["City"]
        v = [];
       
        for (i = 0; i < that.filteredCityNarrations.length; i++) {
          v.push(that.filteredCityNarrations[i].name + "");
          that.citydata = v;
          
        }
  }

  // if(item["AcName"]+""!="undefined")
  // {
  
    
  //       that.filteredAcNameNarrations = json.narrations[index]["AcName"]
  //       v = [];
       
  //       for (i = 0; i < that.filteredAcNameNarrations.length; i++) {
  //         v.push(that.filteredAcNameNarrations[i].name + "");
  //         that.acnamedata = v;
          
  //       }
  // }

  if(item["Distt"]+""!="undefined")
  {
  
    
        that.filteredDisttNarrations = json.narrations[index]["Distt"]
        v = [];
       
        for (i = 0; i < that.filteredDisttNarrations.length; i++) {
          v.push(that.filteredDisttNarrations[i].name + "");
          that.disttdata = v;
          
        }
  }

  if(item["Works"]+""!="undefined")
  {
  
    
        that.filteredWorksNarrations = json.narrations[index]["Works"]
        v = [];
       
        for (i = 0; i < that.filteredWorksNarrations.length; i++) {
          v.push(that.filteredWorksNarrations[i].name + "");
          that.worksdata = v;
          
        }
  }

          if (item["email"] + "" != "undefined") {
            that.filteredEmailNarrations = json.narrations[index]["email"];
            v = [];

            for (i = 0; i < that.filteredEmailNarrations.length; i++) {
              v.push(that.filteredEmailNarrations[i].name + "");
              that.emaildata = v;
            }
          }

          if (item["group"] + "" != "undefined") {
            that.filteredGroupNarrations = json.narrations[index]["group"];
            v = [];

            for (i = 0; i < that.filteredGroupNarrations.length; i++) {
              v.push(that.filteredGroupNarrations[i].name + "");
              that.groupdata = v;
            }
          }
        });
      })
      .catch(error => {
        alert(error);
      });

      this.getData('prev')

  },

 mounted() {
    // //alert("page mounted");\
    let user = sessionStorage.getItem("user");
    let companyName = JSON.parse(user)[0].companyname;
    this.titleAction = "View";
  
 




 

 









    var n = {
      companyname: companyName
    };

    axios
      .post("http://localhost:2000/GetAllAnnexureNames", n)
      .then(response => {
        ////alert(JSON.stringify(response.data));

        let data = JSON.stringify(response.data);

        let json = JSON.parse(data);
        this.annexures = json.names;
        // //alert(JSON.stringify(this.annexures));
        this.filteredAnnexures = this.annexures;
      })
      .catch(error => {
        alert(error);
      });

    let that = this;
    window.addEventListener("keydown", function(event) {
      if(event.keyCode==18){
                if(that.currentfield=="comboarea")
{
 that.showdescNar('area')
}
else  if(that.currentfield=="combogroup")
{
 that.showdescNar('group')
}
else  if(that.currentfield=="Works")
{
 that.showdescNar('Works')
}
else  if(that.currentfield=="Distt")
{
 that.showdescNar('Distt')
}
else  if(that.currentfield=="AcName")
{
 that.showdescNar('AcName')
}
else  if(that.currentfield=="City")
{
 that.showdescNar('City')
}
else  if(that.currentfield=="comboemail")
{
 that.showdescNar('email')
}

      }
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
        if (that.popupActive3 == true) {
          that.popupActive3 = false;

          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        if (that.drcrpopup == true) {
          that.drcrpopup = false;
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
      if (event.keyCode === 38) {
        // up arrow
        if (that.drcrpopup == true) {
          that.popupKeyUp();
        }

        that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
      }
      if (event.keyCode === 40) {
        // down arrow

        if (that.drcrpopup == true) {
          that.popupKeyDown();
        }
         that.$forceUpdate();
      }
       if (event.keyCode === 13) {
        // enter

        if (that.drcrpopup == true) {
          
          that.drcrpopup = false;
          //alert(document.getElementById("drcr" + that.popupSelectedRow))
         that.annexureText= that.drcrFilteredNarrations[that.popupSelectedRow].name;
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }


   
      }
if (event.keyCode === 80) {
// alert(that.$router.currentRoute.path)
  if(that.$router.currentRoute.path=="/dashboard/newledgervue")
        {//alert("df")
        //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
        if (that.disEdit== false && that.disAdd==false && that.disPrevious==false && that.disNext==false && that.disLast==false && that.disFirst==false && that.disSearch==false && that.disPrinter==false) 
        {
          that.getData('prev');
         
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
}
if (event.keyCode === 78) {
// alert(that.$router.currentRoute.path)
  if(that.$router.currentRoute.path=="/dashboard/newledgervue")
        {//alert("df")
        //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
        if (that.disEdit== false && that.disAdd==false && that.disPrevious==false && that.disNext==false && that.disLast==false && that.disFirst==false && that.disSearch==false && that.disPrinter==false) 
        {
          that.getData('next');
         
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
}
if (event.keyCode === 70) {
// alert(that.$router.currentRoute.path)
  if(that.$router.currentRoute.path=="/dashboard/newledgervue")
        {//alert("df")
        //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
        if (that.disEdit== false && that.disAdd==false && that.disPrevious==false && that.disNext==false && that.disLast==false && that.disFirst==false && that.disSearch==false && that.disPrinter==false) 
        {
          that.getFirst();
         
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
}
if (event.keyCode === 76) {
// alert(that.$router.currentRoute.path)
  if(that.$router.currentRoute.path=="/dashboard/newledgervue")
        {//alert("df")
        //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
        if (that.disEdit== false && that.disAdd==false && that.disPrevious==false && that.disNext==false && that.disLast==false && that.disFirst==false && that.disSearch==false && that.disPrinter==false) 
        {
          that.getLast();
         
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
}

    });
    
  }
};
</script>




