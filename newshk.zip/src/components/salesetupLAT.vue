
<style>
.select-large input.vs-select--input {
  padding: 5px;
}

#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
.margin {
  margin: 5px;
}
.vs-button {
  display: inline-block;
}
.tdInputsmall {
  width: 100px;
  height: 25px;
}
.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>

<template>
  <div class="modalsalesetup">
    <div class="vx-card p-6" style>
      <!-- popup definition starts -->


<vs-popup classContent="popup-example" title="Account Form" button-close-hidden="true" :active.sync="popupActiveLedger"  >
       <modalLedgerSetup v-model="modalOpenLedger" v-on:childToParent="onChildClick" :SearchText="searchlabel"  ref="childComponentLedger1"/>
   </vs-popup>

  <vs-popup classContent="popup-example" title="Sale Series" :active.sync="popupActiveSaleSeries" fullscreen >
       <saleseriesmodal v-model="modalOpenSaleSeries"  :SearchText="searchlabel"  ref="childComponentSaleSeries"/>
   </vs-popup>


      <vs-popup classContent="popup-example" title :active.sync="popupActive_2">
        <div style="overflow-x:auto;">
          <table class="tables">
            <thead class="bg-primary">
              <tr>
                <th>
                  <p style="color:white;">Member ID</p>
                </th>
                <th>
                  <p style="color:white;">First Name</p>
                </th>
                <th>
                  <p style="color:white;">Middle Name</p>
                </th>
                <th>
                  <p style="color:white;">Last Name</p>
                </th>
                <th>
                  <p style="color:white;">Address</p>
                </th>
                <th>
                  <p style="color:white;">Actions</p>
                </th>
              </tr>
            </thead>

            <tbody>
              <tr scope="row" v-for="(result,j) in popupDataList" :key="j">
                <td>{{result.memberId}}</td>
                <td>{{result.firstName}}</td>
                <td>{{result.middleName}}</td>
                <td>{{result.lastName}}</td>
                <td>{{result.address}}</td>

                <div class="row justify-content-center">
                  <vs-button class="button" size="small" @click="setAccountNo(j)">select</vs-button>
                </div>
              </tr>
            </tbody>
          </table>
        </div>
      </vs-popup>

      <!--  Popup definition ends -->

      <vs-popup classContent="popup-example" title="Account Form" button-close-hidden="true" :active.sync="taxStructureActive" >
 <table width="100%" border="0" class="tables">
      <tr>
        <td width="25%"></td>
        <td width="50%">
          <center>
            <h1 class="text-primary">
              Tax Wise Sale
              <br />
              <h4>
                <font color="grey">{{titleAction}}</font>
              </h4>
            </h1>
          </center>
        </td>
        <td width="25%" align="right">
          Today {{now}}
          <br />
          {{currentday}}
        </td>
      </tr>
      <br />
    </table>
    <!--header END-->
        <!-- <date-picker v-model="date" type="date" lang="en" format="YYYY-MM-dd"
        ></date-picker>-->

      <!-- <flat-pickr
        
          v-model="date"
          id="date"
          @input="DateFormate"
          size="small"
          :config="configdateTimePicker"
          style="width:180px; height:25px;"
          placeholder="d-m-Y"
          :disabled="buttondis"
      />-->

          

    <br />
    <!-- Table Start -->
    <div style="overflow-x:auto;">
      <table id="customers" :data="tabledata">
        <tr>
          <th
            d="headerid"
            v-for="(cashheader,key) in cashheaders"
            class="bg-primary"
            :key="`input${key}`"
          >
            {{cashheader}}
           
          </th>
        </tr>
        <tr v-for="(cashVaucher, k) in cashVauchers" :key="k">
          
          <td>
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.Name"
              :id="'0' + k"
             
            />

          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.Tax_type"
             
              :id="'1' + k"
              
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.Taxrate"
              
              :id="'2' + k"
              
              
            />
          </td>
          <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.Vatform"
             
              :id="'3' + k"
            
            />
          </td>
            <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.purcode"
             
              :id="'4' + k"
          
            />
          </td>
            <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.Salecode"
              
              :id="'5' + k"
            
            />
          </td>
            <td class="tdInputsmall">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.GSTreturn"
              
              :id="'6' + k"
        
            />
          </td>
          <td scope="row">
            <vs-input
              class="w-full"
              size="small"
              v-model="cashVaucher.IGSTcode"
              
              :id="'7' + k"
    
            />
          </td>
          <td align="center" class="tdDeletebutton">
            <vs-button
              size="small"
              icon-pack="feather"
              icon="icon-trash"
              color="danger"
              style="margin:3px;"
              @click="deleteRow(k, cashVaucher)"
            ></vs-button>
          </td>
        </tr>
      </table>
    </div>
    <!-- Table End -->
    <br />
    <div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()">
        <i class="fa fa-plus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="pop">
        <i class="fa fa-minus"></i>
      </vs-button>&nbsp;
      <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div>
    <i class="far fa-trash-alt" @click="deleteRow(k, cashVaucher)"></i>
    <br />
    <div style="overflow-x:auto;" width="100%">
      <table border="0" width="100%">
       
             </table>
    </div>
    <div align="left">
      <br />
 <td width="35%" align="left" >
         <table border="0" width="50%" cellspacing="0"  class="tables">
        <br>
        <tr>
        <td class="overlap">Default Vat Rate</td>
          <td  style="padding-left: 5px"><vs-input class="w-full" size="small" v-model="input1" /></td>
 <div align="right" id="tries" >
  
          <vs-button
          style="float:right; display:inline-block;"
          title="exit"
          color="primary"
          
          id="saveButton"
          ref="saveButton"
          class="button margin"
          
          @click="saveTaxType()"
        >Save</vs-button>

          <vs-button

          style="float:right; display:inline-block;"
          title="exit"
          color="primary"
         
          id="saveButton"
          ref="saveButton"
          class="button margin"
          
          @click="save()"
        >Exit</vs-button>

        <vs-button

          style="float:right; display:inline-block;"
          title="exit"
          color="primary"
        
          id="saveButton"
          ref="saveButton"
          class="button margin"
         
          @click="save()"
        >Replace</vs-button>
</div>
          




        </tr>
        
      </table>
               
            
             
      </td>

      <br />
    </div>
  
   </vs-popup>

      <!--header START-->
      <table width="100%" border="0" class="tables">
        <tr>
          <td width="25%"></td>
          <td width="50%">
            <center>
              <h1 class="text-primary">
                Sale Setup
                <br />
                <h4>
                  <font color="grey">{{titleAction}}</font>
                </h4>
              </h1>
            </center>
          </td>
          <td width="25%" align="right"></td>
        </tr>
        <br />
      </table>

      <div class="flex mb-4" style="padding-top:20px;">
        <div
          class="w-1/2 bg-grid-color-secondary h-12 flex"
          style="height:100% !important; width:100% !important; padding-bottom:20px; margin-right:17%;"
        >
          <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
            <tr>
              <td>Color</td>
              <td>
                <vs-select
                  v-model="salesetup_color"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in colorlist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>
            <tr>
              <td class="overlap">Cust. Name</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_custname"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>
            <tr>
              <td class="overlap">Terms</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_terms"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Vehicle No.</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_vehicleno"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>
            <tr>
              <td>Tax Type</td>
              <td>
                <vs-select
                  v-model="salesetup_taxtype"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in taxtypelist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td>Bill Cash</td>
              <td>
                <vs-select
                  v-model="salesetup_billcash"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in billcashlist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td class="overlap">Duty</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_duty"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Product</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_product"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 1</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_remno1"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 2</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_remno2"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Rem No. 3</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_remno3"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Transport</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_transport"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">Broker</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_broker"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td class="overlap">GR Number</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_grnumber"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
            </tr>

            <tr>
              <td>Sale A/c</td>
              <td>
                <vs-select
                  v-model="salesetup_saleac"
                  class="w-full select-large"
                  style="margin-top:6px;"
                  :disabled="buttondis"
                >
                  <vs-select-item
                    :key="index"
                    :value="item.value"
                    :text="item.text"
                    v-for="(item,index) in supplylist"
                    class="w-full"
                    style="width:180px; height:25px;"
                  />
                </vs-select>
              </td>
            </tr>

            <tr>
              <td class="overlap">Cess Code</td>
              <td>
                <vs-input
                  class="w-full"
                  size="small"
                  v-model="salesetup_cesscode"
                  style="width:180px;  margin-top:10px;"
                  :disabled="buttondis"
                />
              </td>
              <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_cesscode')">...</button>
        </td>
            </tr>
          </table>
        </div>
        <div
          class="w-1/2 bg-grid-color-secondary h-12 flex"
          style="height:100% !important; width:100% !important; padding-bottom:20px;"
          :disabled="buttondis"
        >
          <table border="0" cellspacing="5" style="table-layout:fixed; width:100%;">
            <tr>
              <td>
                <table>
                  <tr>
                    <td>
                      <font color="red">C.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_cgstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_cgstac1')">...</button>
        </td>
                  </tr>
                  <tr>
                    <td>
                      <font color="red">S.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_sgstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_sgstac1')">...</button>
        </td>
                  </tr>
                  <tr>
                    <td>
                      <font color="red">I.GST A/c</font>
                    </td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_igstac1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_igstac1')" >...</button>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td>
                <table>
                  <tr>
                    <td>TCS A/c</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_tdsac"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>Tcs Cess A/c</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_tcscessac"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <button style=" height:25px; margin-top:10px; width:20px;"  @click="openLedger('salesetup_tcscessac')">...</button>
                  </tr>

                  <tr>
                    <td>Tcs on Tax</td>
                    <td>
                      <vs-select
                        v-model="salesetup_tcsontax"
                        class="w-full select-large"
                        style="margin-top:6px;"
                        :disabled="buttondis"
                      >
                        <vs-select-item
                          :key="index"
                          :value="item.value"
                          :text="item.text"
                          v-for="(item,index) in tcsontaxlist"
                          class="w-full"
                          style="width:180px; height:25px;"
                        />
                      </vs-select>
                    </td>
                  </tr>

                  <tr>
                    <td>TCS Rate All</td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_tcsrateall"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>+/-</td>
                    <td>Rate</td>
                  </tr>
                  <tr>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_labour"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_labour"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;"  @click="openLedger('salesetup_labour')">...</button>
        </td>
                  <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v1"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v1"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                      <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_postage"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_postage"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_postage')">...</button>
        </td>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v2"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v2"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_discount"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_discount"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_discount')">...</button>
        </td>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v3"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v3"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_freight"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_freight"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                     <td>
          <button style=" height:25px; margin-top:10px; width:20px;"  @click="openLedger('salesetup_freight')">...</button>
        </td>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v4"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v4"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                     <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense5"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense5"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense5')">...</button>
        </td>
                  <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v5"
                        style="width:180px;  margin-top:10px;"
                        
                      /></td>
                    <td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v5"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense6"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense6"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense6')">...</button>
        </td>
                     <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v6"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v6"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense7"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense7"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense7')">...</button>
        </td>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v7"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v7"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense8"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense8"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                     <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense8')">...</button>
        </td>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v8"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v8"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense9"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense9"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense9')">...</button>
        </td>
                   <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v9"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v9"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                  <tr>
                    <vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_expense10"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_expense10"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                    <td>
          <button style=" height:25px; margin-top:10px; width:20px;" @click="openLedger('salesetup_expense10')">...</button>
        </td>
                    <td><vs-input
                        class="w-full"
                        size="small"
                        v-model="purchasesetup2_1_v10"
                        style="width:180px;  margin-top:10px;"
                        
                      ></vs-input></td>
                    <td>
                      <vs-input
                        class="w-full"
                        size="small"
                        v-model="salesetup_v10"
                        style="width:180px;  margin-top:10px;"
                        :disabled="buttondis"
                      />
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <hr />
      <center>Additional Settings</center>
      <hr />
      <div class="flex mb-4" style="padding-top:20px;">
        <table>
          <tr>
            <td>
              <table>
                <tr>
                  <td>Disable Inv. Time</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_disableinvtime"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Disable Rev. Time</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_disablerevtime"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>A/c Name in Led.</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_acnameinled"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Remarks Post</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_remarkspost"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>

                <tr>
                  <td>Cursor Focus to Date</td>
                  <td>
                    <vs-select
                      v-model="salesetup_cursorfocustodate"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>Show Window Exp. Before Tax</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_showwindowexpbeforetax"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Show Window Exp. After Tax</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_showwindowexpafterttax"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Item Name in Led.</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_itemnameinled"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Extra Remarks</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_extraremarks"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>CD Window</td>
                  <td>
                    <vs-select
                      v-model="salesetup_cdwindow"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>Round Off</td>
                  <td>
                    <vs-select
                      v-model="salesetup_roundoff"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Tax Round Off</td>
                  <td>
                    <vs-select
                      v-model="salesetup_taxroundoff"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Display Item</td>
                  <td>
                    <vs-select
                      v-model="salesetup_displayitem"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Default Button</td>
                  <td>
                    <vs-select
                      v-model="salesetup_defaultbutton"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in defaultbuttonlist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
                <tr>
                  <td>Low Sale</td>
                  <td>
                    <vs-select
                      v-model="salesetup_lowsale"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                Decimals
                <tr>
                  <td>Rate</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_rate"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Bag</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_bag"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Qty</td>
                  <td>
                    <vs-input
                      class="w-full"
                      size="small"
                      v-model="salesetup_qty"
                      style="width:180px;  margin-top:10px;"
                      :disabled="buttondis"
                    />
                  </td>
                </tr>
                <tr>
                  <td>Negative Stock Lock</td>
                  <td>
                    <vs-select
                      v-model="salesetup_lowsale"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
              </table>
            </td>
            <td>
              <table>
                <tr>
                  <td>
                    <font color="red">Display HSN Code</font>
                  </td>
                  <td>
                    <vs-select
                      v-model="salesetup_displayhsncode"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>
  <tr>
                  <td>
                    <font >Cash/Card</font>
                  </td>
                  <td>
                    <vs-select
                      v-model="salesetup_displayCashCard"
                      class="w-full select-large"
                      style="margin-top:6px;"
                      :disabled="buttondis"
                       @input="cashcardchangecheck"
                      
                      autocomplete="true"
                    >
                      <vs-select-item
                        :key="index"
                        :value="item.value"
                        :text="item.text"
                        
                        v-for="(item,index) in yesnolist"
                        class="w-full"
                        style="width:180px; height:25px;"
                      />
                    </vs-select>
                  </td>
                </tr>

              </table>
            </td>
          </tr>
        </table>
      </div>

      <div align="right">
        <br />

        <br />
        <!-- Button set start-->
        <div align="left">
          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="save()"
          >Save</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="taxtableshow"
          >Tax Structure</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
             @click="openSaleSeriesPopup"
          >Sale Series</vs-button>

          <vs-button
            style="float:right; display:inline-block;"
            :color="getColor('saveButton')"
            :disabled="buttondis"
            id="saveButton"
            class="button margin"
            @keyup.right="buttonNext('saveButton')"
            @keyup.left="buttonPrev('saveButton')"
            @click="save()"
          >Browse</vs-button>
        </div>
        <!-- Button set end -->
      </div>
      <br />
      <br />
      <br />
    </div>
  </div>
</template>




<script>
import flatPickr from "vue-flatpickr-component";
import axios from "@/axios";
import "flatpickr/dist/flatpickr.css";
import saleseriesmodal from "@/components/saleseriesmodal.vue";
import modalLedgerSetup from "@/components/Ledgerpopup2.vue";
export default {
  name: "modalsalesetup",

  data() {
    return {

      
taxStructureActive: false,
rowlength: 1,
cashVauchers: [
        {
          Name: "",
          Tax_type: "",
          Taxrate: "",
          Vatform: "",
          purcode: "",
          salecode: "",
          GSTcode:   "",     
          IGSTcode:   "",  
             }
      ],
      cashheaders: [
        "Name",
        "Tax_type",
        "Taxrate",
        "Vat Form",
        "Pur.code",
        "Sale.code",
        "GST Return",
        "I.GST Code",
      ],


      sentValue:"",
   popupActiveSaleSeries: false,
      modalOpenSaleSeries:false,

  purchasesetup2_1_labour: "",
  purchasesetup2_1_v1: "",
  purchasesetup2_1_postage: "",
  purchasesetup2_1_v2: "",
  purchasesetup2_1_discount: "",
  purchasesetup2_1_v3 : "",
  purchasesetup2_1_freight: "",
  purchasesetup2_1_v4 : "",
  purchasesetup2_1_expense5 : "",
  purchasesetup2_1_v5 : "",
  purchasesetup2_1_expense6 : "",
  purchasesetup2_1_v6 : "",
  purchasesetup2_1_expense7 : "",
  purchasesetup2_1_v7 : "",
  purchasesetup2_1_expense8 : "",
  purchasesetup2_1_v8 : "",
  purchasesetup2_1_expense9 : "",
  purchasesetup2_1_v9 : "",
  purchasesetup2_1_expense10 : "",
  purchasesetup2_v10 : "",


   firsttime:0,
      currentsetupform:"",
      popupActiveLedger: false,
      modalOpenLedger:false,
      salesetup_displayCashCard:"",
  
           

      configdateTimePicker: {
        allowInput: true,
        dateFormat: "d-m-Y"
      },
      titleAction: "",

      date: null,
      salesetup_v9: "",
      salesetup_expense10: "",
      salesetup_expense9: "",
      salesetup_discount: "",
      salesetup_postage: "",
      salesetup_labour: "",
      salesetup_tdsac: "",
      salesetup_color: "",
      salesetup_custname: "",
      salesetup_terms: "",
      salesetup_vehicleno: "",
      salesetup_taxtype: "",
      salesetup_billcash: "",
      salesetup_duty: "",
      salesetup_product: "",
      salesetup_remno1: "",
      salesetup_remno2: "",
      salesetup_remno3: "",
      salesetup_transport: "",
      salesetup_broker: "",
      salesetup_grnumber: "",
      salesetup_saleac: "",
      salesetup_cesscode: "",

      salesetup_cgstac1: "",
      salesetup_sgstac1: "",
      salesetup_igstac1: "",

      salesetup_tcsac: "",
      salesetup_tcscessac: "",
      salesetup_tcsontax: "",
      salesetup_tcsrateall: "",

      salesetup_v1: "",
      salesetup_v2: "",
      salesetup_v3: "",
      salesetup_v4: "",
      salesetup_v5: "",
      salesetup_v6: "",
      salesetup_v7: "",
      salesetup_v8: "",

      salesetup_v10: "",

      salesetup_freight: "",
      salesetup_expense5: "",
      salesetup_expense6: "",
      salesetup_expense7: "",
      salesetup_expense8: "",

      salesetup_disableinvtime: "",
      salesetup_disablerevtime: "",
      salesetup_acnameinled: "",
      salesetup_remarkspost: "",
      salesetup_cursorfocustodate: "",
      salesetup_showwindowexpafterttax: "",
      salesetup_showwindowexpbeforetax: "",
      salesetup_itemnameinled: "",
      salesetup_extraremarks: "",
      salesetup_cdwindow: "",
      salesetup_roundoff: "",
      salesetup_taxroundoff: "",
      salesetup_displayitem: "",
      salesetup_defaultbutton: "",
      salesetup_lowsale: "",
      salesetup_rate: "",
      salesetup_bag: "",
      salesetup_qty: "",
      salesetup_negativestocklock: "",
      salesetup_displayhsncode: "",

      billcashlist: [
        { text: "Bill", value: "bill" },
        { text: "Cash Memo", value: "cashmemo" }
      ],

      tcsontaxlist: [
         { text: "Yes", value: "yes" },
        { text: "No", value: "no" }, 
        { text: "Amt", value: "amt" }, 
      ],
      colorlist: [
        { text: "0.Default Scheme", value: "defaultscheme" },
        { text: "1. Scheme No. 1", value: "schemeno1" },
        { text: "2. Scheme No. 2", value: "schemeno1" },
        { text: "3. Scheme No. 3", value: "schemeno1" },
        { text: "4. Scheme No. 4", value: "schemeno1" },
        { text: "5. Scheme No. 5", value: "schemeno1" },
        { text: "6. Scheme No. 6", value: "schemeno1" }
      ],

      taxtypelist: [
        { text: "Vat Sale", value: "vatsale" },
        { text: "Out of State (R.D.)", value: "outofstate(rd)" },
        { text: "Retail Within Sale", value: "retailwithinsale" },
        { text: "Out of State (URD)", value: "outofstate(urd)" },
        { text: "Exempted Sale", value: "exemptedsale" },
        { text: "Tax Free Within State", value: "taxfreewithinstate" },
        { text: "Export Sale", value: "exportsale" },
        { text: "H Form Within State", value: "hformwithinstate" },
        { text: "H Form Outside State", value: "hformoutsidestate" },
        { text: "E1/E2 Sale", value: "e1e2sale" },
        { text: "Including CST", value: "icludingcst" },
        { text: "Consignment", value: "consignment" },
        { text: "Including Vat", value: "includingvat" },
        { text: "J & I Form", value: "j&iform" },
        { text: "Tax Free Interstate", value: "taxfreeinterstate" }
      ],
      supplylist: [
        { text: "Manufacturing Sale", value: "manufacturingssale" },
        { text: "Trading Sale", value: "tradingsale" }
      ],

      purchaseaclist: [
        { text: "Including Duty", value: "includingduty" },
        { text: "Excluding Duty", value: "excludingduty" }
      ],

      yesnolist: [
        { text: "Yes", value: "yes" },
        { text: "NO", value: "no" }
      ],

      displayitemlist: [
        { text: "Product Code", value: "productcode" },
        { text: "HSN Code", value: "hsncode" },
        { text: "Product Name", value: "Product Name" }
      ],

      defaultbuttonlist: [
        { text: "Print", value: "print" },
        { text: "Add", value: "add" }
      ],

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],

      selectedAccountNo: "",
      rowNumberIndicator: 0,
      value1: "",
      value2: "",
      popupActive_2: false,
      popupActive3: false,
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false
    };
  },

  components: {
    flatPickr,
    modalLedgerSetup,
    saleseriesmodal
  },
  methods: {
taxtableshow()
{
  this.taxStructureActive = true;
},
openSaleSeriesPopup(){
     //   alert(this.popupActiveSaleSeries+" ghfg")
      this.popupActiveSaleSeries=true
      this.modalOpenSaleSeries=true
    },
 onChildClick (value) {
       //alert("called")
       if(value=="closeledger")
       {this.popupActiveLedger=false
      this.modalOpenLedger=false;
      }
    
     else{  const words=value.split(':');
     // alert("what"+"")
      if(this.currentsetupform=="salesetup_cesscode")
      this.salesetup_cesscode = words[1]

       else if(this.currentsetupform=="salesetup_cgstac")
      this.salesetup_cgstac = words[1]
       
       else if(this.currentsetupform=="salesetup_sgstac")
      this.salesetup_sgstac = words[1]
    
     else if(this.currentsetupform=="salesetup_igstac")
      this.salesetup_igstac = words[1]

       else if(this.currentsetupform=="salesetup_tcscessac")
      this.salesetup_tcscessac = words[1]
    
      else if(this.currentsetupform=="salesetup_labour")
      this.salesetup_labour = words[1]

        else if(this.currentsetupform=="salesetup_postage")
      this.salesetup_postage = words[1]

        else if(this.currentsetupform=="salesetup_discount")
      this.salesetup_discount = words[1]

      else if(this.currentsetupform=="salesetup_freight")
      this.salesetup_freight = words[1]
      
      else if(this.currentsetupform=="salesetup_expense5")
      this.salesetup_expense5 = words[1]

      else if(this.currentsetupform=="salesetup_expense6")
      this.salesetup_expense6 = words[1]

      else if(this.currentsetupform=="salesetup_expense7")
      this.salesetup_expense7 = words[1]


      else if(this.currentsetupform=="salesetup_expense8")
      this.salesetup_expense8 = words[1]


      else if(this.currentsetupform=="salesetup_expense9")
      this.salesetup_expense9 = words[1]

      else if(this.currentsetupform=="salesetup_expense10")
      this.salesetup_expense10 = words[1]
    
      else{
        alert("emitted")
        this.$emit("fromsalesetup",words[0],words[1],words[2],words[3],words[4])
      }


      if(this.popupActiveLedger==true)
      {this.popupActiveLedger=false
      this.modalOpenLedger=false;
      }
     }
    },

      longfunctionfirst(t) {
        
       return new Promise(resolve => {
if(t=="popupActiveLedger")
{this.popupActiveLedger=true
  this.modalOpenLedger=true
resolve('resolved');
}
else if(t=="PopUp")
{this.PopUp=true
resolve('resolved');}
       })
       },
 async shortfunctionsecond(g,k,l) {
   if(g=="popupActiveLedger")
   {await this.longfunctionfirst(g); 
   
  
   this.$refs.childComponentLedger1.setValue(k,l,this.sentValue);
  
   }
   else if(g=="PopUp")
   {await this.longfunctionfirst(g); 
   document.getElementById("card_setup").focus()}
   },
    openLedger(value,value2){
      this.currentsetupform=value

      alert(value2)
      if(value2)
      this.sentValue=value2
     
     this.shortfunctionsecond("popupActiveLedger","true",value)
    },
    cashcardchangecheck(){
     
        if (this.salesetup_displayCashCard+"" == "yes") {
          this.shortfunctionsecond("PopUp","true","bankname")
     
      }
    },
CashCardOption(){
  this.PopUp=false
},

 onlyNumber($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
        // 46 is dot
        return $event.preventDefault();
      } else return null;
    },
    


    // get collection
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },
    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },

saveTaxType() {
     
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      alert(" something yo " + JSON.stringify(companyName))
      var value = {
        companyname: companyName,
        taxTable : this.cashVauchers,
        note:"sale"
      };
        
console.log(value)
        alert(JSON.stringify(this.cashVauchers))

     

      axios
        .post("/transactions/saveTaxStructure", value)
        .then(function(response) {
          
          alert(response);          
        })
        .catch(error => {
          alert(error);
        });

    },

    getTaxType() {
     
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      alert(" something yo " + JSON.stringify(companyName))
      var value = {
        companyname: companyName,
        note: "sale"
        
      };
        let that=this
axios
        .post("/transactions/getTaxStructure", value)
        .then(function(response) {
         var data = JSON.stringify(response.data);

          var json = JSON.parse(data);


         that.cashVauchers= json.completejson.sale.data
         alert(JSON.stringify(json.names))          
        })
        .catch(error => {

          alert(error);
        });

    },

  addNewRow() {
      this.cashVauchers.push({
          Name: "",
          Tax_type: "",
          Taxrate: "",
          Vatform: "",
          purcode: "",
          salecode: "",
          GSTcode:   "",     
          IGSTcode:   "", 
      });

      this.rowlength++;
    },
pop() {
      this.cashVauchers.pop({
         Name: "",
          Tax_type: "",
          Taxrate: "",
          Vatform: "",
          purcode: "",
          salecode: "",
          GSTcode:   "",     
          IGSTcode:   "", 
      });

      this.deleteNotify();
    },

    deleteNotify() {
      this.$vs.notify({
        text: "Row is deleted",
        color: "danger",
        iconPack: "feather",
        icon: "icon-trash"
      });
    },


    addNotify() {
      this.$vs.notify({
        text: "Row is Added",
        color: "primary",
        iconPack: "feather",
        icon: "icon-plus"
      });
    },

    save() {
 
      var exportData = {
        date: this.date,
        voucherno: this.voucherno,
         salesetup_displayCashCard:this.salesetup_displayCashCard,
      
        salesetup_color: this.salesetup_color,
        salesetup_custname: this.salesetup_custname,
        salesetup_terms: this.salesetup_terms,
        salesetup_vehicleno: this.salesetup_vehicleno,
        salesetup_taxtype: this.salesetup_taxtype,
        salesetup_expense10: this.salesetup_expense10,
        salesetup_billcash: this.salesetup_billcash,
        salesetup_duty: this.salesetup_duty,
        salesetup_product: this.salesetup_product,
        salesetup_remno1: this.salesetup_remno1,
        salesetup_remno2: this.salesetup_remno2,
        salesetup_remno3: this.salesetup_remno3,
        salesetup_transport: this.salesetup_transport,
        salesetup_broker: this.salesetup_broker,
        salesetup_grnumber: this.salesetup_grnumber,
        salesetup_v10: this.salesetup_v10,
        salesetup_postage: this.salesetup_postage,
        salesetup_discount: this.salesetup_discount,
        salesetup_purimportgst: this.salesetup_purimportgst,
        salesetup_tcsontax: this.salesetup_tcsontax,
        salesetup_cgstac1: this.salesetup_cgstac1,
        salesetup_cgstac2: this.salesetup_cgstac2,
        salesetup_cgstac3: this.salesetup_cgstac3,
        salesetup_sgstac1: this.salesetup_sgstac1,
        salesetup_sgstac2: this.salesetup_sgstac2,
        salesetup_sgstac3: this.salesetup_sgstac3,
        salesetup_igstac1: this.salesetup_igstac1,
        salesetup_igstac2: this.salesetup_igstac2,
        salesetup_igstac3: this.salesetup_igstac3,
        salesetup_tcsac: this.salesetup_tcsac,
        salesetup_labour: this.salesetup_labour,
        salesetup_expense9: this.salesetup_expense9,
        salesetup_cesscode: this.salesetup_cesscode,
        salesetup_tcscessac: this.salesetup_tcscessac,
        salesetup_tcsrateall: this.salesetup_tcsrateall,
        salesetup_csta: this.salesetup_csta,
        salesetup_freight: this.salesetup_freight,
        salesetup_comm: this.salesetup_comm,
        salesetup_v9: this.salesetup_v9,
        salesetup_others: this.salesetup_others,
        salesetup_tdsac: this.salesetup_tdsac,
        salesetup_expense5: this.salesetup_expense5,
        salesetup_expense6: this.salesetup_expense6,
        salesetup_expense7: this.salesetup_expense7,
        salesetup_expense8: this.salesetup_expense8,
        salesetup_v1: this.salesetup_v1,
        salesetup_v2: this.salesetup_v2,
        salesetup_v3: this.salesetup_v3,
        salesetup_v4: this.salesetup_v4,
        salesetup_v5: this.salesetup_v5,
        salesetup_v6: this.salesetup_v6,
        salesetup_v7: this.salesetup_v7,
        salesetup_v8: this.salesetup_v8,
        salesetup_disableinvtime: this.salesetup_disableinvtime,
        salesetup_disablerevtime: this.salesetup_disablerevtime,
        salesetup_acnameinled: this.salesetup_acnameinled,
        salesetup_remarkspost: this.salesetup_remarkspost,
        salesetup_cursorfocustodate: this.salesummary2_19,
        salesetup_showwindowexpbeforetax: this
          .salesetup_showwindowexpbeforetax,
        salesetup_showwindowexpafterttax: this
          .salesetup_showwindowexpafterttax,

        salesetup_itemnameinled: this.salesetup_itemnameinled,

        salesetup_extraremarks: this.salesetup_extraremarks,

        salesetup_roundoff: this.salesetup_roundoff,

        salesetup_taxroundoff: this.salesetup_taxroundoff,

        salesetup_displayitem: this.salesetup_displayitem,

        salesetup_defaultbutton: this.salesetup_defaultbutton,

        salesetup_lowsale: this.salesetup_lowsale,

        salesetup_rate: this.salesetup_rate,

        salesetup_bag: this.salesetup_bag,

        salesetup_qty: this.salesetup_qty,

        salesetup_displayhsncode: this.salesetup_displayhsncode,
        salesetup_tdsoptions: this.salesetup_tdsoptions,
        salesetup_focusaftersave: this.salesetup_focusaftersave,
        purchasesetup2_1_labour: this.purchasesetup2_1_labour,
  purchasesetup2_1_v1: this.purchasesetup2_1_v1,
  purchasesetup2_1_postage: this.purchasesetup2_1_postage,
  purchasesetup2_1_v2: this.purchasesetup2_1_v2,
  purchasesetup2_1_discount: this.purchasesetup2_1_discount,
  purchasesetup2_1_v3 : this.purchasesetup2_1_v3,
  purchasesetup2_1_freight: this.purchasesetup2_1_freight,
  purchasesetup2_1_v4 : this.purchasesetup2_1_v4,
  purchasesetup2_1_expense5 : this.purchasesetup2_1_expense5,
  purchasesetup2_1_v5 : this.purchasesetup2_1_v5,
  purchasesetup2_1_expense6 : this.purchasesetup2_1_expense6,
  purchasesetup2_1_v6 : this.purchasesetup2_1_v6,
  purchasesetup2_1_expense7 : this.purchasesetup2_1_expense7,
  purchasesetup2_1_v7 : this.purchasesetup2_1_v7,
  purchasesetup2_1_expense8 : this.purchasesetup2_1_expense8,
  purchasesetup2_1_v8 : this.purchasesetup2_1_v8,
  purchasesetup2_1_expense9 : this.purchasesetup2_1_expense9,
  purchasesetup2_1_v9 : this.purchasesetup2_1_v9,
  purchasesetup2_1_expense10 : this.purchasesetup2_1_expense10,
  purchasesetup2_v10 : this.purchasesetup2_v10
      };

    //  alert(JSON.stringify(exportData));
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      var vall = {
        companyname: companyName,
        exportdata: exportData,
        note: "sale"
      };

      axios
        .post("/SaveSpSetup", vall)
        .then(response => {
          var data = JSON.stringify(response.data);
          console.log(data)
          alert("sd")
          //alert("go this response on save " + data);
        })
        .catch(error => {
          alert(error);
        });
    },
    // Add button

    getData() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var exp = {
        companyname: companyName,
        directory: "sp_setup.json",
        note: "sale"
      };

      axios
        .post("/getSpSetup", exp)
        .then(response => {
          var data = JSON.stringify(response.data);

          var json = JSON.parse(data);

          this.date = json.date
            this.voucherno = json.voucherno
            this.salesetup_color = json.salesetup_color
            this.salesetup_custname = json.salesetup_custname;

      this.salesetup_displayCashCard=json.salesetup_displayCashCard

          this.salesetup_terms = json.salesetup_terms;
          this.salesetup_vehicleno = json.salesetup_vehicleno;
          this.salesetup_taxtype = json.salesetup_taxtype;
          this.salesetup_billcash = json.salesetup_billcash;
          this.salesetup_duty = json.salesetup_duty;
          this.salesetup_expense10 = json.salesetup_expense10;
          this.salesetup_labour = json.salesetup_labour;
          this.salesetup_product = json.salesetup_product;
          this.salesetup_remno1 = json.salesetup_remno1;
          this.salesetup_remno2 = json.salesetup_remno2;
          this.salesetup_v9 = json.salesetup_v9;
          this.salesetup_v10 = json.salesetup_v10;
          this.salesetup_remno3 = json.salesetup_remno3;
          this.salesetup_postage = json.salesetup_postage;
          this.salesetup_transport = json.salesetup_transport;
          this.salesetup_broker = json.salesetup_broker;
          this.salesetup_grnumber = json.salesetup_grnumber;
          this.salesetup_purimportgst = json.salesetup_purimportgst;
          this.salesetup_cgstac1 = json.salesetup_cgstac1;
          this.salesetup_cgstac2 = json.salesetup_cgstac2;
          this.salesetup_cgstac3 = json.salesetup_cgstac3;
          this.salesetup_sgstac1 = json.salesetup_sgstac1;
          this.salesetup_sgstac2 = json.salesetup_sgstac2;
          this.salesetup_sgstac3 = json.salesetup_sgstac3;
          this.salesetup_igstac1 = json.salesetup_igstac1;
          this.salesetup_expense9 = json.salesetup_expense9;
          this.salesetup_igstac2 = json.salesetup_igstac2;
          this.salesetup_igstac3 = json.salesetup_igstac3;
          this.salesetup_tcsac = json.salesetup_tcsac;
          this.salesetup_cesscode = json.salesetup_cesscode;
          this.salesetup_tdsac = json.salesetup_tdsac;
          this.salesetup_tcscessac = json.salesetup_tcscessac;
          this.salesetup_discount = json.salesetup_discount;
          this.salesetup_tcsrateall = json.salesetup_tcsrateall;
          this.salesetup_csta = json.salesetup_csta;
          this.salesetup_tcsontax = json.salesetup_tcsontax
          this.salesetup_freight = json.salesetup_freight;
          this.salesetup_comm = json.salesetup_comm;
          this.salesetup_others = json.salesetup_others;
          this.salesetup_expense5 = json.salesetup_expense5;
          this.salesetup_expense6 = json.salesetup_expense6;
          this.salesetup_expense7 = json.salesetup_expense7;
          this.salesetup_expense8 = json.salesetup_expense8;
          this.salesetup_v1 = json.salesetup_v1;
          this.salesetup_v2 = json.salesetup_v2;
          this.salesetup_v3 = json.salesetup_v3;
          this.salesetup_v4 = json.salesetup_v4;
          this.salesetup_v5 = json.salesetup_v5;
          this.salesetup_v6 = json.salesetup_v6;
          this.salesetup_v7 = json.salesetup_v7;
          this.salesetup_v8 = json.salesetup_v8;
          this.salesetup_disableinvtime =
            json.salesetup_disableinvtime;
          this.salesetup_disablerevtime =
            json.salesetup_disablerevtime;
          this.salesetup_acnameinled = json.salesetup_acnameinled;
          this.salesetup_remarkspost = json.salesetup_remarkspost;
          this.salesummary2_19 = json.salesummary2_19;
          this.salesetup_showwindowexpbeforetax =
            json.salesetup_showwindowexpbeforetax;
          this.salesetup_showwindowexpafterttax =
            json.salesetup_showwindowexpafterttax;

          this.salesetup_itemnameinled = json.salesetup_itemnameinled;

          this.salesetup_extraremarks = json.salesetup_extraremarks;

          this.salesetup_roundoff = json.salesetup_roundoff;

          this.salesetup_taxroundoff = json.salesetup_taxroundoff;

          this.salesetup_displayitem = json.salesetup_displayitem;

          this.salesetup_defaultbutton = json.salesetup_defaultbutton;

          this.salesetup_lowsale = json.salesetup_lowsale;

          this.salesetup_rate = json.salesetup_rate;

          this.salesetup_bag = json.salesetup_bag;

          this.salesetup_qty = json.salesetup_qty;

          this.purchasesetup2_1_labour= json.purchasesetup2_1_labour;
  this.purchasesetup2_1_v1= json.purchasesetup2_1_v1;
  this.purchasesetup2_1_postage= json.purchasesetup2_1_postage;
  this.purchasesetup2_1_v2= json.purchasesetup2_1_v2;
  this.purchasesetup2_1_discount= json.purchasesetup2_1_discount;
  this.purchasesetup2_1_v3 = json.purchasesetup2_1_v3;
  this.purchasesetup2_1_freight= json.purchasesetup2_1_freight;
  this.purchasesetup2_1_v4 = json.purchasesetup2_1_v4
  this.purchasesetup2_1_expense5 = json.purchasesetup2_1_expense5;
  this.purchasesetup2_1_v5 = json.purchasesetup2_1_v5;
  this.purchasesetup2_1_expense6 = json.purchasesetup2_1_expense6;
  this.purchasesetup2_1_v6 = json.purchasesetup2_1_v6;
  this.purchasesetup2_1_expense7 = json.purchasesetup2_1_expense7;
  this.purchasesetup2_1_v7 = json.purchasesetup2_1_v7;
  this.purchasesetup2_1_expense8 = json.purchasesetup2_1_expense8;
  this.purchasesetup2_1_v8 = json.purchasesetup2_1_v8;
  this.purchasesetup2_1_expense9 = json.purchasesetup2_1_expense9;
  this.purchasesetup2_1_v9 = json.purchasesetup2_1_v9;
  this.purchasesetup2_1_expense10 = json.purchasesetup2_1_expense10;
  this.purchasesetup2_v10 = json.purchasesetup2_1_v10;

          this.salesetup_displayhsncode =
            json.salesetup_displayhsncode;
          this.salesetup_tdsoptions = json.salesetup_tdsoptions;
          this.salesetup_focusaftersave =
            json.salesetup_focusaftersave;
        })
        .catch(error => {
          alert(error);
        });
    },

    moveFocus(index) {
      if (this.elements[index]) {
        this.elements[index].focus();
      }
      console.log("b");
    }
  },
mounted() {


 



 
  
},
  created() {
    let that = this;
    that.getData();
    that.getTaxType();
  }
};
</script>





