<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#wrapper1 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

.margin {
  margin: 5px;
}

[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::before,
[dir] .e-input-group:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::before,
[dir]
  .e-input-group.e-control-wrapper:not(.e-float-icon-left):not(.e-float-input)::after,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::before,
[dir]
  .e-input-group.e-control-wrapper.e-float-icon-left:not(.e-float-input)
  .e-input-in-wrap::after {
  background: #ffffff !important;
}

[dir] .e-input-group:not(.e-float-icon-left),
[dir] .e-input-group.e-control-wrapper:not(.e-float-icon-left) {
  border-bottom: 0px !important;
}

.vs-table--thead {
  background: #453e90;
}

#wrapper2 {
  background: #ffccee00;

  border-color: #000;
  border-radius: 5px;
  height: 25px;
  width: 200px;
  margin: 1px;
  box-shadow: 0 0 2px 1px #00000059;
}

.vs-button {
  display: inline-block;
}

.tdInputsmall {
  width: 100px;
  height: 25px;
}

.tdDeletebutton {
  width: 50px;
  height: 25px;
}

#customers th {
  border: 1px solid #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
}

.column1 {
  float: left;
  width: 75%;
  padding: 10px;
}

.column2 {
  float: right;
  width: 25%;
  padding: 10px;
}

.column3 {
  float: left;
  width: 55%;
  padding: 10px;
}

.column4 {
  float: right;
  width: 45%;
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
<template>
  <div class="modal">
    <div class="vx-card p-6" style>
      <vs-popup
        classContent="popup-example"
        title="Account Form(press esc to close)"
        button-close-hidden="true"
        :active.sync="popupActive2"
      >
        <modal
          v-model.lazy="modalOpen"
          v-on:childToParent="onChildClick"
          :SearchText="searchlabel"
          ref="childComponentLedger"
        />
      </vs-popup>
      <vs-popup
        classContent="popup-example"
        title="Narrations"
        name="popupActive3"
        button-close-hidden="true"
        :active.sync="popupActiveNarration"
      >
        <modalnarration
          ref="childComponent"
          :parentData="narrationtypename"
          v-on:spdatareceived="onspdatareceived"
          v-model.lazy="modalOpenNarration"
          v-on:childToParentNarration="onChildClickNarration"
          :SearchText="searchlabel"
        />
      </vs-popup>

      <vs-popup
        classContent="popup-example"
        title="New Ledger Acc Form Setup"
        name="setupForm"
        button-close-hidden="false"
        :active.sync="setupForm"
      >
        <vs-tr>
          <vs-td>vacode:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vacode" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vacode"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vacode"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vacode"
            />
          </vs-td>
          <vs-td style="padding-left:15px">vdate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vdate" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vdate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vdate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vdate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>vcode:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vcode" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vcode"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vcode"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vcode"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vamt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vamt" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vamt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vamt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vamt"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>others:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_others" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_others"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_others"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_others"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vdesc:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vdesc" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vdesc"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vdesc"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vdesc"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>stype:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_stype" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_stype"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_stype"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_stype"
            />
          </vs-td>

          <vs-td style="padding-left:15px">freight:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_freight" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_freight"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_freight"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_freight"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>weight:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_weight" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_weight"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_weight"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_weight"
            />
          </vs-td>

          <vs-td style="padding-left:15px">pkgs:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_pkgs" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_pkgs"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_pkgs"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_pkgs"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>tax:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tax" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tax"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tax"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tax"
            />
          </vs-td>

          <vs-td style="padding-left:15px">sdisc:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_sdisc" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_sdisc"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_sdisc"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_sdisc"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>etype:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_etype" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_etype"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_etype"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_etype"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exfor:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exfor" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exfor"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exfor"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exfor"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rate"
            />
          </vs-td>

          <vs-td style="padding-left:15px">stkcode:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_stkcode" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_stkcode"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_stkcode"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_stkcode"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>balance:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_balance" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_balance"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_balance"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_balance"
            />
          </vs-td>

          <vs-td style="padding-left:15px">conv:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_conv" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_conv"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_conv"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_conv"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>plarg:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_plarg" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_plarg"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_plarg"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_plarg"
            />
          </vs-td>

          <vs-td style="padding-left:15px">entno:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_entno" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_entno"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_entno"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_entno"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>pb_wt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_pb_wt" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_pb_wt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_pb_wt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_pb_wt"
            />
          </vs-td>

          <vs-td style="padding-left:15px">freight1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_freight1" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_freight1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_freight1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_freight1"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>weighing:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_weighing" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_weighing"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_weighing"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_weighing"
            />
          </vs-td>

          <vs-td style="padding-left:15px">pla:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_pla" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_pla"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_pla"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_pla"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>tds_frt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tds_frt" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tds_frt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tds_frt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tds_frt"
            />
          </vs-td>
          <vs-td style="padding-left:15px">tdsrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tdsrate" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tdsrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tdsrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tdsrate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td style="padding-left:15px">cess:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cess" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cess"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cess"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cess"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>vbillno1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vbillno1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vbillno1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vbillno1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vbillno1"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vbdate1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vbdate1" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vbdate1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vbdate1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vbdate1"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>vamt1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vamt1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vamt1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vamt1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vamt1"
            />
          </vs-td>

          <vs-td style="padding-left:15px">duedate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_duedate" />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_duedate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_duedate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_duedate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>cl_date:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cl_date" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cl_date"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cl_date"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cl_date"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vacode1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vacode1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vacode1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vacode1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vacode1"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>hcess:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_hcess" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_hcess"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_hcess"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_hcess"
            />
          </vs-td>

          <vs-td style="padding-left:15px">trpt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_trpt" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_trpt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_trpt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_trpt"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>weight_ch:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_weight_ch" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_weight_ch"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_weight_ch"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_weight_ch"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vamt_ch:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vamt_ch" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vamt_ch"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vamt_ch"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vamt_ch"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>vdate_ch:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vdate_ch" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vdate_ch"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vdate_ch"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vdate_ch"
            />
          </vs-td>

          <vs-td style="padding-left:15px">vhead:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_vhead" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_vhead"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_vhead"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_vhead"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>credit:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_credit" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_credit"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_credit"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_credit"
            />
          </vs-td>

          <vs-td style="padding-left:15px">pcess:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_pcess" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_pcess"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_pcess"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_pcess"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>tcs_cess:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs_cess" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs_cess"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs_cess"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs_cess"
            />
          </vs-td>

          <vs-td style="padding-left:15px">tcs_hcess:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs_hcess" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs_hcess"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs_hcess"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs_hess"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp1"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp2:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp2" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp2"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp2"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp2"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp3:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp3" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp3"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp3"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp3"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp4:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp4" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp4"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp4"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp4"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>exp5:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp5" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp5"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp5"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp5"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp6:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp6" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp6"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp6"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp6"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp7:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp7" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp7"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp7"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp7"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp8:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp8" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp8"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp8"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp8"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp9:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp9" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp9"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp9"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp9"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp1_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp1_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp1_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp1_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp1_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp2_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp2_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp2_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp2_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp2_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp3_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp3_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp3_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp3_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp3_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp4_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp4_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp4_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp4_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp4_rate"
            />
          </vs-td>

          <vs-td style="padding-left:15px">exp5_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp5_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp5_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp5_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp5_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp6_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp6_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp6_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp6_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp6_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp7_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp7_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp7_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp7_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp7_rate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>exp8_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp8_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp8_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp8_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp8_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp9_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp9_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp9_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp9_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp9_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp10_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp10_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp10_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp10_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp10_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rem1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem1"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>rem2:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem2" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem2"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem2"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem2"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rem3:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem3" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem3"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem3"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem3"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>rem4:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem4" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem4"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem4"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem4"
            />
          </vs-td>
          <vs-td style="padding-left:15px">transport:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_transport" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_transport"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_transport"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_transport"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>order:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_order" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_order"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_order"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_order"
            />
          </vs-td>
          <vs-td style="padding-left:15px">order_date:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_order_date" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_order_date"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_order_date"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_order_date"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>agent:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_agent" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_agent"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_agent"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_agent"
            />
          </vs-td>
          <vs-td style="padding-left:15px">broker:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_broker" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_broker"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_broker"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_broker"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>cd_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cd_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cd_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cd_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cd_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">cd:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cd" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cd"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cd"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cd"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>sch_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_sch_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_sch_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_sch_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_sch_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">scheme:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_scheme" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_scheme"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_scheme"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_scheme"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>srv_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_srv_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_srv_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_srv_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_srv_rate"
            />
          </vs-td>

          <vs-td style="padding-left:15px">srv_tax:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_srv_tax" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_srv_tax"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_srv_tax"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_srv_tax"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>inv_tm:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_inv_tm" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_inv_tm"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_inv_tm"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_inv_tm"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rev_dt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rev_dt" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rev_dt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rev_dt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rev_dt"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>rem5:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem5" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem5"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem5"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem5"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rem6:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem6" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem6"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem6"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem6"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>rem7:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem7" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem7"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem7"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem7"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rem8:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem8" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem8"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem8"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem8"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>cvd:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cvd" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cvd"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cvd"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cvd"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exrate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exrate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>cessrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cessrate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cessrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cessrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cessrate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">hcrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_hcrate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_hcrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_hcrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_hcrate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>cvdrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cvdrate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cvdrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cvdrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cvdrate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp_before:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp_before" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp_before"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp_before"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp_before"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>exp_after:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp_after" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp_after"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp_after"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp_after"
            />
          </vs-td>
          <vs-td style="padding-left:15px">tax_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tax_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tax_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tax_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tax_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp10:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp10" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp10"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp10"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp10"
            />
          </vs-td>
          <vs-td style="padding-left:15px">loose:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_loose" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_loose"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_loose"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_loose"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>spec:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_spec" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_spec"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_spec"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_spec"
            />
          </vs-td>
          <vs-td style="padding-left:15px">pckng:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_pckng" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_pckng"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_pckng"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_pckng"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>wf:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_wf" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_wf"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_wf"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_wf"
            />
          </vs-td>
          <vs-td style="padding-left:15px">wwf:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_wwf" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_wwf"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_wwf"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_wwf"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>bill:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_bill" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_bill"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_bill"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_bill"
            />
          </vs-td>
          <vs-td style="padding-left:15px">stk_code:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_stk_code" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_stk_code"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_stk_code"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_stk_code"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>rateins:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rateins" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rateins"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rateins"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rateins"
            />
          </vs-td>
          <vs-td style="padding-left:15px">srates:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_srates" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_srates"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_srates"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_srates"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>qpps:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_qpps" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_qpps"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_qpps"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_qpps"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td style="padding-left:15px">tcs:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>tcs1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs1"
            />
          </vs-td>
          <vs-td style="padding-left:15px">tcs2:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs2" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs2"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs2"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs2"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>tcs_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">tcs1_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs1_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs1_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs1_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs1_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>tcs2_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tcs2_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tcs2_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tcs2_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tcs2_rate"
            />
          </vs-td>
          <vs-td style="padding-left:15px">saletype:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_saletype" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_saletype"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_saletype"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_saletype"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>unit_ex:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_unit_ex" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_unit_ex"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_unit_ex"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_unit_ex"
            />
          </vs-td>
          <vs-td style="padding-left:15px">unit_cs:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_unit_cs" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_unit_cs"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_unit_cs"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_unit_cs"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>unit_hs:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_unit_hs" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_unit_hs"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_unit_hs"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_unit_hs"
            />
          </vs-td>
          <vs-td style="padding-left:15px">unit_cv:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_unit_cv" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_unit_cv"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_unit_cv"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_unit_cv"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>cd1:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cd1" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cd1"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cd1"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cd1"
            />
          </vs-td>
          <vs-td style="padding-left:15px">cd1_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cd1_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cd1_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cd1_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cd1_rate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>tariff:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_tariff" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_tariff"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_tariff"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_tariff"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp1_ex:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp1_ex" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp1_ex"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp1_ex"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp1_ex"
            />
          </vs-td>
        </vs-tr>

        <vs-tr>
          <vs-td>exp2_ex:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp2_ex" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp2_ex"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp2_ex"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp2_ex"
            />
          </vs-td>
          <vs-td style="padding-left:15px">weights:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_weights" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_weights"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_weights"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_weights"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp1_exr:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp1_exr" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp1_exr"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp1_exr"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp1_exr"
            />
          </vs-td>
          <vs-td style="padding-left:15px">exp2_exr:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp2_exr" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp2_exr"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp2_exr"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp2_exr"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>rem9:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem9" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem9"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem9"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem9"
            />
          </vs-td>
          <vs-td style="padding-left:15px">rem10:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_rem10" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_rem10"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_rem10"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_rem10"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td style="padding-left:15px">exp01:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp01" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp01"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp01"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp01"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>exp01code:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_exp01code" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_exp01code"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_exp01code"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_exp01code"
            />
          </vs-td>
          <vs-td style="padding-left:15px">p_vbillno:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_p_vbillno" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_p_vbillno"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_p_vbillno"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_p_vbillno"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>usname:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_usname" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_usname"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_usname"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_usname"
            />
          </vs-td>
          <vs-td style="padding-left:15px">usrate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_usrate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_usrate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_usrate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_usrate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>usvamt:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_usvamt" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_usvamt"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_usvamt"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_usvamt"
            />
          </vs-td>
          <vs-td style="padding-left:15px">cardno:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_cardno" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_cardno"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_cardno"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_cardno"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>ctax:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_ctax" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_ctax"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_ctax"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_ctax"
            />
          </vs-td>
          <vs-td style="padding-left:15px">ctax_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_ctax_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_ctax_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_ctax_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_ctax_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>stax:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_stax" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_stax"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_stax"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_stax"
            />
          </vs-td>
          <vs-td style="padding-left:15px">stax_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_stax_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_stax_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_stax_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_stax_rate"
            />
          </vs-td>
        </vs-tr>
        <vs-tr>
          <vs-td>itax:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_itax" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_itax"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_itax"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_itax"
            />
          </vs-td>
          <vs-td style="padding-left:15px">itax_rate:</vs-td>
          <vs-td>
            <vs-checkbox v-model.lazy="ch_itax_rate" />
          </vs-td>
          <vs-td>
            <vs-input
              size="small"
              class="w-full"
              type="text"
              label-placeholder="label text"
              v-model.lazy="lt_itax_rate"
            />
          </vs-td>
          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="DEfault value"
              v-model.lazy="dv_itax_rate"
            />
          </vs-td>

          <vs-td>
            <vs-input
              class="w-full"
              size="small"
              type="text"
              label-placeholder="width percent"
              v-model.lazy="wi_itax_rate"
            />
          </vs-td>
        </vs-tr>

        <vs-tr align="right">
          <vs-td>
            <vs-button size="medium" title="Save" @click="SaveLedgerSetup" color="primary">Save</vs-button>
          </vs-td>
        </vs-tr>
      </vs-popup>

      <vs-popup
        classContent="popup"
        title="Annexures"
        :active.sync="drcrpopup"
        id="drcrpopup"
        name="drcrpopup"
      >
        <div class="search-wrapper" name="divpopupActive3">
          <tr>
            <td>
              <label>Search:</label>
            </td>

            <td style="padding-left:10px;" name="DRCRPOPUP">
              <vs-input
                class="w-full"
                size="small"
                type="text"
                id="drcrfilter"
                ref="drcrfilter"
                v-model.lazy="drcrFilter"
                :autofocus="true"
                @input="drcrFilteredList()"
              />
            </td>
          </tr>
        </div>
        <br />

        <div>
          <vs-table
            v-model.lazy="chosen"
            @selected="handleClick"
            pagination
            max-items="8"
            :data="drcrFilteredNarrations"
          >
            <template slot-scope="{data}">
              <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" :id="'drcr'+indextr">
                <vs-td size="small">{{ data[indextr].name }}</vs-td>
              </vs-tr>
            </template>
          </vs-table>
        </div>
        <div>
          <tr>
            <td class="tdInputsmall" style="padding-left:20px;">
              <vs-button
                size="small"
                title="Add"
                color="primary"
                id="narAddButtonPopup"
                @click="showAddPopupNarration()"
              >Add</vs-button>
            </td>
            <td class="tdInputsmall" style="padding-left:10px;">
              <vs-button
                size="small"
                title="Modify"
                color="primary"
                id="modifyButtonPopup"
                @click="showAddPopupNarration()"
              >Modify</vs-button>
            </td>
          </tr>
        </div>
      </vs-popup>

      <table width="100%" border="0" class="tables">
        <tr>
          <td width="25%"></td>
          <td width="50%">
            <center>
              <h1 class="text-primary">
                {{this.annexureText}}
                <br />
                <h4>
                  <font color="grey">{{titleAction}}</font>
                </h4>
              </h1>
            </center>
          </td>
          <td width="25%" align="right">
            <vs-button
              color="primary"
              type="border"
              :disabled="buttondis"
              @click="showSetupForm()"
            >Setup</vs-button>
          </td>&nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          <td width="25%" align="right" style="padding-left:10px">
            Today {{now}}
            <br />
            {{currentday}}
          </td>
        </tr>
        <br />
      </table>
      <br />
      <br />

      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Ahead</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" v-model.lazy="Ahead" :disabled="buttondis" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px"></div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Form_type</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            :disabled="buttondis"
            v-model.lazy="Form_type"
            id="type_form"
          />
        </div>
        <div class="vx-col sm:w-1/4 w-full" style="padding-left:150px">
          <span>Led_post:</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox :disabled="buttondis" v-model.lazy="Led_post" id="post_led" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Vat_post:</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox :disabled="buttondis" v-model.lazy="Vat_post" id="post_vat" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Ex_post:</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox :disabled="buttondis" v-model.lazy="Ex_post" id="post_ex" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Serial</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            :disabled="buttondis"
            v-model.lazy="Serial"
            @keypress="onlyNumber"
          />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Short_name:</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox :disabled="buttondis" v-model.lazy="Short_name" id="name_short" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Stk_post</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-checkbox :disabled="buttondis" v-model.lazy="Stk_post" id="post_stk" />
        </div>
      </div>

      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Form_rtype</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input
            class="w-full"
            size="small"
            :disabled="buttondis"
            v-model.lazy="Form_rtype"
            id="rtype_form"
          />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Rep_name</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Rep_name" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Bill_no_h</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Bill_no_h" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Salef3</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Salef3" />
        </div>
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Tick</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Tick" />
        </div>
      </div>

      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Vacode</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Vacode" />
        </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/4" style="padding-left:150px">
          <span>Rep_gst</span>
        </div>
        <div class="vx-col sm:w-1/6 w-full">
          <vs-input class="w-full" size="small" :disabled="buttondis" v-model.lazy="Rep_gst" />
        </div>
         <div class="vx-col sm:w-1/4" style="padding-left:150px">
                <span><b>Continuous/Discontinuos</b></span>
            </div>
            <div class="vx-col sm:w-1/6 w-full">
                <vs-checkbox :disabled="buttondis" v-model.lazy="cont" id="cont" />
            </div>
      </div>

      <br />
      <br />
      <div align="left">
        <vs-button
          :color="getColor('addButton')"
          type="filled"
          title="Add"
          id="addButton"
          icon-pack="feather"
          icon="icon-file-plus"
          @keyup.right="buttonNext('addButton')"
          @keyup.left="buttonPrev('addButton')"
          @click="newdisable"
          :disabled="disAdd"
          :autofocus="true"
        />
        <vs-button
          title="Edit"
          type="filled"
          icon-pack="feather"
          icon="icon-edit-1"
          :disabled="disEdit"
          :color="getColor('editButton')"
          id="editButton"
          class="button margin"
          @keyup.right="buttonNext('editButton')"
          @keyup.left="buttonPrev('editButton')"
          @click="editButton()"
        />
        <vs-button
          title="Previous"
          type="filled"
          icon-pack="feather"
          icon="icon-chevrons-left"
          :disabled="disPrevious"
          :color="getColor('previousButton')"
          id="previousButton"
          class="button margin"
          @keyup.right="buttonNext('previousButton')"
          @keyup.left="buttonPrev('previousButton')"
          @click="getData('prev')"
        />
        <vs-button
          title="Next"
          icon-pack="feather"
          icon="icon-chevrons-right"
          :disabled="disNext"
          :color="getColor('nextButton')"
          id="nextButton"
          class="button margin"
          @keyup.right="buttonNext('nextButton')"
          @keyup.left="buttonPrev('nextButton')"
          @click="getData('next')"
        />
        <vs-button
          title="First"
          icon-pack="feather"
          icon="icon-arrow-left"
          :disabled="disFirst"
          id="firstButton"
          :color="getColor('firstButton')"
          class="button margin"
          @keyup.right="buttonNext('firstButton')"
          @keyup.left="buttonPrev('firstButton')"
          @click="getFirst"
        />
        <vs-button
          title="Last"
          icon-pack="feather"
          icon="icon-arrow-right"
          :disabled="disLast"
          :color="getColor('lastButton')"
          id="lastButton"
          class="button margin"
          @keyup.right="buttonNext('lastButton')"
          @keyup.left="buttonPrev('lastButton')"
          @click="getLast"
        />
        <vs-button
          title="Search"
          icon-pack="feather"
          icon="icon-search"
          :disabled="disSearch"
          :color="getColor('searchButton')"
          id="searchButton"
          class="button margin"
          @keyup.right="buttonNext('searchButton')"
          @keyup.left="buttonPrev('searchButton')"
          @click="search"
        />

        <vs-button
          title="Printer"
          icon-pack="feather"
          icon="icon-printer"
          :disabled="disPrinter"
          :color="getColor('printButton')"
          id="printButton"
          class="button margin"
          @keyup.right="buttonNext('printButton')"
          @keyup.left="buttonPrev('printButton')"
          @click="print"
        />
        <vs-button
          title="Delete"
          icon-pack="feather"
          icon="icon-trash"
          :disabled="disDelete"
          :color="getColor('deleteButton')"
          id="deleteButton"
          class="button margin"
          @keyup.right="buttonNext('deleteButton')"
          @keyup.left="buttonPrev('deleteButton')"
          @click="onDelete"
        />
        <vs-button
          title="Exit"
          icon-pack="feather"
          icon="icon-x"
          :disabled="disExit"
          :color="getColor('exitButton')"
          id="exitButton"
          class="button margin"
          @keyup.right="buttonNext('exitButton')"
          @keyup.left="buttonPrev('exitButton')"
          @click="onExit"
        />
        <vs-button
          style="float:right; display:inline-block;"
          title="Save"
          :color="getColor('saveButton')"
          id="saveButton"
          class="button margin"
          @keyup.right="buttonNext('saveButton')"
          @keyup.left="buttonPrev('saveButton')"
          @click="save()"
        >Save</vs-button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Vue from "vue";
import { TooltipPlugin } from "@syncfusion/ej2-vue-popups";
Vue.use(TooltipPlugin);
import { ComboBoxPlugin } from "@syncfusion/ej2-vue-dropdowns";
import { CheckBoxPlugin } from "@syncfusion/ej2-vue-buttons";
import { Query, DataManager, WebApiAdaptor } from "@syncfusion/ej2-data";
import modal from "@/components/Ledgerpopup.vue";
import modalnarration from "@/components/NarrationsModal.vue";
import "@syncfusion/ej2-base/styles/material.css";
import "@syncfusion/ej2-inputs/styles/material.css";
import "@syncfusion/ej2-vue-dropdowns/styles/material.css";
import "@syncfusion/ej2-base/styles/material.css";
import "@syncfusion/ej2-vue-popups/styles/material.css";
Vue.use(ComboBoxPlugin);
Vue.use(CheckBoxPlugin);
var remoteData = new DataManager({
  url:
    "https://ej2services.syncfusion.com/production/web-services/api/Employees",
  adaptor: new WebApiAdaptor(),
  crossDomain: true
});
export default {
  name: "Modal",
  data() {
    return {
      Ahead: "",
      Form_type: "",
      Led_post: "",
      Vat_post: "",
      Ex_post: "",
      Serial: "",
      Short_name: "",
      Stk_post: "",
      Form_rtype: "",
      Rep_name: "",
      Bill_no_h: "",
      Salef3: "",
      Tick: "",
      Vacode: "",
      Rep_gst: "",
      cont: false,

      ch_vdate: false,

      ch_vtype: false,

      ch_vno: false,

      ch_valpha: false,

      ch_vcode: false,

      ch_vacode: false,

      ch_vamt: false,

      ch_others: false,

      ch_vamtcode: false,

      ch_vdesc: false,

      ch_vbillno: false,

      ch_vbdate: false,

      ch_stype: false,

      ch_freight: false,

      ch_excise: false,

      ch_weight: false,

      ch_pkgs: false,

      ch_tax: false,

      ch_counter: false,

      ch_sdisc: false,

      ch_etype: false,

      ch_exfor: false,

      ch_rate: false,

      ch_btype: false,

      ch_stkcode: false,

      ch_balance: false,

      ch_conv: false,

      ch_plarg: false,

      ch_entno: false,

      ch_pb_wt: false,

      ch_srno1: false,

      ch_freight1: false,

      ch_weighing: false,

      ch_pla: false,

      ch_tds_frt: false,

      ch_tdsrate: false,

      ch_ppcode: false,

      ch_cess: false,

      ch_vbillno1: false,

      ch_vbdate1: false,

      ch_vamt1: false,

      ch_duedate: false,

      ch_cl_date: false,

      ch_emcode: false,

      ch_mon: false,

      ch_vacode1: false,

      ch_hcess: false,

      ch_trpt: false,

      ch_intial: false,

      ch_weight_ch: false,

      ch_vamt_ch: false,

      ch_vdate_ch: false,

      ch_vacode_ch: false,

      ch_record: false,

      ch_vhead_ch: false,

      ch_vhead: false,

      ch_remarks: false,

      ch_tick: false,

      ch_credit: false,

      ch_debit: false,

      ch_pcess: false,

      ch_tcs_cess: false,

      ch_tcs_hcess: false,

      ch_vat: false,

      ch_exp1: false,

      ch_exp2: false,

      ch_exp3: false,

      ch_exp4: false,

      ch_exp5: false,

      ch_exp6: false,

      ch_exp7: false,

      ch_exp8: false,

      ch_exp9: false,

      ch_exp1_rate: false,

      ch_exp2_rate: false,

      ch_exp3_rate: false,

      ch_exp4_rate: false,

      ch_exp5_rate: false,

      ch_exp6_rate: false,

      ch_exp7_rate: false,

      ch_exp8_rate: false,

      ch_exp9_rate: false,

      ch_exp10_rate: false,

      ch_rem1: false,

      ch_rem2: false,

      ch_rem3: false,

      ch_rem4: false,

      ch_transport: false,

      ch_order: false,

      ch_order_date: false,

      ch_agent: false,

      ch_broker: false,

      ch_cd_rate: false,

      ch_cd: false,

      ch_sch_rate: false,

      ch_scheme: false,

      ch_srv_rate: false,

      ch_srv_tax: false,

      ch_gr: false,

      ch_inv_tm: false,

      ch_rev_tm: false,

      ch_inv_dt: false,

      ch_rev_dt: false,

      ch_rem5: false,

      ch_rem6: false,

      ch_rem7: false,

      ch_rem8: false,

      ch_cvd: false,

      ch_exrate: false,

      ch_cessrate: false,

      ch_hcrate: false,

      ch_cvdrate: false,

      ch_exp_before: false,

      ch_exp_after: false,

      ch_total: false,

      ch_b_tpt: false,

      ch_sub_total: false,

      ch_party_code: false,

      ch_tax_rate: false,

      ch_exp10: false,

      ch_loose: false,

      ch_spec: false,

      ch_pckng: false,

      ch_wf: false,

      ch_wwf: false,

      ch_tx_from: false,

      ch_tx_upto: false,

      ch_tx_type: false,

      ch_ssr: false,

      ch_vat_post: false,

      ch_led_post: false,

      ch_ex_post: false,

      ch_bill: false,

      ch_stk_post: false,

      ch_opening: false,

      ch_purr: false,

      ch_sale: false,

      ch_prdd: false,

      ch_issuee: false,

      ch_closing: false,

      ch_stk_code: false,

      ch_rateins: false,

      ch_srates: false,

      ch_qpps: false,

      ch_tcs: false,

      ch_tcs1: false,

      ch_tcs2: false,

      ch_tcs_rate: false,

      ch_tcs1_rate: false,

      ch_tcs2_rate: false,

      ch_saletype: false,

      ch_purtype: false,

      ch_ahead: false,

      ch_add1: false,

      ch_add2: false,

      ch_city: false,

      ch_tin: false,

      ch_phone: false,

      ch_cash_name: false,

      ch_cash_add1: false,

      ch_cash_city: false,

      ch_tax0_sale: false,

      ch_tax1_sale: false,

      ch_p_vdate: false,

      ch_p_vno: false,

      ch_p_valpha: false,

      ch_p_counter: false,

      ch_unit_ex: false,

      ch_unit_cs: false,

      ch_unit_hs: false,

      ch_unit_cv: false,

      ch_cd1: false,

      ch_cd1_rate: false,

      ch_tariff: false,

      ch_user_name: false,

      ch_exp1_ex: false,

      ch_exp2_ex: false,

      ch_weights: false,

      ch_emistatus: false,

      ch_p_pageno: false,

      ch_p_entry: false,

      ch_taxsurr: false,

      ch_o_vdate: false,

      ch_o_vno: false,

      ch_o_valpha: false,

      ch_o_counter: false,

      ch_exp1_exr: false,

      ch_exp2_exr: false,

      ch_rem9: false,
      ch_initial: false,

      ch_rem10: false,
      ch_rem11: false,
      ch_exp01: false,
      ch_exp01code: false,
      ch_p_vbillno: false,
      ch_usname: false,

      ch_usrate: false,

      ch_usvamt: false,

      ch_cardno: false,

      ch_cashrec: false,

      ch_bank: false,

      ch_bcode: false,

      ch_exp3_ex: false,
      ch_ctax: false,
      ch_ctax_rate: false,
      ch_stax: false,
      ch_stax_rate: false,
      ch_itax: false,
      ch_itax_rate: false,

      lt_vdate: "vdate",

      lt_vtype: "vtype",

      lt_vno: "vno",

      lt_valpha: "valpha",

      lt_vcode: "vcode",

      lt_vacode: "vacode",

      lt_vamt: "vamt",

      lt_others: "others",

      lt_vamtcode: "vamtcode",

      lt_vdesc: "vdesc",

      lt_vbillno: "vbillno",

      lt_vbdate: "vbdate",

      lt_stype: "stype",

      lt_freight: "freight",

      lt_excise: "excise",

      lt_weight: "weight",

      lt_pkgs: "pkgs",

      lt_tax: "tax",

      lt_counter: "counter",

      lt_sdisc: "sdisc",

      lt_etype: "etype",

      lt_exfor: "exfor",

      lt_rate: "rate",

      lt_btype: "btype",

      lt_stkcode: "stkcode",

      lt_balance: "balance",

      lt_conv: "conv",

      lt_plarg: "plarg",

      lt_entno: "entno",

      lt_pb_wt: "pb_wt",

      lt_srno1: "srno1",

      lt_freight1: "freight1",

      lt_weighing: "weighing",

      lt_pla: "pla",

      lt_tds_frt: "tds_frt",

      lt_tdsrate: "tdsrate",

      lt_ppcode: "ppcode",

      lt_cess: "cess",

      lt_vbillno1: "vbillno1",

      lt_vbdate1: "vbdate1",

      lt_vamt1: "vamt1",

      lt_duedate: "duedate",

      lt_cl_date: "cl_date",

      lt_emcode: "emcode",

      lt_mon: "mon",

      lt_vacode1: "vacode1",

      lt_hcess: "hcess",

      lt_trpt: "trpt",

      lt_intial: "intial",

      lt_weight_ch: "weight_ch",

      lt_vamt_ch: "vamt_ch",

      lt_vdate_ch: "vdate_ch",

      lt_vacode_ch: "vacode_ch",

      lt_record: "record",

      lt_vhead_ch: "vhead_ch",

      lt_vhead: "vhead",

      lt_remarks: "remarks",

      lt_tick: "tick",

      lt_credit: "credit",

      lt_debit: "debit",

      lt_pcess: "pcess",

      lt_tcs_cess: "tcs_cess",

      lt_tcs_hcess: "tcs_hcess",

      lt_vat: "vat",

      lt_exp1: "exp1",

      lt_exp2: "exp2",

      lt_exp3: "exp3",

      lt_exp4: "exp4",

      lt_exp5: "exp5",

      lt_exp6: "exp6",

      lt_exp7: "exp7",

      lt_exp8: "exp8",

      lt_exp9: "exp9",

      lt_exp1_rate: "exp1_rate",

      lt_exp2_rate: "exp2_rate",

      lt_exp3_rate: "exp3_rate",

      lt_exp4_rate: "exp4_rate",

      lt_exp5_rate: "exp5_rate",

      lt_exp6_rate: "exp6_rate",

      lt_exp7_rate: "exp7_rate",

      lt_exp8_rate: "exp8_rate",

      lt_exp9_rate: "exp9_rate",

      lt_exp10_rate: "exp10_rate",

      lt_rem1: "rem1",

      lt_rem2: "rem2",

      lt_rem3: "rem3",

      lt_rem4: "rem4",

      lt_transport: "transport",

      lt_order: "order",

      lt_order_date: "order_date",

      lt_agent: "agent",

      lt_broker: "broker",

      lt_cd_rate: "cd_rate",

      lt_cd: "cd",

      lt_sch_rate: "sch_rate",

      lt_scheme: "scheme",

      lt_srv_rate: "srv_rate",

      lt_srv_tax: "srv_tax",

      lt_gr: "gr",

      lt_inv_tm: "inv_tm",

      lt_rev_tm: "rev_tm",

      lt_inv_dt: "inv_dt",

      lt_rev_dt: "rev_dt",

      lt_rem5: "rem5",

      lt_rem6: "rem6",

      lt_rem7: "rem7",

      lt_rem8: "rem8",

      lt_cvd: "cvd",

      lt_exrate: "exrate",

      lt_cessrate: "cessrate",

      lt_hcrate: "hcrate",

      lt_cvdrate: "cvdrate",

      lt_exp_before: "exp_before",

      lt_exp_after: "exp_after",

      lt_total: "total",

      lt_b_tpt: "b_tpt",

      lt_sub_total: "sub_total",

      lt_party_code: "party_code",

      lt_tax_rate: "tax_rate",

      lt_exp10: "exp10",

      lt_loose: "loose",

      lt_spec: "spec",

      lt_pckng: "pckng",

      lt_wf: "wf",

      lt_wwf: "wwf",

      lt_tx_from: "tx_from",

      lt_tx_upto: "tx_upto",

      lt_tx_type: "tx_type",

      lt_ssr: "ssr",

      lt_vat_post: "vat_post",

      lt_led_post: "led_post",

      lt_ex_post: "ex_post",

      lt_bill: "bill",

      lt_stk_post: "stk_post",

      lt_opening: "opening",

      lt_purr: "purr",

      lt_sale: "sale",

      lt_prdd: "prdd",

      lt_issuee: "issuee",

      lt_closing: "closing",

      lt_stk_code: "stk_code",

      lt_rateins: "rateins",

      lt_srates: "srates",

      lt_qpps: "qpps",

      lt_tcs: "tcs",

      lt_tcs1: "tcs1",

      lt_tcs2: "tcs2",

      lt_tcs_rate: "tcs_rate",

      lt_tcs1_rate: "tcs1_rate",

      lt_tcs2_rate: "tcs2_rate",

      lt_saletype: "saletype",

      lt_purtype: "purtype",

      lt_ahead: "ahead",

      lt_add1: "add1",

      lt_add2: "add2",

      lt_city: "city",

      lt_tin: "tin",

      lt_phone: "phone",

      lt_cash_name: "cash_name",

      lt_cash_add1: "cash_add1",

      lt_cash_city: "cash_city",

      lt_tax0_sale: "tax0_sale",

      lt_tax1_sale: "tax1_sale",

      lt_p_vdate: "p_vdate",

      lt_p_vno: "p_vno",

      lt_p_valpha: "p_valpha",

      lt_p_counter: "p_counter",

      lt_unit_ex: "unit_ex",

      lt_unit_cs: "unit_cs",

      lt_unit_hs: "unit_hs",

      lt_unit_cv: "unit_cv",

      lt_cd1: "cd1",

      lt_cd1_rate: "cd1_rate",

      lt_tariff: "tariff",

      lt_user_name: "user_name",

      lt_exp1_ex: "exp1_ex",

      lt_exp2_ex: "exp2_ex",

      lt_weights: "weights",

      lt_emistatus: "emistatus",

      lt_p_pageno: "p_pageno",

      lt_p_entry: "p_entry",

      lt_taxsurr: "taxsurr",

      lt_o_vdate: "o_vdate",

      lt_o_vno: "o_vno",

      lt_o_valpha: "o_valpha",

      lt_o_counter: "o_counter",

      lt_exp1_exr: "exp1_exr",

      lt_exp2_exr: "exp2_exr",

      lt_rem9: "rem9",

      lt_rem10: "rem10",
      lt_rem11: "rem11",
      lt_exp01: "exp01",
      lt_exp01code: "exp01code",
      lt_p_vbillno: "p_vbillno",
      lt_usname: "usname",
      lt_initial: "initial",

      lt_usrate: "usrate",

      lt_usvamt: "usvamt",

      lt_cardno: "cardno",

      lt_cashrec: "cashrec",

      lt_bank: "bank",

      lt_bcode: "bcode",

      lt_exp3_ex: "exp3_ex",
      lt_ctax: "ctax",
      lt_ctax_rate: "ctax_rate",
      lt_stax: "stax",
      lt_stax_rate: "stax_rate",
      lt_itax: "itax",
      lt_itax_rate: "itax_rate",

      // DV declaration

      dv_vacode: 1,
      dv_vdate: 2,
      dv_vcode: 3,
      dv_vamt: 4,
      dv_others: 5,
      dv_vdesc: 6,
      dv_stype: 7,
      dv_freight: 8,
      dv_weight: 9,

      dv_pkgs: 10,

      dv_tax: 11,

      dv_sdisc: 12,

      dv_etype: 13,

      dv_exfor: 14,

      dv_rate: 15,

      dv_stkcode: 16,

      dv_balance: 17,

      dv_conv: 18,

      dv_plarg: 19,

      dv_entno: 20,

      dv_pb_wt: 21,

      dv_freight1: 22,

      dv_weighing: 23,

      dv_pla: 24,

      dv_tds_frt: 25,

      dv_tdsrate: 26,

      dv_cess: 27,

      dv_vbillno1: 28,

      dv_vbdate1: 29,

      dv_vamt1: 30,

      dv_duedate: 31,

      dv_cl_date: 32,

      dv_vacode1: 33,

      dv_hcess: 34,

      dv_trpt: 35,

      dv_weight_ch: 36,

      dv_vamt_ch: 37,

      dv_vdate_ch: 38,

      dv_vhead: 39,

      dv_credit: 40,

      dv_pcess: 41,

      dv_tcs_cess: 42,

      dv_tcs_hcess: 43,

      dv_exp1: 44,

      dv_exp2: 45,

      dv_exp3: 46,

      dv_exp4: 47,

      dv_exp5: 48,

      dv_exp6: 49,

      dv_exp7: 50,

      dv_exp8: 51,

      dv_exp9: 52,
      dv_exp1_rate: 53,

      dv_exp2_rate: 54,

      dv_exp3_rate: 55,

      dv_exp4_rate: 56,

      dv_exp5_rate: 57,

      dv_exp6_rate: 58,

      dv_exp7_rate: 59,

      dv_exp8_rate: 60,

      dv_exp9_rate: 61,

      dv_exp10_rate: 62,
      dv_rem1: 63,
      dv_rem2: 64,
      dv_rem3: 65,
      dv_rem4: 66,

      dv_transport: 67,

      dv_order: 68,

      dv_order_date: 69,

      dv_agent: 70,

      dv_broker: 71,

      dv_cd_rate: 72,
      dv_cd: 73,

      dv_sch_rate: 74,

      dv_scheme: 75,

      dv_srv_rate: 76,

      dv_srv_tax: 77,

      dv_inv_tm: 78,

      dv_rev_dt: 79,

      dv_rem5: 80,

      dv_rem6: 81,

      dv_rem7: 82,

      dv_rem8: 83,

      dv_cvd: 84,

      dv_exrate: 85,

      dv_cessrate: 86,

      dv_hcrate: 87,

      dv_cvdrate: 88,

      dv_exp_before: 89,

      dv_exp_after: 90,

      dv_tax_rate: 91,

      dv_exp10: 92,

      dv_loose: 93,
      dv_spec: 94,

      dv_pckng: 95,
      dv_wf: 96,

      dv_wwf: 97,

      dv_bill: 98,

      dv_stk_code: 99,

      dv_rateins: 100,

      dv_srates: 101,

      dv_qpps: 102,

      dv_tcs: 103,

      dv_tcs1: 104,

      dv_tcs2: 105,

      dv_tcs_rate: 106,

      dv_tcs1_rate: 107,

      dv_tcs2_rate: 108,

      dv_saletype: 109,

      dv_unit_ex: 110,

      dv_unit_cs: 111,

      dv_unit_hs: 112,

      dv_unit_cv: 113,

      dv_cd1: 114,

      dv_cd1_rate: 115,

      dv_tariff: 116,

      dv_exp1_ex: 117,

      dv_exp2_ex: 118,

      dv_weights: 119,

      dv_exp1_exr: 120,

      dv_exp2_exr: 121,

      dv_rem9: 122,

      dv_rem10: 123,

      dv_exp01: 124,

      dv_exp01code: 125,

      dv_p_vbillno: 126,

      dv_usname: 127,

      dv_usrate: 128,

      dv_usvamt: 129,

      dv_cardno: 130,

      dv_ctax: 131,

      dv_ctax_rate: 132,

      dv_stax: 133,

      dv_stax_rate: 134,

      dv_itax: 135,

      dv_itax_rate: 136,

      dv_valpha: 137,

      dv_vno: 138,

      dv_vtype: 139,

      dv_vamtcode: 140,

      dv_vbillno: 141,

      dv_vbdate: 142,

      dv_excise: 143,

      dv_counter: 144,

      dv_btype: 145,

      dv_srno1: 146,

      dv_ppcode: 147,

      dv_emcode: 148,
      dv_mon: 149,

      dv_initial: 150,

      dv_vacode_ch: 151,

      dv_record: 152,

      dv_vhead_ch: 153,

      dv_remarks: 154,

      dv_tick: 155,

      dv_debit: 156,

      dv_vat: 157,
      dv_gr: 158,

      dv_rev_tm: 159,

      dv_inv_dt: 160,

      dv_total: 161,

      dv_b_tpt: 162,

      dv_sub_total: 163,

      dv_party_code: 164,

      dv_tx_from: 165,

      dv_tx_upto: 166,

      dv_tx_type: 167,

      dv_ssr: 168,

      dv_vat_post: 169,

      dv_led_post: 170,

      dv_ex_post: 171,

      dv_stk_post: 172,

      dv_opening: 173,

      dv_purr: 174,

      dv_sale: 175,

      dv_prdd: 176,

      dv_issuee: 177,

      dv_closing: 178,

      dv_purtype: 179,

      dv_ahead: 180,

      dv_add1: 181,

      dv_add2: 182,

      dv_city: 183,
      dv_tin: 184,

      dv_phone: 185,

      dv_cash_name: 186,

      dv_cash_add1: 187,

      dv_cash_city: 188,

      dv_tax0_sale: 189,

      dv_tax1_sale: 190,

      dv_p_vdate: 191,

      dv_p_vno: 192,

      dv_p_valpha: 193,

      dv_p_counter: 194,

      dv_user_name: 195,

      dv_emistatus: 196,

      dv_p_pageno: 197,

      dv_p_entry: 198,

      dv_taxsurr: 199,

      dv_o_vdate: 200,

      dv_o_vno: 201,

      dv_o_valpha: 202,

      dv_o_counter: 203,

      dv_rem11: 204,

      dv_cashrec: 205,

      dv_bank: 206,

      dv_bcode: 207,

      dv_exp3_ex: 208,

      //Width Declarations

      wi_vacode: 0,
      wi_vdate: 0,
      wi_vcode: 0,

      wi_vamt: 0,
      wi_others: 0,
      wi_vdesc: 0,
      wi_stype: 0,
      wi_freight: 0,
      wi_weight: 0,
      wi_pkgs: 0,

      wi_tax: 0,

      wi_sdisc: 0,

      wi_etype: 0,

      wi_exfor: 0,

      wi_rate: 0,

      wi_stkcode: 0,

      wi_balance: 0,

      wi_conv: 0,

      wi_plarg: 0,

      wi_entno: 0,

      wi_pb_wt: 0,

      wi_freight1: 0,

      wi_weighing: 0,

      wi_pla: 0,

      wi_tds_frt: 0,

      wi_tdsrate: 0,

      wi_cess: 0,

      wi_vbillno1: 0,

      wi_vbdate1: 0,

      wi_vamt1: 0,

      wi_duedate: 0,

      wi_cl_date: 0,

      wi_vacode1: 0,

      wi_hcess: 0,

      wi_trpt: 0,

      wi_weight_ch: 0,

      wi_vamt_ch: 0,

      wi_vdate_ch: 0,

      wi_vhead: 0,

      wi_credit: 0,

      wi_pcess: 0,

      wi_tcs_cess: 0,

      wi_tcs_hcess: 0,

      wi_exp1: 0,

      wi_exp2: 0,

      wi_exp3: 0,

      wi_exp4: 0,

      wi_exp5: 0,

      wi_exp6: 0,

      wi_exp7: 0,

      wi_exp8: 0,

      wi_exp9: 0,
      wi_exp1_rate: 0,

      wi_exp2_rate: 0,

      wi_exp3_rate: 0,

      wi_exp4_rate: 0,

      wi_exp5_rate: 0,

      wi_exp6_rate: 0,

      wi_exp7_rate: 0,

      wi_exp8_rate: 0,

      wi_exp9_rate: 0,

      wi_exp10_rate: 0,
      wi_rem1: 0,
      wi_rem2: 0,
      wi_rem3: 0,
      wi_rem4: 0,

      wi_transport: 0,

      wi_order: 0,

      wi_order_date: 0,

      wi_agent: 0,

      wi_broker: 0,

      wi_cd_rate: 0,
      wi_cd: 0,

      wi_sch_rate: 0,

      wi_scheme: 0,

      wi_srv_rate: 0,

      wi_srv_tax: 0,

      wi_inv_tm: 0,

      wi_rev_dt: 0,

      wi_rem5: 0,

      wi_rem6: 0,

      wi_rem7: 0,

      wi_rem8: 0,

      wi_cvd: 0,

      wi_exrate: 0,

      wi_cessrate: 0,

      wi_hcrate: 0,

      wi_cvdrate: 0,

      wi_exp_before: 0,

      wi_exp_after: 0,

      wi_tax_rate: 0,

      wi_exp10: 0,

      wi_loose: 0,
      wi_spec: 0,

      wi_pckng: 0,
      wi_wf: 0,

      wi_wwf: 0,

      wi_bill: 0,

      wi_stk_code: 0,

      wi_rateins: 0,

      wi_srates: 0,

      wi_qpps: 0,

      wi_tcs: 0,

      wi_tcs1: 0,

      wi_tcs2: 0,

      wi_tcs_rate: 0,

      wi_tcs1_rate: 0,

      wi_tcs2_rate: 0,

      wi_saletype: 0,

      wi_unit_ex: 0,

      wi_unit_cs: 0,

      wi_unit_hs: 0,

      wi_unit_cv: 0,

      wi_cd1: 0,

      wi_cd1_rate: 0,

      wi_tariff: 0,

      wi_exp1_ex: 0,

      wi_exp2_ex: 0,

      wi_weights: 0,

      wi_exp1_exr: 0,

      wi_exp2_exr: 0,

      wi_rem9: 0,

      wi_rem10: 0,

      wi_exp01: 0,

      wi_exp01code: 0,

      wi_p_vbillno: 0,

      wi_usname: 0,

      wi_usrate: 0,

      wi_usvamt: 0,

      wi_cardno: 0,

      wi_ctax: 0,

      wi_ctax_rate: 0,

      wi_stax: 0,

      wi_stax_rate: 0,

      wi_itax: 0,

      wi_itax_rate: 0,

      wi_valpha: 0,

      wi_vno: 0,

      wi_vtype: 0,

      wi_vamtcode: 0,

      wi_vbillno: 0,

      wi_vbdate: 0,

      wi_excise: 0,

      wi_counter: 0,

      wi_btype: 0,

      wi_srno1: 0,

      wi_ppcode: 0,

      wi_emcode: 0,
      wi_mon: 0,

      wi_initial: 0,

      wi_vacode_ch: 0,

      wi_record: 0,

      wi_vhead_ch: 0,

      wi_remarks: 0,

      wi_tick: 0,

      wi_debit: 0,

      wi_vat: 0,
      wi_gr: 0,

      wi_rev_tm: 0,

      wi_inv_dt: 0,

      wi_total: 0,

      wi_b_tpt: 0,

      wi_sub_total: 0,

      wi_party_code: 0,

      wi_tx_from: 0,

      wi_tx_upto: 0,

      wi_tx_type: 0,

      wi_ssr: 0,

      wi_vat_post: 0,

      wi_led_post: 0,

      wi_ex_post: 0,

      wi_stk_post: 0,

      wi_opening: 0,

      wi_purr: 0,

      wi_sale: 0,

      wi_prdd: 0,

      wi_issuee: 0,

      wi_closing: 0,

      wi_purtype: 0,

      wi_ahead: 0,

      wi_add1: 0,

      wi_add2: 0,

      wi_city: 0,
      wi_tin: 0,

      wi_phone: 0,

      wi_cash_name: 0,

      wi_cash_add1: 0,

      wi_cash_city: 0,

      wi_tax0_sale: 0,

      wi_tax1_sale: 0,

      wi_p_vdate: 0,

      wi_p_vno: 0,

      wi_p_valpha: 0,

      wi_p_counter: 0,

      wi_user_name: 0,

      wi_emistatus: 0,

      wi_p_pageno: 0,

      wi_p_entry: 0,

      wi_taxsurr: 0,

      wi_o_vdate: 0,

      wi_o_vno: 0,

      wi_o_valpha: 0,

      wi_o_counter: 0,

      wi_rem11: 0,

      wi_cashrec: 0,

      wi_bank: 0,

      wi_bcode: 0,

      wi_exp3_ex: 0,

      latestCode: 0,

      setupForm: false,
      State: "",
      colorx: "#103767",
      gstwisestates: {
        "1": "JAMMU AND KASHMIR",
        "2": "HIMACHAL PRADESH",
        "3": "PUNJAB",
        "4": "CHANDIGARH",
        "5": "UTTARAKHAND",
        "6": "HARYANA",
        "7": "DELHI",
        "8": "RAJASTHAN",
        "9": "UTTAR PRADESH",
        "10": "BIHAR",
        "11": "SIKKIM",
        "12": "ARUNACHAL PRADESH (Old)",
        "13": "NAGALAND",
        "14": "MANIPUR",
        "15": "MIZORAM",
        "16": "TRIPURA",
        "17": "MEGHLAYA",
        "18": "ASSAM",
        "19": "WEST BENGAL",
        "20": "JHARKHAND",
        "21": "ODISHA",
        "22": "CHATTISGARH",
        "23": "MADHYA PRADESH",
        "24": "GUJARAT",
        "25": "DAMAN AND DIU",
        "26": "DADRA AND NAGAR HAVELI",
        "27": "MAHARASHTRA",
        "28": "ANDHRA PRADESH",
        "29": "KARNATAKA",
        "30": "GOA",
        "31": "LAKSHWADEEP",
        "32": "KERALA",
        "33": "TAMIL NADU",
        "34": "PUDUCHERRY",
        "35": "ANDAMAN AND NICOBAR ISLANDS",
        "36": "TELANGANA",
        "37": "ANDHRA PRADESH (NEW)"
      },
      states: [
        "Andaman and Nicobar Islands",
        "Andhra Pradesh",
        "Arunachal Pradesh",
        "Assam",
        "Bihar",
        "Chandigarh",
        "Chhattisgarh",
        "Dadra and Nagar Haveli",
        "Daman and Diu",
        "Delhi",
        "Goa",
        "Gujarat",
        "Haryana",
        "Himachal Pradesh",
        "Jammu and Kashmir",
        "Jharkhand",
        "Karnataka",
        "Kerala",
        "Ladakh",
        "Lakshadweep",
        "Madhya Pradesh",
        "Maharashtra",
        "Manipur",
        "Meghalaya",
        "Mizoram",
        "Nagaland",
        "Odisha",
        "Puducherry",
        "Punjab",
        "Rajasthan",
        "Sikkim",
        "Tamil Nadu",
        "Telangana",
        "Tripura",
        "Uttar Pradesh",
        "Uttarakhand",
        "West Bengal"
      ],

      searchindex: 0,
      modalOpen: false,

      titleAction: "",
      finalind: 0,
      comboarea: "",
      combogroup: "",
      comboemail: "",
      popupActiveNarration: false,
      modalOpenNarration: false,
      miscpopup: false,
      drcrNarrations: [],
      drcrFilteredNarrations: [],
      popupSelectedRow: 0,
      drcrFilter: "",
      chosen: "",
      drcrpopup: false,
      showdrcr: false,
      reload: "false",
      oldNarrationToEdit: "",
      modifiedNarration: "",
      annexurecalled: "",
      currentfield: "",
      emaildata: [],
      citydata: [],
      acnamedata: [],
      disttdata: [],
      worksdata: [],
      groupdata: [],
      agentdata: [],
      companyname: "",
      newNarration: "",
      popupdata: null,
      field: "",
      filterbar2: "",
      filteredUsers: [],
      tabledata: [],
      users: [],
      narrations: [],
      filteredAreaNarrations: [],
      filteredEmailNarrations: [],
      filteredCityNarrations: [],
      filteredAcNameNarrations: [],
      filteredDisttNarrations: [],
      filteredWorksNarrations: [],
      filteredGroupNarrations: [],
      popupActiveNarr: false,
      dat: remoteData,
      spdata: ["hey", "sfsdf@gmail.com"],
      query: new Query()
        .select(["FirstName", "EmployeeID"])
        .take(10)
        .requiresCount(),

      AcNam: "",

      Address1: "",
      BankACName: "",
      Address2: "",
      AadhaarNo: "",
      IFSCCode: "",
      City: "",
      Division: "",
      PinCode: "",
      Collectorate: "",
      Distt: "",
      drdis: false,
      crdis: false,
      DGSTNo: "",
      SACCode: "",
      Distance: "",
      OpeningBalanceDr: "",
      ContactPerson: "",
      OpeningBalanceCr: "",
      InttDepcRate: "",
      ContactNo: "",
      TDSRate: "",
      MEmailIDArea: "",
      TGSTShare: "",
      AgentGroup: "",
      Quantitiy: "",
      v: "",
      a: false,
      BankACNo: "",
      PAN: "",
      TDSAcNo: "",
      CompositionYN: "",
      Works: "",
      NameAddress1: "",
      NameAddress2: "",
      dbIndex: "",
      bufferIndex: "",
      requiredIndex: -999,
      disAdd: false,
      disCopy: false,
      disDelete: false,
      disEdit: false,
      disFirst: false,
      disLast: false,
      disNext: false,
      disSave: true,
      disSearch: false,
      disPrinter: false,
      disPrevious: false,
      disExit: false,
      buttondis: true,

      buttondis_AcCode: true,
      buttonen_AcName: false,
      buttondis_State: true,
      buttondis_Address1: true,
      buttondis_BankACName: true,
      buttondis_Address2: true,
      buttondis_AadhaarNo: true,
      buttondis_IFSCCode: true,
      buttonen_City: false,
      buttondis_Division: true,
      buttondis_PinCode: true,
      buttondis_Collectorate: true,
      buttonen_Distt: false,
      buttondis_DGSTNo: true,
      buttondis_SACCode: true,
      buttondis_Distance: true,
      buttondis_OpeningBalanceDr: true,
      buttondis_ContactPerson: true,
      buttondis_OpeningBalanceCr: true,
      buttondis_InttDepcRate: true,
      buttondis_ContactNo: true,
      buttondis_TDSRate: true,

      buttonen_comboemail: false,
      buttondis_TGSTShare: true,
      buttonen_comboarea: false,
      buttonen_combogroup: false,
      buttondis_Quantitiy: true,
      buttondis_v: true,

      buttondis_BankACNo: true,
      buttondis_PAN: true,
      buttondis_TDSAcNo: true,
      buttondis_CompositionYN: true,
      buttonen_Works: false,
      buttondis_NameAddress1: true,
      buttondis_NameAddress2: true,

      annexureText: "Purchase Series",
      selected: "",

      mis_payment_limit: "",
      mis_payment_due_days: "",
      mis_int_grace_days: "",
      mis_sorting_index_no: "",
      mis_qty_in_bsheet: "",
      mis_tr_discount: "",
      mis_terms_exfor: "",
      mis_trading_ac_no: "",
      mis_status: "",
      mis_ward: "",
      mis_last_ass: "",
      mis_area_code: "",
      mis_range_code: "",
      mis_ao_no: "",
      filedata: "",

      buttonList: [
        "addButton",
        "editButton",
        "previousButton",
        "nextButton",
        "firstButton",
        "lastButton",
        "searchButton",
        "moveButton",
        "printButton",
        "deleteButton",
        "exitButton",
        "saveButton"
      ],
      buttonActiveList: [
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ],
      filteredAnnexures: [],
      annexures: [],
      selectedDropdown: "name",
      popupActive2: false,
      popupActive3: false,
      popupActive4: false,
      popupActive5: false,
      popupActive6: false,
      buttonColor: "#7367F0",
      activeColor: "#c72a75",
      inactiveColor: "#7367F0",
      hasfocus: false
    };
  },
  components: {
    modalnarration,
    modal
  },
  methods: {
    setSetupData(columndata, orderdata, labeldata,widthdata) {
      console.log(labeldata);
       console.log(widthdata);
      this.ch_vdate = columndata.vdate;
      this.ch_vtype = columndata.vtype;
      this.ch_vno = columndata.vno;
      this.ch_valpha = columndata.valpha;
      this.ch_vcode = columndata.vcode;

      this.ch_vacode = columndata.vacode;

      this.ch_vamt = columndata.vamt;

      this.ch_others = columndata.others;

      this.ch_vamtcode = columndata.vamtcode;

      this.ch_vdesc = columndata.vdesc;

      this.ch_vbillno = columndata.vbillno;

      this.ch_vbdate = columndata.vbdate;

      this.ch_stype = columndata.stype;

      this.ch_freight = columndata.freight;

      this.ch_excise = columndata.excise;

      this.ch_weight = columndata.weight;

      this.ch_pkgs = columndata.pkgs;

      this.ch_tax = columndata.tax;

      this.ch_counter = columndata.counter;

      this.ch_sdisc = columndata.sdisc;

      this.ch_etype = columndata.etype;

      this.ch_exfor = columndata.exfor;

      this.ch_rate = columndata.rate;

      this.ch_btype = columndata.btype;

      this.ch_stkcode = columndata.stkcode;

      this.ch_balance = columndata.balance;

      this.ch_conv = columndata.conv;

      this.ch_plarg = columndata.plarg;

      this.ch_entno = columndata.entno;

      this.ch_pb_wt = columndata.pb_wt;

      this.ch_srno1 = columndata.srno1;

      this.ch_freight1 = columndata.freight1;

      this.ch_weighing = columndata.weighing;

      this.ch_pla = columndata.pla;

      this.ch_tds_frt = columndata.tds_frt;

      this.ch_tdsrate = columndata.tdsrate;

      this.ch_ppcode = columndata.ppcode;

      this.ch_cess = columndata.cess;

      this.ch_vbillno1 = columndata.vbillno1;

      this.ch_vbdate1 = columndata.vbdate1;

      this.ch_vamt1 = columndata.vamt1;

      this.ch_duedate = columndata.duedate;

      this.ch_cl_date = columndata.cl_date;

      this.ch_emcode = columndata.emcode;

      this.ch_mon = columndata.mon;

      this.ch_vacode1 = columndata.vacode1;

      this.ch_hcess = columndata.hcess;

      this.ch_trpt = columndata.trpt;

      this.ch_intial = columndata.intial;

      this.ch_weight_ch = columndata.weight_ch;

      this.ch_vamt_ch = columndata.vamt_ch;

      this.ch_vdate_ch = columndata.vdate_ch;

      this.ch_vacode_ch = columndata.vacode_ch;

      this.ch_record = columndata.record;

      this.ch_vhead_ch = columndata.vhead_ch;

      this.ch_vhead = columndata.vhead;

      this.ch_remarks = columndata.remarks;

      this.ch_tick = columndata.tick;

      this.ch_credit = columndata.credit;

      this.ch_debit = columndata.debit;

      this.ch_pcess = columndata.pcess;

      this.ch_tcs_cess = columndata.tcs_cess;

      this.ch_tcs_hcess = columndata.tcs_hcess;

      this.ch_vat = columndata.vat;

      this.ch_exp1 = columndata.exp1;

      this.ch_exp2 = columndata.exp2;

      this.ch_exp3 = columndata.exp3;

      this.ch_exp4 = columndata.exp4;

      this.ch_exp5 = columndata.exp5;

      this.ch_exp6 = columndata.exp6;

      this.ch_exp7 = columndata.exp7;

      this.ch_exp8 = columndata.exp8;

      this.ch_exp9 = columndata.exp9;

      this.ch_exp1_rate = columndata.exp1_rate;

      this.ch_exp2_rate = columndata.exp2_rate;

      this.ch_exp3_rate = columndata.exp3_rate;

      this.ch_exp4_rate = columndata.exp4_rate;

      this.ch_exp5_rate = columndata.exp5_rate;

      this.ch_exp6_rate = columndata.exp6_rate;

      this.ch_exp7_rate = columndata.exp7_rate;

      this.ch_exp8_rate = columndata.exp8_rate;

      this.ch_exp9_rate = columndata.exp9_rate;

      this.ch_exp10_rate = columndata.exp10_rate;

      this.ch_rem1 = columndata.rem1;

      this.ch_rem2 = columndata.rem2;

      this.ch_rem3 = columndata.rem3;

      this.ch_rem4 = columndata.rem4;

      this.ch_transport = columndata.transport;

      this.ch_order = columndata.order;

      this.ch_order_date = columndata.order_date;

      this.ch_agent = columndata.agent;

      this.ch_broker = columndata.broker;

      this.ch_cd_rate = columndata.cd_rate;

      this.ch_cd = columndata.cd;

      this.ch_sch_rate = columndata.sch_rate;

      this.ch_scheme = columndata.scheme;

      this.ch_srv_rate = columndata.srv_rate;

      this.ch_srv_tax = columndata.srv_tax;

      this.ch_gr = columndata.gr;

      this.ch_inv_tm = columndata.inv_tm;

      this.ch_rev_tm = columndata.rev_tm;

      this.ch_inv_dt = columndata.inv_dt;

      this.ch_rev_dt = columndata.rev_dt;

      this.ch_rem5 = columndata.rem5;

      this.ch_rem6 = columndata.rem6;

      this.ch_rem7 = columndata.rem7;

      this.ch_rem8 = columndata.rem8;

      this.ch_cvd = columndata.cvd;

      this.ch_exrate = columndata.exrate;

      this.ch_cessrate = columndata.cessrate;

      this.ch_hcrate = columndata.hcrate;

      this.ch_cvdrate = columndata.cvdrate;

      this.ch_exp_before = columndata.exp_before;

      this.ch_exp_after = columndata.exp_after;

      this.ch_total = columndata.total;

      this.ch_b_tpt = columndata.b_tpt;

      this.ch_sub_total = columndata.sub_total;

      this.ch_party_code = columndata.party_code;

      this.ch_tax_rate = columndata.tax_rate;

      this.ch_exp10 = columndata.exp10;

      this.ch_loose = columndata.loose;

      this.ch_spec = columndata.spec;

      this.ch_pckng = columndata.pckng;

      this.ch_wf = columndata.wf;

      this.ch_wwf = columndata.wwf;

      this.ch_tx_from = columndata.tx_from;

      this.ch_tx_upto = columndata.tx_upto;

      this.ch_tx_type = columndata.tx_type;

      this.ch_ssr = columndata.ssr;

      this.ch_vat_post = columndata.vat_post;

      this.ch_led_post = columndata.led_post;

      this.ch_ex_post = columndata.ex_post;

      this.ch_bill = columndata.bill;

      this.ch_stk_post = columndata.stk_post;

      this.ch_opening = columndata.opening;

      this.ch_purr = columndata.purr;

      this.ch_sale = columndata.sale;

      this.ch_prdd = columndata.prdd;

      this.ch_issuee = columndata.issuee;

      this.ch_closing = columndata.closing;

      this.ch_stk_code = columndata.stk_code;

      this.ch_rateins = columndata.rateins;

      this.ch_srates = columndata.srates;

      this.ch_qpps = columndata.qpps;

      this.ch_tcs = columndata.tcs;

      this.ch_tcs1 = columndata.tcs1;

      this.ch_tcs2 = columndata.tcs2;

      this.ch_tcs_rate = columndata.tcs_rate;

      this.ch_tcs1_rate = columndata.tcs1_rate;

      this.ch_tcs2_rate = columndata.tcs2_rate;

      this.ch_saletype = columndata.saletype;

      this.ch_purtype = columndata.purtype;

      this.ch_ahead = columndata.ahead;

      this.ch_add1 = columndata.add1;

      this.ch_add2 = columndata.add2;

      this.ch_city = columndata.city;

      this.ch_tin = columndata.tin;

      this.ch_phone = columndata.phone;

      this.ch_cash_name = columndata.cash_name;

      this.ch_cash_add1 = columndata.cash_add1;

      this.ch_cash_city = columndata.cash_city;

      this.ch_tax0_sale = columndata.tax0_sale;

      this.ch_tax1_sale = columndata.tax1_sale;

      this.ch_p_vdate = columndata.p_vdate;

      this.ch_p_vno = columndata.p_vno;

      this.ch_p_valpha = columndata.p_valpha;

      this.ch_p_counter = columndata.p_counter;

      this.ch_unit_ex = columndata.unit_ex;

      this.ch_unit_cs = columndata.unit_cs;

      this.ch_unit_hs = columndata.unit_hs;

      this.ch_unit_cv = columndata.unit_cv;

      this.ch_cd1 = columndata.cd1;

      this.ch_cd1_rate = columndata.cd1_rate;

      this.ch_tariff = columndata.tariff;

      this.ch_user_name = columndata.user_name;

      this.ch_exp1_ex = columndata.exp1_ex;

      this.ch_exp2_ex = columndata.exp2_ex;

      this.ch_weights = columndata.weights;

      this.ch_emistatus = columndata.emistatus;

      this.ch_p_pageno = columndata.p_pageno;

      this.ch_p_entry = columndata.p_entry;

      this.ch_taxsurr = columndata.taxsurr;

      this.ch_o_vdate = columndata.o_vdate;

      this.ch_o_vno = columndata.o_vno;

      this.ch_o_valpha = columndata.o_valpha;

      this.ch_o_counter = columndata.o_counter;

      this.ch_exp1_exr = columndata.exp1_exr;

      this.ch_exp2_exr = columndata.exp2_exr;

      this.ch_rem9 = columndata.rem9;

      this.ch_rem10 = columndata.rem10;
      this.ch_rem11 = columndata.rem11;
      this.ch_exp01 = columndata.exp01;
      this.ch_exp01code = columndata.exp01code;
      this.ch_p_vbillno = columndata.p_vbillno;
      this.ch_usname = columndata.usname;

      this.ch_usrate = columndata.usrate;

      this.ch_usvamt = columndata.usvamt;

      this.ch_cardno = columndata.cardno;

      this.ch_cashrec = columndata.cashrec;

      this.ch_bank = columndata.bank;

      this.ch_bcode = columndata.bcode;

      this.ch_exp3_ex = columndata.exp3_ex;
      this.ch_ctax = columndata.ctax;
      this.ch_ctax_rate = columndata.ctax_rate;
      this.ch_stax = columndata.stax;
      this.ch_stax_rate = columndata.stax_rate;
      this.ch_itax = columndata.itax;
      this.ch_itax_rate=columndata.itax_rate

this.wi_vdate = widthdata.vdate;
      this.wi_vtype = widthdata.vtype;
      this.wi_vno = widthdata.vno;
      this.wi_valpha = widthdata.valpha;
      this.wi_vcode = widthdata.vcode;

      this.wi_vacode = widthdata.vacode;

      this.wi_vamt = widthdata.vamt;

      this.wi_others = widthdata.others;

      this.wi_vamtcode = widthdata.vamtcode;

      this.wi_vdesc = widthdata.vdesc;

      this.wi_vbillno = widthdata.vbillno;

      this.wi_vbdate = widthdata.vbdate;

      this.wi_stype = widthdata.stype;

      this.wi_freight = widthdata.freight;

      this.wi_excise = widthdata.excise;

      this.wi_weight = widthdata.weight;

      this.wi_pkgs = widthdata.pkgs;

      this.wi_tax = widthdata.tax;

      this.wi_counter = widthdata.counter;

      this.wi_sdisc = widthdata.sdisc;

      this.wi_etype = widthdata.etype;

      this.wi_exfor = widthdata.exfor;

      this.wi_rate = widthdata.rate;

      this.wi_btype = widthdata.btype;

      this.wi_stkcode = widthdata.stkcode;

      this.wi_balance = widthdata.balance;

      this.wi_conv = widthdata.conv;

      this.wi_plarg = widthdata.plarg;

      this.wi_entno = widthdata.entno;

      this.wi_pb_wt = widthdata.pb_wt;

      this.wi_srno1 = widthdata.srno1;

      this.wi_freight1 = widthdata.freight1;

      this.wi_weighing = widthdata.weighing;

      this.wi_pla = widthdata.pla;

      this.wi_tds_frt = widthdata.tds_frt;

      this.wi_tdsrate = widthdata.tdsrate;

      this.wi_ppcode = widthdata.ppcode;

      this.wi_cess = widthdata.cess;

      this.wi_vbillno1 = widthdata.vbillno1;

      this.wi_vbdate1 = widthdata.vbdate1;

      this.wi_vamt1 = widthdata.vamt1;

      this.wi_duedate = widthdata.duedate;

      this.wi_cl_date = widthdata.cl_date;

      this.wi_emcode = widthdata.emcode;

      this.wi_mon = widthdata.mon;

      this.wi_vacode1 = widthdata.vacode1;

      this.wi_hcess = widthdata.hcess;

      this.wi_trpt = widthdata.trpt;

      this.wi_intial = widthdata.intial;

      this.wi_weight_ch = widthdata.weight_ch;

      this.wi_vamt_ch = widthdata.vamt_ch;

      this.wi_vdate_ch = widthdata.vdate_ch;

      this.wi_vacode_ch = widthdata.vacode_ch;

      this.wi_record = widthdata.record;

      this.wi_vhead_ch = widthdata.vhead_ch;

      this.wi_vhead = widthdata.vhead;

      this.wi_remarks = widthdata.remarks;

      this.wi_tick = widthdata.tick;

      this.wi_credit = widthdata.credit;

      this.wi_debit = widthdata.debit;

      this.wi_pcess = widthdata.pcess;

      this.wi_tcs_cess = widthdata.tcs_cess;

      this.wi_tcs_hcess = widthdata.tcs_hcess;

      this.wi_vat = widthdata.vat;

      this.wi_exp1 = widthdata.exp1;

      this.wi_exp2 = widthdata.exp2;

      this.wi_exp3 = widthdata.exp3;

      this.wi_exp4 = widthdata.exp4;

      this.wi_exp5 = widthdata.exp5;

      this.wi_exp6 = widthdata.exp6;

      this.wi_exp7 = widthdata.exp7;

      this.wi_exp8 = widthdata.exp8;

      this.wi_exp9 = widthdata.exp9;

      this.wi_exp1_rate = widthdata.exp1_rate;

      this.wi_exp2_rate = widthdata.exp2_rate;

      this.wi_exp3_rate = widthdata.exp3_rate;

      this.wi_exp4_rate = widthdata.exp4_rate;

      this.wi_exp5_rate = widthdata.exp5_rate;

      this.wi_exp6_rate = widthdata.exp6_rate;

      this.wi_exp7_rate = widthdata.exp7_rate;

      this.wi_exp8_rate = widthdata.exp8_rate;

      this.wi_exp9_rate = widthdata.exp9_rate;

      this.wi_exp10_rate = widthdata.exp10_rate;

      this.wi_rem1 = widthdata.rem1;

      this.wi_rem2 = widthdata.rem2;

      this.wi_rem3 = widthdata.rem3;

      this.wi_rem4 = widthdata.rem4;

      this.wi_transport = widthdata.transport;

      this.wi_order = widthdata.order;

      this.wi_order_date = widthdata.order_date;

      this.wi_agent = widthdata.agent;

      this.wi_broker = widthdata.broker;

      this.wi_cd_rate = widthdata.cd_rate;

      this.wi_cd = widthdata.cd;

      this.wi_sch_rate = widthdata.sch_rate;

widthdata.wi_scheme = widthdata.scheme;

      this.wi_srv_rate = widthdata.srv_rate;

      this.wi_srv_tax = widthdata.srv_tax;

      this.wi_gr = widthdata.gr;

      this.wi_inv_tm = widthdata.inv_tm;

      this.wi_rev_tm = widthdata.rev_tm;

      this.wi_inv_dt = widthdata.inv_dt;

      this.wi_rev_dt = widthdata.rev_dt;

      this.wi_rem5 = widthdata.rem5;

      this.wi_rem6 = widthdata.rem6;

      this.wi_rem7 = widthdata.rem7;

      this.wi_rem8 = widthdata.rem8;

      this.wi_cvd = widthdata.cvd;

      this.wi_exrate = widthdata.exrate;

      this.wi_cessrate = widthdata.cessrate;

      this.wi_hcrate = widthdata.hcrate;

      this.wi_cvdrate = widthdata.cvdrate;

      this.wi_exp_before = widthdata.exp_before;

      this.wi_exp_after = widthdata.exp_after;

      this.wi_total = widthdata.total;

      this.wi_b_tpt = widthdata.b_tpt;

      this.wi_sub_total = widthdata.sub_total;

      this.wi_party_code = widthdata.party_code;

      this.wi_tax_rate = widthdata.tax_rate;

      this.wi_exp10 = widthdata.exp10;

      this.wi_loose = widthdata.loose;

      this.wi_spec = widthdata.spec;

      this.wi_pckng = widthdata.pckng;

      this.wi_wf = widthdata.wf;

      this.wi_wwf = widthdata.wwf;

      this.wi_tx_from = widthdata.tx_from;

      this.wi_tx_upto = widthdata.tx_upto;

      this.wi_tx_type = widthdata.tx_type;

      this.wi_ssr = widthdata.ssr;

      this.wi_vat_post = widthdata.vat_post;

      this.wi_led_post = widthdata.led_post;

      this.wi_ex_post = widthdata.ex_post;

      this.wi_bill = widthdata.bill;

      this.wi_stk_post = widthdata.stk_post;

      this.wi_opening = widthdata.opening;

      this.wi_purr = widthdata.purr;

      this.wi_sale = widthdata.sale;

      this.wi_prdd = widthdata.prdd;

      this.wi_issuee = widthdata.issuee;

      this.wi_closing = widthdata.closing;

      this.wi_stk_code = widthdata.stk_code;

      this.wi_rateins = widthdata.rateins;

      this.wi_srates = widthdata.srates;

      this.wi_qpps = widthdata.qpps;

      this.wi_tcs = widthdata.tcs;

      this.wi_tcs1 = widthdata.tcs1;

      this.wi_tcs2 = widthdata.tcs2;

      this.wi_tcs_rate = widthdata.tcs_rate;

      this.wi_tcs1_rate = widthdata.tcs1_rate;

      this.wi_tcs2_rate = widthdata.tcs2_rate;

      this.wi_saletype = widthdata.saletype;

      this.wi_purtype = widthdata.purtype;

      this.wi_ahead = widthdata.ahead;

      this.wi_add1 = widthdata.add1;

      this.wi_add2 = widthdata.add2;

      this.wi_city = widthdata.city;

      this.wi_tin = widthdata.tin;

      this.wi_phone = widthdata.phone;

      this.wi_cash_name = widthdata.cash_name;

      this.wi_cash_add1 = widthdata.cash_add1;

      this.wi_cash_city = widthdata.cash_city;

      this.wi_tax0_sale = widthdata.tax0_sale;

      this.wi_tax1_sale = widthdata.tax1_sale;

      this.wi_p_vdate = widthdata.p_vdate;

      this.wi_p_vno = widthdata.p_vno;

      this.wi_p_valpha = widthdata.p_valpha;

      this.wi_p_counter = widthdata.p_counter;

      this.wi_unit_ex = widthdata.unit_ex;

      this.wi_unit_cs = widthdata.unit_cs;

      this.wi_unit_hs = widthdata.unit_hs;

      this.wi_unit_cv = widthdata.unit_cv;

      this.wi_cd1 = widthdata.cd1;

      this.wi_cd1_rate = widthdata.cd1_rate;

      this.wi_tariff = widthdata.tariff;

      this.wi_user_name = widthdata.user_name;

      this.wi_exp1_ex = widthdata.exp1_ex;

      this.wi_exp2_ex = widthdata.exp2_ex;

      this.wi_weights = widthdata.weights;

      this.wi_emistatus = widthdata.emistatus;

      this.wi_p_pageno = widthdata.p_pageno;

      this.wi_p_entry = widthdata.p_entry;

      this.wi_taxsurr = widthdata.taxsurr;

      this.wi_o_vdate = widthdata.o_vdate;

      this.wi_o_vno = widthdata.o_vno;

      this.wi_o_valpha = widthdata.o_valpha;

      this.wi_o_counter = widthdata.o_counter;

      this.wi_exp1_exr = widthdata.exp1_exr;

      this.wi_exp2_exr = widthdata.exp2_exr;

      this.wi_rem9 = widthdata.rem9;

      this.wi_rem10 = widthdata.rem10;
      this.wi_rem11 = widthdata.rem11;
      this.wi_exp01 = widthdata.exp01;
      this.wi_exp01code = widthdata.exp01code;
      this.wi_p_vbillno = widthdata.p_vbillno;
      this.wi_usname = widthdata.usname;

      this.wi_usrate = widthdata.usrate;

      this.wi_usvamt = widthdata.usvamt;

      this.wi_cardno = widthdata.cardno;

      this.wi_cashrec = widthdata.cashrec;

      this.wi_bank = widthdata.bank;

      this.wi_bcode = widthdata.bcode;

      this.wi_exp3_ex = widthdata.exp3_ex;
      this.wi_ctax = widthdata.ctax;
      this.wi_ctax_rate = widthdata.ctax_rate;
      this.wi_stax = widthdata.stax;
      this.wi_stax_rate = widthdata.stax_rate;
      this.wi_itax = widthdata.itax;


      this.lt_vdate = labeldata.vdate;
      this.lt_vtype = labeldata.vtype;
      this.lt_vno = labeldata.vno;
      this.lt_valpha = labeldata.valpha;
      this.lt_vcode = labeldata.vcode;

      this.lt_vacode = labeldata.vacode;

      this.lt_vamt = labeldata.vamt;

      this.lt_others = labeldata.others;

      this.lt_vamtcode = labeldata.vamtcode;

      this.lt_vdesc = labeldata.vdesc;

      this.lt_vbillno = labeldata.vbillno;

      this.lt_vbdate = labeldata.vbdate;

      this.lt_stype = labeldata.stype;

      this.lt_freight = labeldata.freight;

      this.lt_excise = labeldata.excise;

      this.lt_weight = labeldata.weight;

      this.lt_pkgs = labeldata.pkgs;

      this.lt_tax = labeldata.tax;

      this.lt_counter = labeldata.counter;

      this.lt_sdisc = labeldata.sdisc;

      this.lt_etype = labeldata.etype;

      this.lt_exfor = labeldata.exfor;

      this.lt_rate = labeldata.rate;

      this.lt_btype = labeldata.btype;

      this.lt_stkcode = labeldata.stkcode;

      this.lt_balance = labeldata.balance;

      this.lt_conv = labeldata.conv;

      this.lt_plarg = labeldata.plarg;

      this.lt_entno = labeldata.entno;

      this.lt_pb_wt = labeldata.pb_wt;

      this.lt_srno1 = labeldata.srno1;

      this.lt_freight1 = labeldata.freight1;

      this.lt_weighing = labeldata.weighing;

      this.lt_pla = labeldata.pla;

      this.lt_tds_frt = labeldata.tds_frt;

      this.lt_tdsrate = labeldata.tdsrate;

      this.lt_ppcode = labeldata.ppcode;

      this.lt_cess = labeldata.cess;

      this.lt_vbillno1 = labeldata.vbillno1;

      this.lt_vbdate1 = labeldata.vbdate1;

      this.lt_vamt1 = labeldata.vamt1;

      this.lt_duedate = labeldata.duedate;

      this.lt_cl_date = labeldata.cl_date;

      this.lt_emcode = labeldata.emcode;

      this.lt_mon = labeldata.mon;

      this.lt_vacode1 = labeldata.vacode1;

      this.lt_hcess = labeldata.hcess;

      this.lt_trpt = labeldata.trpt;

      this.lt_intial = labeldata.intial;

      this.lt_weight_ch = labeldata.weight_ch;

      this.lt_vamt_ch = labeldata.vamt_ch;

      this.lt_vdate_ch = labeldata.vdate_ch;

      this.lt_vacode_ch = labeldata.vacode_ch;

      this.lt_record = labeldata.record;

      this.lt_vhead_ch = labeldata.vhead_ch;

      this.lt_vhead = labeldata.vhead;

      this.lt_remarks = labeldata.remarks;

      this.lt_tick = labeldata.tick;

      this.lt_credit = labeldata.credit;

      this.lt_debit = labeldata.debit;

      this.lt_pcess = labeldata.pcess;

      this.lt_tcs_cess = labeldata.tcs_cess;

      this.lt_tcs_hcess = labeldata.tcs_hcess;

      this.lt_vat = labeldata.vat;

      this.lt_exp1 = labeldata.exp1;

      this.lt_exp2 = labeldata.exp2;

      this.lt_exp3 = labeldata.exp3;

      this.lt_exp4 = labeldata.exp4;

      this.lt_exp5 = labeldata.exp5;

      this.lt_exp6 = labeldata.exp6;

      this.lt_exp7 = labeldata.exp7;

      this.lt_exp8 = labeldata.exp8;

      this.lt_exp9 = labeldata.exp9;

      this.lt_exp1_rate = labeldata.exp1_rate;

      this.lt_exp2_rate = labeldata.exp2_rate;

      this.lt_exp3_rate = labeldata.exp3_rate;

      this.lt_exp4_rate = labeldata.exp4_rate;

      this.lt_exp5_rate = labeldata.exp5_rate;

      this.lt_exp6_rate = labeldata.exp6_rate;

      this.lt_exp7_rate = labeldata.exp7_rate;

      this.lt_exp8_rate = labeldata.exp8_rate;

      this.lt_exp9_rate = labeldata.exp9_rate;

      this.lt_exp10_rate = labeldata.exp10_rate;

      this.lt_rem1 = labeldata.rem1;

      this.lt_rem2 = labeldata.rem2;

      this.lt_rem3 = labeldata.rem3;

      this.lt_rem4 = labeldata.rem4;

      this.lt_transport = labeldata.transport;

      this.lt_order = labeldata.order;

      this.lt_order_date = labeldata.order_date;

      this.lt_agent = labeldata.agent;

      this.lt_broker = labeldata.broker;

      this.lt_cd_rate = labeldata.cd_rate;

      this.lt_cd = labeldata.cd;

      this.lt_sch_rate = labeldata.sch_rate;

      this.lt_scheme = labeldata.scheme;

      this.lt_srv_rate = labeldata.srv_rate;

      this.lt_srv_tax = labeldata.srv_tax;

      this.lt_gr = labeldata.gr;

      this.lt_inv_tm = labeldata.inv_tm;

      this.lt_rev_tm = labeldata.rev_tm;

      this.lt_inv_dt = labeldata.inv_dt;

      this.lt_rev_dt = labeldata.rev_dt;

      this.lt_rem5 = labeldata.rem5;

      this.lt_rem6 = labeldata.rem6;

      this.lt_rem7 = labeldata.rem7;

      this.lt_rem8 = labeldata.rem8;

      this.lt_cvd = labeldata.cvd;

      this.lt_exrate = labeldata.exrate;

      this.lt_cessrate = labeldata.cessrate;

      this.lt_hcrate = labeldata.hcrate;

      this.lt_cvdrate = labeldata.cvdrate;

      this.lt_exp_before = labeldata.exp_before;

      this.lt_exp_after = labeldata.exp_after;

      this.lt_total = labeldata.total;

      this.lt_b_tpt = labeldata.b_tpt;

      this.lt_sub_total = labeldata.sub_total;

      this.lt_party_code = labeldata.party_code;

      this.lt_tax_rate = labeldata.tax_rate;

      this.lt_exp10 = labeldata.exp10;

      this.lt_loose = labeldata.loose;

      this.lt_spec = labeldata.spec;

      this.lt_pckng = labeldata.pckng;

      this.lt_wf = labeldata.wf;

      this.lt_wwf = labeldata.wwf;

      this.lt_tx_from = labeldata.tx_from;

      this.lt_tx_upto = labeldata.tx_upto;

      this.lt_tx_type = labeldata.tx_type;

      this.lt_ssr = labeldata.ssr;

      this.lt_vat_post = labeldata.vat_post;

      this.lt_led_post = labeldata.led_post;

      this.lt_ex_post = labeldata.ex_post;

      this.lt_bill = labeldata.bill;

      this.lt_stk_post = labeldata.stk_post;

      this.lt_opening = labeldata.opening;

      this.lt_purr = labeldata.purr;

      this.lt_sale = labeldata.sale;

      this.lt_prdd = labeldata.prdd;

      this.lt_issuee = labeldata.issuee;

      this.lt_closing = labeldata.closing;

      this.lt_stk_code = labeldata.stk_code;

      this.lt_rateins = labeldata.rateins;

      this.lt_srates = labeldata.srates;

      this.lt_qpps = labeldata.qpps;

      this.lt_tcs = labeldata.tcs;

      this.lt_tcs1 = labeldata.tcs1;

      this.lt_tcs2 = labeldata.tcs2;

      this.lt_tcs_rate = labeldata.tcs_rate;

      this.lt_tcs1_rate = labeldata.tcs1_rate;

      this.lt_tcs2_rate = labeldata.tcs2_rate;

      this.lt_saletype = labeldata.saletype;

      this.lt_purtype = labeldata.purtype;

      this.lt_ahead = labeldata.ahead;

      this.lt_add1 = labeldata.add1;

      this.lt_add2 = labeldata.add2;

      this.lt_city = labeldata.city;

      this.lt_tin = labeldata.tin;

      this.lt_phone = labeldata.phone;

      this.lt_cash_name = labeldata.cash_name;

      this.lt_cash_add1 = labeldata.cash_add1;

      this.lt_cash_city = labeldata.cash_city;

      this.lt_tax0_sale = labeldata.tax0_sale;

      this.lt_tax1_sale = labeldata.tax1_sale;

      this.lt_p_vdate = labeldata.p_vdate;

      this.lt_p_vno = labeldata.p_vno;

      this.lt_p_valpha = labeldata.p_valpha;

      this.lt_p_counter = labeldata.p_counter;

      this.lt_unit_ex = labeldata.unit_ex;

      this.lt_unit_cs = labeldata.unit_cs;

      this.lt_unit_hs = labeldata.unit_hs;

      this.lt_unit_cv = labeldata.unit_cv;

      this.lt_cd1 = labeldata.cd1;

      this.lt_cd1_rate = labeldata.cd1_rate;

      this.lt_tariff = labeldata.tariff;

      this.lt_user_name = labeldata.user_name;

      this.lt_exp1_ex = labeldata.exp1_ex;

      this.lt_exp2_ex = labeldata.exp2_ex;

      this.lt_weights = labeldata.weights;

      this.lt_emistatus = labeldata.emistatus;

      this.lt_p_pageno = labeldata.p_pageno;

      this.lt_p_entry = labeldata.p_entry;

      this.lt_taxsurr = labeldata.taxsurr;

      this.lt_o_vdate = labeldata.o_vdate;

      this.lt_o_vno = labeldata.o_vno;

      this.lt_o_valpha = labeldata.o_valpha;

      this.lt_o_counter = labeldata.o_counter;

      this.lt_exp1_exr = labeldata.exp1_exr;

      this.lt_exp2_exr = labeldata.exp2_exr;

      this.lt_rem9 = labeldata.rem9;

      this.lt_rem10 = labeldata.rem10;
      this.lt_rem11 = labeldata.rem11;
      this.lt_exp01 = labeldata.exp01;
      this.lt_exp01code = labeldata.exp01code;
      this.lt_p_vbillno = labeldata.p_vbillno;
      this.lt_usname = labeldata.usname;

      this.lt_usrate = labeldata.usrate;

      this.lt_usvamt = labeldata.usvamt;

      this.lt_cardno = labeldata.cardno;

      this.lt_cashrec = labeldata.cashrec;

      this.lt_bank = labeldata.bank;

      this.lt_bcode = labeldata.bcode;

      this.lt_exp3_ex = labeldata.exp3_ex;
      this.lt_ctax = labeldata.ctax;
      this.lt_ctax_rate = labeldata.ctax_rate;
      this.lt_stax = labeldata.stax;
      this.lt_stax_rate = labeldata.stax_rate;
      this.lt_itax = labeldata.itax;
      this.lt_itax_rate=labeldata.itax_rate

      this.dv_itax_rate=orderdata.itax_rate
      this.dv_vdate = orderdata.vdate;
      this.dv_vtype = orderdata.vtype;
      this.dv_vno = orderdata.vno;
      this.dv_valpha = orderdata.valpha;
      this.dv_vcode = orderdata.vcode;

      this.dv_vacode = orderdata.vacode;

      this.dv_vamt = orderdata.vamt;

      this.dv_others = orderdata.others;

      this.dv_vamtcode = orderdata.vamtcode;

      this.dv_vdesc = orderdata.vdesc;

      this.dv_vbillno = orderdata.vbillno;

      this.dv_vbdate = orderdata.vbdate;

      this.dv_stype = orderdata.stype;

      this.dv_freight = orderdata.freight;

      this.dv_excise = orderdata.excise;

      this.dv_weight = orderdata.weight;

      this.dv_pkgs = orderdata.pkgs;

      this.dv_tax = orderdata.tax;

      this.dv_counter = orderdata.counter;

      this.dv_sdisc = orderdata.sdisc;

      this.dv_etype = orderdata.etype;

      this.dv_exfor = orderdata.exfor;

      this.dv_rate = orderdata.rate;

      this.dv_btype = orderdata.btype;

      this.dv_stkcode = orderdata.stkcode;

      this.dv_balance = orderdata.balance;

      this.dv_conv = orderdata.conv;

      this.dv_plarg = orderdata.plarg;

      this.dv_entno = orderdata.entno;

      this.dv_pb_wt = orderdata.pb_wt;

      this.dv_srno1 = orderdata.srno1;

      this.dv_freight1 = orderdata.freight1;

      this.dv_weighing = orderdata.weighing;

      this.dv_pla = orderdata.pla;

      this.dv_tds_frt = orderdata.tds_frt;

      this.dv_tdsrate = orderdata.tdsrate;

      this.dv_ppcode = orderdata.ppcode;

      this.dv_cess = orderdata.cess;

      this.dv_vbillno1 = orderdata.vbillno1;

      this.dv_vbdate1 = orderdata.vbdate1;

      this.dv_vamt1 = orderdata.vamt1;

      this.dv_duedate = orderdata.duedate;

      this.dv_cl_date = orderdata.cl_date;

      this.dv_emcode = orderdata.emcode;

      this.dv_mon = orderdata.mon;

      this.dv_vacode1 = orderdata.vacode1;

      this.dv_hcess = orderdata.hcess;

      this.dv_trpt = orderdata.trpt;

      this.dv_intial = orderdata.intial;

      this.dv_weight_ch = orderdata.weight_ch;

      this.dv_vamt_ch = orderdata.vamt_ch;

      this.dv_vdate_ch = orderdata.vdate_ch;

      this.dv_vacode_ch = orderdata.vacode_ch;

      this.dv_record = orderdata.record;

      this.dv_vhead_ch = orderdata.vhead_ch;

      this.dv_vhead = orderdata.vhead;

      this.dv_remarks = orderdata.remarks;

      this.dv_tick = orderdata.tick;

      this.dv_credit = orderdata.credit;

      this.dv_debit = orderdata.debit;

      this.dv_pcess = orderdata.pcess;

      this.dv_tcs_cess = orderdata.tcs_cess;

      this.dv_tcs_hcess = orderdata.tcs_hcess;

      this.dv_vat = orderdata.vat;

      this.dv_exp1 = orderdata.exp1;

      this.dv_exp2 = orderdata.exp2;

      this.dv_exp3 = orderdata.exp3;

      this.dv_exp4 = orderdata.exp4;

      this.dv_exp5 = orderdata.exp5;

      this.dv_exp6 = orderdata.exp6;

      this.dv_exp7 = orderdata.exp7;

      this.dv_exp8 = orderdata.exp8;

      this.dv_exp9 = orderdata.exp9;

      this.dv_exp1_rate = orderdata.exp1_rate;

      this.dv_exp2_rate = orderdata.exp2_rate;

      this.dv_exp3_rate = orderdata.exp3_rate;

      this.dv_exp4_rate = orderdata.exp4_rate;

      this.dv_exp5_rate = orderdata.exp5_rate;

      this.dv_exp6_rate = orderdata.exp6_rate;

      this.dv_exp7_rate = orderdata.exp7_rate;

      this.dv_exp8_rate = orderdata.exp8_rate;

      this.dv_exp9_rate = orderdata.exp9_rate;

      this.dv_exp10_rate = orderdata.exp10_rate;

      this.dv_rem1 = orderdata.rem1;

      this.dv_rem2 = orderdata.rem2;

      this.dv_rem3 = orderdata.rem3;

      this.dv_rem4 = orderdata.rem4;

      this.dv_transport = orderdata.transport;

      this.dv_order = orderdata.order;

      this.dv_order_date = orderdata.order_date;

      this.dv_agent = orderdata.agent;

      this.dv_broker = orderdata.broker;

      this.dv_cd_rate = orderdata.cd_rate;

      this.dv_cd = orderdata.cd;

      this.dv_sch_rate = orderdata.sch_rate;

      this.dv_scheme = orderdata.scheme;

      this.dv_srv_rate = orderdata.srv_rate;

      this.dv_srv_tax = orderdata.srv_tax;

      this.dv_gr = orderdata.gr;

      this.dv_inv_tm = orderdata.inv_tm;

      this.dv_rev_tm = orderdata.rev_tm;

      this.dv_inv_dt = orderdata.inv_dt;

      this.dv_rev_dt = orderdata.rev_dt;

      this.dv_rem5 = orderdata.rem5;

      this.dv_rem6 = orderdata.rem6;

      this.dv_rem7 = orderdata.rem7;

      this.dv_rem8 = orderdata.rem8;

      this.dv_cvd = orderdata.cvd;

      this.dv_exrate = orderdata.exrate;

      this.dv_cessrate = orderdata.cessrate;

      this.dv_hcrate = orderdata.hcrate;

      this.dv_cvdrate = orderdata.cvdrate;

      this.dv_exp_before = orderdata.exp_before;

      this.dv_exp_after = orderdata.exp_after;

      this.dv_total = orderdata.total;

      this.dv_b_tpt = orderdata.b_tpt;

      this.dv_sub_total = orderdata.sub_total;

      this.dv_party_code = orderdata.party_code;

      this.dv_tax_rate = orderdata.tax_rate;

      this.dv_exp10 = orderdata.exp10;

      this.dv_loose = orderdata.loose;

      this.dv_spec = orderdata.spec;

      this.dv_pckng = orderdata.pckng;

      this.dv_wf = orderdata.wf;

      this.dv_wwf = orderdata.wwf;

      this.dv_tx_from = orderdata.tx_from;

      this.dv_tx_upto = orderdata.tx_upto;

      this.dv_tx_type = orderdata.tx_type;

      this.dv_ssr = orderdata.ssr;

      this.dv_vat_post = orderdata.vat_post;

      this.dv_led_post = orderdata.led_post;

      this.dv_ex_post = orderdata.ex_post;

      this.dv_bill = orderdata.bill;

      this.dv_stk_post = orderdata.stk_post;

      this.dv_opening = orderdata.opening;

      this.dv_purr = orderdata.purr;

      this.dv_sale = orderdata.sale;

      this.dv_prdd = orderdata.prdd;

      this.dv_issuee = orderdata.issuee;

      this.dv_closing = orderdata.closing;

      this.dv_stk_code = orderdata.stk_code;

      this.dv_rateins = orderdata.rateins;

      this.dv_srates = orderdata.srates;

      this.dv_qpps = orderdata.qpps;

      this.dv_tcs = orderdata.tcs;

      this.dv_tcs1 = orderdata.tcs1;

      this.dv_tcs2 = orderdata.tcs2;

      this.dv_tcs_rate = orderdata.tcs_rate;

      this.dv_tcs1_rate = orderdata.tcs1_rate;

      this.dv_tcs2_rate = orderdata.tcs2_rate;

      this.dv_saletype = orderdata.saletype;

      this.dv_purtype = orderdata.purtype;

      this.dv_ahead = orderdata.ahead;

      this.dv_add1 = orderdata.add1;

      this.dv_add2 = orderdata.add2;

      this.dv_city = orderdata.city;

      this.dv_tin = orderdata.tin;

      this.dv_phone = orderdata.phone;

      this.dv_cash_name = orderdata.cash_name;

      this.dv_cash_add1 = orderdata.cash_add1;

      this.dv_cash_city = orderdata.cash_city;

      this.dv_tax0_sale = orderdata.tax0_sale;

      this.dv_tax1_sale = orderdata.tax1_sale;

      this.dv_p_vdate = orderdata.p_vdate;

      this.dv_p_vno = orderdata.p_vno;

      this.dv_p_valpha = orderdata.p_valpha;

      this.dv_p_counter = orderdata.p_counter;

      this.dv_unit_ex = orderdata.unit_ex;

      this.dv_unit_cs = orderdata.unit_cs;

      this.dv_unit_hs = orderdata.unit_hs;

      this.dv_unit_cv = orderdata.unit_cv;

      this.dv_cd1 = orderdata.cd1;

      this.dv_cd1_rate = orderdata.cd1_rate;

      this.dv_tariff = orderdata.tariff;

      this.dv_user_name = orderdata.user_name;

      this.dv_exp1_ex = orderdata.exp1_ex;

      this.dv_exp2_ex = orderdata.exp2_ex;

      this.dv_weights = orderdata.weights;

      this.dv_emistatus = orderdata.emistatus;

      this.dv_p_pageno = orderdata.p_pageno;

      this.dv_p_entry = orderdata.p_entry;

      this.dv_taxsurr = orderdata.taxsurr;

      this.dv_o_vdate = orderdata.o_vdate;

      this.dv_o_vno = orderdata.o_vno;

      this.dv_o_valpha = orderdata.o_valpha;

      this.dv_o_counter = orderdata.o_counter;

      this.dv_exp1_exr = orderdata.exp1_exr;

      this.dv_exp2_exr = orderdata.exp2_exr;

      this.dv_rem9 = orderdata.rem9;

      this.dv_rem10 = orderdata.rem10;
      this.dv_rem11 = orderdata.rem11;
      this.dv_exp01 = orderdata.exp01;
      this.dv_exp01code = orderdata.exp01code;
      this.dv_p_vbillno = orderdata.p_vbillno;
      this.dv_usname = orderdata.usname;

      this.dv_usrate = orderdata.usrate;

      this.dv_usvamt = orderdata.usvamt;

      this.dv_cardno = orderdata.cardno;

      this.dv_cashrec = orderdata.cashrec;

      this.dv_bank = orderdata.bank;

      this.dv_bcode = orderdata.bcode;

      this.dv_exp3_ex = orderdata.exp3_ex;
      this.dv_ctax = orderdata.ctax;
      this.dv_ctax_rate = orderdata.ctax_rate;
      this.dv_stax = orderdata.stax;
      this.dv_stax_rate = orderdata.stax_rate;
      this.dv_itax = orderdata.itax;
    },

    //Don't check on enter by Shkun sir
    // CheckInSP(){
    //   let that=this
    // this.acnamedata.forEach((item)=>{
    //   if(item.trim().toLowerCase()==this.AcName.trim().toLowerCase())
    //   {
    // that.DuplicateNotify()
    //    return false;
    // }
    // })

    // },
    CheckInSp() {
      let that = this;
      that.acnamedata.forEach(item => {
        if (item.trim().toLowerCase() == this.AcNam.trim().toLowerCase()) {
          that.DuplicateNotify();
          return false;
        }
      });
    },
    initializedefault() {
     this.ch_vdate= false

     this. ch_vtype= false

     this. ch_vno= false

     this. ch_valpha= false

     this. ch_vcode= false

     this. ch_vacode= false

     this. ch_vamt= false

     this. ch_others= false

     this. ch_vamtcode= false

     this. ch_vdesc= false

     this. ch_vbillno= false

     this. ch_vbdate= false

     this. ch_stype= false

     this. ch_freight= false

     this. ch_excise= false

     this. ch_weight= false

     this. ch_pkgs= false

     this. ch_tax= false

     this. ch_counter= false

     this. ch_sdisc= false

     this. ch_etype= false

     this. ch_exfor= false

     this. ch_rate= false

     this. ch_btype= false

     this. ch_stkcode= false

     this. ch_balance= false

     this. ch_conv= false

     this. ch_plarg= false

     this. ch_entno= false

     this. ch_pb_wt= false

     this. ch_srno1= false

     this. ch_freight1= false

     this. ch_weighing= false

     this. ch_pla= false

     this. ch_tds_frt= false

     this. ch_tdsrate= false

     this. ch_ppcode= false

     this. ch_cess= false

     this. ch_vbillno1= false

     this. ch_vbdate1= false

     this. ch_vamt1= false

     this. ch_duedate= false

     this. ch_cl_date= false

     this. ch_emcode= false

     this. ch_mon= false

     this. ch_vacode1= false

     this. ch_hcess= false

     this. ch_trpt= false

     this. ch_intial= false

     this. ch_weight_ch= false

     this. ch_vamt_ch= false

     this. ch_vdate_ch= false

     this. ch_vacode_ch= false

     this. ch_record= false

     this. ch_vhead_ch= false

     this. ch_vhead= false

     this. ch_remarks= false

     this. ch_tick= false

     this. ch_credit= false

     this. ch_debit= false

     this. ch_pcess= false

     this. ch_tcs_cess= false

     this. ch_tcs_hcess= false

     this. ch_vat= false

     this. ch_exp1= false

     this. ch_exp2= false

     this. ch_exp3= false

     this. ch_exp4= false

     this. ch_exp5= false

     this. ch_exp6= false

     this. ch_exp7= false

     this. ch_exp8= false

     this. ch_exp9= false

     this. ch_exp1_rate= false

     this. ch_exp2_rate= false

     this. ch_exp3_rate= false

     this. ch_exp4_rate= false

     this. ch_exp5_rate= false

     this. ch_exp6_rate= false

     this. ch_exp7_rate= false

     this. ch_exp8_rate= false

     this. ch_exp9_rate= false

     this. ch_exp10_rate= false

     this. ch_rem1= false

     this. ch_rem2= false

     this. ch_rem3= false

     this. ch_rem4= false

     this. ch_transport= false

     this. ch_order= false

     this. ch_order_date= false

     this. ch_agent= false

     this. ch_broker= false

     this. ch_cd_rate= false

     this. ch_cd= false

     this. ch_sch_rate= false

     this. ch_scheme= false

     this. ch_srv_rate= false

     this. ch_srv_tax= false

     this. ch_gr= false

     this. ch_inv_tm= false

     this. ch_rev_tm= false

     this. ch_inv_dt= false

     this. ch_rev_dt= false

     this. ch_rem5= false

     this. ch_rem6= false

     this. ch_rem7= false

     this. ch_rem8= false

     this. ch_cvd= false

     this. ch_exrate= false

     this. ch_cessrate= false

     this. ch_hcrate= false

     this. ch_cvdrate= false

     this. ch_exp_before= false

     this. ch_exp_after= false

     this. ch_total= false

     this. ch_b_tpt= false

     this. ch_sub_total= false

     this. ch_party_code= false

     this. ch_tax_rate= false

     this. ch_exp10= false

     this. ch_loose= false

     this. ch_spec= false

     this. ch_pckng= false

     this. ch_wf= false

     this. ch_wwf= false

     this. ch_tx_from= false

     this. ch_tx_upto= false

     this. ch_tx_type= false

     this. ch_ssr= false

     this. ch_vat_post= false

     this. ch_led_post= false

     this. ch_ex_post= false

     this. ch_bill= false

     this. ch_stk_post= false

     this. ch_opening= false

     this. ch_purr= false

     this. ch_sale= false

     this. ch_prdd= false

     this. ch_issuee= false

     this. ch_closing= false

     this. ch_stk_code= false

     this. ch_rateins= false

     this. ch_srates= false

     this. ch_qpps= false

     this. ch_tcs= false

     this. ch_tcs1= false

     this. ch_tcs2= false

     this. ch_tcs_rate= false

     this. ch_tcs1_rate= false

     this. ch_tcs2_rate= false

     this. ch_saletype= false

     this. ch_purtype= false

     this. ch_ahead= false

     this. ch_add1= false

     this. ch_add2= false

     this. ch_city= false

     this. ch_tin= false

     this. ch_phone= false

     this. ch_cash_name= false

     this. ch_cash_add1= false

     this. ch_cash_city= false

     this. ch_tax0_sale= false

     this. ch_tax1_sale= false

     this. ch_p_vdate= false

     this. ch_p_vno= false

     this. ch_p_valpha= false

     this. ch_p_counter= false

     this. ch_unit_ex= false

     this. ch_unit_cs= false

     this. ch_unit_hs= false

     this. ch_unit_cv= false

     this. ch_cd1= false

     this. ch_cd1_rate= false

     this. ch_tariff= false

     this. ch_user_name= false

     this. ch_exp1_ex= false

     this. ch_exp2_ex= false

     this. ch_weights= false

     this. ch_emistatus= false

     this. ch_p_pageno= false

     this. ch_p_entry= false

     this. ch_taxsurr= false

     this. ch_o_vdate= false

     this. ch_o_vno= false

     this. ch_o_valpha= false

     this. ch_o_counter= false

     this. ch_exp1_exr= false

     this. ch_exp2_exr= false

     this. ch_rem9= false
     this. ch_initial= false

     this. ch_rem10= false
     this. ch_rem11= false
     this. ch_exp01= false
     this. ch_exp01code= false
     this. ch_p_vbillno= false
     this. ch_usname= false

     this. ch_usrate= false

     this. ch_usvamt= false

     this. ch_cardno= false

     this. ch_cashrec= false

     this. ch_bank= false

     this. ch_bcode= false

     this. ch_exp3_ex= false
     this. ch_ctax= false
     this. ch_ctax_rate= false
     this. ch_stax= false
     this. ch_stax_rate= false
     this. ch_itax= false
     this. ch_itax_rate= false

     this. lt_vdate= "vdate"

     this. lt_vtype= "vtype"

     this. lt_vno= "vno"

     this. lt_valpha= "valpha"

     this. lt_vcode= "vcode"

     this. lt_vacode= "vacode"

     this. lt_vamt= "vamt"

     this. lt_others= "others"

     this. lt_vamtcode= "vamtcode"

     this. lt_vdesc= "vdesc"

     this. lt_vbillno= "vbillno"

     this. lt_vbdate= "vbdate"

     this. lt_stype= "stype"

     this. lt_freight= "freight"

     this. lt_excise= "excise"

     this. lt_weight= "weight"

     this. lt_pkgs= "pkgs"

     this. lt_tax= "tax"

     this. lt_counter= "counter"

     this. lt_sdisc= "sdisc"

     this. lt_etype= "etype"

     this. lt_exfor= "exfor"

     this. lt_rate= "rate"

     this. lt_btype= "btype"

     this. lt_stkcode= "stkcode"

     this. lt_balance= "balance"

     this. lt_conv= "conv"

     this. lt_plarg= "plarg"

     this. lt_entno= "entno"

     this. lt_pb_wt= "pb_wt"

     this. lt_srno1= "srno1"

     this. lt_freight1= "freight1"

     this. lt_weighing= "weighing"

     this. lt_pla= "pla"

     this. lt_tds_frt= "tds_frt"

     this. lt_tdsrate= "tdsrate"

     this. lt_ppcode= "ppcode"

     this. lt_cess= "cess"

     this. lt_vbillno1= "vbillno1"

     this. lt_vbdate1= "vbdate1"

     this. lt_vamt1= "vamt1"

     this. lt_duedate= "duedate"

     this. lt_cl_date= "cl_date"

     this. lt_emcode= "emcode"

     this. lt_mon= "mon"

     this. lt_vacode1= "vacode1"

     this. lt_hcess= "hcess"

     this. lt_trpt= "trpt"

     this. lt_intial= "intial"

     this. lt_weight_ch= "weight_ch"

     this. lt_vamt_ch= "vamt_ch"

     this. lt_vdate_ch= "vdate_ch"

     this. lt_vacode_ch= "vacode_ch"

     this. lt_record= "record"

     this. lt_vhead_ch= "vhead_ch"

     this. lt_vhead= "vhead"

     this. lt_remarks= "remarks"

     this. lt_tick= "tick"

     this. lt_credit= "credit"

     this. lt_debit= "debit"

     this. lt_pcess= "pcess"

     this. lt_tcs_cess= "tcs_cess"

     this. lt_tcs_hcess= "tcs_hcess"

     this. lt_vat= "vat"

     this. lt_exp1= "exp1"

     this. lt_exp2= "exp2"

     this. lt_exp3= "exp3"

     this. lt_exp4= "exp4"

     this. lt_exp5= "exp5"

     this. lt_exp6= "exp6"

     this. lt_exp7= "exp7"

     this. lt_exp8= "exp8"

     this. lt_exp9= "exp9"

     this. lt_exp1_rate= "exp1_rate"

     this. lt_exp2_rate= "exp2_rate"

     this. lt_exp3_rate= "exp3_rate"

     this. lt_exp4_rate= "exp4_rate"

     this. lt_exp5_rate= "exp5_rate"

     this. lt_exp6_rate= "exp6_rate"

     this. lt_exp7_rate= "exp7_rate"

     this. lt_exp8_rate= "exp8_rate"

     this. lt_exp9_rate= "exp9_rate"

     this. lt_exp10_rate= "exp10_rate"

     this. lt_rem1= "rem1"

     this. lt_rem2= "rem2"

     this. lt_rem3= "rem3"

     this. lt_rem4= "rem4"

     this. lt_transport= "transport"

     this. lt_order= "order"

     this. lt_order_date= "order_date"

     this. lt_agent= "agent"

     this. lt_broker= "broker"

     this. lt_cd_rate= "cd_rate"

     this. lt_cd= "cd"

     this. lt_sch_rate= "sch_rate"

     this. lt_scheme= "scheme"

     this. lt_srv_rate= "srv_rate"

     this. lt_srv_tax= "srv_tax"

     this. lt_gr= "gr"

     this. lt_inv_tm= "inv_tm"

     this. lt_rev_tm= "rev_tm"

     this. lt_inv_dt= "inv_dt"

     this. lt_rev_dt= "rev_dt"

     this. lt_rem5= "rem5"

     this. lt_rem6= "rem6"

     this. lt_rem7= "rem7"

     this. lt_rem8= "rem8"

     this. lt_cvd= "cvd"

     this. lt_exrate= "exrate"

     this. lt_cessrate= "cessrate"

     this. lt_hcrate= "hcrate"

     this. lt_cvdrate= "cvdrate"

     this. lt_exp_before= "exp_before"

     this. lt_exp_after= "exp_after"

     this. lt_total= "total"

     this. lt_b_tpt= "b_tpt"

     this. lt_sub_total= "sub_total"

     this. lt_party_code= "party_code"

     this. lt_tax_rate= "tax_rate"

     this. lt_exp10= "exp10"

     this. lt_loose= "loose"

     this. lt_spec= "spec"

     this. lt_pckng= "pckng"

     this. lt_wf= "wf"

     this. lt_wwf= "wwf"

     this. lt_tx_from= "tx_from"

     this. lt_tx_upto= "tx_upto"

     this. lt_tx_type= "tx_type"

     this. lt_ssr= "ssr"

     this. lt_vat_post= "vat_post"

     this. lt_led_post= "led_post"

     this. lt_ex_post= "ex_post"

     this. lt_bill= "bill"

     this. lt_stk_post= "stk_post"

     this. lt_opening= "opening"

     this. lt_purr= "purr"

     this. lt_sale= "sale"

     this. lt_prdd= "prdd"

     this. lt_issuee= "issuee"

     this. lt_closing= "closing"

     this. lt_stk_code= "stk_code"

     this. lt_rateins= "rateins"

     this. lt_srates= "srates"

     this. lt_qpps= "qpps"

     this. lt_tcs= "tcs"

     this. lt_tcs1= "tcs1"

     this. lt_tcs2= "tcs2"

     this. lt_tcs_rate= "tcs_rate"

     this. lt_tcs1_rate= "tcs1_rate"

     this. lt_tcs2_rate= "tcs2_rate"

     this. lt_saletype= "saletype"

     this. lt_purtype= "purtype"

     this. lt_ahead= "ahead"

     this. lt_add1= "add1"

     this. lt_add2= "add2"

     this. lt_city= "city"

     this. lt_tin= "tin"

     this. lt_phone= "phone"

     this. lt_cash_name= "cash_name"

     this. lt_cash_add1= "cash_add1"

     this. lt_cash_city= "cash_city"

     this. lt_tax0_sale= "tax0_sale"

     this. lt_tax1_sale= "tax1_sale"

     this. lt_p_vdate= "p_vdate"

     this. lt_p_vno= "p_vno"

     this. lt_p_valpha= "p_valpha"

     this. lt_p_counter= "p_counter"

     this. lt_unit_ex= "unit_ex"

     this. lt_unit_cs= "unit_cs"

     this. lt_unit_hs= "unit_hs"

     this. lt_unit_cv= "unit_cv"

     this. lt_cd1= "cd1"

     this. lt_cd1_rate= "cd1_rate"

     this. lt_tariff= "tariff"

     this. lt_user_name= "user_name"

     this. lt_exp1_ex= "exp1_ex"

     this. lt_exp2_ex= "exp2_ex"

     this. lt_weights= "weights"

     this. lt_emistatus= "emistatus"

     this. lt_p_pageno= "p_pageno"

     this. lt_p_entry= "p_entry"

     this. lt_taxsurr= "taxsurr"

     this. lt_o_vdate= "o_vdate"

     this. lt_o_vno= "o_vno"

     this. lt_o_valpha= "o_valpha"

     this. lt_o_counter= "o_counter"

     this. lt_exp1_exr= "exp1_exr"

     this. lt_exp2_exr= "exp2_exr"

     this. lt_rem9= "rem9"

     this. lt_rem10= "rem10"
     this. lt_rem11= "rem11"
     this. lt_exp01= "exp01"
     this. lt_exp01code= "exp01code"
     this. lt_p_vbillno= "p_vbillno"
     this. lt_usname= "usname"
     this. lt_initial= "initial"

     this. lt_usrate= "usrate"

     this. lt_usvamt= "usvamt"

     this. lt_cardno= "cardno"

     this. lt_cashrec= "cashrec"

     this. lt_bank= "bank"

     this. lt_bcode= "bcode"

     this. lt_exp3_ex= "exp3_ex"
     this. lt_ctax= "ctax"
     this. lt_ctax_rate= "ctax_rate"
     this. lt_stax= "stax"
     this. lt_stax_rate= "stax_rate"
     this. lt_itax= "itax"
     this. lt_itax_rate= "itax_rate"

     //=DVdeclaration

     this. dv_vacode= 1
     this. dv_vdate= 2
     this. dv_vcode= 3
     this. dv_vamt= 4
     this. dv_others= 5
     this. dv_vdesc= 6
     this. dv_stype= 7
     this. dv_freight= 8
     this. dv_weight= 9

     this. dv_pkgs= 10

     this. dv_tax= 11

     this. dv_sdisc= 12

     this. dv_etype= 13

     this. dv_exfor= 14

     this. dv_rate= 15

     this. dv_stkcode= 16

     this. dv_balance= 17

     this. dv_conv= 18

     this. dv_plarg= 19

     this. dv_entno= 20

     this. dv_pb_wt= 21

     this. dv_freight1= 22

     this. dv_weighing= 23

     this. dv_pla= 24

     this. dv_tds_frt= 25

     this. dv_tdsrate= 26

     this. dv_cess= 27

     this. dv_vbillno1= 28

     this. dv_vbdate1= 29

     this. dv_vamt1= 30

     this. dv_duedate= 31

     this. dv_cl_date= 32

     this. dv_vacode1= 33

     this. dv_hcess= 34

     this. dv_trpt= 35

     this. dv_weight_ch= 36

     this. dv_vamt_ch= 37

     this. dv_vdate_ch= 38

     this. dv_vhead= 39

     this. dv_credit= 40

     this. dv_pcess= 41

     this. dv_tcs_cess= 42

     this. dv_tcs_hcess= 43

     this. dv_exp1= 44

     this. dv_exp2= 45

     this. dv_exp3= 46

     this. dv_exp4= 47

     this. dv_exp5= 48

     this. dv_exp6= 49

     this. dv_exp7= 50

     this. dv_exp8= 51

     this. dv_exp9= 52
     this. dv_exp1_rate= 53

     this. dv_exp2_rate= 54

     this. dv_exp3_rate= 55

     this. dv_exp4_rate= 56

     this. dv_exp5_rate= 57

     this. dv_exp6_rate= 58

     this. dv_exp7_rate= 59

     this. dv_exp8_rate= 60

     this. dv_exp9_rate= 61

     this. dv_exp10_rate= 62
     this. dv_rem1= 63
     this. dv_rem2= 64
     this. dv_rem3= 65
     this. dv_rem4= 66

     this. dv_transport= 67

     this. dv_order= 68

     this. dv_order_date= 69

     this. dv_agent= 70

     this. dv_broker= 71

     this. dv_cd_rate= 72
     this. dv_cd= 73

     this. dv_sch_rate= 74

     this. dv_scheme= 75

     this. dv_srv_rate= 76

     this. dv_srv_tax= 77

     this. dv_inv_tm= 78

     this. dv_rev_dt= 79

     this. dv_rem5= 80

     this. dv_rem6= 81

     this. dv_rem7= 82

     this. dv_rem8= 83

     this. dv_cvd= 84

     this. dv_exrate= 85

     this. dv_cessrate= 86

     this. dv_hcrate= 87

     this. dv_cvdrate= 88

     this. dv_exp_before= 89

     this. dv_exp_after= 90

     this. dv_tax_rate= 91

     this. dv_exp10= 92

     this. dv_loose= 93
     this. dv_spec= 94

     this. dv_pckng= 95
     this. dv_wf= 96

     this. dv_wwf= 97

     this. dv_bill= 98

     this. dv_stk_code= 99

     this. dv_rateins= 100

     this. dv_srates= 101

     this. dv_qpps= 102

     this. dv_tcs= 103

     this. dv_tcs1= 104

     this. dv_tcs2= 105

     this. dv_tcs_rate= 106

     this. dv_tcs1_rate= 107

     this. dv_tcs2_rate= 108

     this. dv_saletype= 109

     this. dv_unit_ex= 110

     this. dv_unit_cs= 111

     this. dv_unit_hs= 112

     this. dv_unit_cv= 113

     this. dv_cd1= 114

     this. dv_cd1_rate= 115

     this. dv_tariff= 116

     this. dv_exp1_ex= 117

     this. dv_exp2_ex= 118

     this. dv_weights= 119

     this. dv_exp1_exr= 120

     this. dv_exp2_exr= 121

     this. dv_rem9= 122

     this. dv_rem10= 123

     this. dv_exp01= 124

     this. dv_exp01code= 125

     this. dv_p_vbillno= 126

     this. dv_usname= 127

     this. dv_usrate= 128

     this. dv_usvamt= 129

     this. dv_cardno= 130

     this. dv_ctax= 131

     this. dv_ctax_rate= 132

     this. dv_stax= 133

     this. dv_stax_rate= 134

     this. dv_itax= 135

     this. dv_itax_rate= 136

     this. dv_valpha= 137

     this. dv_vno= 138

     this. dv_vtype= 139

     this. dv_vamtcode= 140

     this. dv_vbillno= 141

     this. dv_vbdate= 142

     this. dv_excise= 143

     this. dv_counter= 144

     this. dv_btype= 145

     this. dv_srno1= 146

     this. dv_ppcode= 147

     this. dv_emcode= 148
     this. dv_mon= 149

     this. dv_initial= 150

     this. dv_vacode_ch= 151

     this. dv_record= 152

     this. dv_vhead_ch= 153

     this. dv_remarks= 154

     this. dv_tick= 155

     this. dv_debit= 156

     this. dv_vat= 157
     this. dv_gr= 158

     this. dv_rev_tm= 159

     this. dv_inv_dt= 160

     this. dv_total= 161

     this. dv_b_tpt= 162

     this. dv_sub_total= 163

     this. dv_party_code= 164

     this. dv_tx_from= 165

     this. dv_tx_upto= 166

     this. dv_tx_type= 167

     this. dv_ssr= 168

     this. dv_vat_post= 169

     this. dv_led_post= 170

     this. dv_ex_post= 171

     this. dv_stk_post= 172

     this. dv_opening= 173

     this. dv_purr= 174

     this. dv_sale= 175

     this. dv_prdd= 176

     this. dv_issuee= 177

     this. dv_closing= 178

     this. dv_purtype= 179

     this. dv_ahead= 180

     this. dv_add1= 181

     this. dv_add2= 182

     this. dv_city= 183
     this. dv_tin= 184

     this. dv_phone= 185

     this. dv_cash_name= 186

     this. dv_cash_add1= 187

     this. dv_cash_city= 188

     this. dv_tax0_sale= 189

     this. dv_tax1_sale= 190

     this. dv_p_vdate= 191

     this. dv_p_vno= 192

     this. dv_p_valpha= 193

     this. dv_p_counter= 194

     this. dv_user_name= 195

     this. dv_emistatus= 196

     this. dv_p_pageno= 197

     this. dv_p_entry= 198

     this. dv_taxsurr= 199

     this. dv_o_vdate= 200

     this. dv_o_vno= 201

     this. dv_o_valpha= 202

     this. dv_o_counter= 203

     this. dv_rem11= 204

     this. dv_cashrec= 205

     this. dv_bank= 206

     this. dv_bcode= 207

     this. dv_exp3_ex= 208

      //=idthDeclarations

     this. wi_vacode= 0
     this. wi_vdate= 0
     this. wi_vcode= 0

     this. wi_vamt= 0
     this. wi_others= 0
     this. wi_vdesc= 0
     this. wi_stype= 0
     this. wi_freight= 0
     this. wi_weight= 0
     this. wi_pkgs= 0

     this. wi_tax= 0

     this. wi_sdisc= 0

     this. wi_etype= 0

     this. wi_exfor= 0

     this. wi_rate= 0

     this. wi_stkcode= 0

     this. wi_balance= 0

     this. wi_conv= 0

     this. wi_plarg= 0

     this. wi_entno= 0

     this. wi_pb_wt= 0

     this. wi_freight1= 0

     this. wi_weighing= 0

     this. wi_pla= 0

     this. wi_tds_frt= 0

     this. wi_tdsrate= 0

     this. wi_cess= 0

     this. wi_vbillno1= 0

     this. wi_vbdate1= 0

     this. wi_vamt1= 0

     this. wi_duedate= 0

     this. wi_cl_date= 0

     this. wi_vacode1= 0

     this. wi_hcess= 0

     this. wi_trpt= 0

     this. wi_weight_ch= 0

     this. wi_vamt_ch= 0

     this. wi_vdate_ch= 0

     this. wi_vhead= 0

     this. wi_credit= 0

     this. wi_pcess= 0

     this. wi_tcs_cess= 0

     this. wi_tcs_hcess= 0

     this. wi_exp1= 0

     this. wi_exp2= 0

     this. wi_exp3= 0

     this. wi_exp4= 0

     this. wi_exp5= 0

     this. wi_exp6= 0

     this. wi_exp7= 0

     this. wi_exp8= 0

     this. wi_exp9= 0
     this. wi_exp1_rate= 0

     this. wi_exp2_rate= 0

     this. wi_exp3_rate= 0

     this. wi_exp4_rate= 0

     this. wi_exp5_rate= 0

     this. wi_exp6_rate= 0

     this. wi_exp7_rate= 0

     this. wi_exp8_rate= 0

     this. wi_exp9_rate= 0

     this. wi_exp10_rate= 0
     this. wi_rem1= 0
     this. wi_rem2= 0
     this. wi_rem3= 0
     this. wi_rem4= 0

     this. wi_transport= 0

     this. wi_order= 0

     this. wi_order_date= 0

     this. wi_agent= 0

     this. wi_broker= 0

     this. wi_cd_rate= 0
     this. wi_cd= 0

     this. wi_sch_rate= 0

     this. wi_scheme= 0

     this. wi_srv_rate= 0

     this. wi_srv_tax= 0

     this. wi_inv_tm= 0

     this. wi_rev_dt= 0

     this. wi_rem5= 0

     this. wi_rem6= 0

     this. wi_rem7= 0

     this. wi_rem8= 0

     this. wi_cvd= 0

     this. wi_exrate= 0

     this. wi_cessrate= 0

     this. wi_hcrate= 0

     this. wi_cvdrate= 0

     this. wi_exp_before= 0

     this. wi_exp_after= 0

     this. wi_tax_rate= 0

     this. wi_exp10= 0

     this. wi_loose= 0
     this. wi_spec= 0

     this. wi_pckng= 0
     this. wi_wf= 0

     this. wi_wwf= 0

     this. wi_bill= 0

     this. wi_stk_code= 0

     this. wi_rateins= 0

     this. wi_srates= 0

     this. wi_qpps= 0

     this. wi_tcs= 0

     this. wi_tcs1= 0

     this. wi_tcs2= 0

     this. wi_tcs_rate= 0

     this. wi_tcs1_rate= 0

     this. wi_tcs2_rate= 0

     this. wi_saletype= 0

     this. wi_unit_ex= 0

     this. wi_unit_cs= 0

     this. wi_unit_hs= 0

     this. wi_unit_cv= 0

     this. wi_cd1= 0

     this. wi_cd1_rate= 0

     this. wi_tariff= 0

     this. wi_exp1_ex= 0

     this. wi_exp2_ex= 0

     this. wi_weights= 0

     this. wi_exp1_exr= 0

     this. wi_exp2_exr= 0

     this. wi_rem9= 0

     this. wi_rem10= 0

     this. wi_exp01= 0

     this. wi_exp01code= 0

     this. wi_p_vbillno= 0

     this. wi_usname= 0

     this. wi_usrate= 0

     this. wi_usvamt= 0

     this. wi_cardno= 0

     this. wi_ctax= 0

     this. wi_ctax_rate= 0

     this. wi_stax= 0

     this. wi_stax_rate= 0

     this. wi_itax= 0

     this. wi_itax_rate= 0

     this. wi_valpha= 0

     this. wi_vno= 0

     this. wi_vtype= 0

     this. wi_vamtcode= 0

     this. wi_vbillno= 0

     this. wi_vbdate= 0

     this. wi_excise= 0

     this. wi_counter= 0

     this. wi_btype= 0

     this. wi_srno1= 0

     this. wi_ppcode= 0

     this. wi_emcode= 0
     this. wi_mon= 0

     this. wi_initial= 0

     this. wi_vacode_ch= 0

     this. wi_record= 0

     this. wi_vhead_ch= 0

     this. wi_remarks= 0

     this. wi_tick= 0

     this. wi_debit= 0

     this. wi_vat= 0
     this. wi_gr= 0

     this. wi_rev_tm= 0

     this. wi_inv_dt= 0

     this. wi_total= 0

     this. wi_b_tpt= 0

     this. wi_sub_total= 0

     this. wi_party_code= 0

     this. wi_tx_from= 0

     this. wi_tx_upto= 0

     this. wi_tx_type= 0

     this. wi_ssr= 0

     this. wi_vat_post= 0

     this. wi_led_post= 0

     this. wi_ex_post= 0

     this. wi_stk_post= 0

     this. wi_opening= 0

     this. wi_purr= 0

     this. wi_sale= 0

     this. wi_prdd= 0

     this. wi_issuee= 0

     this. wi_closing= 0

     this. wi_purtype= 0

     this. wi_ahead= 0

     this. wi_add1= 0

     this. wi_add2= 0

     this. wi_city= 0
     this. wi_tin= 0

     this. wi_phone= 0

     this. wi_cash_name= 0

     this. wi_cash_add1= 0

     this. wi_cash_city= 0

     this. wi_tax0_sale= 0

     this. wi_tax1_sale= 0

     this. wi_p_vdate= 0

     this. wi_p_vno= 0

     this. wi_p_valpha= 0

     this. wi_p_counter= 0

     this. wi_user_name= 0

     this. wi_emistatus= 0

     this. wi_p_pageno= 0

     this. wi_p_entry= 0

     this. wi_taxsurr= 0

     this. wi_o_vdate= 0

     this. wi_o_vno= 0

     this. wi_o_valpha= 0

     this. wi_o_counter= 0

     this. wi_rem11= 0

     this. wi_cashrec= 0

     this. wi_bank= 0

     this. wi_bcode= 0

     this. wi_exp3_ex= 0

    },

    SaveLedgerSetup() {
      this.setupForm = false;
    },
    buttondis_true() {
      if (this.ch_accode == true) this.buttondis_AcCode = true;

      if (this.ch_acname == true) this.buttonen_AcName = false;

      if (this.ch_address == true) this.buttondis_Address1 = true;

      if (this.ch_bankacname == true) this.buttondis_BankACName = true;

      if (this.ch_state == true) this.buttondis_State = true;

      if (this.ch_address == true) this.buttondis_Address2 = true;

      if (this.ch_aadhaarno == true) this.buttondis_AadhaarNo = true;

      if (this.ch_ifsccode == true) this.buttondis_IFSCCode = true;

      if (this.ch_city == true) this.buttonen_City = false;

      if (this.ch_division == true) this.buttondis_Division = true;

      if (this.ch_pincode == true) this.buttondis_PinCode = true;

      if (this.ch_collectorate == true) this.buttondis_Collectorate = true;

      if (this.ch_distt == true) this.buttonen_Distt = false;

      if (this.ch_gstno == true) this.buttondis_DGSTNo = true;

      if (this.ch_saccode == true) this.buttondis_SACCode = true;

      if (this.ch_distance == true) this.buttondis_Distance = true;

      if (this.ch_openingbaldr == true) this.buttondis_OpeningBalanceDr = true;

      if (this.ch_contactperson == true) this.buttondis_ContactPerson = true;

      if (this.ch_openingbalcr == true) this.buttondis_OpeningBalanceCr = true;

      if (this.ch_inttdepcrate == true) this.buttondis_InttDepcRate = true;

      if (this.ch_contactno == true) this.buttondis_ContactNo = true;

      if (this.ch_tdsrate == true) this.buttondis_TDSRate = true;

      if (this.ch_email == true) this.buttonen_comboemail = false;

      if (this.ch_tgstshare == true) this.buttondis_TGSTShare = true;

      if (this.ch_area == true) this.buttonen_comboarea = false;

      if (this.ch_agent == true) this.buttonen_combogroup = false;

      if (this.ch_quantity == true) this.buttondis_Quantitiy = true;

      this.buttondis_v = true;

      if (this.ch_bankacno == true) this.buttondis_BankACNo = true;

      if (this.ch_pan == true) this.buttondis_PAN = true;

      if (this.ch_tdsacno == true) this.buttondis_TDSAcNo = true;

      if (this.ch_composition == true) this.buttondis_CompositionYN = true;

      if (this.ch_works == true) this.buttonen_Works = false;

      if (this.ch_nameandaddress == true) this.buttondis_NameAddress1 = true;

      if (this.ch_nameandaddress == true) this.buttondis_NameAddress2 = true;
    },
    buttondis_false() {
      if (this.ch_accode == true) this.buttondis_AcCode = false;

      if (this.ch_acname == true) this.buttonen_AcName = true;

      if (this.ch_address == true) this.buttondis_Address1 = false;

      if (this.ch_bankacname == true) this.buttondis_BankACName = false;

      if (this.ch_address == true) this.buttondis_Address2 = false;

      if (this.ch_aadhaarno == true) this.buttondis_AadhaarNo = false;

      if (this.ch_state == true) this.buttondis_State = false;

      if (this.ch_ifsccode == true) this.buttondis_IFSCCode = false;

      if (this.ch_city == true) this.buttonen_City = true;

      if (this.ch_division == true) this.buttondis_Division = false;

      if (this.ch_pincode == true) this.buttondis_PinCode = false;

      if (this.ch_collectorate == true) this.buttondis_Collectorate = false;

      if (this.ch_distt == true) this.buttonen_Distt = true;

      if (this.ch_gstno == true) this.buttondis_DGSTNo = false;

      if (this.ch_saccode == true) this.buttondis_SACCode = false;

      if (this.ch_distance == true) this.buttondis_Distance = false;

      if (this.ch_openingbaldr == true) this.buttondis_OpeningBalanceDr = false;

      if (this.ch_contactperson == true) this.buttondis_ContactPerson = false;

      if (this.ch_openingbalcr == true) this.buttondis_OpeningBalanceCr = false;

      if (this.ch_inttdepcrate == true) this.buttondis_InttDepcRate = false;

      if (this.ch_contactno == true) this.buttondis_ContactNo = false;

      if (this.ch_tdsrate == true) this.buttondis_TDSRate = false;

      if (this.ch_email == true) this.buttonen_comboemail = true;

      if (this.ch_tgstshare == true) this.buttondis_TGSTShare = false;

      if (this.ch_area == true) this.buttonen_comboarea = true;

      if (this.ch_agent == true) this.buttonen_combogroup = true;

      if (this.ch_quantity == true) this.buttondis_Quantitiy = false;

      this.buttondis_v = false;

      if (this.ch_bankacno == true) this.buttondis_BankACNo = false;

      if (this.ch_pan == true) this.buttondis_PAN = false;

      if (this.ch_tdsacno == true) this.buttondis_TDSAcNo = false;

      if (this.ch_composition == true) this.buttondis_CompositionYN = false;

      if (this.ch_works == true) this.buttonen_Works = true;

      if (this.ch_nameandaddress == true) this.buttondis_NameAddress1 = false;

      if (this.ch_nameandaddress == true) this.buttondis_NameAddress2 = false;
    },
    showSetupForm() {
      this.setupForm = true;
    },
    search() {
      this.shortfunctionsecond("popupActive2", "true", "comp");
    },
    crdrcheck() {
      if (this.OpeningBalanceDr != "" && this.OpeningBalanceDr + "" != "0") {
        this.buttondis_OpeningBalanceCr = true;
      } else if (
        this.OpeningBalanceCr != "" &&
        this.OpeningBalanceCr + "" != "0"
      ) {
        this.buttondis_OpeningBalanceDr = true;
      } else {
        this.buttondis_OpeningBalanceCr = false;
        this.buttondis_OpeningBalanceDr = false;
      }
    },

    getsearchdata(ind) {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        companyname: companyName,
        requiredIndex: ind,
        note:"purchase"
      };
      // //alert(JSON.stringify(n));
      axios
        .post("/transactions/getSaleSeries", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            this.Ahead = resp.Ahead;
            this.AcNam = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
            this.State = resp.state;
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.comboemail = resp.MEmailIDArea;
            this.comboarea = resp.Area;
            this.TGSTShare = resp.TGSTShare;
            this.combogroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });
    },
    getFirst() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        companyname: companyName,
        requiredIndex: 0,
        note:"purchase"
      };
      // //alert(JSON.stringify(n));
      axios
        .post("/transactions/getSaleSeries", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.AcName == "out of bounds" || resp.AcName == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {

 var keys = [];
            var values = [];
            let datas = resp.data.data;
            var columndata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              keys.push(Object.keys(item)[0]);
              values.push(item[Object.keys(item)[0]]);

              columndata[keys[index]] = values[index];
              //}
            });

            var valuesorder = [];

            var orderdata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{
              valuesorder.push(item[Object.keys(item)[1]]);

              orderdata[keys[index]] = parseInt(valuesorder[index]) + 1;
              //}
            });

          
            var valueslabel = [];

            var labeldata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              
              valueslabel.push(item[Object.keys(item)[2]]);

              labeldata[keys[index]] = valueslabel[index];
              //}
            });

            
            var valueswidth = [];

            var widthdata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              valueswidth.push(item[Object.keys(item)[3]]);

              widthdata[keys[index]] = valueswidth[index];
              //}
            });

            this.setSetupData(columndata, orderdata, labeldata,widthdata);

            // //alert("do something with" + resp.index)
            this.Ahead = resp.Ahead;
            this.AcNam = resp.AcName;
            this.Address1 = resp.Address1;
            this.RCNo = resp.RCNo;
            this.Address2 = resp.Address2;
            this.BankACName = resp.BankACName;
            this.City = resp.City;
            this.Division = resp.Division;
            this.PinCode = resp.PinCode;
            this.Collectorate = resp.Collectorate;
            this.Distt = resp.Distt;
            this.State = resp.state;
            this.DGSTNo = resp.DGSTNo;
            this.SACCode = resp.SACCode;
            this.Distance = resp.Distance;
            this.OpeningBalanceDr = resp.OpeningBalanceDr;
            this.ContactPerson = resp.ContactPerson;
            this.OpeningBalanceCr = resp.OpeningBalanceCr;
            this.InttDepcRate = resp.InttDepcRate;
            this.ContactNo = resp.ContactNo;
            this.TDSRate = resp.TDSRate;
            this.comboemail = resp.MEmailIDArea;
            this.comboarea = resp.Area;
            this.TGSTShare = resp.TGSTShare;
            this.combogroup = resp.AgentGroup;
            this.Quantitiy = resp.Quantitiy;
            this.PAN = resp.PAN;
            this.AadhaarNo = resp.AadhaarNo;
            this.TDSAcNo = resp.TDSAcNo;
            this.CompositionYN = resp.CompositionYN;
            this.Works = resp.Works;
            this.NameAddress1 = resp.NameAddress1;
            this.NameAddress2 = resp.NameAddress2;
            this.bufferIndex = resp.index;

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },

    getLast() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      var n = {
        companyname: companyName,
        requiredIndex: -999,
        note:"purchase"
      };
      // //alert(JSON.stringify(n));
      axios
        .post("/transactions/getSaleSeries", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          alert("yaar");
          alert(resp);
          resp = JSON.parse(resp);
          var keys = [];
          var values = [];
          let datas = resp.data.data;
          var columndata = {};
          datas.forEach(function(item, index) {
            // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
            //  if(columndata[key] == true)
            //{

            keys.push(Object.keys(item)[0]);
            values.push(item[Object.keys(item)[0]]);

            columndata[keys[index]] = values[index];
            //}
          });

          var valuesorder = [];

          var orderdata = {};
          datas.forEach(function(item, index) {
            // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
            //  if(columndata[key] == true)
            //{

            valuesorder.push(item[Object.keys(item)[1]]);

            orderdata[keys[index]] = parseInt(valuesorder[index]) + 1;
            //}
          });

         var valueslabel = [];

            var labeldata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              
              valueslabel.push(item[Object.keys(item)[2]]);

              labeldata[keys[index]] = valueslabel[index];
              //}
            });

            
            var valueswidth = [];

            var widthdata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              valueswidth.push(item[Object.keys(item)[3]]);

              widthdata[keys[index]] = valueswidth[index];
              //}
            });


          if (resp.Ahead == "out of bounds" || resp.Ahead == "no data") {
            // //alert("do nothing: " + resp.AcName);
          } else {
            // //alert("do something with" + resp.index)

            (this.Ahead = resp.Ahead),
              (this.Form_type = resp.Form_type),
              (this.Led_post = resp.Led_post),
              (this.Vat_post = resp.Vat_post),
              (this.Ex_post = resp.Ex_post),
              (this.Serial = resp.Serial),
              (this.Short_name = resp.Short_name),
              (this.Stk_post = resp.Stk_post),
              (this.Form_rtype = resp.Form_rtype),
              (this.Rep_name = resp.Rep_name),
              (this.Bill_no_h = resp.Bill_no_h),
              (this.Salef3 = resp.Salef3),
              (this.Tick = resp.Tick),
              (this.Vacode = resp.Vacode),
              (this.Rep_gst = resp.Rep_gst),
              (this.cont = resp.cont),
              (this.bufferIndex = resp.index);
            this.setSetupData(columndata, orderdata, labeldata,widthdata);
            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },

    onspdatareceived(value) {
      //  alert(value[0]);
      if (this.currentfield == "comboarea") {
        this.groupdata = value;
        this.shortfunctionsecond("areais");
      } else if (this.currentfield == "comboemail") {
        this.emaildata = value;
        this.shortfunctionsecond("emaildata");
      } else if (this.currentfield == "City") {
        this.citydata = value;
        this.shortfunctionsecond("citydata");
      } else if (this.currentfield == "AcName") {
        this.acnamedata = value;
        this.shortfunctionsecond("acnamedata");
      } else if (this.currentfield == "Distt") {
        this.disttdata = value;
        this.shortfunctionsecond("disttdata");
      } else if (this.currentfield == "Works") {
        this.worksdata = value;

        this.shortfunctionsecond("worksdata");
      } else if (this.currentfield == "combogroup") {
        this.groupdata = value;
        this.shortfunctionsecond("groupdata");
      }
    },
    longfunctionfirst(t) {
      return new Promise(resolve => {
        if (t == "popupActiveNarration") {
          this.modalOpenNarration = true;
          this.popupActiveNarration = true;
          resolve("resolved");
        } else if (t == "popupActive5") {
          this.popupActive5 = true;
          //  alert(this.jony);
          resolve("resolved");
        } else if (t == "popupActive3") {
          this.popupActive3 = true;

          resolve("resolved");
        } else if (t == "areais") {
          setTimeout(() => resolve("done!"), 500);
        } else if (t == "popupActive2") {
          this.popupActive2 = true;

          resolve("resolved");
        } else if (t == "dateprevnext") {
          setTimeout(() => resolve("done!"), 500);
        } else if (t == "modifyLedger") {
          this.popupActiveModifyLedger = true;
          resolve("resolved");
        } else if (t == "drcrpopup") {
          this.drcrpopup = true;

          resolve("resolved");
        } else if (t == "closedrc") {
          this.drcrpopup = false;

          resolve("resolved");
        } else if (t == "newannex") {
          resolve("resolved");
        }
      });
    },

    async shortfunctionsecond(g, k, l) {
      if (g == "popupActiveNarration") {
        await this.longfunctionfirst(g);
        this.$refs.childComponent.setValue(k, "ledgerform" + l);
      } else if (g == "popupActive5") {
        await this.longfunctionfirst(g);
        document.getElementById("newNarrationBox").focus();
      } else if (g == "areais") {
        await this.longfunctionfirst("areais");

        document.getElementById("quantitiy").focus();
        //this.$refs["areais"].focus()
      } else if (g == "acnamedatafocus") {
        await this.longfunctionfirst("areais");
        document.getElementById("acname").focus();
      } else if (g == "acnamedatafocus2") {
        await this.longfunctionfirst("closedrc");

        document.getElementById("acname").focus();
      } else if (g == "emaildata") {
        const result = await this.longfunctionfirst("areais");
        //alert("maybe")
        document.getElementById("tgstshare").focus();

        console.log(result);
      } else if (g == "citydata") {
        await this.longfunctionfirst("areais");

        document.getElementById("division").focus();
      } else if (g == "acnamedata") {
        await this.longfunctionfirst("areais");

        document.getElementById("bankacname").focus();
      } else if (g == "disttdata") {
        await this.longfunctionfirst("areais");

        document.getElementById("dgstno").focus();
      } else if (g == "editbutton") {
        // alert("here");
        await this.longfunctionfirst(g);
        var p = this.rowlength - 1;
        document.getElementById("0" + p).focus();
      } else if (g == "groupdata") {
        //alert("here");
        await this.longfunctionfirst("areais");
        document.getElementById("pan").focus();
      } else if (g == "dateprevnext") {
        // alert("here");
        await this.longfunctionfirst("dateprevnext");
        document.getElementById("editButton").focus();
      } else if (g == "worksdata") {
        //alert("here");
        await this.longfunctionfirst("areais");

        document.getElementById("nameaddress1").focus();
      } else if (g == "drcrpopup") {
        await this.longfunctionfirst(g);

        document.getElementById("drcrfilter").focus();
      } else if (g == "newannex") {
        await this.longfunctionfirst(g);

        document.getElementById("filterbar").focus();
      } else if (g == "popupActive2") {
        await this.longfunctionfirst(g);
        this.$refs.childComponentLedger.setValue(k, "ledgerform" + l, "");
      }
    },
    onChildClick(value) {
      //alert("called")
      if (value == "closeledger") {
        this.popupActive2 = false;
        this.modalOpen = false;
      } else {
        const words = value.split(":");
        this.searchindex = parseInt(words[2] + "");
        this.getsearchdata(this.searchindex);
        if (this.popupActive2 == true) {
          this.popupActive2 = false;
          this.modalOpen = false;
        }
      }
    },
    onChildClickNarration(valu) {
      if (this.modalOpenNarration == true) {
        if (valu == "closenarration") {
          this.modalOpenNarration = false;
          this.popupActiveNarration = false;
        } else {
          const words = valu.split(":");

          if (this.currentfield == "comboarea") {
            this.comboarea = words[0] + "";

            this.shortfunctionsecond("areais");
          } else if (this.currentfield == "comboemail") {
            this.comboemail = words[0] + "";

            document.getElementById("tgstshare").focus();
            //    this.shortfunctionsecond("emaildata");
          } else if (this.currentfield == "City") {
            this.City = words[0] + "";
            this.shortfunctionsecond("citydata");
          } else if (this.currentfield == "AcName") {
            this.AcNam = words[0] + "";
            this.shortfunctionsecond("acnamedata");
          } else if (this.currentfield == "Distt") {
            this.Distt = words[0] + "";
            this.shortfunctionsecond("disttdata");
          } else if (this.currentfield == "Works") {
            this.Works = words[0] + "";

            this.shortfunctionsecond("worksdata");
          } else if (this.currentfield == "combogroup") {
            this.combogroup = words[0] + "";
            this.shortfunctionsecond("groupdata");
          }
          this.popupActiveNarration = false;
          this.modalOpenNarration = false;
        }
      }
      // this.shortfunctionsecond(valu)
    },
    showdescNar(k) {
      this.shortfunctionsecond("popupActiveNarration", k, k);
    },

    popupKeyDown() {
      //

      if (
        document.getElementById(
          "annexuresPopupListItem" + parseInt(this.popupSelectedRow + 1)
        )
      ) {
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#FFFFFF";
        }

        if (
          this.popupSelectedRow == this.filteredUsers.length - 1 ||
          this.popupSelectedRow > 6
        ) {
          this.popupSelectedRow = -1;
        }

        this.popupSelectedRow = this.popupSelectedRow + 1;
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#BCD4EC";
        }
      } else {
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#FFFFFF";
        }

        this.popupSelectedRow = 0;
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";
      }
    },

    popupKeyUp() {
      if (
        document.getElementById(
          "annexuresPopupListItem" + parseInt(this.popupSelectedRow - 1)
        )
      ) {
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#FFFFFF";
        }
        if (this.popupSelectedRow == 0) {
          this.filteredUsers.length < 8
            ? (this.popupSelectedRow = this.filteredUsers.length)
            : (this.popupSelectedRow = 8);
        }
        this.popupSelectedRow = this.popupSelectedRow - 1;
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#BCD4EC";
        }
      } else {
        if (
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          )
        ) {
          document.getElementById(
            "annexuresPopupListItem" + this.popupSelectedRow
          ).style.backgroundColor = "#FFFFFF";
        }
        this.popupSelectedRow = 0;
        while (
          document.getElementById(
            "annexuresPopupListItem" + parseInt(this.popupSelectedRow + 1)
          )
        ) {
          this.popupSelectedRow++;
        }
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";
      }
    },

    drcrFilteredList() {
      let inp = this.drcrFilter;
      inp = inp.toLowerCase();

      if (inp.length < 1) {
        this.drcrFilteredNarrations = this.drcrNarrations;
      } else {
        this.drcrFilteredNarrations = [];
        for (let i = 0; i < this.drcrNarrations.length; i++) {
          //alert(this.drcrNarrations[i].name)
          let str = this.drcrNarrations[i].name;
          str = str.toLowerCase();
          if (str.indexOf(inp) == 0) {
            this.drcrFilteredNarrations.push(this.drcrNarrations[i]);
          }
        }
      }
      if (
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        )
      ) {
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#FFFFFF";
      }

      this.popupSelectedRow = 0;

      if (
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        )
      ) {
        document.getElementById(
          "annexuresPopupListItem" + this.popupSelectedRow
        ).style.backgroundColor = "#BCD4EC";
      }
    },
    showdrcrpopup(text) {
      this.drcrNarrations = [];
      this.drcrFilter = "";
      for (let i in this.annexures) {
        if (text == "d" && this.annexures[i].debit == "D") {
          this.drcrNarrations.push(this.annexures[i]);
        }

        if (text == "c" && this.annexures[i].debit == "C") {
          this.drcrNarrations.push(this.annexures[i]);
        }
      }
      this.drcrFilteredNarrations = this.drcrNarrations;
      //alert(JSON.stringify(this.drcrFilteredNarrations))

      this.shortfunctionsecond("drcrpopup");
    },
    misSave() {
      this.miscpopup = false;
    },
    onfileselect(event) {
      var input = event.target;
      // Ensure that you have a file before attempting to read it
      if (input.files && input.files[0]) {
        // create a new FileReader to read this image and convert to base64 format
        var reader = new FileReader();
      }
      reader.onload = e => {
        // Note: arrow function used here, so that "this.imageData" refers to the imageData of Vue component
        // Read image as base64 and set to imageData
        this.filedata = e.target.result;
        var img = this.filedata;

        console.log("hello" + img);
      };

      reader.readAsDataURL(input.files[0]);
      //alert(this.filedata + reader);
    },
    miscPopupOpen() {
      this.miscpopup = true;
    },
    openMap() {
      let user = sessionStorage.getItem("user");
      let city = JSON.parse(user)[0].city;
      //alert(city);
      // https://www.google.com/maps/dir/Jammu/Chandigarh/
      if (this.City != "") {
        let theURL =
          "https://www.google.com/maps/dir/" + this.City + "/" + city + "/";
        window.open(theURL);
      } else {
        alert("Please enter a city to search in maps");
      }
    },
    onlyNumber($event) {
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
        // 46 is dot
        return $event.preventDefault();
      } else return null;
    },

    validateemail() {
      var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(this.emaildata);
    },
    recordDoubleClick: function(e) {
      // you can show Dialog component here
      //alert("dblclick");
      console.log(e);
    },
    reloadPage() {
      window.location.reload();
    },
    con() {
      var a = this.ContactNo;
      var b;

      if (a.length === 10) {
        b = confirm("Want to enter more no:");
        if (b === true) {
          this.con();
          a = a + " , ";
        } else {
          a = "+91" + a;
        }
      } else if (a.length < 10) {
        alert("Enter 10 digit no:");
      } else {
        console.log(" ");
      }
    },
    addhver() {
      var a = this.AadhaarNo;

      if (a.length === 12) {
        return 0;
      } else if (a.length < 10) {
        alert("enter 12 digit aadhaar no");
        this.AadhaarNo = "";
        this.a = true;

        this.$refs.cono.$el.focus();
      } else {
        alert("enter 12 digit aadhaar no");
        this.AadhaarNo = "";
        this.a = true;
        this.$refs.cono.$el.focus();
      }
    },

    caseSense(k) {
      var str;
      if (k == "Address1") {
        str = this.Address1;
      } else if (k == "Address2") {
        str = this.Address2;
      } else if (k == "Collectorate") {
        str = this.Collectorate;
      } else if (k == "SACCode") {
        str = this.SACCode;
      } else if (k == "ContactPerson") {
        str = this.ContactPerson;
      } else if (k == "TDSAcNo") {
        str = this.TDSAcNo;
      } else if (k == "CompositionYN") {
        str = this.CompositionYN;
      } else if (k == "BankACName") {
        str = this.BankACName;
      } else if (k == "Division") {
        str = this.Division;
      } else if (k == "NameAddress1") {
        str = this.NameAddress1;
      } else if (k == "NameAddress2") {
        str = this.NameAddress2;
      } else {
        console.log(" ");
      }

      if (str.length > 1) {
        //var arr = str.split("");
        if (str[str.length - 2] == "." || str[str.length - 2] == " ") {
          var a = str.charAt(str.length - 1).toUpperCase();
          //console.log(a);
          var rd = str.slice(0, str.length - 1);

          var b = rd + a;
          if (k == "Address1") {
            this.Address1 = b;
          } else if (k == "Address2") {
            this.Address2 = b;
          } else if (k == "Collectorate") {
            this.Collectorate = b;
          } else if (k == "SACCode") {
            this.SACCode = b;
          } else if (k == "ContactPerson") {
            this.ContactPerson = b;
          } else if (k == "TDSAcNo") {
            this.TDSAcNo = b;
          } else if (k == "CompositionYN") {
            this.CompositionYN = b;
          } else if (k == "BankACName") {
            this.BankACName = b;
          } else if (k == "Division") {
            this.Division = b;
          } else if (k == "NameAddress1") {
            this.NameAddress1 = b;
          } else if (k == "NameAddress2") {
            this.NameAddress2 = b;
          } else {
            console.log(" ");
          }
          document.getElementById("myID").value = rd + a;
        }
      } else {
        if (k == "Address1") {
          this.Address1 = str.toUpperCase();
        } else if (k == "Address2") {
          this.Address2 = str.toUpperCase();
        } else if (k == "Collectorate") {
          this.Collectorate = str.toUpperCase();
        } else if (k == "SACCode") {
          this.SACCode = str.toUpperCase();
        } else if (k == "ContactPerson") {
          this.ContactPerson = str.toUpperCase();
        } else if (k == "TDSAcNo") {
          this.TDSAcNo = str.toUpperCase();
        } else if (k == "CompositionYN") {
          this.CompositionYN = str.toUpperCase();
        } else if (k == "BankACName") {
          this.BankACName = str.toUpperCase();
        } else if (k == "Division") {
          this.Division = str.toUpperCase();
        } else if (k == "NameAddress1") {
          this.NameAddress1 = str.toUpperCase();
        } else if (k == "NameAddress2") {
          this.NameAddress2 = str.toUpperCase();
        } else {
          console.log(" ");
        }
        document.getElementById("myID").value = str.toUpperCase();
      }
    },
    gstcheck() {
      var input = this.DGSTNo;

      if (/\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/.test(input)) {
        console.log("HI");
        this.checkValid = false;
        this.checkvalidation = true;
      } else {
        alert("Enter Valid ");
      }
    },
    upper(k) {
      var a;
      if (k == "PinCode") {
        a = this.PinCode;
      } else if (k == "BankACName") {
        a = this.BankACName;
      } else if (k == "DGSTNo") {
        a = this.DGSTNo;
      } else if (k == "IFSCCode") {
        a = this.IFSCCode;
      } else {
        console.log(" ");
      }
      var b = a.toUpperCase();
      console.log(b);
      if (k == "PinCode") {
        this.PinCode = b;
      } else if (k == "BankACName") {
        this.BankACName = b;
      } else if (k == "DGSTNo") {
        this.DGSTNo = b;
      } else if (k == "IFSCCode") {
        this.IFSCCode = b;
      } else {
        console.log(" ");
      }
    },
    panno() {
      var b = this.DGSTNo.substring(3, 12);
      this.PAN = b;
    },

    narrationModify2() {
      let n = 0;
      //alert("hey")
      var fin;
      this.popupdata.forEach(y => {
        if (y.name == this.oldNarrationToEdit) {
          this.popupdata[n].name = this.modifiedNarration;
          fin = n;
        }
        n++;
      });
      if (this.field == "area") {
        this.spdata = this.popupdata;
        this.spdata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.spdata.push(this.popupdata[i].name + "");
        }
      } else if (this.field == "email") {
        this.emaildata = this.popupdata;
        this.emaildata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.emaildata.push(this.popupdata[i].name + "");
        }
      } else if (this.field == "group") {
        this.groupdata = this.popupdata;
        this.groupdata = [];
        for (let i = 0; i < this.popupdata.length; i++) {
          this.groupdata.push(this.popupdata[i].name + "");
        }
      }

      var that = this;
      //
      ////alert(this.spdata)
      var input = {
        companyname: this.companyname,
        inputval: this.modifiedNarration,
        key: this.field,
        index: fin
      };
      axios.post("/modifyNarration", input).then(response => {
        that.narrations = JSON.parse(JSON.stringify(response.data));
        //alert(JSON.stringify(response.data))
        if (that.field == "area") {
          that.filteredAreaNarrations = that.narrations;
        } else if (that.field == "email") {
          that.filteredEmailNarrations = that.narrations;
        } else if (that.field == "group") {
          that.filteredGroupNarrations = that.narrations;
        }
      });
      this.popupActive6 = false;
    },
    narrationModify() {
      var indexList = [];
      //
      ////alert(indexList);
      //alert("heya")
      for (var x = 0; x < this.popupdata.length; x++) {
        let p = "annexureCheck";
        p = p + x;
        if (document.getElementById(p).checked == true) {
          indexList.push(this.popupdata[x]);
          document.getElementById(p).checked = false;
        }
      }

      this.oldNarrationToEdit = indexList[0].name;
      this.popupActive6 = true;
      this.modifiedNarration = indexList[0].name;
      document.getElementById("modifyNarrationBox").focus();

      //
      ////alert("To be added after permission  check is done");
    },

    AddNewNarration() {
      //alert("api called 1 "+ this.newNarration)

      var value = {
        narrations: []
      };
      var that = this;
      var value1 = {
        companyname: this.companyname,
        value: value,
        key: that.field,
        data: this.newNarration
      };
      axios
        .post("/addNarration", value1)
        .then(response => {
          //alert(response.data)
          that.narrations = JSON.parse(JSON.stringify(response.data));
          //alert(that.narrations)

          // //
          // ////alert("pooooop" + that.users[that.users.length - 1].accountname);
          that.newNarration = " ";

          that.popupActive5 = false;

          that.spdata = [];
          that.emaildata = [];
          that.groupdata = [];
          that.agentdata = [];

          if (that.field + "" == "area") {
            //alert("in area")
            that.filteredAreaNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.spdata.push(that.narrations[i].name + "");
              that.popupdata = that.filteredAreaNarrations;
            }
          } else if (that.field + "" == "email") {
            //alert("in filtered")
            that.filteredEmailNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.emaildata.push(that.narrations[i].name + "");
            }
            that.popupdata = that.filteredEmailNarrations;
          } else if (that.field + "" == "group") {
            //alert("in group")
            that.filteredGroupNarrations = that.narrations;
            for (let i = 0; i < that.narrations.length; i++) {
              that.groupdata.push(that.narrations[i].name + "");
            }
            that.popupdata = that.filteredGroupNarrations;
          }
          // //
          // ////alert(that.spdata)
          //  //alert("api called 2")
        })
        .catch(error => {
          alert(error);
        });

      this.$forceUpdate();
    },
    filtering: function(e) {
      if (e.text !== "") {
        var str = e.text;
        var splitStr = str.toLowerCase().split(" ");
        for (var i = 0; i < splitStr.length; i++) {
          splitStr[i] =
            splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }

        if (this.currentfield == "comboarea") {
          document.getElementById("idarea").value = splitStr.join(" ");
        } else if (this.currentfield == "combogroup") {
          document.getElementById("idgroup").value = splitStr.join(" ");
        } else if (this.currentfield == "AcName") {
          document.getElementById("acname").value = splitStr.join(" ");
          // this.AcNam=splitStr.join(" ")
          //  this.setacname(splitStr.join(" "))
        }
      }
    },
    setacname(na) {
      this.AcNam = na;
    },
    filtering2(name) {
      this.currentfield = name + "";
    },
    showAddPopup() {
      this.popupActive4 = true;

      this.$forceUpdate();
    },
    showAddPopupNarration() {
      this.popupActive5 = true;

      this.$nextTick(() => {
        this.$refs.addBox.focus();
      });
    },
    handleClick() {
      this.annexureText = this.chosen.name;
      alert("yo");

      this.shortfunctionsecond("acnamedatafocus2");
    },
    handleSelected() {
      if (this.annexurecalled != "1") {
        let finder = this.selected2.id;
        //
        ////alert(finder);
        let k = 0;
        let n = 0;
        let id = "annexureCheck";
        for (var y in this.popupdata) {
          //
          ////alert(y.id);
          if (this.popupdata[y].id == finder) {
            n = k;
          }
          k++;
        }
        //
        ////alert(n);

        id += n;
        document.getElementById(id).checked = true;
        this.selected2 = [];
      } else {
        //alert("this")
        this.popupActive3 = false;
        this.annexureText = this.selected.name;

        this.annexurecalled = "0";
        this.shortfunctionsecond("acnamedatafocus2");
      }
      document.getElementById("filterbar").value = "";
    },
    filteredList() {
      ////alert("p");
      let p = document.getElementById("filterbar").value.toLowerCase();
      var searchtag = "name";
      this.filteredAnnexures = [];

      if (p == "") {
        this.filteredAnnexures = this.annexures;
      } else {
        for (var x in this.annexures) {
          //let id = this.users[x].id.toLowerCase();
          searchtag = this.annexures[x].name.toLowerCase();

          if (searchtag.indexOf(p) == 0) {
            ////alert(name);
            this.filteredAnnexures.push(this.annexures[x]);
          }
        }
      }
    },
    isGSTvalid($event) {
      // alert("no");
      let keyCode = $event.keyCode ? $event.keyCode : $event.which;
      var n = this.DGSTNo + "";

      if (n.length <= 1) {
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          // 46 is dot

          return $event.preventDefault();
        } else {
          console.log("khali");
        }
      } else if (n.length > 1 && n.length <= 6) {
        if (keyCode <= 122 && keyCode >= 97) {
          // 46 is dot

          this.upper("DGSTNo");
        } else {
          return $event.preventDefault();
        }
      } else if (n.length > 6 && n.length <= 10) {
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          // 46 is dot
          return $event.preventDefault();
        } else {
          console.log("khali");
        }
      } else if (n.length > 10 && n.length <= 11) {
        if (keyCode <= 122 && keyCode >= 97) {
          // 46 is dot

          this.upper("DGSTNo");
        } else {
          return $event.preventDefault();
        }
      } else if (n.length > 11 && n.length <= 14) {
        console.log("khali");
      } else {
        this.upper("DGSTNo");
        return $event.preventDefault();
      }

      if (this.DGSTNo.length > 1 && this.DGSTNo.length <= 12)
        this.PAN = this.DGSTNo.substring(2, this.DGSTNo.length + 1);

      if (this.DGSTNo.length == 2) {
        var code = parseInt(this.DGSTNo.substring(0, 2) + "") + "";

        this.State = this.gstwisestates[code];
      }
    },
    newdisable() {
      this.titleAction = "New";

      this.disAdd = true;

      this.buttondis_false();
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.disSave = false;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.crdis = false;
      this.drdis = false;

      this.Ahead = "";
      this.Form_type = "";
      this.Led_post = "";
      this.Vat_post = "";
      this.Ex_post = "";
      this.Serial = "";
      this.Short_name = "";
      this.Stk_post = "";
      this.Form_rtype = "";
      this.Rep_name = "";
      this.Bill_no_h = "";
      this.Salef3 = "";
      this.Tick = "";
      this.Vacode = "";
      this.Rep_gst = "";
      this.cont = false;
      this.buttondis = false;
      this.initializedefault()
      this.dbIndex = this.dbIndex == "" ? null : this.dbIndex;
    },
    getColor(p) {
      var i = this.buttonList.indexOf(p);
      if (this.buttonActiveList[i] == "active") {
        return this.activeColor;
      } else return this.inactiveColor;
    },

    buttonNext(p) {
      var i = this.buttonList.indexOf(p);

      if (i != this.buttonList.length - 1) {
        this.buttonActiveList[i] = "inactive";
        i = i + 1;
        this.buttonActiveList[i] = "active";
      }

      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    buttonPrev(p) {
      var i = this.buttonList.indexOf(p);

      if (i != 0) {
        this.buttonActiveList[i] = "inactive";
        i = i - 1;
        this.buttonActiveList[i] = "active";
      }
      document.getElementById(this.buttonList[i]).focus();
      this.$forceUpdate();
    },
    save() {
      var lastdata = { data: [] };
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      this.disSave = false;
      var ind;
      alert(this.ch_vdate + "  fd" + this.dbIndex);
      if (this.dbIndex + "" == "0") ind = parseInt(this.dbIndex);
      else if (parseInt(this.dbIndex + "") > 0) ind = parseInt(this.dbIndex);
      else ind = null;

      var n = {
        note:"purchase",
        dataAll: {
          index: ind,
          Ahead: this.Ahead,
          Form_type: this.Form_type,
          Led_post: this.Led_post,
          Vat_post: this.Vat_post,
          Ex_post: this.Ex_post,
          Serial: this.Serial,
          Short_name: this.Short_name,
          Stk_post: this.Stk_post,
          Form_rtype: this.Form_rtype,
          Rep_name: this.Rep_name,
          Bill_no_h: this.Bill_no_h,
          Salef3: this.Salef3,
          Tick: this.Tick,
          Vacode: this.Vacode,
          Rep_gst: this.Rep_gst,
          cont: this.cont,
          data: ""
        },
        companyname: companyName
      };

      var columndata = {
        data: [
          { vacode: this.ch_vacode },

          { vdate: this.ch_vdate },

          { vcode: this.ch_vcode },

          { vamt: this.ch_vamt },

          { others: this.ch_others },

          { vdesc: this.ch_vdesc },

          { stype: this.ch_stype },

          { freight: this.ch_freight },

          { weight: this.ch_weight },

          { pkgs: this.ch_pkgs },

          { tax: this.ch_tax },

          { sdisc: this.ch_sdisc },

          { etype: this.ch_etype },

          { exfor: this.ch_exfor },

          { rate: this.ch_rate },

          { stkcode: this.ch_stkcode },

          { balance: this.ch_balance },

          { conv: this.ch_conv },

          { plarg: this.ch_plarg },

          { entno: this.ch_entno },

          { pb_wt: this.ch_pb_wt },

          { freight1: this.ch_freight1 },

          { weighing: this.ch_weighing },

          { pla: this.ch_pla },

          { tds_frt: this.ch_tds_frt },

          { tdsrate: this.ch_tdsrate },

          { cess: this.ch_cess },

          { vbillno1: this.ch_vbillno1 },

          { vbdate1: this.ch_vbdate1 },

          { vamt1: this.ch_vamt1 },

          { duedate: this.ch_duedate },

          { cl_date: this.ch_cl_date },

          { vacode1: this.ch_vacode1 },

          { hcess: this.ch_hcess },

          { trpt: this.ch_trpt },

          { weight_ch: this.ch_weight_ch },

          { vamt_ch: this.ch_vamt_ch },

          { vdate_ch: this.ch_vdate_ch },

          { vhead: this.ch_vhead },

          { credit: this.ch_credit },

          { pcess: this.ch_pcess },

          { tcs_cess: this.ch_tcs_cess },

          { tcs_hcess: this.ch_tcs_hcess },

          { exp1: this.ch_exp1 },

          { exp2: this.ch_exp2 },

          { exp3: this.ch_exp3 },

          { exp4: this.ch_exp4 },

          { exp5: this.ch_exp5 },

          { exp6: this.ch_exp6 },

          { exp7: this.ch_exp7 },

          { exp8: this.ch_exp8 },

          { exp9: this.ch_exp9 },

          { exp1_rate: this.ch_exp1_rate },

          { exp2_rate: this.ch_exp2_rate },

          { exp3_rate: this.ch_exp3_rate },

          { exp4_rate: this.ch_exp4_rate },

          { exp5_rate: this.ch_exp5_rate },

          { exp6_rate: this.ch_exp6_rate },

          { exp7_rate: this.ch_exp7_rate },

          { exp8_rate: this.ch_exp8_rate },

          { exp9_rate: this.ch_exp9_rate },

          { exp10_rate: this.ch_exp10_rate },

          { rem1: this.ch_rem1 },

          { rem2: this.ch_rem2 },

          { rem3: this.ch_rem3 },

          { rem4: this.ch_rem4 },

          { transport: this.ch_transport },

          { order: this.ch_order },

          { order_date: this.ch_order_date },

          { agent: this.ch_agent },

          { broker: this.ch_broker },

          { cd_rate: this.ch_cd_rate },

          { cd: this.ch_cd },

          { sch_rate: this.ch_sch_rate },

          { scheme: this.ch_scheme },

          { srv_rate: this.ch_srv_rate },

          { srv_tax: this.ch_srv_tax },

          { inv_tm: this.ch_inv_tm },

          { rev_dt: this.ch_rev_dt },

          { rem5: this.ch_rem5 },

          { rem6: this.ch_rem6 },

          { rem7: this.ch_rem7 },

          { rem8: this.ch_rem8 },

          { cvd: this.ch_cvd },

          { exrate: this.ch_exrate },

          { cessrate: this.ch_cessrate },

          { hcrate: this.ch_hcrate },

          { cvdrate: this.ch_cvdrate },

          { exp_before: this.ch_exp_before },

          { exp_after: this.ch_exp_after },

          { tax_rate: this.ch_tax_rate },

          { exp10: this.ch_exp10 },

          { loose: this.ch_loose },

          { spec: this.ch_spec },

          { pckng: this.ch_pckng },

          { wf: this.ch_wf },

          { wwf: this.ch_wwf },

          { bill: this.ch_bill },

          { stk_code: this.ch_stk_code },

          { rateins: this.ch_rateins },

          { srates: this.ch_srates },

          { qpps: this.ch_qpps },

          { tcs: this.ch_tcs },

          { tcs1: this.ch_tcs1 },

          { tcs2: this.ch_tcs2 },

          { tcs_rate: this.ch_tcs_rate },

          { tcs1_rate: this.ch_tcs1_rate },

          { tcs2_rate: this.ch_tcs2_rate },

          { saletype: this.ch_saletype },

          { unit_ex: this.ch_unit_ex },

          { unit_cs: this.ch_unit_cs },

          { unit_hs: this.ch_unit_hs },

          { unit_cv: this.ch_unit_cv },

          { cd1: this.ch_cd1 },

          { cd1_rate: this.ch_cd1_rate },

          { tariff: this.ch_tariff },

          { exp1_ex: this.ch_exp1_ex },

          { exp2_ex: this.ch_exp2_ex },

          { weights: this.ch_weights },

          { exp1_exr: this.ch_exp1_exr },

          { exp2_exr: this.ch_exp2_exr },

          { rem9: this.ch_rem9 },

          { rem10: this.ch_rem10 },

          { exp01: this.ch_exp01 },

          { exp01code: this.ch_exp01code },

          { p_vbillno: this.ch_p_vbillno },

          { usname: this.ch_usname },

          { usrate: this.ch_usrate },

          { usvamt: this.ch_usvamt },

          { cardno: this.ch_cardno },

          { ctax: this.ch_ctax },

          { ctax_rate: this.ch_ctax_rate },

          { stax: this.ch_stax },

          { stax_rate: this.ch_stax_rate },

          { itax: this.ch_itax },

          { itax_rate: this.ch_itax_rate },

          { valpha: this.ch_valpha },

          { vno: this.ch_vno },

          { vtype: this.ch_vtype },

          { vamtcode: this.ch_vamtcode },

          { vbillno: this.ch_vbillno },

          { vbdate: this.ch_vbdate },

          { excise: this.ch_excise },

          { counter: this.ch_counter },

          { btype: this.ch_btype },

          { srno1: this.ch_srno1 },

          { ppcode: this.ch_ppcode },

          { emcode: this.ch_emcode },

          { mon: this.ch_mon },

          { initial: this.ch_initial },

          { vacode_ch: this.ch_vacode_ch },

          { record: this.ch_record },

          { vhead_ch: this.ch_vhead_ch },

          { remarks: this.ch_remarks },

          { tick: this.ch_tick },

          { debit: this.ch_debit },

          { vat: this.ch_vat },

          { gr: this.ch_gr },

          { rev_tm: this.ch_rev_tm },

          { inv_dt: this.ch_inv_dt },

          { total: this.ch_total },

          { b_tpt: this.ch_b_tpt },

          { sub_total: this.ch_sub_total },

          { party_code: this.ch_party_code },

          { tx_from: this.ch_tx_from },

          { tx_upto: this.ch_tx_upto },

          { tx_type: this.ch_tx_type },

          { ssr: this.ch_ssr },

          { vat_post: this.ch_vat_post },

          { led_post: this.ch_led_post },

          { ex_post: this.ch_ex_post },

          { stk_post: this.ch_stk_post },

          { opening: this.ch_opening },

          { purr: this.ch_purr },

          { sale: this.ch_sale },

          { prdd: this.ch_prdd },

          { issuee: this.ch_issuee },

          { closing: this.ch_closing },

          { purtype: this.ch_purtype },

          { ahead: this.ch_ahead },

          { add1: this.ch_add1 },

          { add2: this.ch_add2 },

          { city: this.ch_city },

          { tin: this.ch_tin },

          { phone: this.ch_phone },

          { cash_name: this.ch_cash_name },

          { cash_add1: this.ch_cash_add1 },

          { cash_city: this.ch_cash_city },

          { tax0_sale: this.ch_tax0_sale },

          { tax1_sale: this.ch_tax1_sale },

          { p_vdate: this.ch_p_vdate },

          { p_vno: this.ch_p_vno },

          { p_valpha: this.ch_p_valpha },

          { p_counter: this.ch_p_counter },

          { user_name: this.ch_user_name },

          { emistatus: this.ch_emistatus },

          { p_pageno: this.ch_p_pageno },

          { p_entry: this.ch_p_entry },

          { taxsurr: this.ch_taxsurr },

          { o_vdate: this.ch_o_vdate },

          { o_vno: this.ch_o_vno },

          { o_valpha: this.ch_o_valpha },

          { o_counter: this.ch_o_counter },

          { rem11: this.ch_rem11 },

          { cashrec: this.ch_cashrec },

          { bank: this.ch_bank },

          { bcode: this.ch_bcode },

          { exp3_ex: this.ch_exp3_ex }
        ]
      };

      var labeldata = {
        vacode: this.lt_vacode,
        vdate: this.lt_vdate,

        vcode: this.lt_vcode,

        vamt: this.lt_vamt,

        others: this.lt_others,

        vdesc: this.lt_vdesc,

        stype: this.lt_stype,

        freight: this.lt_freight,

        weight: this.lt_weight,

        pkgs: this.lt_pkgs,

        tax: this.lt_tax,

        sdisc: this.lt_sdisc,

        etype: this.lt_etype,

        exfor: this.lt_exfor,

        rate: this.lt_rate,

        stkcode: this.lt_stkcode,

        balance: this.lt_balance,

        conv: this.lt_conv,

        plarg: this.lt_plarg,

        entno: this.lt_entno,

        pb_wt: this.lt_pb_wt,

        freight1: this.lt_freight1,

        weighing: this.lt_weighing,

        pla: this.lt_pla,

        tds_frt: this.lt_tds_frt,

        tdsrate: this.lt_tdsrate,

        cess: this.lt_cess,

        vbillno1: this.lt_vbillno1,

        vbdate1: this.lt_vbdate1,

        vamt1: this.lt_vamt1,

        duedate: this.lt_duedate,

        cl_date: this.lt_cl_date,

        vacode1: this.lt_vacode1,

        hcess: this.lt_hcess,

        trpt: this.lt_trpt,

        weight_ch: this.lt_weight_ch,

        vamt_ch: this.lt_vamt_ch,

        vdate_ch: this.lt_vdate_ch,

        vhead: this.lt_vhead,

        credit: this.lt_credit,

        pcess: this.lt_pcess,

        tcs_cess: this.lt_tcs_cess,

        tcs_hcess: this.lt_tcs_hcess,

        exp1: this.lt_exp1,

        exp2: this.lt_exp2,

        exp3: this.lt_exp3,

        exp4: this.lt_exp4,

        exp5: this.lt_exp5,

        exp6: this.lt_exp6,

        exp7: this.lt_exp7,

        exp8: this.lt_exp8,

        exp9: this.lt_exp9,
        exp1_rate: this.lt_exp1_rate,

        exp2_rate: this.lt_exp2_rate,

        exp3_rate: this.lt_exp3_rate,

        exp4_rate: this.lt_exp4_rate,

        exp5_rate: this.lt_exp5_rate,

        exp6_rate: this.lt_exp6_rate,

        exp7_rate: this.lt_exp7_rate,

        exp8_rate: this.lt_exp8_rate,

        exp9_rate: this.lt_exp9_rate,

        exp10_rate: this.lt_exp10_rate,

        rem1: this.lt_rem1,

        rem2: this.lt_rem2,

        rem3: this.lt_rem3,

        rem4: this.lt_rem4,

        transport: this.lt_transport,

        order: this.lt_order,

        order_date: this.lt_order_date,

        agent: this.lt_agent,

        broker: this.lt_broker,

        cd_rate: this.lt_cd_rate,

        cd: this.lt_cd,

        sch_rate: this.lt_sch_rate,

        scheme: this.lt_scheme,

        srv_rate: this.lt_srv_rate,

        srv_tax: this.lt_srv_tax,

        inv_tm: this.lt_inv_tm,

        rev_dt: this.lt_rev_dt,

        rem5: this.lt_rem5,

        rem6: this.lt_rem6,

        rem7: this.lt_rem7,

        rem8: this.lt_rem8,

        cvd: this.lt_cvd,

        exrate: this.lt_exrate,

        cessrate: this.lt_cessrate,

        hcrate: this.lt_hcrate,

        cvdrate: this.lt_cvdrate,

        exp_before: this.lt_exp_before,

        exp_after: this.lt_exp_after,

        tax_rate: this.lt_tax_rate,

        exp10: this.lt_exp10,

        loose: this.lt_loose,

        spec: this.lt_spec,

        pckng: this.lt_pckng,

        wf: this.lt_wf,

        wwf: this.lt_wwf,

        bill: this.lt_bill,

        stk_code: this.lt_stk_code,

        rateins: this.lt_rateins,

        srates: this.lt_srates,

        qpps: this.lt_qpps,

        tcs: this.lt_tcs,

        tcs1: this.lt_tcs1,

        tcs2: this.lt_tcs2,

        tcs_rate: this.lt_tcs_rate,

        tcs1_rate: this.lt_tcs1_rate,

        tcs2_rate: this.lt_tcs2_rate,

        saletype: this.lt_saletype,

        unit_ex: this.lt_unit_ex,

        unit_cs: this.lt_unit_cs,

        unit_hs: this.lt_unit_hs,

        unit_cv: this.lt_unit_cv,

        cd1: this.lt_cd1,

        cd1_rate: this.lt_cd1_rate,

        tariff: this.lt_tariff,

        exp1_ex: this.lt_exp1_ex,

        exp2_ex: this.lt_exp2_ex,

        weights: this.lt_weights,

        exp1_exr: this.lt_exp1_exr,

        exp2_exr: this.lt_exp2_exr,

        rem9: this.lt_rem9,

        rem10: this.lt_rem10,

        exp01: this.lt_exp01,

        exp01code: this.lt_exp01code,

        p_vbillno: this.lt_p_vbillno,

        usname: this.lt_usname,

        usrate: this.lt_usrate,

        usvamt: this.lt_usvamt,

        cardno: this.lt_cardno,

        ctax: this.lt_ctax,

        ctax_rate: this.lt_ctax_rate,

        stax: this.lt_stax,

        stax_rate: this.lt_stax_rate,

        itax: this.lt_itax,

        itax_rate: this.lt_itax_rate,

        valpha: this.lt_valpha,

        vno: this.lt_vno,

        vtype: this.lt_vtype,

        vamtcode: this.lt_vamtcode,

        vbillno: this.lt_vbillno,

        vbdate: this.lt_vbdate,

        excise: this.lt_excise,

        counter: this.lt_counter,

        btype: this.lt_btype,

        srno1: this.lt_srno1,

        ppcode: this.lt_ppcode,

        emcode: this.lt_emcode,

        mon: this.lt_mon,

        initial: this.lt_initial,

        vacode_ch: this.lt_vacode_ch,

        record: this.lt_record,

        vhead_ch: this.lt_vhead_ch,

        remarks: this.lt_remarks,

        tick: this.lt_tick,

        debit: this.lt_debit,

        vat: this.lt_vat,

        gr: this.lt_gr,

        rev_tm: this.lt_rev_tm,

        inv_dt: this.lt_inv_dt,

        total: this.lt_total,

        b_tpt: this.lt_b_tpt,

        sub_total: this.lt_sub_total,

        party_code: this.lt_party_code,

        tx_from: this.lt_tx_from,

        tx_upto: this.lt_tx_upto,

        tx_type: this.lt_tx_type,

        ssr: this.lt_ssr,

        vat_post: this.lt_vat_post,

        led_post: this.lt_led_post,

        ex_post: this.lt_ex_post,

        stk_post: this.lt_stk_post,

        opening: this.lt_opening,

        purr: this.lt_purr,

        sale: this.lt_sale,

        prdd: this.lt_prdd,

        issuee: this.lt_issuee,

        closing: this.lt_closing,

        purtype: this.lt_purtype,

        ahead: this.lt_ahead,

        add1: this.lt_add1,

        add2: this.lt_add2,

        city: this.lt_city,

        tin: this.lt_tin,

        phone: this.lt_phone,

        cash_name: this.lt_cash_name,

        cash_add1: this.lt_cash_add1,

        cash_city: this.lt_cash_city,

        tax0_sale: this.lt_tax0_sale,

        tax1_sale: this.lt_tax1_sale,

        p_vdate: this.lt_p_vdate,

        p_vno: this.lt_p_vno,

        p_valpha: this.lt_p_valpha,

        p_counter: this.lt_p_counter,

        user_name: this.lt_user_name,

        emistatus: this.lt_emistatus,

        p_pageno: this.lt_p_pageno,

        p_entry: this.lt_p_entry,

        taxsurr: this.lt_taxsurr,

        o_vdate: this.lt_o_vdate,

        o_vno: this.lt_o_vno,

        o_valpha: this.lt_o_valpha,

        o_counter: this.lt_o_counter,

        rem11: this.lt_rem11,

        cashrec: this.lt_cashrec,

        bank: this.lt_bank,

        bcode: this.lt_bcode,

        exp3_ex: this.lt_exp3_ex
      };

      var orderdata = {
        vacode: this.dv_vacode,
        vdate: this.dv_vdate,

        vcode: this.dv_vcode,

        vamt: this.dv_vamt,

        others: this.dv_others,

        vdesc: this.dv_vdesc,

        stype: this.dv_stype,

        freight: this.dv_freight,

        weight: this.dv_weight,

        pkgs: this.dv_pkgs,

        tax: this.dv_tax,

        sdisc: this.dv_sdisc,

        etype: this.dv_etype,

        exfor: this.dv_exfor,

        rate: this.dv_rate,

        stkcode: this.dv_stkcode,

        balance: this.dv_balance,

        conv: this.dv_conv,

        plarg: this.dv_plarg,

        entno: this.dv_entno,

        pb_wt: this.dv_pb_wt,

        freight1: this.dv_freight1,

        weighing: this.dv_weighing,

        pla: this.dv_pla,

        tds_frt: this.dv_tds_frt,

        tdsrate: this.dv_tdsrate,

        cess: this.dv_cess,

        vbillno1: this.dv_vbillno1,

        vbdate1: this.dv_vbdate1,

        vamt1: this.dv_vamt1,

        duedate: this.dv_duedate,

        cl_date: this.dv_cl_date,

        vacode1: this.dv_vacode1,

        hcess: this.dv_hcess,

        trpt: this.dv_trpt,

        weight_ch: this.dv_weight_ch,

        vamt_ch: this.dv_vamt_ch,

        vdate_ch: this.dv_vdate_ch,

        vhead: this.dv_vhead,

        credit: this.dv_credit,

        pcess: this.dv_pcess,

        tcs_cess: this.dv_tcs_cess,

        tcs_hcess: this.dv_tcs_hcess,

        exp1: this.dv_exp1,

        exp2: this.dv_exp2,

        exp3: this.dv_exp3,

        exp4: this.dv_exp4,

        exp5: this.dv_exp5,

        exp6: this.dv_exp6,

        exp7: this.dv_exp7,

        exp8: this.dv_exp8,

        exp9: this.dv_exp9,
        exp1_rate: this.dv_exp1_rate,

        exp2_rate: this.dv_exp2_rate,

        exp3_rate: this.dv_exp3_rate,

        exp4_rate: this.dv_exp4_rate,

        exp5_rate: this.dv_exp5_rate,

        exp6_rate: this.dv_exp6_rate,

        exp7_rate: this.dv_exp7_rate,

        exp8_rate: this.dv_exp8_rate,

        exp9_rate: this.dv_exp9_rate,

        exp10_rate: this.dv_exp10_rate,

        rem1: this.dv_rem1,

        rem2: this.dv_rem2,

        rem3: this.dv_rem3,

        rem4: this.dv_rem4,

        transport: this.dv_transport,

        order: this.dv_order,

        order_date: this.dv_order_date,

        agent: this.dv_agent,

        broker: this.dv_broker,

        cd_rate: this.dv_cd_rate,

        cd: this.dv_cd,

        sch_rate: this.dv_sch_rate,

        scheme: this.dv_scheme,

        srv_rate: this.dv_srv_rate,

        srv_tax: this.dv_srv_tax,

        inv_tm: this.dv_inv_tm,

        rev_dt: this.dv_rev_dt,

        rem5: this.dv_rem5,

        rem6: this.dv_rem6,

        rem7: this.dv_rem7,

        rem8: this.dv_rem8,

        cvd: this.dv_cvd,

        exrate: this.dv_exrate,

        cessrate: this.dv_cessrate,

        hcrate: this.dv_hcrate,

        cvdrate: this.dv_cvdrate,

        exp_before: this.dv_exp_before,

        exp_after: this.dv_exp_after,

        tax_rate: this.dv_tax_rate,

        exp10: this.dv_exp10,

        loose: this.dv_loose,

        spec: this.dv_spec,

        pckng: this.dv_pckng,

        wf: this.dv_wf,

        wwf: this.dv_wwf,

        bill: this.dv_bill,

        stk_code: this.dv_stk_code,

        rateins: this.dv_rateins,

        srates: this.dv_srates,

        qpps: this.dv_qpps,

        tcs: this.dv_tcs,

        tcs1: this.dv_tcs1,

        tcs2: this.dv_tcs2,

        tcs_rate: this.dv_tcs_rate,

        tcs1_rate: this.dv_tcs1_rate,

        tcs2_rate: this.dv_tcs2_rate,

        saletype: this.dv_saletype,

        unit_ex: this.dv_unit_ex,

        unit_cs: this.dv_unit_cs,

        unit_hs: this.dv_unit_hs,

        unit_cv: this.dv_unit_cv,

        cd1: this.dv_cd1,

        cd1_rate: this.dv_cd1_rate,

        tariff: this.dv_tariff,

        exp1_ex: this.dv_exp1_ex,

        exp2_ex: this.dv_exp2_ex,

        weights: this.dv_weights,

        exp1_exr: this.dv_exp1_exr,

        exp2_exr: this.dv_exp2_exr,

        rem9: this.dv_rem9,

        rem10: this.dv_rem10,

        exp01: this.dv_exp01,

        exp01code: this.dv_exp01code,

        p_vbillno: this.dv_p_vbillno,

        usname: this.dv_usname,

        usrate: this.dv_usrate,

        usvamt: this.dv_usvamt,

        cardno: this.dv_cardno,

        ctax: this.dv_ctax,

        ctax_rate: this.dv_ctax_rate,

        stax: this.dv_stax,

        stax_rate: this.dv_stax_rate,

        itax: this.dv_itax,

        itax_rate: this.dv_itax_rate,

        valpha: this.dv_valpha,

        vno: this.dv_vno,

        vtype: this.dv_vtype,

        vamtcode: this.dv_vamtcode,

        vbillno: this.dv_vbillno,

        vbdate: this.dv_vbdate,

        excise: this.dv_excise,

        counter: this.dv_counter,

        btype: this.dv_btype,

        srno1: this.dv_srno1,

        ppcode: this.dv_ppcode,

        emcode: this.dv_emcode,

        mon: this.dv_mon,

        initial: this.dv_initial,

        vacode_ch: this.dv_vacode_ch,

        record: this.dv_record,

        vhead_ch: this.dv_vhead_ch,

        remarks: this.dv_remarks,

        tick: this.dv_tick,

        debit: this.dv_debit,

        vat: this.dv_vat,

        gr: this.dv_gr,

        rev_tm: this.dv_rev_tm,

        inv_dt: this.dv_inv_dt,

        total: this.dv_total,

        b_tpt: this.dv_b_tpt,

        sub_total: this.dv_sub_total,

        party_code: this.dv_party_code,

        tx_from: this.dv_tx_from,

        tx_upto: this.dv_tx_upto,

        tx_type: this.dv_tx_type,

        ssr: this.dv_ssr,

        vat_post: this.dv_vat_post,

        led_post: this.dv_led_post,

        ex_post: this.dv_ex_post,

        stk_post: this.dv_stk_post,

        opening: this.dv_opening,

        purr: this.dv_purr,

        sale: this.dv_sale,

        prdd: this.dv_prdd,

        issuee: this.dv_issuee,

        closing: this.dv_closing,

        purtype: this.dv_purtype,

        ahead: this.dv_ahead,

        add1: this.dv_add1,

        add2: this.dv_add2,

        city: this.dv_city,

        tin: this.dv_tin,

        phone: this.dv_phone,

        cash_name: this.dv_cash_name,

        cash_add1: this.dv_cash_add1,

        cash_city: this.dv_cash_city,

        tax0_sale: this.dv_tax0_sale,

        tax1_sale: this.dv_tax1_sale,

        p_vdate: this.dv_p_vdate,

        p_vno: this.dv_p_vno,

        p_valpha: this.dv_p_valpha,

        p_counter: this.dv_p_counter,

        user_name: this.dv_user_name,

        emistatus: this.dv_emistatus,

        p_pageno: this.dv_p_pageno,

        p_entry: this.dv_p_entry,

        taxsurr: this.dv_taxsurr,

        o_vdate: this.dv_o_vdate,

        o_vno: this.dv_o_vno,

        o_valpha: this.dv_o_valpha,

        o_counter: this.dv_o_counter,

        rem11: this.dv_rem11,

        cashrec: this.dv_cashrec,

        bank: this.dv_bank,

        bcode: this.dv_bcode,

        exp3_ex: this.dv_exp3_ex
      };


 var widthdata = {
        vacode: this.wi_vacode,
        vdate: this.wi_vdate,

        vcode: this.wi_vcode,

        vamt: this.wi_vamt,

        others: this.wi_others,

        vdesc: this.wi_vdesc,

        stype: this.wi_stype,

        freight: this.wi_freight,

        weight: this.wi_weight,

        pkgs: this.wi_pkgs,

        tax: this.wi_tax,

        sdisc: this.wi_sdisc,

        etype: this.wi_etype,

        exfor: this.wi_exfor,

        rate: this.wi_rate,

        stkcode: this.wi_stkcode,

        balance: this.wi_balance,

        conv: this.wi_conv,

        plarg: this.wi_plarg,

        entno: this.wi_entno,

        pb_wt: this.wi_pb_wt,

        freight1: this.wi_freight1,

        weighing: this.wi_weighing,

        pla: this.wi_pla,

        tds_frt: this.wi_tds_frt,

        tdsrate: this.wi_tdsrate,

        cess: this.wi_cess,

        vbillno1: this.wi_vbillno1,

        vbdate1: this.wi_vbdate1,

        vamt1: this.wi_vamt1,

        duedate: this.wi_duedate,

        cl_date: this.wi_cl_date,

        vacode1: this.wi_vacode1,

        hcess: this.wi_hcess,

        trpt: this.wi_trpt,

        weight_ch: this.wi_weight_ch,

        vamt_ch: this.wi_vamt_ch,

        vdate_ch: this.wi_vdate_ch,

        vhead: this.wi_vhead,

        credit: this.wi_credit,

        pcess: this.wi_pcess,

        tcs_cess: this.wi_tcs_cess,

        tcs_hcess: this.wi_tcs_hcess,

        exp1: this.wi_exp1,

        exp2: this.wi_exp2,

        exp3: this.wi_exp3,

        exp4: this.wi_exp4,

        exp5: this.wi_exp5,

        exp6: this.wi_exp6,

        exp7: this.wi_exp7,

        exp8: this.wi_exp8,

        exp9: this.wi_exp9,
        exp1_rate: this.wi_exp1_rate,

        exp2_rate: this.wi_exp2_rate,

        exp3_rate: this.wi_exp3_rate,

        exp4_rate: this.wi_exp4_rate,

        exp5_rate: this.wi_exp5_rate,

        exp6_rate: this.wi_exp6_rate,

        exp7_rate: this.wi_exp7_rate,

        exp8_rate: this.wi_exp8_rate,

        exp9_rate: this.wi_exp9_rate,

        exp10_rate: this.wi_exp10_rate,

        rem1: this.wi_rem1,

        rem2: this.wi_rem2,

        rem3: this.wi_rem3,

        rem4: this.wi_rem4,

        transport: this.wi_transport,

        order: this.wi_order,

        order_date: this.wi_order_date,

        agent: this.wi_agent,

        broker: this.wi_broker,

        cd_rate: this.wi_cd_rate,

        cd: this.wi_cd,

        sch_rate: this.wi_sch_rate,

        scheme: this.wi_scheme,

        srv_rate: this.wi_srv_rate,

        srv_tax: this.wi_srv_tax,

        inv_tm: this.wi_inv_tm,

        rev_dt: this.wi_rev_dt,

        rem5: this.wi_rem5,

        rem6: this.wi_rem6,

        rem7: this.wi_rem7,

        rem8: this.wi_rem8,

        cvd: this.wi_cvd,

        exrate: this.wi_exrate,

        cessrate: this.wi_cessrate,

        hcrate: this.wi_hcrate,

        cvdrate: this.wi_cvdrate,

        exp_before: this.wi_exp_before,

        exp_after: this.wi_exp_after,

        tax_rate: this.wi_tax_rate,

        exp10: this.wi_exp10,

        loose: this.wi_loose,

        spec: this.wi_spec,

        pckng: this.wi_pckng,

        wf: this.wi_wf,

        wwf: this.wi_wwf,

        bill: this.wi_bill,

        stk_code: this.wi_stk_code,

        rateins: this.wi_rateins,

        srates: this.wi_srates,

        qpps: this.wi_qpps,

        tcs: this.wi_tcs,

        tcs1: this.wi_tcs1,

        tcs2: this.wi_tcs2,

        tcs_rate: this.wi_tcs_rate,

        tcs1_rate: this.wi_tcs1_rate,

        tcs2_rate: this.wi_tcs2_rate,

        saletype: this.wi_saletype,

        unit_ex: this.wi_unit_ex,

        unit_cs: this.wi_unit_cs,

        unit_hs: this.wi_unit_hs,

        unit_cv: this.wi_unit_cv,

        cd1: this.wi_cd1,

        cd1_rate: this.wi_cd1_rate,

        tariff: this.wi_tariff,

        exp1_ex: this.wi_exp1_ex,

        exp2_ex: this.wi_exp2_ex,

        weights: this.wi_weights,

        exp1_exr: this.wi_exp1_exr,

        exp2_exr: this.wi_exp2_exr,

        rem9: this.wi_rem9,

        rem10: this.wi_rem10,

        exp01: this.wi_exp01,

        exp01code: this.wi_exp01code,

        p_vbillno: this.wi_p_vbillno,

        usname: this.wi_usname,

        usrate: this.wi_usrate,

        usvamt: this.wi_usvamt,

        cardno: this.wi_cardno,

        ctax: this.wi_ctax,

        ctax_rate: this.wi_ctax_rate,

        stax: this.wi_stax,

        stax_rate: this.wi_stax_rate,

        itax: this.wi_itax,

        itax_rate: this.wi_itax_rate,

        valpha: this.wi_valpha,

        vno: this.wi_vno,

        vtype: this.wi_vtype,

        vamtcode: this.wi_vamtcode,

        vbillno: this.wi_vbillno,

        vbdate: this.wi_vbdate,

        excise: this.wi_excise,

        counter: this.wi_counter,

        btype: this.wi_btype,

        srno1: this.wi_srno1,

        ppcode: this.wi_ppcode,

        emcode: this.wi_emcode,

        mon: this.wi_mon,

        initial: this.wi_initial,

        vacode_ch: this.wi_vacode_ch,

        record: this.wi_record,

        vhead_ch: this.wi_vhead_ch,

        remarks: this.wi_remarks,

        tick: this.wi_tick,

        debit: this.wi_debit,

        vat: this.wi_vat,

        gr: this.wi_gr,

        rev_tm: this.wi_rev_tm,

        inv_dt: this.wi_inv_dt,

        total: this.wi_total,

        b_tpt: this.wi_b_tpt,

        sub_total: this.wi_sub_total,

        party_code: this.wi_party_code,

        tx_from: this.wi_tx_from,

        tx_upto: this.wi_tx_upto,

        tx_type: this.wi_tx_type,

        ssr: this.wi_ssr,

        vat_post: this.wi_vat_post,

        led_post: this.wi_led_post,

        ex_post: this.wi_ex_post,

        stk_post: this.wi_stk_post,

        opening: this.wi_opening,

        purr: this.wi_purr,

        sale: this.wi_sale,

        prdd: this.wi_prdd,

        issuee: this.wi_issuee,

        closing: this.wi_closing,

        purtype: this.wi_purtype,

        ahead: this.wi_ahead,

        add1: this.wi_add1,

        add2: this.wi_add2,

        city: this.wi_city,

        tin: this.wi_tin,

        phone: this.wi_phone,

        cash_name: this.wi_cash_name,

        cash_add1: this.wi_cash_add1,

        cash_city: this.wi_cash_city,

        tax0_sale: this.wi_tax0_sale,

        tax1_sale: this.wi_tax1_sale,

        p_vdate: this.wi_p_vdate,

        p_vno: this.wi_p_vno,

        p_valpha: this.wi_p_valpha,

        p_counter: this.wi_p_counter,

        user_name: this.wi_user_name,

        emistatus: this.wi_emistatus,

        p_pageno: this.wi_p_pageno,

        p_entry: this.wi_p_entry,

        taxsurr: this.wi_taxsurr,

        o_vdate: this.wi_o_vdate,

        o_vno: this.wi_o_vno,

        o_valpha: this.wi_o_valpha,

        o_counter: this.wi_o_counter,

        rem11: this.wi_rem11,

        cashrec: this.wi_cashrec,

        bank: this.wi_bank,

        bcode: this.wi_bcode,

        exp3_ex: this.wi_exp3_ex
      };

      var finaldata = { data: [] };
      finaldata.data = columndata.data.slice();

      alert(labeldata["stkcode"])

      var flag = 0;

      for (let m = 0; m <= Object.keys(orderdata).length; m++) {
        if (flag == 0) {
          var f = columndata.data[m];

          finaldata.data.splice(
            parseInt(parseInt(orderdata[Object.keys(orderdata)[m]]) - 1),
            1,
            f
          );
          // alert(JSON.stringify(finaldata))

          if (m == Object.keys(orderdata).length - 1) {
            for (let g = 0; g < Object.keys(orderdata).length; g++) {
              var v = {};
              var l = Object.keys(finaldata.data[g])[0];
              v[l] = finaldata.data[g][Object.keys(finaldata.data[g])[0]];

              v["dv_order"] = g;
              
              v["labeltext"] =
                labeldata[l] + "";
                v["width"]= widthdata[l]
                
              flag = 1;

              lastdata.data.push(v);
            }
          }
        } else {
          alert("hhh" + m);
          alert(JSON.stringify(finaldata));
          n.dataAll.data = lastdata;

          alert(JSON.stringify(n));

          axios
            .post("/transactions/saveSaleSeries", n)
            .then(response => {
              ////alert(JSON.stringify(response.data));

              //this.DuplicateNotify(JSON.stringify(response.data));
              let resp = JSON.stringify(response.data.dooda);
              resp = resp.slice(0, -1);
              resp = resp.substring(1);

              if (resp == "duplicate") {
                this.DuplicateNotify();
              } else {
                this.Savenotify();
                this.latestCode = this.latestCode + 1;
                this.requiredIndex = -999;
              }

              //this.Savenotify();
              // //alert("saved")
            })
            .catch(error => {
              alert(error);
            });
        }
      }

      this.buttondis_true();
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = false;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.crdis = true;
      this.drdis = true;
      document.getElementById("addButton").focus();
      (this.buttonActiveList = [
        "active",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive",
        "inactive"
      ]),
        this.$forceUpdate();
    },

    getData(text) {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;
      let ch;
      if (text == "prev") {
        ch = parseInt(this.requiredIndex) - 1;
      }
      if (text == "next") {
        ch = parseInt(this.requiredIndex) + 1;
      }
      if (text == "init") {
        this.requiredIndex = -999;
      }

      var n = {
        companyname: companyName,
        requiredIndex: this.requiredIndex == -999 ? -999 : ch,
        note:"purchase"
      };
      // //alert(JSON.stringify(n));
      axios
        .post("/transactions/getSaleSeries", n)
        .then(response => {
          let resp = JSON.stringify(response.data);
          resp = JSON.parse(resp);
          if (resp.Ahead == "out of bounds" || resp.Ahead == "no data") {
            // //alert("do nothingresp.AcName);
          } else {
            // //alert("do something with" + resp.index)
            var keys = [];
            var values = [];
            let datas = resp.data.data;
            var columndata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              keys.push(Object.keys(item)[0]);
              values.push(item[Object.keys(item)[0]]);

              columndata[keys[index]] = values[index];
              //}
            });

            var valuesorder = [];

            var orderdata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{
              valuesorder.push(item[Object.keys(item)[1]]);

              orderdata[keys[index]] = parseInt(valuesorder[index]) + 1;
              //}
            });

          
            var valueslabel = [];

            var labeldata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              
              valueslabel.push(item[Object.keys(item)[2]]);

              labeldata[keys[index]] = valueslabel[index];
              //}
            });

            
            var valueswidth = [];

            var widthdata = {};
            datas.forEach(function(item, index) {
              // console.table('Key : ' + key + ', Value : ' + item.columndata[key])
              //  if(columndata[key] == true)
              //{

              valueswidth.push(item[Object.keys(item)[3]]);

              widthdata[keys[index]] = valueswidth[index];
              //}
            });

            this.Ahead = resp.Ahead;
            this.Form_type = resp.Form_type;
            this.Led_post = resp.Led_post;
            this.Vat_post = resp.Vat_post;
            this.Ex_post = resp.Ex_post;
            this.Serial = resp.Serial;
            this.Short_name = resp.Short_name;
            this.Stk_post = resp.Stk_post;
            this.Form_rtype = resp.Form_rtype;
            this.Rep_name = resp.Rep_name;
            this.Bill_no_h = resp.Bill_no_h;
            this.Salef3 = resp.Salef3;
            this.Tick = resp.Tick;
            this.Vacode = resp.Vacode;
            this.Rep_gst = resp.Rep_gst;
            this.cont = resp.cont;
            this.bufferIndex = resp.index;

            this.setSetupData(columndata, orderdata, labeldata,widthdata);

            this.requiredIndex = parseInt(resp.index);
          }
        })
        .catch(error => {
          alert("rahul" + error);
        });

      // //alert("Request to get sent!");
    },

    onDelete() {
      var user = sessionStorage.getItem("user");
      var companyName = JSON.parse(user)[0].companyname;

      ////alert(this.group);

      var n = {
        indexToDelete: this.bufferIndex,
        companyname: companyName,
        note:"purchase"
      };
      ////alert("Sending these to deleteJSON.stringify(n));
      axios
        .post("http://localhost:2000/deleteLedger", n)
        .then(response => {
          ////alert(JSON.stringify(response.data));

          //this.DuplicateNotify(JSON.stringify(response.data));
          let resp = JSON.stringify(response.data);
          resp = resp.slice(0, -1);
          resp = resp.substring(1);
          console.log(resp);
          window.location.href = "/dashboard/newledgervue";
        })
        .catch(error => {
          alert(error);
        });
    },
    onExit() {
      //  this.buttondis = true;
      this.buttondis_true();
      this.buttonen = false;
      this.disAdd = false;
      this.disCopy = false;
      this.disDelete = false;
      this.disEdit = false;
      this.disFirst = false;
      this.disLast = false;
      this.disNext = false;
      this.disSave = true;
      this.disSearch = false;
      this.disPrinter = false;
      this.disPrevious = false;
      this.disExit = false;
      this.crdis = true;
      this.drdis = true;
      this.dbIndex = -999;
      this.titleAction = "View";
      this.getLast();
      this.buttondis = true;
      this.showdrcr = false;
    },

    editButton() {
      this.titleAction = "Edit";
      // alert(document.getElementById("emaildata").value)
      this.dbIndex = this.bufferIndex;
      alert(this.bufferIndex);
      // //alert(this.dbIndex);

      this.buttonen = true;
      this.disSave = false;
      this.showdrcr = true;
      this.crdis = false;
      this.drdis = false;
      this.disAdd = true;
      this.buttondis_false();
      this.buttonen = true;
      this.disCopy = false;
      this.disDelete = true;
      this.disEdit = true;
      this.disFirst = true;
      this.disLast = true;
      this.disNext = true;
      this.buttondis = false;
      this.disSearch = true;
      this.disPrinter = true;
      this.disPrevious = true;
      this.disExit = false;
      this.isEditingOld = true;

      if (this.OpeningBalanceDr == "" || this.OpeningBalanceDr == "0")
        this.buttondis_OpeningBalanceDr = true;

      if (this.OpeningBalanceCr == "" || this.OpeningBalanceCr == "0")
        this.buttondis_OpeningBalanceCr = true;

      //document.getElementById("acname").focus()
      this.shortfunctionsecond("acnamedatafocus");
    },

    computed: {
      now: function() {
        var today = new Date();
        var date =
          today.getFullYear() +
          "-" +
          (today.getMonth() + 1) +
          "-" +
          today.getDate();
        return date;
      },
      currentday: function() {
        var today = new Date();
        var weekday = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday"
        ];
        var currenday = weekday[today.getDay()];
        return currenday;
      }
    },

    enterKeyTrig(p) {
      var id = p.slice(0, -1);
      var k = p.substring(p.length - 1, p.length);
      k = parseInt(k);

      var val = "saveButton";

      ////alert(JSON.stringify(this.cashVauchers[k].accountno));
      // console.log(id);

      if (id == "accountno") {
        if (this.cashVauchers[k].accountno == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "narration") {
        if (this.cashVauchers[k].narration == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "payment") {
        if (this.cashVauchers[k].payment == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      } else if (id == "receipt") {
        if (this.cashVauchers[k].receipt == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }

      if (id == "discount") {
        if (k == this.cashVauchers.length - 1) {
          this.cashVauchers.push({
            accountno: "",
            narration: "",
            payment: "",
            receipt: "",
            discount: ""
          });

          this.addNotify();
        } else if (this.cashVauchers[k].discount == "") {
          this.buttonActiveList[11] = "active";
          document.getElementById(val).focus();
          this.$forceUpdate();
        }
      }
    },
    Savenotify() {
      this.$vs.notify({
        title: "Success",
        text: "Saved Annexure Data Successfully",
        iconPack: "feather",
        icon: "icon-//alert-circle",
        color: "success"
      });
    },
    DuplicateNotify() {
      this.$vs.notify({
        title: "Error",
        text: "Duplicate Name not allowed!",
        iconPack: "feather",
        icon: "icon-//alert-circle",
        color: "danger"
      });
    }
  },
  created() {
    this.reload = sessionStorage.getItem("reload");

    var user = sessionStorage.getItem("user");

    var companyName = JSON.parse(user)[0].companyname;

    this.companyname = companyName;
    //alert(companyName)
    var type = JSON.parse(user)[0].type;

    if (type == "user") {
      var Role = sessionStorage.getItem("role");
      //  var permissions = JSON.parse(Role)[0].rolename.permission[0].roletype;
      var perm = JSON.parse(Role);
      var Add = perm[0].rolename.permission[0].roletype.Add;
      var modify = perm[0].rolename.permission[0].roletype.modify;
      var del = perm[0].rolename.permission[0].roletype.delete;

      console.log(Add + " " + modify + " " + del);
    }
    var v = [];
    let that = this;
    var i;
    var value1 = {
      companyname: companyName,
      directory: "ledger_master.json"
    };
    axios
      .post("/user/getCashformData", value1)
      .then(response => {
        var data = JSON.stringify(response.data);

        var json = JSON.parse(data);
        // this.users = json.ledgerdata;
        //  alert(JSON.stringify(json.ledgerdata))

        for (i = 0; i < json.ledgerdata.length; i++) {
          v.push(json.ledgerdata[i].AcName + "");
          that.acnamedata = v;
        }

        this.filteredUsers = this.users;
      })
      .catch(error => {
        alert(error);
      });

    var value2 = {
      companyname: companyName,
      directory: "narration.json"
    };
    axios
      .post("/user/getCashformData", value2)
      .then(response => {
        //alert("api 1")
        var data = JSON.stringify(response.data);
        //alert("api called 1" +data)
        var json = JSON.parse(data);

        json.narrations.filter(function(item, index) {
          if (item["area"] + "" != "undefined") {
            that.narrations = json.narrations[index]["area"];

            that.filteredAreaNarrations = that.narrations;
            v = [];

            for (i = 0; i < that.narrations.length; i++) {
              v.push(that.narrations[i].name + "");
              that.spdata = v;
            }
          }

          if (item["City"] + "" != "undefined") {
            that.filteredCityNarrations = json.narrations[index]["City"];
            v = [];

            for (i = 0; i < that.filteredCityNarrations.length; i++) {
              v.push(that.filteredCityNarrations[i].name + "");
              that.citydata = v;
            }
          }

          // if(item["AcName"]+""!="undefined")
          // {

          //       that.filteredAcNameNarrations = json.narrations[index]["AcName"]
          //       v = [];

          //       for (i = 0; i < that.filteredAcNameNarrations.length; i++) {
          //         v.push(that.filteredAcNameNarrations[i].name + "");
          //         that.acnamedata = v;

          //       }
          // }

          if (item["Distt"] + "" != "undefined") {
            that.filteredDisttNarrations = json.narrations[index]["Distt"];
            v = [];

            for (i = 0; i < that.filteredDisttNarrations.length; i++) {
              v.push(that.filteredDisttNarrations[i].name + "");
              that.disttdata = v;
            }
          }

          if (item["Works"] + "" != "undefined") {
            that.filteredWorksNarrations = json.narrations[index]["Works"];
            v = [];

            for (i = 0; i < that.filteredWorksNarrations.length; i++) {
              v.push(that.filteredWorksNarrations[i].name + "");
              that.worksdata = v;
            }
          }

          if (item["email"] + "" != "undefined") {
            that.filteredEmailNarrations = json.narrations[index]["email"];
            v = [];

            for (i = 0; i < that.filteredEmailNarrations.length; i++) {
              v.push(that.filteredEmailNarrations[i].name + "");
              that.emaildata = v;
            }
          }

          if (item["group"] + "" != "undefined") {
            that.filteredGroupNarrations = json.narrations[index]["group"];
            v = [];

            for (i = 0; i < that.filteredGroupNarrations.length; i++) {
              v.push(that.filteredGroupNarrations[i].name + "");
              that.groupdata = v;
            }
          }
        });
      })
      .catch(error => {
        alert(error);
      });
  },

  mounted() {
    // //alert("page mounted");\
    let user = sessionStorage.getItem("user");
    let companyName = JSON.parse(user)[0].companyname;
    this.titleAction = "View";

    this.getledgersetup();
    this.getData("prev");
    var n = {
      companyname: companyName
    };

    axios
      .post("http://localhost:2000/GetAllAnnexureNames", n)
      .then(response => {
        ////alert(JSON.stringify(response.data));

        let data = JSON.stringify(response.data);

        let json = JSON.parse(data);
        this.annexures = json.names;
        //alert(JSON.stringify(this.annexures));
        this.filteredAnnexures = this.annexures;
      })
      .catch(error => {
        alert(error);
      });

    let that = this;
    window.addEventListener("keydown", function(event) {
      if (event.keyCode == 18) {
        if (that.currentfield == "comboarea") {
          that.showdescNar("area");
        } else if (that.currentfield == "combogroup") {
          that.showdescNar("group");
        } else if (that.currentfield == "Works") {
          that.showdescNar("Works");
        } else if (that.currentfield == "Distt") {
          that.showdescNar("Distt");
        } else if (that.currentfield == "AcName") {
          that.showdescNar("AcName");
        } else if (that.currentfield == "City") {
          that.showdescNar("City");
        } else if (that.currentfield == "comboemail") {
          that.showdescNar("email");
        }
      }
      // If  ESC key was pressed...
      if (event.keyCode === 27) {
        if (that.popupActive3 == true) {
          that.popupActive3 = false;
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }

        if (that.setupForm == true) {
          that.setupForm = false;
        }
        if (that.drcrpopup == true) {
          that.drcrpopup = false;
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
      }
      if (event.keyCode === 38) {
        // up arrow
        if (that.popupActive3 == true) {
          that.popupKeyUp();
        }

        that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
      }
      if (event.keyCode === 13 && event.ctrlKey) {
        // up arrow
        that.save();

        that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
      }
      if (event.keyCode === 40) {
        // down arrow

        if (that.popupActive3 == true) {
          that.popupKeyDown();
        }
        that.$forceUpdate();
      }
      if (event.keyCode === 13) {
        if (that.titleAction == "View" && that.popupActive2 == false) {
          that.newdisable();
        } else if (that.popupActive3 == true) {
          that.popupActive3 = false;
          //alert(document.getElementById("drcr" + that.popupSelectedRow))
          that.annexureText =
            that.filteredAnnexures[that.popupSelectedRow].name;

          that.shortfunctionsecond("acnamedatafocus2");
          that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
        }
        // enter
        else if (that.currentfield == "AcName") {
          event.preventDefault();
        }
      }
      if (event.keyCode === 80) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newledgervue") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getData("prev");

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 78) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newledgervue") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getData("next");

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 70) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newledgervue") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getFirst();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
      if (event.keyCode === 76) {
        // alert(that.$router.currentRoute.path)
        if (that.$router.currentRoute.path == "/dashboard/newledgervue") {
          //alert("df")
          //alert(that.disEdit+" "+ that.disAdd+" "+ that.disPrevious+" "+ that.nextButton+" "+ that.lastButton+" "+ that.firstButton+" "+ that.searchButton+" "+ that.moveButton+" "+ that.printButton)
          if (
            that.disEdit == false &&
            that.disAdd == false &&
            that.disPrevious == false &&
            that.disNext == false &&
            that.disLast == false &&
            that.disFirst == false &&
            that.disSearch == false &&
            that.disPrinter == false
          ) {
            that.getLast();

            that.$forceUpdate(); // Need to force an update cuz changing a variable doesn't load the state automatically
          }
        }
      }
    });
  }
};
</script>
