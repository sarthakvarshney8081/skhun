

import Vue from 'vue'
import Router from 'vue-router'


Vue.use(Router)

const router = new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    scrollBehavior () {
        return { x: 0, y: 0 }
    },
    routes: [

        {
    // =============================================================================
    // MAIN LAYOUT ROUTES
    // =============================================================================
            path: '',
            component: () => import('./layouts/main/Main.vue'),
            children: [
        // =============================================================================
        // Theme Routes
        // =============================================================================
                {
                    path: '/',

                    redirect: '/pages/login'
                },
                {
                    path: '/dashboard/rrrr',
                    name: 'dashboard-user1',
                    component: () => import('./views/skcompany/rrrr.vue'),
                    meta: {
                        rule: 'editor',
                    }
                },
                {
                    path: '/dashboard/analytics',
                    name: 'dashboard-analytics',
                    component: () => import('./views/DashboardAnalytics.vue'),
                    meta: {
                        rule: 'editor',
                    }
                },
                {
                    path: '/dashboard/company',
                    name: 'dashboard-company',
                    component: () => import('@/views/apps/user/user-list/UserList.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },

                {
                    path: '/dashboard/company-add',
                    name: 'dashboard-company-add',
                    component: () => import('@/views/skcompany/newcompany.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/user',
                    name: 'dashboard-user',
                    component: () => import('@/views/skcompany/user.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/role',
                    name: 'dashboard-role-add',
                    component: () => import('@/views/apps/user/user-edit/UserEdit.vue'),
                    meta: {
                        breadcrumb: [
                            { title: 'Home', url: '/' },
                            { title: 'User' },
                            { title: 'Edit', active: true },
                        ],
                        pageTitle: 'User Edit',
                        rule: 'editor'
                    }
                },
             
               

                

                {
                    path: '/dashboard/sale-gst',
                    name: 'dashboard-sale-gst',
                    component: () => import('@/views/skpage/seriesselection.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/Recolliation',
                    name: 'dashboard-sale-gst',
                    component: () => import('@/views/skpage/Recolliation.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/sale-page',
                    name: 'dashboard-sale-page',
                    component: () => import('@/views/ui-elements/data-list/list-view/salegst.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                
                {
                    path: '/dashboard/sale-gst-dev',
                    name: 'dashboard-sale-gst-dev',
                    component: () => import('@/views/ui-elements/data-list/list-view/salegstwithvshow.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/sale-gstform',
                    name: 'dashboard-sale-gstform',
                    component: () => import('@/views/skpage/salegstform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/purchasegstforms',
                    name: 'dashboard-purchaseform',
                    component: () => import('@/views/skpage/purchaseselection.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/companyinfo',
                    name: 'dashboard-company-info',
                    component: () => import('@/views/skpage/company info.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/purchase-page',
                    name: 'dashboard-purchase-page',
                    component: () => import('@/views/skpage/purchasegstform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/cashvoucher',
                    name: 'dashboard-cashform',
                    component: () => import('@/views/skpage/cashform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/cashreceipt',
                    name: 'dashboard-cashform',
                    component: () => import('@/views/skpage/cashformre.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/journal',
                    name: 'dashboard-journal',
                    component: () => import('@/views/skpage/journalform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/bank',
                    name: 'dashboard-bank',
                    component: () => import('@/views/skpage/bankselection.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/bankform',
                    name: 'dashboard-bank',
                    component: () => import('@/views/skpage/bankform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/tdsvouchar',
                    name: 'dashboard-tsd',
                    component: () => import('@/views/skpage/tdsselection.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/tdsvoucharform',
                    name: 'dashboard-tsd-form',
                    component: () => import('@/views/skpage/tdsvoucharform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                { path: '/dashboard/newledger',
                redirect: '/dashboard/newledgervue'
                },

                {
                    path: '/dashboard/newledgervue',
                    name: 'dashboard-tsd',
                    
                    component: () => import('@/views/skpage/newledgerform.vue'),
                    meta: {
                        rule: 'admin',
                        reload: true
                       
                    }
                },
                {
                    path: '/dashboard/TCS Reports',
                    name: 'dashboard-purchaseform',
                    component: () => import('@/views/skpage/TCS Reports.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },



                {
                    path: '/dashboard/billsection',
                    name: 'dashboard-purchaseform',
                    component: () => import('@/views/skpage/billsection.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },



                // {
                //     path: '/dashboard/selectproduct',
                //     name: 'dashboard-purchaseform',
                //     component: () => import('@/views/skpage/selectproduct.vue'),
                //     meta: {
                //         rule: 'admin'
                //     }
                // },
                {
                    path: '/dashboard/newstockacc',
                    name: 'dashboard-stck',
                    component: () => import('@/views/skpage/newstockaccform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/definehsn',
                    name: 'dashboard-hsn',
                    component: () => import('@/views/skpage/definehsn.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/productionchart',
                    name: 'dashboard-chart',
                    component: () => import('@/views/skpage/productionchart.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/stocktransfer',
                    name: 'dashboard-chart',
                    component: () => import('@/views/skpage/stocktransfer.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/annexure',
                    name: 'dashboard-annexure',
                    component: () => import('@/views/skpage/annexure.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/inventory',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inventory.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/inveorderstatpur',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inveorderstatpur.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/inveorderstatsale',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inveorderstatsale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/invematerialissueform',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invematerialissueform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
              
                {
                    path: '/dashboard/invematerialrec',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invematerialrec.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                
                {
                    path: '/dashboard/inveproduction',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inveproduction.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/inveconsumption',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inveconsumption.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/invematerialtest',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invematerialtest.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/invejobworklist',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invejobworklist.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/invependingchallansale',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invependingchallansale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/invependigcallanpurchase',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/invependigcallanpurchase.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/inveledgerpost',
                    name: 'dashboard-inventory',
                    component: () => import('@/views/skpage/inveledgerpost.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },




                {
                    path: '/dashboard/banking',
                    name: 'dashboard-banking',
                    component: () => import('@/views/skpage/banking.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/bankpass',
                    name: 'dashboard-bankpass',
                    component: () => import('@/views/skpage/bankpasbook.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/reconciliation',
                    name: 'dashboard-reconciliation',
                    component: () => import('@/views/skpage/reconciliation.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/stockmargin',
                    name: 'dashboard-stockmargin',
                    component: () => import('@/views/skpage/stockmarginreport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                
                {
                    path: '/dashboard/goodreturnpur',
                    name: 'dashboard-return',
                    component: () => import('@/views/skpage/goodsreturnpurchase.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/goodreturnsale',
                    name: 'dashboard-sale',
                    component: () => import('@/views/skpage/goodsreturnsale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/creditnote',
                    name: 'dashboard-creditnote',
                    component: () => import('@/views/skpage/creditnote.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/debitnote',
                    name: 'dashboard-debitnote',
                    component: () => import('@/views/skpage/debitnote.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/cashreceiptform',
                    name: 'dashboard-cashreform',
                    component: () => import('@/views/skpage/cashreceiptform.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/salegstchallan',
                    name: 'dashboard-salereturn',
                    component: () => import('@/views/skpage/salegstchallan.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/salegstchallan2',
                    name: 'dashboard-salereturn',
                    component: () => import('@/views/skpage/salegstchallan2.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

          // Report Link

               {
                    path: '/dashboard/accountstatement',
                    name: 'dashboard-salereturn',
                    component: () => import('@/views/skreport/accountstatement.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/trialbal',
                    name: 'dashboard-trialbal',
                    component: () => import('@/views/skreport/trialbal.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/balancesheet',
                    name: 'dashboard-balance',
                    component: () => import('@/views/skreport/balancesheet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/bookcash',
                    name: 'dashboard-bookcash',
                    component: () => import('@/views/skreport/bookcash.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/bookjournal',
                    name: 'dashboard-bookjurnal',
                    component: () => import('@/views/skreport/bookjournal.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/bookbank',
                    name: 'dashboard-bookbank',
                    component: () => import('@/views/skreport/bookbank.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/booksale',
                    name: 'dashboard-booksale',
                    component: () => import('@/views/skreport/booksale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/bookpurchase',
                    name: 'dashboard-bookpurchase',
                    component: () => import('@/views/skreport/bookpurchase.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/booktds',
                    name: 'dashboard-booktds',
                    component: () => import('@/views/skreport/booktds.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/bookrecieptbook',
                    name: 'dashboard-booktds',
                    component: () => import('@/views/skreport/bookrecieptbook.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/bookvoucherprint',
                    name: 'dashboard-booktds',
                    component: () => import('@/views/skreport/bookvoucherprint.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/summerysale',
                    name: 'dashboard-summerycash',
                    component: () => import('@/views/skreport/summerysale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/summerypurchase',
                    name: 'dashboard-summerypur',
                    component: () => import('@/views/skreport/summerypurchase.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },



                {
                    path: '/dashboard/sumcash',
                    name: 'dashboard-sumcash',
                    component: () => import('@/views/skreport/summerycash.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

            

                {
                    path: '/dashboard/ledgerprint',
                    name: 'dashboard-trialbal',
                    component: () => import('@/views/skreport/ledgerprint.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/ledgerindex',
                    name: 'dashboard-ledgerindex',
                    component: () => import('@/views/skreport/ledgerindex.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/ledgersummary',
                    name: 'dashboard-ledgersummary',
                    component: () => import('@/views/skreport/ledgersummary.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/outdebitors',
                    name: 'dashboard-outdebitors',
                    component: () => import('@/views/skreport/outdebitors.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                

                {
                    path: '/dashboard/outcreditors',
                    name: 'dashboard-outcreditors',
                    component: () => import('@/views/skreport/outcreditors.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/outgroupsummery',
                    name: 'dashboard-outgrpsum',
                    component: () => import('@/views/skreport/outgroupsummery.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },



                {
                    path: '/dashboard/stockreport',
                    name: 'dashboard-stockreport',
                    component: () => import('@/views/skreport/stockreport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/stocksumm',
                    name: 'dashboard-stocksumm',
                    component: () => import('@/views/skreport/stocksumm.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/stocksummary',
                    name: 'dashboard-stocksummary',
                    component: () => import('@/views/skreport/stocksummary.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/stockledger',
                    name: 'dashboard-stockledger',
                    component: () => import('@/views/skreport/stockledger.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/stockotherdet',
                    name: 'dashboard-stockotherdet',
                    component: () => import('@/views/skreport/stockotherdet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/stockpartywise',
                    name: 'dashboard-stockpartywise',
                    component: () => import('@/views/skreport/stockpartywise.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/stockproducregis',
                    name: 'dashboard-stockproducregis',
                    component: () => import('@/views/skreport/stockproducregis.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/stockpices',
                    name: 'dashboard-stockpices',
                    component: () => import('@/views/skreport/stockpices.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/exciseregister',
                    name: 'dashboard-exciseregister',
                    component: () => import('@/views/skreport/exciseregister.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/excisestockregister',
                    name: 'dashboard-excisestockreport',
                    component: () => import('@/views/skreport/excisestockregister.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/excisereport',
                    name: 'dashboard-excisereport',
                    component: () => import('@/views/skreport/excisereport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/excisedutytransaction',
                    name: 'dashboard-excisedutytransaction',
                    component: () => import('@/views/skreport/excisedutytransaction.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                


                {
                    path: '/dashboard/exisecurrentreport',
                    name: 'dashboard-exisecurrentreport',
                    component: () => import('@/views/skreport/exisecurrentreport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/gstrepgstled',
                    name: 'dashboard-gstrepgstled',
                    component: () => import('@/views/skreport/gstrepgstled.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


               
                {
                    path: '/dashboard/productwisesale',
                    name: 'dashboard-productwisesale',
                    component: () => import('@/views/skreport/productwisesale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/purchasestatewisesummary',
                    name: 'dashboard-productwisesale',
                    component: () => import('@/views/skreport/purchasestatewisesummary.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/salepartywisesummary',
                    name: 'dashboard-productwisesale',
                    component: () => import('@/views/skreport/salepartywisesummary.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepmonthly',
                    name: 'dashboard-gstrepmonthly',
                    component: () => import('@/views/skreport/gstrepmonthly.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/gstreppartywisegstsumm',
                    name: 'dashboard-gstreppartywisegstsumm',
                    component: () => import('@/views/skreport/gstreppartywisegstsumm.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepworksheet',
                    name: 'dashboard-gstrepworksheet',
                    component: () => import('@/views/skreport/gstrepworksheet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepwisegstdet',
                    name: 'dashboard-gstrepwisegstdet',
                    component: () => import('@/views/skreport/gstrepwisegstdet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepaccwiserep',
                    name: 'dashboard-gstrepaccwiserep',
                    component: () => import('@/views/skreport/gstrepaccwiserep.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepotherdet',
                    name: 'dashboard-gstrepotherdet',
                    component: () => import('@/views/skreport/gstrepotherdet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstrepyearlygst',
                    name: 'dashboard-gstrepyearlygst',
                    component: () => import('@/views/skreport/gstrepyearlygst.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstreptaxsale',
                    name: 'dashboard-gstreptaxsale',
                    component: () => import('@/views/skreport/gstreptaxsale.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/gstreptaxpurchase',
                    name: 'dashboard-gstreptaxpurchase',
                    component: () => import('@/views/skreport/gstreptaxpurchase.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },



                {
                    path: '/dashboard/tdsform16',
                    name: 'dashboard-tdsform16',
                    component: () => import('@/views/skreport/tdsform16.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },


                {
                    path: '/dashboard/tdsform26',
                    name: 'dashboard-tdsform26',
                    component: () => import('@/views/skreport/tdsform26.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/tdscommission',
                    name: 'dashboard-tdscommission',
                    component: () => import('@/views/skreport/tdscommission.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/tcsreport',
                    name: 'dashboard-tcsreport',
                    component: () => import('@/views/skreport/tcsreport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/incompurpartywise',
                    name: 'dashboard-incompurpartywise',
                    component: () => import('@/views/skreport/incompurpartywise.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incompurpartysumm',
                    name: 'dashboard-incompurpartysumm',
                    component: () => import('@/views/skreport/incompurpartysumm.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/incompurchprowisepur',
                    name: 'dashboard-incompurchprowisepur',
                    component: () => import('@/views/skreport/incompurchprowisepur.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incompurchprowisedetail',
                    name: 'dashboard-incompurchprowisedetail',
                    component: () => import('@/views/skreport/incompurchprowisedetail.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incompurbroker',
                    name: 'dashboard-incompurbroker',
                    component: () => import('@/views/skreport/incompurbroker.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/icomsalestatewisesumm',
                    name: 'dashboard-icomsalestatewisesumm',
                    component: () => import('@/views/skreport/icomsalestatewisesumm.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incomsaleproductwisedet',
                    name: 'dashboard-incomsaleproductwisedet',
                    component: () => import('@/views/skreport/incomsaleproductwisedet.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incomsaleaccountwise',
                    name: 'dashboard-incomsaleaccountwise',
                    component: () => import('@/views/skreport/incomsaleaccountwise.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incomsaleotherreport',
                    name: 'dashboard-incomsaleotherreport',
                    component: () => import('@/views/skreport/incomsaleotherreport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/incomsaleagentwise',
                    name: 'dashboard-incomsaleagentwise',
                    component: () => import('@/views/skreport/incomsaleagentwise.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/servicetaxlist',
                    name: 'dashboard-servicetaxlist',
                    component: () => import('@/views/skreport/servicetaxlist.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/otherintcalindv',
                    name: 'dashboard-otherintcalindv',
                    component: () => import('@/views/skreport/otherintcalindv.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                
                {
                    path: '/dashboard/otherintcalgroup',
                    name: 'dashboard-otherintcalgroup',
                    component: () => import('@/views/skreport/otherintcalgroup.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },

                {
                    path: '/dashboard/othercformlist',
                    name: 'dashboard-othercformlist',
                    component: () => import('@/views/skreport/othercformlist.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherdailymargin',
                    name: 'dashboard-otherdailymargin',
                    component: () => import('@/views/skreport/otherdailymargin.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/othershortagelist',
                    name: 'dashboard-othershortagelist',
                    component: () => import('@/views/skreport/othershortagelist.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/othercomprep',
                    name: 'dashboard-othercomprep',
                    component: () => import('@/views/skreport/othercomprep.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherdiscountrep',
                    name: 'dashboard-otherdiscountrep',
                    component: () => import('@/views/skreport/otherdiscountrep.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherexcelformat',
                    name: 'dashboard-otherexcelformat',
                    component: () => import('@/views/skreport/otherexcelformat.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherinvoiceprinting',
                    name: 'dashboard-otherinvoiceprinting',
                    component: () => import('@/views/skreport/otherinvoiceprinting.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherconsignmentnote',
                    name: 'dashboard-otherconsignmentnote',
                    component: () => import('@/views/skreport/otherconsignmentnote.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherpollutionrep',
                    name: 'dashboard-otherpollutionrep',
                    component: () => import('@/views/skreport/otherpollutionrep.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/othercashinoice',
                    name: 'dashboard-othercashinoice',
                    component: () => import('@/views/skreport/othercashinoice.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/otherosalereport',
                    name: 'dashboard-othercashinoice',
                    component: () => import('@/views/skreport/otherosalereport.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                {
                    path: '/dashboard/checklist',
                    name: 'dashboard-checklist',
                    component: () => import('@/views/skreport/checklist.vue'),
                    meta: {
                        rule: 'admin'
                    }
                },
                
                
               
                
                







        // =============================================================================
        // Application Routes
        // =============================================================================
                {
                    path: '/apps/todo',
                    redirect: '/apps/todo/all',
                    name: 'todo',
                },
                {
                    path: '/apps/todo/:filter',
                    component: () => import('./views/apps/todo/Todo.vue'),
                    meta: {
                        rule: 'editor',
                        parent: "todo",
                        no_scroll: true,
                    }
                },
                {
                    path: '/apps/chat',
                    name: 'chat',
                    component: () => import('./views/apps/chat/Chat.vue'),
                    meta: {
                        rule: 'editor',
                        no_scroll: true,
                    }
                },
                {
                    path: '/apps/email',
                    redirect: '/apps/email/inbox',
                    name: 'email',
                },
                {
                    path: '/apps/email/:filter',
                    component: () => import('./views/apps/email/Email.vue'),
                    meta: {
                        rule: 'editor',
                        parent: 'email',
                        no_scroll: true,
                    }
                },
                {
                    path: '/apps/calendar/vue-simple-calendar',
                    name: 'calendar-simple-calendar',
                    component: () => import('./views/apps/calendar/SimpleCalendar.vue'),
                    meta: {
                        rule: 'editor',
                        no_scroll: true,
                    }
                },
               
            
            
               
        // =============================================================================
        // UI ELEMENTS
        // =============================================================================
               
            ],
        },
    // =============================================================================
    // FULL PAGE LAYOUTS
    // =============================================================================
        {
            path: '',
            component: () => import('@/layouts/full-page/FullPage.vue'),
            children: [
        // =============================================================================
        // PAGES
        // =============================================================================
                {
                    path: '/callback',
                    name: 'auth-callback',
                    component: () => import('@/views/Callback.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/login',
                    name: 'page-login',
                    component: () => import('@/views/pages/login/Login.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/register',
                    name: 'page-register',
                    component: () => import('@/views/pages/register/Register.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/forgot-password',
                    name: 'page-forgot-password',
                    component: () => import('@/views/pages/ForgotPassword.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/reset-password',
                    name: 'page-reset-password',
                    component: () => import('@/views/pages/ResetPassword.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/lock-screen',
                    name: 'page-lock-screen',
                    component: () => import('@/views/pages/LockScreen.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/comingsoon',
                    name: 'page-coming-soon',
                    component: () => import('@/views/pages/ComingSoon.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/error-404',
                    name: 'page-error-404',
                    component: () => import('@/views/pages/Error404.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/error-500',
                    name: 'page-error-500',
                    component: () => import('@/views/pages/Error500.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/not-authorized',
                    name: 'page-not-authorized',
                    component: () => import('@/views/pages/NotAuthorized.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },
                {
                    path: '/pages/maintenance',
                    name: 'page-maintenance',
                    component: () => import('@/views/pages/Maintenance.vue'),
                    meta: {
                        rule: 'editor'
                    }
                },













            
                {
                    path: '/apps/user/user-edit/:userId',
                    name: 'app-user-edit',
                    component: () => import('@/views/apps/user/user-edit/UserEdit.vue'),
                    meta: {
                       
                        rule: 'editor'
                    },
                },






            ]
        },
        // Redirect to 404 page, if no match found
        {
            path: '*',
            redirect: '/pages/error-404'
        }
    ],
})

router.afterEach(() => {
  // Remove initial loading
  const appLoading = document.getElementById('loading-bg')
    if (appLoading) {
        appLoading.style.display = "none";
    }
})



export default router