<template>

      
    <div :style="{'direction': $vs.rtl ? 'rtl' : 'ltr'}">
    
  <!-- <feather-icon icon="Edit3Icon" svgClasses="h-5 w-5 mr-4 hover:text-primary cursor-pointer" @click="editRecord" /> -->
      <!-- <feather-icon icon="UserIcon" svgClasses="h-5 w-5 hover:text-danger cursor-pointer" @click="confirmlogin" /> -->
     <vs-popup classContent="popup-example" title="Login" color="primary"    :active.sync="popupActive2">
         <p class="mb-3">Login to {{this.params.data.email}}</p>
        <vs-input class="inputx mb-3" placeholder="password" v-bind:id="this.params.data.email" type="password" autofocus="autfo" v-model="password" alignment="center" />
        <vs-button @click="loginRecored()" color="primary" type="filled">Login</vs-button>
             &nbsp;
        <vs-button @click="popupActive3=true;popupActive2=false" color="primary" type="filled">Forget Password</vs-button>
     <vs-popup title="Forget Password" :active.sync="popupActive3" on-v:keyup.esc="popupA()">
         <div class="centerx">
            <vs-input class="input mb-5" placeholder="password" v-model="pass" alignment="center"/>
            <vs-input class="input mb-5" placeholder="confirm password" v-model="confirmpass" alignment="center" />
         </div>   
       <vs-button @click="forgetpassword" color="primary" type="filled" align="center">Save Password</vs-button>
      </vs-popup> 
    
    </vs-popup>
     <vs-button radius  color="primary" type="filled" icon-pack="feather" @click="showpop" icon="icon-user-plus"></vs-button>
 
  </div>
   
</template>

<script>
import axios from '@/axios'
    export default {
        name: 'CellRendererActions',
        data() {
          return {
            autfo:true,
            password:'',
            confirmpass:'',
            pass:'',
            popupActive2: false,
            popupActive3: false
          }
         },
        methods: {

          popupA(){
            alert('b');
          },
          editRecord() {
            this.$router.push("/apps/user/user-edit/" + 268).catch(() => {})

            /*
              Below line will be for actual product
              Currently it's commented due to demo purpose - Above url is for demo purpose

              this.$router.push("/apps/user/user-edit/" + this.params.data.id).catch(() => {})
            */
          },
          keyHandler(){
              alert('h');
          },
          confirmlogin() {
       
            this.$vs.dialog({
              type: 'confirm',
              color: 'primary',
              title: `Confirm Login`,
              text: `You are about to Login ${this.params.data.companyname}`,
              input:`this`,
              accept: this.loginRecored,
              acceptText: "Login"
            })
      
          },

          loginRecored() {
            
            alert(document.getElementById(this.params.data.email).value+" fg")

            /* Below two lines are just for demo purpose */
              if(this.params.data.email ==="" || this.password==="") return this.showDeleteSuccess();
          
                  axios.post("user/login/",{email:this.params.data.email,password:this.password}).then((response) => {
               
                 var token=JSON.stringify(response.data);

                var myObj = JSON.parse(token);
      
       sessionStorage.setItem("reload","false");
               //  this.$vs.loading();
                if(myObj[0]!=null){
                 //  this.$vs.loading.close() ;
                  sessionStorage.setItem('user',token);
           if(JSON.parse(token)[0].type+""=="user")
               {var myval= {companyname: JSON.parse(token)[0].companyname,
               rolename:JSON.parse(token)[0].rolename}  
                    axios.post("/user/getUserRole",myval).then((response) => {
                sessionStorage.setItem('role',response.data);
                alert(JSON.stringify(response.data))
                 window.location.href = '/dashboard/analytics'
             }).catch((error) => {
                 alert(error)
             })
               }
               else
               {sessionStorage.setItem('role',"complete");
                window.location.href = '/dashboard/analytics/'}
               
                }else{
                    this.showDeleteSuccess();
                }
             }).catch((error) => {
                 alert(error)
             });
          

            /* UnComment below lines for enabling true flow if deleting user */
            // this.$store.dispatch("userManagement/removeRecord", this.params.data.id)
            //   .then(()   => { this.showDeleteSuccess() })
            //   .catch(err => { console.error(err)       })
          },
          forgetpassword(){
         
               if(this.confirmpass =="" && this.pass=="") return this.showCompareError();
               if(this.confirmpass !=this.pass) return this.showCompareError();
       axios.post("/forgetpassword/",{email:this.params.data.email,password:this.pass})
       .then((response) => {      
              var token=JSON.stringify(response.data);
                  var myObj = JSON.parse(token);
               
              //  this.$vs.loading();
               if(myObj[0]!=null){
                  this.PasswordUpdate();
                  this.popupActive3=false;
              
               }else{
                     this.$vs.notify({
                        title: 'Error',
                        text: 'Enter the  correct password..',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'danger'
                       });
               }
            }).catch((error) => {
                alert(error)
            });
          

          },
          showDeleteSuccess() {
             this.$vs.notify({
                        title: 'Error',
                        text: 'Enter the  correct password..',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'danger'
                         });
          }
          ,showCompareError() {
             this.$vs.notify({
                        title: 'Error',
                        text: 'password Is not Match..',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'danger'
                       });
          },
          PasswordUpdate() {
              this.$vs.notify({
                        title: 'Success',
                        text: 'Password Update successfully..',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'success'
                       });
          },
          async shortfunctionsecond(g) {
   if(g=="passwordinput"+this.params.data.email)
  {await this.longfunctionfirst(g);
  
  document.getElementById(this.params.data.email).focus()
  }
  


},
  longfunctionfirst(t) {
        
       return new Promise(resolve => {
   if(t=="passwordinput"+this.params.data.email)
    {  this.popupActive2=true
    resolve('resolved');
    }
  
  
     
  
  });
       
   
},
showpop(){
  alert(this.params.data.email)
  this.shortfunctionsecond("passwordinput"+this.params.data.email)
}
        },
     
          mounted() {
            let that=this;
            
             document.body.addEventListener('keyup', function(event) {
            // If  ESC key was pressed...
            if (event.keyCode === 27) {
              that.popupActive2=false;
              that.popupActive3=false;
             
            }
        });
    },
       
       
    }
</script>
