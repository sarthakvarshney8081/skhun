
<template>
  <div id="user-edit-tab-info">
    <vx-card class="mt-base" no-shadow card-border>
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="icon-printer" class="mr-2" />
            <span class="font-medium text-lg leading-none">Role</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">
          <tr>
            <td class="px-3 py-2">
              <vs-input
                class="w-full"
                icon-pack="feather"
                icon="icon-calendar"
                label-placeholder="Enter Role Name"
                v-model="RoleName"
                id="RoleName"
              />

              <vs-input
                class="w-full"
                onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))"
                icon-pack="feather"
                icon="icon-calendar"
                type="number"
                label-placeholder="Enter Security Days"
                v-model="securitydays"
                min="0"
              />
            </td>
          </tr>
        </table>
      </div>
    </vx-card>

    <!-- Permissions -->
    <vx-card class="mt-base" no-shadow card-border>
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="LockIcon" class="mr-2" />
            <span class="font-medium text-lg leading-none">Permissions</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">
          <tr>
            <th
              class="font-semibold text-base text-left px-3 py-2"
              v-for="heading in ['Module', 'Add', 'Modify', 'Delete']"
              :key="heading"
            >{{ heading }}</th>
          </tr>
          <tr v-for="(role,i) in permissions" :key="role">
            <td class="px-3 py-2">{{ role.rolename }}</td>
            <td v-for=" (index,y) in role.roletype" class="px-3 py-2" :key="index+y">
              <vs-checkbox :id="'c_'+ i + y" v-model="role.roletype[y]" />
              <!-- <input type="checkbox" :placeholder="'c_' + i+ y" :id="'c_'+ i +y"  /> -->
            </td>
          </tr>
        </table>
      </div>
    </vx-card>

    <vx-card class="mt-base" no-shadow card-border>
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="LockIcon" class="mr-2" />
            <span class="font-medium text-lg leading-none">Reports</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">
          <tr>
            <td class="px-3 py-2" v-for="(repo,ind) in  reports" :key="repo+ind">
              <p>{{ind}}</p>
              <vs-checkbox v-model="reports[ind]" :id="'r_'+ind"></vs-checkbox>
              <!-- <input  :placeholder="'r_' + p" :id="'c_'+ i +y"  /> -->
            </td>
          </tr>
        </table>
      </div>
    </vx-card>
    <vx-card class="mt-base" no-shadow card-border>
      <vs-table
        :data="requestedList"
        v-model="selected"
        @selected="handleSelected"
        @keyup.down="moveDown"
        @keyup.up="moveUp"
        search
      >
        <template slot="header">
          <h2>Roles List</h2>
        </template>
        <template slot="thead">
          <vs-th align="center">Role User</vs-th>
          <vs-th>Actions</vs-th>
        </template>

        <template slot-scope="{data}">
          <vs-tr
            :state="indextr == number ?'success':null"
            :key="indextr"
            v-for="(tr, indextr) in data"
          >
            <vs-td :data="data[indextr].roleuser">
              {{data[indextr].roleuser}}
              <vs-button
                title="Click to modify"
                radius
                color="primary"
                type="flat"
                icon="expand_more"
              ></vs-button>

              <!-- Edit slot for the data shown -->

              <template slot="edit">
                <vs-tr>
                  <vs-td>
                    <vs-input
                      v-model="tr.roleuser"
                      label="RoleUser"
                      class="inputx"
                      placeholder="roleuser"
                      v-on:keyup.enter="modifyRoles(indextr)"
                    />
                  </vs-td>
                  <vs-td>
                    <vs-button @click="modifyRoles(indextr)" title="Modify Role">Modify Roles</vs-button>
                  </vs-td>
                </vs-tr>
              </template>
            </vs-td>

            <vs-td>
              <vs-tr>
                <vs-td>
                  <vs-button @click="showDetails(indextr)" title="Show Details">Show Details</vs-button>
                </vs-td>
                <vs-td>
                  <vs-button title="Delete" color="danger">Delete</vs-button>
                </vs-td>
              </vs-tr>
            </vs-td>
          </vs-tr>
        </template>
      </vs-table>

      <vs-button @click="number++"></vs-button>
    </vx-card>

    <!-- Save & Reset Button -->
    <div class="vx-row">
      <div class="vx-col w-full">
        <div class="mt-8 flex flex-wrap items-center justify-end">
          <vs-button class="ml-auto mt-2" @click="save_changes">Save Changes</vs-button>
          <vs-button class="ml-4 mt-2" type="border" color="warning" @click="reset_data">Reset</vs-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>

<script>
import moduleUserManagement from "@/store/user-management/moduleUserManagement.js";

import vSelect from "vue-select";
import axios from "axios";

export default {
  components: {
    vSelect
  },
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      RoleName: "",
      securitydays: 0,
      data_local: JSON.parse(JSON.stringify(this.data)),

      Rolebase: [],
      requestedList: [],
      deletedList: [],
      unmodifiedList: [],

      Roleword: {
        roleuser: this.RoleName,
        securitydays: this.securitydays + "",
        rolename: []
      },
      employees: {
        permission: this.permissions,
        report: []
      },

      statusOptions: [
        { label: "Active", value: "active" },
        { label: "Blocked", value: "blocked" },
        { label: "Deactivated", value: "deactivated" }
      ],
      roleOptions: [
        { label: "Admin", value: "admin" },
        { label: "User", value: "user" },
        { label: "Staff", value: "staff" }
      ],
      permissions: [
        {
          rolename: "Cash",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Journal",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Bank",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Sale",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Purchase",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Inventory",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "TDS VCH",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Leadger A/C",
          roletype: { Add: false, modify: false, delete: false }
        },
        {
          rolename: "Stock Item",
          roletype: { Add: false, modify: false, delete: false }
        }
      ],
      reports: {
        Cash_Book: false,
        Day_Book: false,
        Sale_Book: false,
        Pur_Book: false,
        Bank_Book: false,
        Copy_of_AC: false,
        Trial_Balance: false,
        Balance_Sheet: false,
        Bill_Printing: false,
        Stock_Report: false,
        Income_Tax_Reports: false,
        Ledger: false,
        Cash_Summary: false,
        Sale_Pur_Summary: false,
        Outstanding: false,
        Intt_Statement: false,
        GST_Return: false,
        TCS_Reports: false,
        TDS_Reports: false,
        Trf_Accounts: false
      }
    };
  },

  methods: {
    modifyRoles(indextr) {
     
   // this.unmodifiedList = this.requestedList;   
         // alert(this.unmodifiedList[0].roleuser + this.requestedList[0].roleuser)
      var user = sessionStorage.getItem("user");
      sessionStorage.setItem("reload","false");
      var companyName = JSON.parse(user)[0].companyname;

      alert(companyName);

      var n = {
        roleuserToModify: this.unmodifiedList[indextr].roleuser ,
        roleuserNewValue: this.requestedList[indextr].roleuser,
        companyname: companyName
      };
      alert(n.roleuserToModify + " is sent to be modified to: " + n.roleuserNewValue );
      axios
        .post("http://localhost:2000/ModifyUserRole", n)
        .then(response => {
          this.Savenotify();
          alert(JSON.stringify(response.data));
          this.$forceUpdate();
        })
        .catch(error => {
          alert(error);
        });
      alert("delete modification done.");
      window.location.reload();

    },

    deleteRoles(indextr) {
      this.deletedList.push(this.requestedList[indextr].roleuser);
      alert(this.deletedList);
      var user = sessionStorage.getItem("user");
      sessionStorage.setItem("reload","false");
      var companyName = JSON.parse(user)[0].companyname;

      alert(companyName);

      var n = {
        roleuser: this.deletedList,
        companyname: companyName
      };
      alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/DeleteUserRole", n)
        .then(response => {
          this.Savenotify();
          alert(JSON.stringify(response.data));
          this.$forceUpdate();
        })
        .catch(error => {
          alert(error);
        });
      alert("delete req done.");

      // var finalObj =this.permissions.concat(this.reports);
      // alert(JSON.stringify(finalObj));
      // alert(finalObj);
      //  this.data_local = JSON.parse(JSON.stringify(this.permissions))
      this.deletedList = [];
      window.location.reload();
    },
    showDetails(indextr) {
      var user = sessionStorage.getItem("user");
sessionStorage.setItem("reload","false");
      var company = { companyname: JSON.parse(user)[0].companyname };
      // axios
      //   .post("/user/ViewRoleNames", company)
      //   .then(response => {
      //     var data = JSON.stringify(response.data);

      //     this.requestedList = JSON.parse(data);
      //     this.unmodifiedList = this.requestedList;
      //     alert(data);
      //   })
      //   .catch(error => {
      //     alert(error);
      //   });
      

      let gotPermissions = this.requestedList[indextr].rolename.permission;

      alert(
        JSON.stringify(this.permissions[0].roletype) +
          " " +
          gotPermissions[0].roletype.delete
      );
      document.getElementById("RoleName").focus();

      for (let i = 0; i < gotPermissions.length; i++) {
        // let add = "c_" + i + 0;
        // let mod = "c_" + i + 1;
        // let del = "c_" + i + 2;

        // document.getElementById(add).checked = gotPermissions[i].roletype.Add;

        // document.getElementById(mod).checked =
        //   gotPermissions[i].roletype.modify;

        // document.getElementById(del).checked =
        //   gotPermissions[i].roletype.delete;

        this.permissions[i].roletype.Add = gotPermissions[i].roletype.Add;
        this.permissions[i].roletype.modify = gotPermissions[i].roletype.modify;
        this.permissions[i].roletype.delete = gotPermissions[i].roletype.delete;
      }
      var gotReport = this.requestedList[indextr].rolename.report;
      alert(" hey");

      let n = 0;
      var i = 0;
      this.reports.Cash_Book = true;
      for (let x in this.reports) {
        this.reports[x] = gotReport[x];
      }
      this.RoleName = this.requestedList[indextr].roleuser;
      this.securitydays = this.requestedList[indextr].securitydays;

      //Clicked data populated !
    },

    capitalize(str) {
      return str.slice(0, 1).toUpperCase() + str.slice(1, str.length);
    },
    reset_data() {
      if (!this.validateForm) return;

      // Here will go your API call for updating data
      // You can get data in "this.data_local"
    },
    save_changes() {
      var user = sessionStorage.getItem("user");
      sessionStorage.setItem("reload","false");
      var companyName = JSON.parse(user)[0].companyname;

      alert(companyName);
      if (!this.RoleName) return this.Rolenotify();
      this.employees.permission = this.permissions;
      this.employees.report = this.reports;
      this.Roleword.rolename = this.employees;
      this.Roleword.roleuser = this.RoleName;
      this.Roleword.securitydays = this.securitydays;
      if (this.Roleword.securitydays + "" == "undefined")
        this.Roleword.securitydays = "0";
      this.Rolebase = '{"userRoles":[' + JSON.stringify(this.Roleword) + "]}";
      var n = {
        myval: JSON.parse(this.Rolebase),
        companyname: companyName,
        
      };
      alert(JSON.stringify(n));
      axios
        .post("http://localhost:2000/UserRoleDetails", n)
        .then(response => {
          this.Savenotify();
          alert(JSON.stringify(response.data));
        })
        .catch(error => {
          alert(error);
        });
      alert("sa");

      // var finalObj =this.permissions.concat(this.reports);
      // alert(JSON.stringify(finalObj));
      // alert(finalObj);
      //  this.data_local = JSON.parse(JSON.stringify(this.permissions))
    },
    Rolenotify() {
      this.$vs.notify({
        title: "Error",
        text: "Enter Role Name",
        iconPack: "feather",
        icon: "icon-alert-circle",
        color: "danger"
      });
    },
    Savenotify() {
      this.$vs.notify({
        title: "Success",
        text: "Create Role Successfully",
        iconPack: "feather",
        icon: "icon-alert-circle",
        color: "success"
      });
    }
  },
  created() {
    var user = sessionStorage.getItem("user");
    sessionStorage.setItem("reload","false");

    var company = { companyname: JSON.parse(user)[0].companyname };
    axios
      .post("/user/ViewRoleNames", company)
      .then(response => {
        var data = JSON.stringify(response.data);

        this.requestedList = JSON.parse(data);
           this.unmodifiedList = JSON.parse(data);
        alert(data);
      })
      .catch(error => {
        alert(error);
      });

    for (let i = 0; i < this.permissions.length; i++) {
      let add = "c_" + i + 0;
      let mod = "c_" + i + 1;
      let del = "c_" + i + 2;

      document.getElementById(add).checked = false;

      document.getElementById(mod).checked = false;

      document.getElementById(del).checked = false;
    }
 
  }
};
</script>
