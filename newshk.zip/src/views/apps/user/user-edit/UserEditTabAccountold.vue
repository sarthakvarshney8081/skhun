
<template>
  <div id="user-edit-tab-info">
     <vx-card class="mt-base" no-shadow card-border>
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="icon-printer" class="mr-2" />
            <span class="font-medium text-lg leading-none">Role</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">
          <tr>   
            <td class="px-3 py-2">    
            <vs-input class="w-full"  icon-pack="feather" icon="icon-calendar" label-placeholder="Enter Role Name" v-model="RoleName" />   

            <vs-input class="w-full"  onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" icon-pack="feather" icon="icon-calendar" type="number" label-placeholder="Enter Security Days" v-model="securitydays" min="0"  />   
            </td>
          </tr>
        </table>
      </div>
    </vx-card>

    <!-- Permissions -->
    <vx-card class="mt-base" no-shadow card-border>

      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="LockIcon" class="mr-2" />
            <span class="font-medium text-lg leading-none">Permissions</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">
          <tr>
            <th class="font-semibold text-base text-left px-3 py-2" v-for="heading in ['Module', 'Add', 'Modify', 'Delete']" :key="heading">{{ heading }}</th>
          </tr>
          <tr v-for="(role) in permissions" :key="role">
            <td class="px-3 py-2">{{ role.rolename }}</td>
            <td v-for="(rolet, index) in role.roletype" class="px-3 py-2" :key="rolet+index">
              <vs-checkbox v-model="role.roletype[index]" />
            </td>
          </tr>
        </table>
      </div>

    </vx-card>

         <vx-card class="mt-base" no-shadow card-border>

      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="flex items-end px-3">
            <feather-icon svgClasses="w-6 h-6" icon="LockIcon" class="mr-2" />
            <span class="font-medium text-lg leading-none">Reports</span>
          </div>
          <vs-divider />
        </div>
      </div>

      <div class="block overflow-x-auto">
        <table class="w-full">     
          <tr>
            <td class="px-3 py-2" v-for="(repo,ind) in  reports" :key="repo+ind">                          
            <p>{{ind}}</p>
            <vs-checkbox v-model="reports[ind]">   </vs-checkbox>
             </td>
          </tr>
        </table>
      </div>

    </vx-card>

    <!-- Save & Reset Button -->
    <div class="vx-row">
      <div class="vx-col w-full">
        <div class="mt-8 flex flex-wrap items-center justify-end">
          <vs-button class="ml-auto mt-2" @click="save_changes" >Save Changes</vs-button>
          <vs-button class="ml-4 mt-2" type="border" color="warning" @click="reset_data">Reset</vs-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script src="https://unpkg.com/axios/dist/axios.min.js"></script>

<script>

import moduleUserManagement from '@/store/user-management/moduleUserManagement.js'

import vSelect from 'vue-select'
import axios from 'axios'


export default {
  components: {
    vSelect
  },
  props: {
    data: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
     RoleName:"",
     securitydays:0,
      data_local: JSON.parse(JSON.stringify(this.data)),
      
        Rolebase:[],
      
      Roleword:
          {    
            roleuser:this.RoleName,
            securitydays:this.securitydays+"",
            rolename:[],
           
             
           }
          ,
      employees : {
                         permission:this.permissions,
                         report:[]

              }, 

      statusOptions: [
        { label: "Active",  value: "active" },
        { label: "Blocked",  value: "blocked" },
        { label: "Deactivated",  value: "deactivated" },
      ],
      roleOptions: [
        { label: "Admin",  value: "admin" },
        { label: "User",  value: "user" },
        { label: "Staff",  value: "staff" },
      ],
        permissions:[
          {rolename:"Cash",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Journal",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Bank",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Sale",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Purchase",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Inventory",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"TDS VCH",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Leadger A/C",roletype:{Add:false,modify:false,delete:false}},
          {rolename:"Stock Item",roletype:{Add:false,modify:false,delete:false}}
        ],
        reports:{
          Cash_Book:false,Day_Book:false,Sale_Book:false,Pur_Book:false,Bank_Book:false,Copy_of_AC:false,Trial_Balance:false,
          Balance_Sheet:false,Bill_Printing:false,Stock_Report:false,Income_Tax_Reports:false,Ledger:false,Cash_Summary:false,Sale_Pur_Summary:false,
          Outstanding:false,Intt_Statement:false,GST_Return:false,TCS_Reports:false,TDS_Reports:false,Trf_Accounts:false

        }

        
    }
  },
 
  methods: {
    capitalize(str) {
      return str.slice(0,1).toUpperCase() + str.slice(1,str.length)
    },
    reset_data() {
      if(!this.validateForm) return

      // Here will go your API call for updating data
      // You can get data in "this.data_local"

    },
    save_changes() {
          var user=sessionStorage.getItem('user');
          sessionStorage.setItem("reload","false");
var companyName=JSON.parse(user)[0].companyname
alert(companyName);
 alert(this.securitydays+"")
              if(!this.RoleName) return this.Rolenotify();
          this.employees.permission=this.permissions;
          this.employees.report=this.reports;
          this.Roleword.rolename=this.employees;
          this.Roleword.roleuser=this.RoleName;
          this.Roleword.securitydays=this.securitydays
         
          if(this.Roleword.securitydays+""=="undefined")
          this.Roleword.securitydays="0"
        
          this.Rolebase="{\"userRoles\":["+JSON.stringify(this.Roleword)+"]}";
          var n={myval:JSON.parse(this.Rolebase),
          companyname:companyName};
          alert(JSON.stringify(n));
            axios.post("http://localhost:2000/UserRoleDetails",n).then((response) => {
                this.Savenotify();
               alert(JSON.stringify(response.data))
            }).catch((error) => {
                alert(error)
            })
            alert("sa");
          
      // var finalObj =this.permissions.concat(this.reports);
      // alert(JSON.stringify(finalObj));
      // alert(finalObj);
 //  this.data_local = JSON.parse(JSON.stringify(this.permissions))
    },
     Rolenotify() {
          this.$vs.notify({
                        title: 'Error',
                        text: 'Enter Role Name',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'danger'
                       });
     
    },
    Savenotify() {
          this.$vs.notify({
                        title: 'Success',
                        text: 'Create Role Successfully',
                        iconPack: 'feather',
                        icon: 'icon-alert-circle',
                        color: 'success'
                       });
     
    }
  },
}
</script>
